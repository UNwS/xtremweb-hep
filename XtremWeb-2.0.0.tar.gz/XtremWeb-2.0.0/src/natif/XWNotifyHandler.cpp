
#include <windows.h>
#include <jni.h>
#include "XWNotifyHandler.h"
#include "XWNotifyThread.h"


#define WM_DESKTOPINDICATOR_CLICK (WM_USER+1)
#define MNU_EXIT                  (WM_USER+2)
#define MNU_STATS                 (WM_USER+3)
#define MNU_CONFIG                (WM_USER+4)
#define MNU_ABOUT                 (WM_USER+5)
#define MNU_EXIT_AFTER            (WM_USER+6)



XWNotifyHandler *XWNotifyHandler::extract( JNIEnv *env, jobject object )
{
  // Get field ID			
  jfieldID l_handlerId = env->GetFieldID( env->GetObjectClass( object ), "_handler", "I" );

	// Get field
  XWNotifyHandler *l_handler = (XWNotifyHandler *) env->GetIntField( object, l_handlerId );

  return l_handler;
}


XWNotifyHandler::XWNotifyHandler( JNIEnv *env, jobject object, jint image, const char *tooltip )
{
  m_window = NULL;

  m_icon = (HICON) image;

  // Copy string
  m_tooltip = strdup( tooltip );

  // Reference object
  m_object = env->NewGlobalRef( object );

  // Get method ID
  m_stats = 
    env->GetMethodID(env->GetObjectClass(m_object), "statistics", "()V");

  // Get method ID
  m_config = 
    env->GetMethodID(env->GetObjectClass(m_object), "config", "()V");

  // Get method ID
  m_exitApplication = 
    env->GetMethodID(env->GetObjectClass(m_object), "exitApplication", "()V");

  /*
		m_exitAfterTransfers = 
		env->GetMethodID(env->GetObjectClass(m_object), "exitAfterTransfers", "()V");
  */

  // Get method ID
  m_aboutWindow = 
    env->GetMethodID(env->GetObjectClass(m_object), "showAboutWindow", "()V");

  // Get field ID
  jfieldID l_handlerId = env->GetFieldID( env->GetObjectClass( m_object ), "_handler", "I" );

  // Set field
  env->SetIntField( m_object, l_handlerId, (jint) this );
}


XWNotifyHandler::~XWNotifyHandler()
{

  // Get field ID
  jfieldID l_handlerId = 
    g_XWNotifyThread.m_env->GetFieldID( g_XWNotifyThread.m_env->GetObjectClass( m_object ), "_handler", "I" );

  // Set field
  g_XWNotifyThread.m_env->SetIntField( m_object, l_handlerId, 0 );


  // Destroy window
  DestroyWindow( m_window );

  // Free string
  if( m_tooltip )
    delete m_tooltip;


  // Release our reference
  g_XWNotifyThread.m_env->DeleteGlobalRef( m_object );
	
}


void XWNotifyHandler::enable( JNIEnv *env )
{
  g_XWNotifyThread.MakeSureThreadIsUp( env );
  while( !PostThreadMessage( g_XWNotifyThread, WM_DESKTOPINDICATOR, enableCode, (LPARAM) this ) )
    Sleep( 0 );
}


void XWNotifyHandler::doEnable()
{
  // Register window class
  WNDCLASSEX l_Class;
  l_Class.cbSize = sizeof( l_Class );
  l_Class.style = 0;
  l_Class.lpszClassName = TEXT( "XWNotifyHandlerClass" );
  l_Class.lpfnWndProc = WndProc;
  l_Class.hbrBackground = NULL;
  l_Class.hCursor = NULL;
  l_Class.hIcon = NULL;
  l_Class.hIconSm = NULL;
  l_Class.lpszMenuName = NULL;
  l_Class.cbClsExtra = 0;
  l_Class.cbWndExtra = 0;
  l_Class.hInstance = NULL;	//CB enables this code to work in WIN 98

  if( !RegisterClassEx( &l_Class ) )
    return;

	// Create window
  m_window = CreateWindow
    (
     TEXT( "XWNotifyHandlerClass" ),
     TEXT( "XWNotifyHandler" ),
     WS_POPUP,
     0, 0, 0, 0,
     NULL,
     NULL,
     0,
     NULL
     );

  if( !m_window )
    return;

	// Set this pointer
  SetWindowLong( m_window, GWL_USERDATA, (LONG) this );

  // Add shell icon
  NOTIFYICONDATA m_iconData;
  m_iconData.cbSize = sizeof(NOTIFYICONDATA);
  m_iconData.uFlags = NIF_MESSAGE |  NIF_ICON | NIF_TIP;
  m_iconData.uCallbackMessage = WM_DESKTOPINDICATOR_CLICK;
  m_iconData.uID = 0;
  m_iconData.hWnd = m_window;
  m_iconData.hIcon = m_icon;
  strcpy( m_iconData.szTip, m_tooltip );

  Shell_NotifyIcon( NIM_ADD, &m_iconData );
}


void XWNotifyHandler::update( jint image, const char *tooltip )
{
  m_icon = (HICON) image;

  // Free string
  if( m_tooltip )
    delete m_tooltip;

  // Copy string
  m_tooltip = strdup( tooltip );

  PostThreadMessage( g_XWNotifyThread, WM_DESKTOPINDICATOR, updateCode, (LPARAM) this );
}


void XWNotifyHandler::doUpdate()
{
  // Modify shell icon
  NOTIFYICONDATA m_iconData;
  m_iconData.cbSize = sizeof(NOTIFYICONDATA);
  m_iconData.uFlags = NIF_MESSAGE |  NIF_ICON | NIF_TIP;
  m_iconData.uCallbackMessage = WM_DESKTOPINDICATOR_CLICK;
  m_iconData.uID = 0;
  m_iconData.hWnd = m_window;
  m_iconData.hIcon = m_icon;
  strcpy( m_iconData.szTip, m_tooltip );

  Shell_NotifyIcon( NIM_DELETE, &m_iconData );
  Shell_NotifyIcon( NIM_ADD, &m_iconData );
}

void XWNotifyHandler::doHide()
{
  // Modify shell icon
  NOTIFYICONDATA m_iconData;
  m_iconData.cbSize = sizeof( m_iconData );
  m_iconData.uID = 0;
  m_iconData.hWnd = m_window;
  m_iconData.hIcon = m_icon;
  strcpy( m_iconData.szTip, m_tooltip );
  Shell_NotifyIcon( NIM_DELETE, &m_iconData );
}

void XWNotifyHandler::hide()
{
  PostThreadMessage( g_XWNotifyThread, WM_DESKTOPINDICATOR, hideCode, (LPARAM) this );
}



void XWNotifyHandler::disable()
{
  removeNotify();
  PostThreadMessage( g_XWNotifyThread, WM_DESKTOPINDICATOR, disableCode, (LPARAM) this );
}


void XWNotifyHandler::statistics() {
  g_XWNotifyThread.m_env->CallVoidMethod( m_object, m_stats );
}

void XWNotifyHandler::config()
{
  g_XWNotifyThread.m_env->CallVoidMethod( m_object, m_config );
}

void XWNotifyHandler::exitApplication()
{
  g_XWNotifyThread.m_env->CallVoidMethod( m_object, m_exitApplication );
}

void XWNotifyHandler::showAboutWindow()
{
  g_XWNotifyThread.m_env->CallVoidMethod( m_object, m_aboutWindow );
}

/*
	void XWNotifyHandler::exitAfterTransfers()
	{
  g_XWNotifyThread.m_env->CallVoidMethod( m_object, m_exitAfterTransfers );
	}
*/

void XWNotifyHandler::removeNotify()
{
  // Delete shell icon
  NOTIFYICONDATA m_iconData;
  m_iconData.cbSize = sizeof( m_iconData );
  m_iconData.uID = 0;
  m_iconData.hWnd = m_window;

  Shell_NotifyIcon( NIM_DELETE, &m_iconData );
}
 


LRESULT CALLBACK XWNotifyHandler::WndProc( HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam )
{
  // Check for our special notification message
  if( ( uMessage != WM_DESKTOPINDICATOR_CLICK ) ) 
    {
      return DefWindowProc( hWnd, uMessage, wParam, lParam );
    }

  XWNotifyHandler *l_this = (XWNotifyHandler *) GetWindowLong( hWnd, GWL_USERDATA );

  switch(lParam) {
    //case WM_LBUTTONDOWN:
    //do code
    //break;
    //return 0;
    //case WM_RBUTTONDOWN:
    //do code
    //break;
    //return 0;
    //case WM_LBUTTONUP:
    //do code
    //break;
    //return 0;
  case WM_RBUTTONUP: //Display popup menu
    HMENU hMenu;
    POINT pos;
    hMenu = CreatePopupMenu();
    AppendMenu(hMenu, MF_STRING, MNU_CONFIG,  "My &config");
    AppendMenu(hMenu, MF_STRING, MNU_STATS,  "My &stats");
    AppendMenu(hMenu, MF_STRING, MNU_ABOUT, "&About");
    AppendMenu(hMenu, MF_SEPARATOR, 0, NULL);
		//    AppendMenu(hMenu, MF_STRING, MNU_EXIT_AFTER,  "&Exit After Transfers");
    AppendMenu(hMenu, MF_STRING, MNU_EXIT,  "E&xit");
    GetCursorPos(&pos);
	  
    SetForegroundWindow(hWnd);
    switch(TrackPopupMenu(hMenu, TPM_CENTERALIGN | TPM_BOTTOMALIGN | 
													TPM_LEFTBUTTON | TPM_NONOTIFY | TPM_RETURNCMD, 
													pos.x, pos.y, 0, hWnd, NULL)) {
    case MNU_EXIT:	
      l_this->exitApplication();
      return 0;
			/*
				case MNU_EXIT_AFTER:
				l_this->exitAfterTransfers();
				return 0;
			*/
    case MNU_ABOUT:
      l_this->showAboutWindow();
      return 0;
    case MNU_STATS:
      l_this->statistics();
      return 0;
    case MNU_CONFIG:
      l_this->config();
      return 0;
    default:
      return 0;   
    }
    PostMessage(hWnd, WM_NULL, 0, 0);
	
    return 0;
			
  case WM_LBUTTONDBLCLK:
    l_this->statistics();
    return 0;

  case WM_DESTROY:			
    PostQuitMessage (0);
    return 0;  
	  
  default:
    return 0;  
  }
}
