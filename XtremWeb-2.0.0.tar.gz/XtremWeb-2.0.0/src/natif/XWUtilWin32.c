/*
 *  XWUtilWin32.c
 *  Win32 implementation of XWUtil.
 *  
 *  Created by heriard on Tue Apr 16 2002.
 *
 */

#include <windows.h>
#include "XWUtilImpl.h"
#include <sys/types.h>
#include <sys/stat.h>

/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    cd
 * Signature: (Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL 
Java_xtremweb_archdep_XWUtilImpl_cd (JNIEnv *env, jobject obj, jstring s)
{
  const char *str = (*env)->GetStringUTFChars(env, s, 0);
  SetCurrentDirectory(str);
  (*env)->ReleaseStringUTFChars(env, s, str);
  return;
}


/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    getPid
 * Signature: ()I
 */
JNIEXPORT jint JNICALL 
Java_xtremweb_archdep_XWUtilImpl_getPid(JNIEnv *env, jobject obj)
{
  return (jint)GetCurrentProcessId();
}


/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    isRunning
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL 
Java_xtremweb_archdep_XWUtilImpl_isRunning(JNIEnv *env, jobject obj, jint pid)
{
  HANDLE phandle = OpenProcess(PROCESS_QUERY_INFORMATION, 0, (DWORD)pid);
  jboolean ret = (phandle != NULL);
  if (ret) 
    CloseHandle(phandle);
  return ret;
}


/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    chmodpx
 * Signature: (Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL
Java_xtremweb_archdep_XWUtilImpl_chmodpx (JNIEnv *env, jobject o, jstring s)
{
  const char *str = (*env)->GetStringUTFChars(env, s, 0);

  chmod(str, S_IWRITE | S_IREAD | S_IEXEC );
  (*env)->ReleaseStringUTFChars(env, s, str);
  return;
}


/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    getNumProc
 * Signature: ()I
 */
JNIEXPORT jint JNICALL 
Java_xtremweb_archdep_XWUtilImpl_getNumProc (JNIEnv *env , jobject o)
{
  SYSTEM_INFO SystemInfo;

  GetSystemInfo(&SystemInfo);

  return (jint) SystemInfo.dwNumberOfProcessors;
}


/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    getSpeedProc
 * Signature: ()I
 */
JNIEXPORT jint JNICALL 
Java_xtremweb_archdep_XWUtilImpl_getSpeedProc (JNIEnv *env , jobject o)
{
  HKEY hKey;             // handle to registry key
  DWORD dwBuffer;        // bytes to allocate for buffers
  DWORD dwBufferSize;    // size of dwBuffer

  RegOpenKeyEx (HKEY_LOCAL_MACHINE,
                "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",
                0,
                KEY_READ,
                &hKey);

  dwBufferSize = sizeof(dwBuffer);

  RegQueryValueEx (hKey,
                   "~MHz",
                   NULL,
                   NULL,
                   (LPBYTE) &dwBuffer,
                   &dwBufferSize );

  RegCloseKey (hKey);

  sprintf (stderr, "\n\nCPU speed = %li\n\n", dwBuffer);

  return (jint) dwBuffer;
}


/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    getProcModel
 * Signature: ()I
 */
JNIEXPORT jstring JNICALL 
Java_xtremweb_archdep_XWUtilImpl_getProcModel (JNIEnv *env , jobject o)
{
  const char* unknown = "UNKNOWN"; // all Windows version
  const char* intel = "INTEL"; // all Windows version
  const char* mips = "MIPS"; // NT 3.51 only
  const char* alpha = "ALPHA"; // NT 4.0 and earlier
  const char* ppc = "PPC"; // NT 4.0 and earlier
  const char* ia64 = "IA64"; // Windows 64 bits only
  const char* ia32OnWin64 = "IA32WIN64"; // Windows 64 bits only
  const char* amd64 = "AMD64"; // Windows 64 bits only

  SYSTEM_INFO SystemInfo;
  GetSystemInfo(&SystemInfo);

  switch (SystemInfo.wProcessorArchitecture) {
  case PROCESSOR_ARCHITECTURE_UNKNOWN :
    return (*env)->NewStringUTF(env, unknown);
  case PROCESSOR_ARCHITECTURE_INTEL :
    return (*env)->NewStringUTF(env, intel);
  case PROCESSOR_ARCHITECTURE_MIPS :
    return (*env)->NewStringUTF(env, mips);
  case PROCESSOR_ARCHITECTURE_ALPHA :
    return (*env)->NewStringUTF(env, alpha);
  case PROCESSOR_ARCHITECTURE_PPC :
    return (*env)->NewStringUTF(env, ppc);
  case PROCESSOR_ARCHITECTURE_IA64 :
    return (*env)->NewStringUTF(env, ia64);
#ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
  case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64 :
    return (*env)->NewStringUTF(env, ia32OnWin64);
#endif
#ifdef PROCESSOR_ARCHITECTURE_AMD64
  case PROCESSOR_ARCHITECTURE_AMD64 :
    return (*env)->NewStringUTF(env, amd64);
#endif
  }

  return (*env)->NewStringUTF(env, unknown);
}


/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    getTotalMem
 * Signature: ()I
 */
JNIEXPORT jint JNICALL 
Java_xtremweb_archdep_XWUtilImpl_getTotalMem (JNIEnv *env , jobject o)
{
  MEMORYSTATUS stat;
  GlobalMemoryStatus (&stat);
  sprintf (stderr, "\n\nTotal mem = %li\n\n", stat.dwTotalPhys);
  return (jint) (stat.dwTotalPhys / 1024);
}


/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    getTotalSwap
 * Signature: ()I
 */
JNIEXPORT jint JNICALL 
Java_xtremweb_archdep_XWUtilImpl_getTotalSwap (JNIEnv *env , jobject o)
{
  MEMORYSTATUS stat;
  GlobalMemoryStatus (&stat);
  sprintf (stderr, "\n\nTotal swap = %li\n\n", stat.dwTotalVirtual);
  return (jint) (stat.dwTotalVirtual / 1024);
}

/*
 * Class:     xtremweb_archdep_XWUtilImpl
 * Method:    raz
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_xtremweb_archdep_XWUtilImpl_raz
(JNIEnv *env, jobject obj)
{
}



JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getGid
(JNIEnv *e, jobject o) {

  // getgid() is not implemented in win32
  // there should be something to do with LsaGetLogonSessionData
  //  return (jint)getgid();
  return -1;
}

JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getUid
(JNIEnv *e, jobject o) {

  // getuid() is not implemented in win32
  // there should be something to do with LsaGetLogonSessionData
  //  return (jint)getuid();
  return -1;
}

