#define IDI_XWD                       101
#define IDR_XWD                       102
#define IDQUIT		     	        1003

