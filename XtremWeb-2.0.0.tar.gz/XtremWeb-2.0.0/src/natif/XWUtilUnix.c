#include "XWUtilImpl.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>

JNIEXPORT void JNICALL
Java_xtremweb_archdep_XWUtilImpl_cd(JNIEnv *env, jobject obj, jstring s)
{
  jboolean isCopy;
  const char *str;

  if (!env || !s)
    return;

  str = (*env)->GetStringUTFChars(env, s, &isCopy);
  if (!str)
    return;

  chdir(str);

  if (isCopy == JNI_TRUE)
    (*env)->ReleaseStringUTFChars(env, s, str);

  return;
}

JNIEXPORT void JNICALL
Java_xtremweb_archdep_XWUtilImpl_chmodpx(JNIEnv *env, jobject obj, jstring s)
{
  jboolean isCopy;
  const char *str;

  if (!env || !s)
    return;

  str = (*env)->GetStringUTFChars(env, s, &isCopy);

  if (!str)
    return;

  chmod(str, S_IREAD | S_IWRITE | S_IEXEC ); 

  if (isCopy == JNI_TRUE)
    (*env)->ReleaseStringUTFChars(env, s, str);
  return;
}


JNIEXPORT jint JNICALL 
Java_xtremweb_archdep_XWUtilImpl_getPid(JNIEnv *env, jobject obj)
{
  return (jint)getpid();
}

JNIEXPORT jboolean JNICALL 
Java_xtremweb_archdep_XWUtilImpl_isRunning(JNIEnv *env, jobject obj, jint pid)
{
  if (kill (pid, SIGCONT) == 0)
    return JNI_TRUE;
  return JNI_FALSE;
}


JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getGid
  (JNIEnv *e, jobject o) {
  return (jint)getgid();
}

JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getUid
  (JNIEnv *e, jobject o) {
  return (jint)getuid();
}

