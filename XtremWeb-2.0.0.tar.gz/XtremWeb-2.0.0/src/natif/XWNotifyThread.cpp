
#include <windows.h>
#include <jni.h>
#include "XWNotifyThread.h"
#include "XWNotifyHandler.h"


XWNotifyThread g_XWNotifyThread;


XWNotifyThread::XWNotifyThread()
{
	m_env = NULL;
	m_thread = 0;
	m_vm = NULL;
	m_handlerCount = 0;
}


void XWNotifyThread::MakeSureThreadIsUp( JNIEnv *env )
{
	if( !m_thread )
	{
		// Get VM
		env->GetJavaVM( &m_vm );

		// Start "native" thread
		CreateThread
		(
			NULL,
			0,
			ThreadProc,
			this,
			0,
			&m_thread
		);
	}
}


XWNotifyThread::operator DWORD ()
{
	return m_thread;
}


DWORD WINAPI XWNotifyThread::ThreadProc( LPVOID lpParameter )
{
	XWNotifyThread *l_this = (XWNotifyThread *) lpParameter;

	// Attach the thread to the VM
	l_this->m_vm->AttachCurrentThread( (void**) &l_this->m_env, NULL );

	MSG msg;
	while( GetMessage( &msg, NULL, 0, 0 ) )
	{
		if( msg.message == WM_DESKTOPINDICATOR )
		{
			// Extract handler
			XWNotifyHandler *l_handler = (XWNotifyHandler*) msg.lParam;

			switch( msg.wParam )
			{
			case XWNotifyHandler::enableCode:
				l_this->m_handlerCount++;
				l_handler->doEnable();
				break;

			case XWNotifyHandler::updateCode:
				l_handler->doUpdate();
				break;

			case XWNotifyHandler::hideCode:
				l_handler->doHide();
				break;

			case XWNotifyHandler::disableCode:
				// Destroy it!

				delete l_handler;

				// No more handlers?
				if( !--l_this->m_handlerCount )
				{
					
					l_this->m_thread = 0;
					// Detach thread from VM
					l_this->m_vm->DetachCurrentThread();

					// Time to die
					ExitThread( 0 );
				}

				
				break;
			}
		}
		else
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
	}

	// Detach thread from VM
	l_this->m_vm->DetachCurrentThread();
	return 0;
}
