
#ifndef __XWNotifyImages_h__
#define __XWNotifyImages_h__


class XWNotifyImages
{
public:

    jint add( jint resourceid );    //  loads icon from this DLL (DVB19Oct99)
	jint add( const char *filename );
	void remove( jint handle );
};

extern XWNotifyImages g_XWNotifyImages;


#endif
