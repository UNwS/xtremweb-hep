/*
 *  XWUtilFreeBSD.c
 *  FreeBSD implementation of XWUtil 
 *
 *  Quick and dirty,  I don't know anything about freebsd :(
 *  Created by fedak based on the MacOSX from heriard on March 2004.
 *
 */

#include "XWUtilImpl.h"
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/sysctl.h>



static int hw_ncpu[2]           = { CTL_HW, HW_NCPU     };
//does not exist on freebsd
//static int hw_cpu_freq[2]     = { CTL_HW, HW_CPU_FREQ };
static int hw_physmem[2]        = { CTL_HW, HW_PHYSMEM  };

int int_sysctl (int * mib, unsigned int miblen)
{
    int n, err;
    size_t sz =sizeof(int);
    err = sysctl (mib, miblen, &n, &sz, NULL, 0);
    if (err < 0) perror("sysctl");
    return (err < 0 ? err : n);
}

JNIEXPORT jint JNICALL
Java_xtremweb_archdep_XWUtilImpl_getNumProc(JNIEnv *env, jobject obj)
{
    return (jint) int_sysctl (hw_ncpu, 2);
} 

JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getSpeedProc
(JNIEnv * env, jobject obj)
{
 return (jint) 0;
 //   return (jint) int_sysctl (hw_cpu_freq, 2);
}

JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getTotalMem
(JNIEnv * env, jobject obj)
{
    return (jint) int_sysctl (hw_physmem, 2);
}

JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getTotalSwap
(JNIEnv * env, jobject obj) {
    /* don't know if we can get it under FreeBSD */
    return (jint) 0;
}

/*
 * look at hostinfo source for more infos:
 * http://www.opensource.apple.com
 *                   /cgi-bin/registered/cvs/src/live/system_cmds/hostinfo.tproj/hostinfo.c
 */
JNIEXPORT jstring JNICALL Java_xtremweb_archdep_XWUtilImpl_getProcModel
(JNIEnv * env, jobject obj) {
    return (*env)->NewStringUTF(env, "une brouette sous FreeBSD");    
}


JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getGid
  (JNIEnv *e, jobject o) {
  return (jint)getgid();
}

JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getUid
  (JNIEnv *e, jobject o) {
  return (jint)getuid();
}
