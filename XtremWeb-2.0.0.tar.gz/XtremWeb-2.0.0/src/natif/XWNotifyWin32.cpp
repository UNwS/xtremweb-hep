#include <windows.h>
#include "XWNotifyImpl.h"
#include "XWNotifyHandler.h"
#include "XWNotifyImages.h"
#include "XWNotifyRes.h"


extern HINSTANCE g_instance;

extern "C"
/*
 * Class:     XWNotify
 * Method:    nativeDisable
 * Signature: ()V
 */
JNIEXPORT void JNICALL 
Java_xtremweb_archdep_XWNotifyImpl_nativeDisable (JNIEnv *env, jobject object)
{
  // Get handler
  XWNotifyHandler *l_handler = XWNotifyHandler::extract( env, object );

  // Disable it
  if( l_handler )
    l_handler->disable();
}


extern "C"
/*
 * Class:     XWNotify
 * Method:    nativeEnable
 * Signature: (ILjava/lang/String;)V
 */
//Java_com_eii_tooltray_XWNotify_activate
JNIEXPORT void JNICALL
Java_xtremweb_archdep_XWNotifyImpl_nativeEnable (JNIEnv *env,
																								 jobject object,
																								 jint image,
																								 jstring tooltip)
{
  jboolean l_IsCopy;

  // Get Java string
  const char *l_tooltip = env->GetStringUTFChars( tooltip, &l_IsCopy );

  // Get handler
  XWNotifyHandler *l_handler = XWNotifyHandler::extract( env, object );

  if( l_handler ) 
    {
      // Already exists, so update it
      l_handler->update( image, l_tooltip );
      
    }
  else
    {
      // Create our handler
      l_handler = new XWNotifyHandler( env, object, image, l_tooltip );
      
      // Enable it
      if( l_handler )
				l_handler->enable( env );
    }
  
  // Release Java string
  env->ReleaseStringUTFChars( tooltip, l_tooltip );
}


extern "C"
/*
 * Class:     XWNotify
 * Method:    nativeFreeImage
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_xtremweb_archdep_XWNotifyImpl_nativeFreeImage
(JNIEnv *env, jclass, jint image)
{
  g_XWNotifyImages.remove( image );
}



extern "C"
/*
 * Class:     XWNotify
 * Method:    nativeLoadImageFromResource
 * Signature: (Ljava/lang/int;)I
 */
JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWNotifyImpl_nativeLoadImageFromResource
(JNIEnv *env, jclass, jint resourceid)
{
  //  DVB19Oct99 - use resource rather than external file
  jint image = g_XWNotifyImages.add( resourceid );       

  return image;
}


extern "C"
/*
 * Class:     XWNotify
 * Method:    nativeHide
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_xtremweb_archdep_XWNotifyImpl_nativeHide
(JNIEnv *env, jobject object)
{
  // Get handler
  XWNotifyHandler *l_handler = XWNotifyHandler::extract( env, object );
  
  if( l_handler )
    {
      l_handler->hide();
    }	
}


extern "C"
/*
 * Class:     XWNotify
 * Method:    nativeLoadImage
 * Signature: (Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWNotifyImpl_nativeLoadImage
(JNIEnv *env, jclass, jstring filename)
{
  jboolean l_IsCopy;
  
  // Get Java string
  const char *l_filename = env->GetStringUTFChars( filename, &l_IsCopy );
  
  jint image = g_XWNotifyImages.add( l_filename );
  
  // Release Java string
  env->ReleaseStringUTFChars( filename, l_filename );
  
  return image;
}
