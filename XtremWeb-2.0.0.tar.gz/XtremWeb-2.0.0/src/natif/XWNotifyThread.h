
#ifndef __XWNotifyThread_h__
#define __XWNotifyThread_h__


class XWNotifyThread
{
public:

	XWNotifyThread();

	void MakeSureThreadIsUp( JNIEnv *env );

	JNIEnv *m_env;

	operator DWORD ();

	static DWORD WINAPI ThreadProc( LPVOID lpParameter );
private:

	DWORD m_thread;
	JavaVM *m_vm;
	int m_handlerCount;

//	static DWORD WINAPI ThreadProc( LPVOID lpParameter );
};

extern XWNotifyThread g_XWNotifyThread;


#define WM_DESKTOPINDICATOR (WM_USER)


#endif
