/*
 *  XWUtilMacOSX.c
 *  MacOSX implementation of XWUtil 
 *
 *  Created by heriard on Sun Feb 10 2002.
 *
 */

#include "XWUtilImpl.h"
#include <mach/mach.h>
#include <stdio.h>
#include <string.h>
#include <sys/sysctl.h>
#include <CoreServices/CoreServices.h>

static int hw_ncpu[2] 		= { CTL_HW, HW_NCPU 	};
static int hw_cpu_freq[2] 	= { CTL_HW, HW_CPU_FREQ };
static int hw_physmem[2] 	= { CTL_HW, HW_PHYSMEM 	};

int int_sysctl (int * mib, unsigned int miblen)
{
  int n,err;
  size_t sz =sizeof(long);
  err = sysctl (mib, miblen, &n, &sz, NULL, 0);
  if (err < 0) perror("sysctl");
  return (err < 0 ? (long)err : n);
}

/*
JNIEXPORT jint JNICALL
Java_xtremweb_archdep_XWUtilImpl_getNumProc(JNIEnv *env, jobject obj)
{
    return (jint) int_sysctl (hw_ncpu, 2);
} 

JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getSpeedProc
(JNIEnv * env, jobject obj)
{
    return (jint) int_sysctl (hw_cpu_freq, 2);
}

JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getTotalMem
(JNIEnv * env, jobject obj)
{
    return (jint) int_sysctl (hw_physmem, 2);
}

JNIEXPORT jint JNICALL Java_xtremweb_archdep_XWUtilImpl_getTotalSwap
(JNIEnv * env, jobject obj) {
    return (jint) 0;
}
*/
/*
 * look at hostinfo source for more infos:
 * http://www.opensource.apple.com
 *                   /cgi-bin/registered/cvs/src/live/system_cmds/hostinfo.tproj/hostinfo.c
 */
/*
JNIEXPORT jstring JNICALL Java_xtremweb_archdep_XWUtilImpl_getProcModel
(JNIEnv * env, jobject obj) {
    struct host_basic_info  hi;
    int                     size;
    char                    *cpu_name, *cpu_subname;
    host_name_port_t        host;

    host = mach_host_self();
    size = sizeof(hi)/sizeof(int);

    if (host_info(host, HOST_BASIC_INFO, (host_info_t)&hi, &size) != KERN_SUCCESS)
        return (*env)->NewStringUTF(env, "Can't get processor infos");

    slot_name(hi.cpu_type, hi.cpu_subtype, &cpu_name, &cpu_subname);

    return (*env)->NewStringUTF(env, cpu_name);    
}
*/
