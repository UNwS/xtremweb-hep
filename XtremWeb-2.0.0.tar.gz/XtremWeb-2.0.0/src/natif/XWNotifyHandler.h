
#ifndef __XWNotifyHandler_h__
#define __XWNotifyHandler_h__


#include "XWNotifyThread.h"


class XWNotifyHandler
{
	friend DWORD WINAPI XWNotifyThread::ThreadProc( LPVOID lpParameter );

public:

	static XWNotifyHandler *extract( JNIEnv *env, jobject object );

	XWNotifyHandler( JNIEnv *env, jobject object, jint image, const char *tooltip );

	void enable( JNIEnv *env );
	void update( jint image, const char *tooltip );
	void disable();
	void hide();
	//void showMenu();

private:

	enum
	{
		enableCode = 1,
		updateCode = 2,
		disableCode = 3,
		hideCode = 4
	};

	~XWNotifyHandler();

	void doEnable();
	void doUpdate();
	void statistics();
	void config();
	void exitApplication();
//	void exitAfterTransfers();
	//void exitJVM();
	void doHide();
	void removeNotify();
	void showAboutWindow();

	//void makeMenuCallback();

	HWND m_window;
	HICON m_icon;
	jobject m_object;
	jint m_image;
	char *m_tooltip;
	//jmethodID m_fireClicked;
	jmethodID m_stats;
	jmethodID m_config;
	jmethodID m_exitApplication;
//	jmethodID m_exitAfterTransfers;
	//jmethodID m_menuCallback;
	jmethodID m_exitJVM;
	jmethodID m_aboutWindow;

	static LRESULT CALLBACK WndProc( HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam );
	static DWORD WINAPI ThreadProc( LPVOID lpParameter );
};


#endif
