package xtremweb.exec;

/**
 * Executor.java
 * Launch and execute process
 *
 * Created: Sun Mar 28 21:48:40 2004
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */

import xtremweb.common.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.util.Timer;
import java.util.TimerTask;
import java.lang.Runtime;

public class Executor extends Logger {

    /**
     * This is the command line
     * This includes the process command line and its options
     */
    protected String commandLine=null;
    /**
     * This is the process execution directory
     */
    protected String executionDirectory=null;

    /** This is the process standard input */
    protected InputStream stdin=null;
    /** This is the process standard output */
    protected OutputStream stdout=null;
    /** This is the process standard error */
    protected OutputStream stderr=null;

    /** This is the managed process */
    private Process process=null;

    /** This is the execution Runtime*/
    private Runtime machine=Runtime.getRuntime();

    /** This stores the process running flag */
    private boolean isRunning=false;

    private  final int BLOCK_SIZE = 65500; // bytes

    /** 
     * This is the default timer period in milliseconds; default value is 250
     */
    private  final int SLEEP_UNIT = 250;   // msec
    /** 
     * This is the timer period 
     */
    private  long sleep_delay;   // msec

    /**
     * This is a timer; it helps to periodically check process status 
     * and to flush I/O
     */
    private Timer timer = new Timer();


    public Executor() {
    }

    /**
     * This constructor sets execution directory and I/O to null
     * @param cmd is the command to execute
     * @see executionDirectory
     * @see stdin
     * @see stdout
     * @see stderr
     */
    public Executor(String cmd) {
        this( cmd, null);

    } // Executor constructor
    

    /**
     * This constructor sets I/O to the standard input and output
     * @param cmd is the command to execute
     * @param dir is the execution directory 
     * @see #executionDirectory
     * @see #stdin
     * @see #stdout
     * @see #stderr
     */
    public Executor(String cmd, String dir) {
        this(cmd, dir, System.in, (OutputStream) System.out, (OutputStream) System.err);
    }
    

    /**
     * This constructor sets sleep delay to SLEEP_UNIT
     * @see #Executor(String, String, InputStream, OutputStream, OutputStream, int)
     */
    public Executor(String cmd, String dir, InputStream in,
                    OutputStream out, OutputStream err) {  
        this(cmd, dir, in, out, err, -1);
    }

    /**
     * This constructor sets I/O to null
     * If delay == 0 , sleep delay set to 5
     * @param cmd is the command to execute
     * @param dir is the execution directory 
     * @param in is the process input
     * @param out is the process output
     * @param err is the process output error
     * @param delay is the sleep delay
     * @see #executionDirectory
     * @see #stdin
     * @see #stdout
     * @see #stderr
     * @see sleep_delay
     */
    public Executor(String cmd, String dir, InputStream in,
                    OutputStream out, OutputStream err, long delay) {  
        commandLine = cmd;
        executionDirectory = dir;
        stdin = in;
        stdout = out;
        stderr = err;
        setDelay(delay);
        // 				sleep_delay = delay;
        // 				if (sleep_delay < 0)
        // 						sleep_delay = SLEEP_UNIT;
        // 				else if (sleep_delay == 0)
        // 						sleep_delay = 5;
    }

    /**
     * This sets and corrects the sleep delay
     */
    protected long setDelay(long delay) {
        sleep_delay = delay;
        if (sleep_delay < 0)
            sleep_delay = SLEEP_UNIT;
        else if (sleep_delay == 0)
            sleep_delay = 5;
        //				System.out.println("Executor#setDali() = " + sleep_delay);
        return sleep_delay;
    }
    /**
     * This retreives the sleep delay
     */
    protected long delay() {
        return setDelay(sleep_delay);
    }

    /**
     * This retreives an attribute (as the name says)
     * @return the expected attribute
     */
    public String getCmdLine() {
        return commandLine;
    }

    /**
     * This retreives an attribute (as the name says)
     * @return the expected attribute
     */
    public String getExecDir() {
        return executionDirectory;
    }


    /**
     * This sets an attribute (as the name says)
     * @param v is the new attribute value
     */
    public void setCmdLine(String v) {
        commandLine = v;
    }


    /**
     * This sets an attribute (as the name says)
     * @param v is the new attribute value
     */
    public void setExecDir(String v) {
        executionDirectory = v;
    }


    /**
     * This stops the process, if any
     * @exception  ExecutorLaunchException is thrown on error (no running process)
     */
    public void stop () throws ExecutorLaunchException {

        debug("stop process");

        try {
            process.destroy ();
            isRunning = false;	    

        }
        catch (Throwable e) {
            debug("Can't stop process : " + e);
            throw new ExecutorLaunchException();
        }
    }


    /**
     * This starts the process using Runtime.exec ()
     * It instanciates a timer to check process state and periodically flush the I/O
     * @see timer
     * @see flushPipe ()
     */
    public void start() throws ExecutorLaunchException {

        debug("start process : " + commandLine);

        try {
            if ( executionDirectory == null) {
                process = machine.exec(commandLine);
            }
            else {
                process = machine.exec(commandLine, null, new File(executionDirectory));
            }

            isRunning = true;	    
        }
        catch (IOException e) {
            debug("Can't start process : " + commandLine + " " +e);
            throw new ExecutorLaunchException();
        }

        timer.scheduleAtFixedRate( new TimerTask() {
                public void run() {
                    flushPipe();
                }
            },  0,      // run now
                                   delay());
    }


    /**
     * This tells whether the process is running or not
     */
    public boolean isRunning() {
        return isRunning;
    }


    /**
     * This checks for process terminason and flushes the I/O
     * @see pipe (InputStream, OutputStream, boolean)
     */
    public void flushPipe() {
        int returnCode;
        try {		  
            returnCode = process.exitValue();
            isRunning = false;
            timer.cancel ();
        }
        catch (IllegalThreadStateException ie) {
        }
	
        try {
            pipe (stdin, process.getOutputStream(), false);
            pipe (process.getInputStream(), stdout, false);
            pipe (process.getErrorStream(), stderr, false);
        }
        catch(Exception e) {
        }
    }


    /**
     * This waits until the process exits
     * @return the process return code
     */
    public int waitFor() {
        int returnCode = 0;
	
        for (isRunning = true; isRunning;) {
            try {
                Thread.sleep(delay());
            } catch (InterruptedException e) {
		
            } // end of try-catch
	      
            try {		  
                returnCode = process.exitValue();
                isRunning = false;
            } catch (IllegalThreadStateException ie) {}
        }
        //	  System.out.println("done" + returnCode);
        //flush
        flushPipe();
        timer.cancel();
        return(returnCode);	  
    }


    /**
     * This start the process and wait until the process exits
     * @return the process exit code
     * @see start ()
     * @see waitFor ()
     */
    public int startAndWait() throws ExecutorLaunchException {
        start();
        return waitFor();
    }


    /**
     * This pipes from one stream to other
     * @param in is the input stream to read from; if null this method returns immediatly
     * @param out is output stream to write to; if null nothing is written
     * @param isBlocking tells whether I/O are blocking or not
     */
    private void pipe(InputStream in, OutputStream out, boolean isBlocking) throws IOException {
        int nread;
        int navailable;
        int total = 0;

        if (in == null)
            return;

        synchronized (in) {

            byte[] buf = new byte[BLOCK_SIZE];

            while((navailable = isBlocking ? Integer.MAX_VALUE : in.available()) > 0 &&
                  (nread = in.read(buf, 0, Math.min(buf.length, navailable))) >= 0) {

                if (out != null)
                    out.write(buf, 0, nread);
                total += nread;
            }

        }

        if (out != null)
            out.flush();
    }

    protected static String join (String tab[], String sep) {
        String result = "";
        if ( tab==null) {
            return null;
        } // end of if ()	
        if ( tab.length ==0 ) {
            return "";
        } // end of if ()	
        for ( int i=0; i< tab.length - 1; i++) {
            result += (tab[i] + sep);
        } // end of for ()
        return result + tab[tab.length-1];
    }

    /**
     * This is the standard main () method
     * This is only for test purposes
     */
    public static void main(String[] args) {
        Executor e = new Executor("/usr/bin/telnet localhost 8649" ) ;
        try {
            e.startAndWait();	     
        } catch (ExecutorLaunchException ele) {
            e.debug("FUCK");
        } // end of try-catch
	

    } // end of main()

    

} // Executor
