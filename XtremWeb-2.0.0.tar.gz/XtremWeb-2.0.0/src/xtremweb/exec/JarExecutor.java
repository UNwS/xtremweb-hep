package xtremweb.exec;

/**
 * JarExecutor.java
 *
 *
 * Created: Sun Mar 28 22:10:53 2004
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */

import java.io.File;
public class JarExecutor extends JavaByteCodeExecutor {


    public JarExecutor (String jarName) throws ExecutorLaunchException {
	super( null, jarName, null, true );
    } // JarExecutor constructor

    public JarExecutor( String[] classPath, String jarName,   String argv[])  throws ExecutorLaunchException  {
	super( (classPath==null ? null : Executor.join(classPath, ":"))
	       , jarName
	       , (argv == null ? null : Executor.join(argv, " "))
	       , true );
    } // JarExecutor constructor
    

    public JarExecutor(String classPath, String jarName, String argv) throws ExecutorLaunchException  {
	super(classPath, jarName, argv, true);
    } // JarExecutor constructor
    
    public static void main(String[] args) {
	
    } // end of main()
    
} // JarExecutor