package xtremweb.exec;

/**
 * JavaByteCodeExecutor.java
 *
 *
 * Created: Sat Feb 26 10:07:34 2005
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */

import java.io.File;

public class JavaByteCodeExecutor extends Executor{

    protected String jarNameOrClassName;
    protected String args;
    protected boolean isJar;
    protected String jvm;
    protected String classPath;
    
    protected JavaByteCodeExecutor( String cP, String jNoC, String argv, boolean iJ)  throws ExecutorLaunchException {
				jarNameOrClassName = jNoC;
				classPath = cP;
				args = argv;
				isJar = iJ;
				setJVM();
				setCmdLine();
    } // JavaByteCodeExecutor constructor

    private void setJVM() throws ExecutorLaunchException {
				try {
						jvm = System.getProperty("java.home") + File.separator +
								"bin" + File.separator + "java";
				} catch ( Exception e) {
						debug("Can't acces to property java.home");
						throw new ExecutorLaunchException();
				} // end of try-catch	
    }

    private void setCmdLine() {
				//set the vm
				commandLine = jvm;

				//set the classpath
				if ( classPath != null) 
						commandLine += " -classpath " + classPath + " "; 

				// set hte jar switch jar
				if ( isJar ) 
						commandLine += " -jar " ;

				//set the class or jar name
				commandLine += jarNameOrClassName;

				//set the args 
				if ( args != null ) 
						commandLine += " " + args + " ";
    }

} // JavaByteCodeExecutor
