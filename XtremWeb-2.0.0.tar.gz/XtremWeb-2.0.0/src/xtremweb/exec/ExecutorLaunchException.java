package xtremweb.exec;

/**
 * ExecutorLaunchException.java
 *
 *
 * Created: Sun Mar 28 22:21:40 2004
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */
public class ExecutorLaunchException extends Exception{

    public ExecutorLaunchException() {
	
    } // ExecutorLaunchException constructor
    
} // ExecutorLaunchException
