package xtremweb.XwIDL;


import java.rmi.*;


/**
 * CommRMITemplate.java
 * 
 * Template to create RMI RPC calls
 * Created: 
 *
 * @author fedak
 * @version 
 */

public class CommRMITemplate {
    
    protected Remote rmi; 


    public CommRMITemplate () {
				try {
				} catch ( Exception e ) {
				}
    }

    public void initComm ( String dispatcherName,
													 int port,
													 String module
													 ) throws RemoteException {
				try {

						// Create a RMI handler
						rmi =
								Naming.lookup("//" + dispatcherName + ":" + port + "/" + module);
	     
				} catch (SecurityException e) {
						//Some jdk1.1.8 requires this
						System.setSecurityManager(new SecurityManager());
						try {
								rmi =
										Naming.lookup("//" + dispatcherName + ":" + port +
																	"/" + module);
						} catch (Exception e2) {
								throw new RemoteException("Cannot connect to XtremWeb Server\n"
																					 + e2 );
						}
				} catch( NoSuchObjectException nso ){
						System.out.println("//" + dispatcherName + ":" + port +
															 "/" + module);
						try {
								String [] list = Naming.list("//" + dispatcherName + ":" + port +
																						 "/" + module);
								for ( int i=0; i<list.length; i++) 
										System.out.println ( list[i] + "\n");
						} catch(Exception e) {
								System.out.println( "Cannot list rmi server" + e);
						}
				} catch (Exception e) {
						throw new RemoteException( "Cannot connect to XtremWeb Server\n"
																			 + e );
				}
    }
}
