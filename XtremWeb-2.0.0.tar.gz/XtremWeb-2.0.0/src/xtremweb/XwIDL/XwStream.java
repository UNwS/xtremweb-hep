package xtremweb.XwIDL;
import java.io.*;

public class XwStream  implements Serializable{
    private int streamLength;
    private DataInputStream dis;
    private byte[] buffer;
    public int mode;

    private static final int BUFFER=0;
    private static final int STREAM=1;
	
    private int byteRead=0;

    public XwStream() {
    }

    public XwStream( int length, byte[] b) {
      streamLength = length;
      buffer = new byte[streamLength]; 
      System.arraycopy(b, 0, buffer, 0, streamLength);
    }

    public XwStream( int length, DataInputStream is) {
	
    }

    public int  read( byte[] b ) {
	b = new byte[streamLength];
	System.arraycopy(buffer, 0, b, 0, streamLength);
	return streamLength;
    }

    public byte[]  buffer() {
	return buffer;
    }

    public int length() {
      return streamLength;
    }
}
