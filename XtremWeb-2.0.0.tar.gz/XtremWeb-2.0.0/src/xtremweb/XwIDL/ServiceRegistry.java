package xtremweb.XwIDL;

import java.net.*;
import java.util.*;

import xtremweb.common.*;

/**
 * ServiceRegistry.java
 *
 *
 * Created: Mon Apr  8 19:20:56 2002
 *
 * @author <a href="mailto: "Gilles Fedak</a>
 * @version
 */

public class ServiceRegistry {

    private static Hashtable servicesRegistry;
    //    private Logger logger;

    public ServiceRegistry () {
	servicesRegistry = new Hashtable();
    //	logger = util.getLogger(this);
    }

    public static void  registerServices( String serviceName, InetAddress ip, int port) {
	//check if there is already one service named service Name and registered 
	LinkedList locators;
	if ( servicesRegistry.containsKey( serviceName) ) {
	    locators = (LinkedList) servicesRegistry.get( serviceName
							  );
	} else {
	    locators = new LinkedList();
	    servicesRegistry.put( serviceName, locators);
	}
	locators.add( new ServiceLocation( ip, port));
	//	System.out.println("SERV: "+ "register remote service for " +  serviceName + " host: " + ip.getHostAddress() +":" +port);
	//	XWShell.sendEvent("SERV", "register remote service for " +  serviceName + " host: " + ip.getHostAddress() +":" +port);
    }

    public static void unRegisterServices( String serviceName,
					   InetAddress ip) {
	if ( servicesRegistry.containsKey( serviceName) ) {
	    LinkedList locators = (LinkedList) servicesRegistry.get( serviceName );
	    //find out the correct server and remove it from the list
	    for ( ListIterator li = locators.listIterator();
		  li.hasNext(); )  {
		ServiceLocation  sl = ((ServiceLocation) li.next());
		if ( sl.isSameIP(ip) ) {
		    li.remove();
		    System.out.println("SERV: "+ "un register remote service for " +  serviceName + " host: " + ip.getHostAddress());
	//	XWShell.sendEvent("SERV", "unregister remote service
		    //	for " +  serviceName + " host: " +
		    //	ip.getHostAddress() +":" +port);
		    break;
		} 
	    } 	    
	} 
    }

    public static void unRegisterServer( InetAddress ip ) {
	//remove at every services 
	for (Enumeration e = servicesRegistry.keys() ; e.hasMoreElements() ;) {
	    unRegisterServices( (String) e.nextElement(), ip);
	}
    }

    public static LinkedList getServiceLocators( String serviceName){
	if ( servicesRegistry.containsKey( serviceName) ) {
	    return (LinkedList) servicesRegistry.get( serviceName
							  );
	} else {
	    return new LinkedList();
	} 
    }

    //just to debug
    public static void main (String[] args) {
	InetAddress myIP;
	new ServiceRegistry();
	try {
	    myIP= InetAddress.getLocalHost();
	    registerServices( "checkpoint", myIP , 4356);
	    registerServices( "mpi", myIP , 4356);
	    unRegisterServer(  myIP);
	} catch(UnknownHostException e) {
	    System.err.println("Can't guess it's own ip");
	    System.exit(1);
	}
    } 
    

}// ServiceRegistry
