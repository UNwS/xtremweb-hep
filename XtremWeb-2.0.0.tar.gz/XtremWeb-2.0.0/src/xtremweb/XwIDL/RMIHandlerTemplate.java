package xtremweb.XwIDL;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * RMIHandler.java
 * Handles RMI communications from servers  
 *
 * Created: Sun Jul  9 17:46:53 2000
 *
 * @author Gilles Fedak
 * @version
 */

public class RMIHandlerTemplate extends UnicastRemoteObject {

  protected CallbackTemplate callback;

  public RMIHandlerTemplate() throws RemoteException {
    super( ModuleLoader.rmiBackPort );
  }

  public void registerCallback( CallbackTemplate cb) {
    callback = cb;
  }

}
