package xtremweb.XwDIL;
import javax.net.*;
import java.net.*;
import java.io.IOException;
/**
 * PeerServerSocketFactory.java
 *
 *
 * Created: Thu Apr 25 12:28:05 2002
 *
 * @author <a href="mailto: "Gilles Fedak</a>
 * @version
 */

public class PeerServerSocketFactory extends ServerSocketFactory { 

    private static String rootServer=null;
    private static String rootPort=null;
    private static boolean canServer;

    public PeerServerSocketFactory ( String server , int port )  {
	/* Make the Port Challenge Handshake
	 * We open a connection to the server root Server
	 * we request him to open a connection and if he can't
	 * we use the PeerSocketServer
	 */
	try { 
	    Socket sockServer = new Socket (server, port);
	} catch ( Exception  ioe ) {
	    //oucth 
	}
    }

    
    public ServerSocket createServerSocket(int port) 
	throws IOException {
	return new ServerSocket (port);
    }

    public ServerSocket createServerSocket(int port, int backlog)
	throws IOException {
	return new ServerSocket (port, backlog);
    }

    public ServerSocket createServerSocket(int port, int backlog,
					   InetAddress ifAddress) 
	throws IOException {
	return new ServerSocket( port, backlog, ifAddress);
    }
}// PeerServerSocketFactory
