package xtremweb.XwIDL;
import java.net.*;

/**
 * PeerSocket.java
 *
 *
 * Created: Thu Apr 25 12:25:08 2002
 *
 * @author <a href="mailto: "Gilles Fedak</a>
 * @version
 */

public class PeerSocket {

    public Socket socket;
    public String hostName;
    public InetAddress ip;
    public int port;

    public PeerSocket (){
	
    }

}
