package xtremweb.XwIDL;


/**
 * ModuleLoaderException.java
 * A simple Exception for all the communications
 *
 * Created: late in an evening dream
 *
 * @author Gilles Fedak
 * @version
 */


public class ModuleLoaderException extends Exception  {

    Exception lowlevelException;  

    public ModuleLoaderException() {
       super();
    }

    public ModuleLoaderException(String s) {
        super(s);
    }

    public ModuleLoaderException( Exception e ) {
        super();
        lowlevelException = e;

    }
    
    public ModuleLoaderException( String s, Exception e ) {
        super(s);
        lowlevelException = e;
				System.err.println ( "WARN  -- Module Loader: Low level Exception " +e); 
    }
}
