package xtremweb.XwIDL;

/**
 * CallbackTemplate.java
 * Handles RMI communications from servers  
 * 
 * Created: on a rainning sunday
 *
 * @author Gilles Fedak
 * @version
 */

public class CallbackTemplate {

    public CallbackTemplate() {}

}
