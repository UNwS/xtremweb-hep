package xtremweb.XwIDL;

import javax.net.*;
import java.util.*;
import java.net.*;
import java.io.*;

import xtremweb.common.util;

/**
 * PeerSocketFactory.java
 *
 *
 * Created: Thu Apr 25 12:21:23 2002
 *
 * @author <a href="mailto: "Gilles Fedak</a>
 * @version
 */

public class PeerSocketFactory extends SocketFactory {

    static Hashtable peerSockets=null;
    static PeerHandlerThread pht=null;

    public PeerSocketFactory () {       
        if ( peerSockets==null)
            peerSockets = new Hashtable();
        if ( pht==null ) {
            pht = new PeerHandlerThread(4329);
            pht.start();
        }
    }
    public static void addPeerSocket( PeerSocket ps ) {
        System.out.println ( "addPeerSocket " + ipKey( ps.ip ) );
        //if ( !peerSockets.containsKey( ipKey( ps.ip ) ) ) 
        peerSockets.put(ipKey(ps.ip ), ps);	    
    }

    public Socket createSocket(String host, int port,  
                               InetAddress clientHost, int clientPort) 
        throws  IOException, UnknownHostException {
        System.out.println ( "createSocket 1 ");
        if ( peerSockets.containsKey( host ) ) {
            return ((PeerSocket) peerSockets.get(host)).socket;
        } // end of if ()
        else 
            return SocketFactory.getDefault().createSocket( host,
                                                            port,
                                                            clientHost, 
                                                            clientPort);
    }

    public Socket createSocket(String host, int port) 
        throws  IOException, UnknownHostException {
        //	String hostAddr = InetAddress.getByName(host)ipKey( );
        String hostAddr = host;
        System.out.println ( "createSocket 2 " + host + ":" + hostAddr );

        if ( peerSockets.containsKey( hostAddr ) )
            {
                System.out.println("got a socket for: " + host );
                return ((PeerSocket) peerSockets.get(hostAddr)).socket;
            } // end of if ()
        else  {
            System.out.println("couldn't got a socket for: " + host );
            return SocketFactory.getDefault().createSocket( host, port);
        }
    }

    public Socket createSocket( InetAddress ip , int port)  
        throws IOException {
        System.out.println ( "createSocket 3 ");
        if ( peerSockets.containsKey( ipKey( ip ) )) {
            return ((PeerSocket) peerSockets.get( ipKey(ip))).socket;
        }
        else 
            return SocketFactory.getDefault().createSocket( ip, port);
    }


    public Socket createSocket(InetAddress ip,
                               int port,
                               InetAddress clientAddress,
                               int clientPort)
        throws IOException {
        System.out.println ( "createSocket 4 ");
        if ( peerSockets.containsKey( ipKey( ip ) ) ) {
            return ((PeerSocket) peerSockets.get(ip)).socket;
        } // end of if ()
        else 
            return SocketFactory.getDefault().createSocket( ip, port);
    }


    public static String ipKey ( InetAddress ip ) {
        String hostName= ip.getHostName();
        if (hostName.indexOf('.')>0)
            hostName = hostName.substring(0,hostName.indexOf('.')); 
        return hostName;
    }
}

class PeerHandlerThread extends Thread {

    ServerSocket peerHandlers;
    int port;

    public PeerHandlerThread ( int port ) {
        try { 
            peerHandlers = new ServerSocket( port );
            System.out.println ( "PeerHandlerThread: listen on port " + port);
        } catch ( IOException ioe ) {
            System.err.println(" Unable to accept connections on port " +
                        port );
        } 
    }

    public void run () {
        while ( true ) {
            try { 
                Socket peerSocket = peerHandlers.accept();
                PeerSocket ps = new PeerSocket();
                ps.socket = peerSocket;
                ps.ip = peerSocket.getInetAddress();
                ps.hostName = peerSocket.getInetAddress().getHostName();
                PeerSocketFactory.addPeerSocket( ps );
                System.out.println ( "PeerHandlerThread: Accept a new connection from " + ps.hostName);
            } catch ( IOException ioe ) {
                System.err.println(" Unable to accept connections ");
            } 
	
        } // end of while ()
    }
}
