package xtremweb.XwIDL;

import xtremweb.common.util;

import java.io.*;
import java.net.*;


public abstract class TCPHandlerTemplate {

    protected CallbackTemplate callback;
    protected Socket socket = null;
    protected DataOutputStream output= null;
    protected DataInputStream  input = null;

    protected static  TCPHandlerServer server = null;
    protected  boolean isFirewalled=false;

    protected  String proxyHostName;
    protected  int proxyPort;

    public TCPHandlerTemplate( ) {
    }

    public void setFirewalled( boolean firewalledFlag) {
				isFirewalled = firewalledFlag;
    }

    public boolean isFirewalled() {
				return isFirewalled;
    }

    public void setProxy( String host, int port ) {
				proxyHostName = host;
				proxyPort = port;
    }

    public void init( Socket sock)  {
				try {
						socket=sock;
						output = new DataOutputStream(socket.getOutputStream());
						input = new DataInputStream(socket.getInputStream ());
				} catch( IOException ioe) { 
						System.err.println("Cannot get any streams from the socket");
				}
    }

    public void registerCallback( CallbackTemplate cb) {
				callback = cb;
    }

    public void registerModuleHandler( String module,
																			 TCPHandlerTemplate handler ) {
				if (server==null) {
	    
						server = (isFirewalled ? 
											new TCPHandlerPeer( proxyHostName, proxyPort) 
											: new TCPHandlerServer( 4329 ));
						server.registerHandler( module, handler);
						server.start();
				}
    }
    public abstract void jump() throws  EOFException;
}


class TCPHandlerServer extends Thread {

    protected static ServerSocket server = null;
    protected TCPHandlerTemplate handlerTemplate; 

    public TCPHandlerServer() {}

    public TCPHandlerServer( int port  ) {
				try {
						System.err.println("TCP Handler Server created");
						server = new ServerSocket( port );
				} catch( IOException e) {
						util.fatal("TCPHandler: Could not listen on port " + port);
				}
    }
    
    public void registerHandler( String module, TCPHandlerTemplate handler ) {
				System.out.println("TCPHandlerServer register module " + module);
				handlerTemplate = handler;
    }

    public void run() {
				while (true) {
						try{
								System.out.println("TCP Handler Server  started");
								Socket sock = server.accept();
								System.out.println("TCP Handle receives connection from " +sock.getInetAddress().getHostName());
								handlerTemplate.init(sock);
								System.out.println(" Thread Started " + handlerTemplate);
								handlerTemplate.jump( );
						}
						catch (IOException e) {
								util.fatal("Could not accept");
						}
				} 
    } 
}

class TCPHandlerPeer extends TCPHandlerServer {
    protected static PeerServerSocket server = null;

    public TCPHandlerPeer(String proxy, int port  ) {
				try {
						System.err.println("Firewalled TCP Handler Server created");
						if ( server==null)	    
								server = new PeerServerSocket(proxy, port );
				} catch( IOException e) {
						util.fatal("Firewalled  TCPHandler: Could not make a connection to the Proxy  " + proxy +":"+ port);
				}
    }

    public void run() {
				while (true) {
						try{
								System.out.println("Firewalled  TCP Handler Server  started");
								Socket sock = server.accept();
								System.out.println("Firewalled  TCP Handler receives connection from " +sock.getInetAddress().getHostName());
								handlerTemplate.init(sock);
								handlerTemplate.jump( );
		
						} catch (EOFException eofe) {
								util.fatal(" Socket tp proxy server closed");

						} catch (IOException e) {
								util.fatal("Firewalled  TCP Handler  Could not accept");
						}
				} 
    }
}
