package xtremweb.XwIDL;
import java.rmi.*;
import java.util.*;
import xtremweb.common.util;
import xtremweb.common.NewClassLoader;
import java.lang.reflect.*;

public class ModuleLoader {

    static protected Hashtable callbacks;
    static protected NewClassLoader classLoader;
    public static    String proxyName=null;
    public static    int    proxyPort=-1;
    public static    int    rmiBackPort=4327;
    public static    int    rmiPort=4322;

    public ModuleLoader () {
        callbacks = new Hashtable();
        classLoader = new NewClassLoader();
        classLoader.addClassPath( "." );
    }

    protected static Object createInstance( String className )  throws ModuleLoaderException {
        try {
            Class classClass = classLoader.loadClass( className, true);
            Constructor classConstructor =
                classClass.getConstructor(null);
            return classClass.newInstance();
        } catch ( ClassNotFoundException cnfe ) {
            //            logger.warn("ModuleLoader : cannot find class in classpath");
        } catch ( IllegalAccessException iae) {
            throw new ModuleLoaderException( "cannot create object from class " + className, iae);
        } catch ( NoSuchMethodException nsme) {
            throw new ModuleLoaderException( "cannot find a contructor to create an object  " + className, nsme);
            //  	} catch ( InvocationTargetException ite) {
            //  	    throw new ModuleLoaderException( "cannot call the constructor of the class  " + className, ite);
        } catch ( InstantiationException ie) {
            throw new ModuleLoaderException( "cannot instantiate the  class " + className, ie);
        }	    
        return null;
    }

    public static void addCallback( String module) throws ModuleLoaderException {
        // create an instance of the call back
        String callbackClassName = "xtremweb."+ module+  ".Callback" + module;
        CallbackTemplate callb = (CallbackTemplate)  createInstance(callbackClassName);
        if ( callb!=null ) {	    	
            callbacks.put( module, callb );
            //            logger.info("ModuleLoader has registred callback: [" + module+ "]" );
        }
//  else {
//             logger.info("ModuleLoader can't register callback: [" + module+ "]" );     
//         } 
	

        //	throw new ModuleLoaderException( "cannot find a callback definition file for module " + module);
    }

    public static CallbackTemplate getModule( String module ) throws  ModuleLoaderException {
        if ( ! callbacks.containsKey(module)) throw new ModuleLoaderException( "cannot find a callback  for module " + module);
        return (CallbackTemplate) callbacks.get( module );
    }

    public static void addHandler (String module, String media, int port) throws ModuleLoaderException  {
        //get the callback codes for this client
        if ( ! callbacks.containsKey(module)) throw new ModuleLoaderException( "cannot find a callback  for module " + module);
        // First findout handler
	
        //create a communication handler and register its callback
        if (media=="RMI") {
            try {

                RMIHandlerTemplate handler= (RMIHandlerTemplate)
                    createInstance("xtremweb."+ module+ ".RMIHandler" +
                                   module);
                Naming.rebind("//" + "localhost" + ":" + port + "/" + module, handler);
                handler.registerCallback((CallbackTemplate) callbacks.get( module ));
                //                logger.info("ModuleLoader has registred handler: [" + module+ "," + media+ "]");
                return;
            } catch( Exception e ) {
                throw new ModuleLoaderException ( " Can't create a " + media+ " for module "+ module,e);
            }    
        }
        if ( (media=="TCP") || (media=="FTCP")) {
            TCPHandlerTemplate handler = (TCPHandlerTemplate)
                createInstance("xtremweb."+ module+ ".TCPHandler" +
                               module);

            handler.registerCallback((CallbackTemplate) callbacks.get( module ));
            /* if we run an handler on a host which is firewalled
             * let's configure the handler for this
             * note that this  should occured in a transparent way
             */
            if ( media == "FTCP") {
                if (proxyName==null || proxyPort==-1 ) throw new
                                                           ModuleLoaderException (" Error when configuring "
                                                                                  + media + "handler for module " 
                                                                                  + module + ": if the host is defined as firewalled, then it should be given a proxy hostName and port" )  ;		
                handler.setFirewalled( true );
                handler.setProxy( proxyName, proxyPort);
            }
            handler.registerModuleHandler( module, handler);
            //            logger.info("ModuleLoader has registred handler: [" +
            //                        module+ "," + media+ "]");
            return;
        }
        throw new ModuleLoaderException (" Cannot find a " + media + "handler for module " + module)  ;
    }


    //used to test
    public static void main ( String [] args) {
        new ModuleLoader();
        try {
            addCallback( "client" );
        } catch (ModuleLoaderException e) {
            System.err.println("ModuleLoader main(): " +  e);
            System.exit( 1);
        }
        try {
            addHandler( "client", "RMI", rmiPort );
        } catch (ModuleLoaderException e) {
            System.err.println("ModuleLoader main(): " +  e);
            System.exit( 1);
        }
	
    }
}
