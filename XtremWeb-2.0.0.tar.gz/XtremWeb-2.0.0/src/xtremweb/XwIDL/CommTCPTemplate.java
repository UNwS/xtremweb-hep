package xtremweb.XwIDL;

import java.rmi.RemoteException;
import java.io.*;
import java.net.*;


/**
 * CommTCPTemplate.java
 * 
 * Template to create TCP RPC calls
 * Created: 
 *
 * @author fedak
 * @version 
 */

public class CommTCPTemplate {
    
    protected Socket sock = null;
    protected DataOutputStream output= null;
    protected DataInputStream  input = null;

    protected int moduleOffset=-1;

    public CommTCPTemplate () {
	try {
	} catch ( Exception e ) {
	}
    }

    public void initComm ( String dispatcherName,
			   int port,
			   String module
			   ) throws RemoteException {
	try {
	    PeerSocketFactory sf = new PeerSocketFactory();
	    sock = sf.createSocket( dispatcherName, port );
	    output = new DataOutputStream(sock.getOutputStream());
	    input = new DataInputStream(sock.getInputStream ());
	} catch (Exception e) {
	    throw new RemoteException(e.toString());
	}
    }


    public DataOutputStream getOutputStream() {
	return output;
    }

    public DataInputStream getInputStream() {
	return input;
    }

}
