package xtremweb.XwIDL;
import  java.net.*;
import java.io.IOException;

/**
 * PeerServerSocket.java
 *
 *
 * Created: Thu Apr 25 17:43:24 2002
 *
 * @author <a href="mailto: "Gilles Fedak</a>
 * @version
 */

public class PeerServerSocket extends ServerSocket {

    private  PeerSocket peerSocket;
    private  String proxyServer = null;
    private  int proxyPort = -1;

    public PeerServerSocket( int port ) throws IOException {
	super( port);
	//this is fake 
    }

    public PeerServerSocket( String rootHost, int port) throws IOException {
	super( port);
	peerSocket=  new PeerSocket();
	proxyServer = peerSocket.hostName= rootHost;
	proxyPort   = peerSocket.port = port;
	peerSocket.socket = new Socket( rootHost, port);
	peerSocket.ip= peerSocket.socket.getInetAddress();
    }

    public Socket accept()  throws IOException {
	if (peerSocket.socket==null ) 
	    throw  new IOException();
	else  
	    return peerSocket.socket;	     
    }

    public void  close() throws IOException  {
	if (peerSocket!=null )
	    peerSocket.socket.close();
	peerSocket=null;
    }

    public String toString() {
	return "PeerServerSocket";
    }
}
