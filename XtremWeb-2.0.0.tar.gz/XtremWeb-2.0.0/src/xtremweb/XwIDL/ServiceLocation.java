package xtremweb.XwIDL;
import java.net.*;

public class ServiceLocation {

    public InetAddress ip;
    public int port;
    public String comLayer; //RMI, TCP, XML-RPC
    public String socket; //TCP, SSL unused

    public ServiceLocation( InetAddress i,  int p ) {
	    ip = i;
	    port=p;
    }

    public boolean isSameIP( InetAddress i ) {
	return (i==ip);
    }

}
