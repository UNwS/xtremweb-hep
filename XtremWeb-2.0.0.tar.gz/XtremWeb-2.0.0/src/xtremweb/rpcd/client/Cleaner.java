package xtremweb.rpcd.client;

/**
 * Date    : Mar 25th, 2005
 * Project : RPCXW / RPCXW-C
 * File    : Cleaner.java
 *
 * @author <a href="mailto:lodygens_a_lal.in2p3.fr">Oleg Lodygensky</a>
 * @version
 */

import xtremweb.common.*;
import xtremweb.communications.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;


/**
 * This class describes a thread which aims to clean
 * jobs from XtremWeb server
 */
public class Cleaner extends LoggerableThread {


    /**
     * Communication channel
     */
    private CommClient comm;
    /**
     * This is the callback to manage the jobs for
     */
    protected Callback callback;


    /**
     * This is the default consructor.
     * @param c is the XtremWeb config
     * @param cb is the callback to delete jobs for
     */
    protected Cleaner (XWConfigurator c, Callback cb) {

        super("Cleaner", c.getLoggerLevel());

        callback = cb;

        try {
            comm = (CommClient)Class.forName(c.getProperty(XWPropertyDefs.COMMLAYER.toString())).newInstance();
            comm.setConfig(c);
            comm.initComm(c.getCurrentDispatcher());
            level = c.getLoggerLevel();
        }
        catch(Exception e) {
            util.fatal("Can't init comm :  " + e);
        }

        if(comm == null)
            util.fatal("Can't init comm");
    }


    /**
     * This removes jobs from server
     * This does nothing
     */
    public void run() {

        Vector uids = new Vector();

        while (true){

            try {
                sleep(1000);
            }
            catch (InterruptedException ce) {
                error (ce.toString ());
                System.exit (Client.ERR);
            }

            Vector newuids = callback.getJobs();
            if (newuids == null) {
                error ("newuids is nul???");
                System.exit (Client.ERR);
            }

            for (int idx = 0; idx < newuids.size(); idx++) {
                Object o = newuids.elementAt(idx);
                if (o == null)
                    continue;
                if (uids.contains(o) == false) {
                    uids.addElement(o);
                }
            }

            if (uids.size () < 10) {
                continue;
            }

            //System.out.println("Cleaning : removing " + uids.size ());

            try {
                comm.removeWorks(uids);
                //System.out.println("Cleaning : removed " + uids.size ());
                uids.clear ();
            }
            catch (Exception ce) {
                error (ce.toString ());
                System.exit (Client.ERRCONNECTION);
            }
        }
    }

}// Cleaner
