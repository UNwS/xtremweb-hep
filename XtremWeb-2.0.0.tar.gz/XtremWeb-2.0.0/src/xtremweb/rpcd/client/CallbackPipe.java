package xtremweb.rpcd.client;

/**
 * Date    : Mar 25th, 2005
 * Project : RPCXW / RPCXW-C
 * File    : CallbackPipe.java
 *
 * @author <a href="mailto:lodygens_a_lal.in2p3.fr">Oleg Lodygensky</a>
 * @version
 */

import xtremweb.common.*;
import xtremweb.services.rpc.rpcdefs;
import xtremweb.services.rpc.Packet;
import xtremweb.archdep.*;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This class pipes RCP callback on UDP
 */
public class CallbackPipe extends Callback {

		/**
		 * This is the RPC port to forward client requests to This RPC server port
		 * must be determined at runtime
		 */
		protected int rpcServerPort = 0;

		/**
		 * This is the default consructor. This does nothing
		 * 
		 * @param c is the XtremWeb config
		 */
		public CallbackPipe(String argv[], XWConfigurator c) {
				super(argv, c);

				// let preload library now
				int rpcServerPort = ArchDepFactory.portMap().getudpport(0, 0);

				try {
						serverHost = InetAddress.getByName(serverName);
				} catch (Exception e) {
						error("InetAddress.getByName (" + serverName + ") : " + e);
						error("Please use '--name' option");
						System.exit(1);
				}
		}

		/**
		 * This connects RPC clients to RPC servers with a simple pipe. This is
		 * called on UDP connections.
		 * 
		 * It first determines RPC server to connect to, thanks to client RPC
		 * message.
		 * 
		 * @param clientPacket is the client datagram packet
		 */
		protected void udp(DatagramSocket clientSocket,
											 DatagramPacket clientPacket) throws Exception {

				DatagramSocket serverSocket = null;
				DatagramPacket serverPacket = null;

				Packet request = new Packet(clientPacket.getData(), clientPacket
																		.getLength(), level, serverName);

				String proc = null;
				int prog = request.getProg();
				int version = request.getVersion();

				switch (prog) {
				case rpcdefs.RPC_NFS:
						proc = rpcdefs.NFSPROC_TEXT[request.getProc()];
						break;
				case rpcdefs.RPC_MOUNT:
						proc = rpcdefs.MOUNTPROC_TEXT[request.getProc()];
						break;
				}

				System.out.println("CallbackMountd;" + proc + " received;" + new Date().getTime());

				byte[] newDatas = request.getBuffer();
				byte[] datas = null;

				rpcServerPort = ArchDepFactory.portMap().getudpport(prog, version);

				switch (prog) {
				case rpcdefs.RPC_NFS:
						if (nfsPort != -1)
								rpcServerPort = nfsPort;
						break;
				case rpcdefs.RPC_MOUNT:
						if (mountPort != -1)
								rpcServerPort = mountPort;
						break;
				}

				System.out.println("CallbackPipe;" + proc + " forwarding;" + new Date().getTime());

				info("prog " + prog + " version " + version);

				serverSocket = new DatagramSocket();

				info("newDatas.length = " + newDatas.length);
				info("request.getLength() = " + request.getLength());
				serverPacket = new DatagramPacket(newDatas, request.getLength(),
                                                  serverHost, rpcServerPort);

				info("writing to " + serverName + ":" + rpcServerPort);

				//
				// Sending the job
				//

				System.out.println("RPCXW;" + proc + " sending;" + new Date().getTime());

				serverSocket.send(serverPacket);

				System.out.println("RPCXW;" + proc + " sent;" + new Date().getTime());

				byte[] buf = new byte[BUFSIZE];
				serverPacket.setData(buf);
				info("waiting answer from " + serverName + ":" + rpcServerPort);

				serverSocket.receive(serverPacket);

				System.out.println("RPCXW;" + proc + " got result;" + new Date().getTime());

				int nbBytes = serverPacket.getLength();

				System.out.println("CallbackPipe;" + proc + " forwarded;" + new Date().getTime());

				datas = new byte[nbBytes];
				System.arraycopy(serverPacket.getData(), 0, datas, 0, nbBytes);

				clientPacket.setData(datas);
				clientSocket.send(clientPacket);

				System.out.println("CallbackPipe;" + proc + " answered;" + new Date().getTime());
		}

}// CallbackPipe
