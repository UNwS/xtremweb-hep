package xtremweb.rpcd.client;

/**
 * Date : Mar 25th, 2005 Project : RPCXW / RPCXW-C File : CallbackRpc.java
 * 
 * @author <a href="mailto:lodygens_a_lal.in2p3.fr">Oleg Lodygensky </a>
 * @version
 */

import xtremweb.common.XWPropertyDefs;
import xtremweb.common.AppInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.Logger;
import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.MileStone;
import xtremweb.common.XWConfigurator;
import xtremweb.common.Zipper;
import xtremweb.communications.*;
import xtremweb.communications.*;
import xtremweb.services.rpc.*;

import java.io.*;
import java.net.*;
import java.rmi.RemoteException;
import java.util.*;
import java.text.SimpleDateFormat;

/**
 * This class forwards RCP calls on UDP through XtremWeb.
 */
public class Callback extends Logger {

    /**
     * Communication channel
     */
    private CommClient comm;

    /**
     * The zipper/unzipper
     */
    protected Zipper zipper;

    /**
     * This stores client config such as login, password, server addr etc.
     */
    protected XWConfigurator config;

    /**
     * This is the program name to launch
     */
    protected String appName;
    /**
     * This is the program UID to forward to XtremWeb
     */
    protected UID appUID;
    /**
     * This is this client UID
     */
    protected UID clientUID;
    /**
     * This is this client session UID
     */
    protected UID sessionUID;

    /**
     * This aims to display some time stamps
     */
    MileStone mileStone;

    /**
     * This is the file name packet that RPCXW-S forwards to the SunRPC
     * server We write content from SunRPC client to this file; RPCXW-S
     * reads and forwards it to the SunRPC server
     */
    protected final String FILEIN = "packet-in.bin";

    /**
     * This is the file name packet that RPCXW-S received from the SunRPC
     * server RPCXW-S writes this file and we must forward the content to
     * the SunRPC client
     */
    protected final String FILEOUT = "packet-out.bin";

    /**
     * This is the server identifier<br />
     * If forwarding to XtremWeb this is the worker UID String representation<br />
     * If piping (i.e. testing) this is the server host name
     */
    protected String serverId;
    /**
     * If forwarding to XtremWeb this is the worker UID
     */
    protected UID serverUID;

    /**
     * This is the RPC host to forward client requests to The RPC server is
     * supposed to run on local host
     */
    protected InetAddress serverHost = null;

    /**
     * This is the server name This is used to change packet credentials If
     * forwarding to XtremWeb this is the worker name If piping (i.e.
     * testing) this is the server host name
     */
    protected String serverName = null;

    /**
     * This stores XtremWeb job uid
     */
    protected Vector uids;

    /**
     * This is the buffer for communications
     */
    protected byte[] buf;

    /**
     * This is the local host name
     */
    //		protected String localHostName;
    /**
     * This is the transfert buffer size
     */
    protected final int BUFSIZE = 8192;

    /**
     * This stores requests and their datas so that we can get answers per
     * request
     */
    protected Hashtable requests;

    /**
     * This aims to simulate a response time (default is 0) This is supposed
     * to contain seconds
     */
    protected int sleep_delay = 0;

    /**
     * This is only needed if piping to another host If piping to local
     * host, the port is automatically extracted from portmapper
     */
    protected int nfsPort;

    /**
     * This is only needed if piping to another host If piping to local
     * host, the port is automatically extracted from portmapper
     */
    protected int mountPort;

    /**
     * This is the default consructor.
     * 
     * @param c is the XtremWeb config
     */
    protected Callback(String argv[], XWConfigurator c) {

        requests = new Hashtable();
        config = c;
        level = config.getLoggerLevel();
        serverId = null;
        serverUID = null;
        comm = null;
        zipper = new Zipper(level);
        uids = new Vector();
        nfsPort = -1;
        mountPort = -1;
        serverName = null;
        appName = "xtremweb.services.rpc.rpc";
        mileStone = new MileStone(getClass().getName());

        parse(argv);

        boolean test = (this.getClass().getName().compareTo("xtremweb.rpcd.client.CallbackPipe") != 0);

        if(test == true) {

            // serverUID  is already set in case of 
            // instanciation from xtremweb.worker.Worker

            // 						if((serverId == null) && (serverUID == null))
            // 								util.fatal("serverID must be set from commandline, " +
            // 													 "or serverUID from caller...");

            try {
                comm = (CommClient)Class.forName(config.getProperty(XWPropertyDefs.COMMLAYER.toString())).newInstance();
                comm.setConfig(config);
                comm.initComm(config.getCurrentDispatcher());

                Runtime.getRuntime().addShutdownHook(new Thread() {
                        public void run() {
                            cleanup();
                        }
                    });
            }
            catch(Exception e) {
                util.fatal("Can't init comm :  " + e);
            }

            // 						if(serverUID == null)
            try {
                if(serverId != null)
                    serverUID = new UID(serverId);
                else {
                    // 14 nov 2005 : to ease deployment, we now take
                    // the first worker found as NFS server
                    warn("Looking for any server");
                    Vector workers = comm.getHosts();
                    if((workers == null) || (workers.size() < 1))
                        util.fatal("can't find any server");
                    serverUID = (UID)workers.elementAt(0);
                }
                HostInterface host = (HostInterface)comm.get(serverUID);
                if(host == null)
                    util.fatal("can't find server " + serverId);
                serverName = host.getName();
            }
            catch(Exception e) {
                e.printStackTrace();
                util.fatal(e.toString());
            }

            if((comm == null) || (serverUID == null))
                util.fatal("Can't init comm");

            //System.err.println("cleaner not loaded");
            new Cleaner(config, this).start();

            //
            // we must now determine app UID
            // since Sept 19th, 2005 : 
            //    submitting to XW needs app UID and not app name
            //
            try {
                AppInterface app = comm.getApp(appName);
                appUID = app.getUID();

                SessionInterface session = new SessionInterface();
                clientUID = new UID();
                sessionUID = new UID();
                session.setUID(sessionUID);
                session.setClient(clientUID);
                session.setName("RPCXWC");
                comm.send(session);
            }
            catch(Exception e) {
                e.printStackTrace();
                util.fatal("can't retreive app " + appName);
            }
        }

        System.out.println("Server UID       : " + serverUID);
        System.out.println("Server name      : " + serverName);
        System.out.println("Application      : " + appName);
        debug("mount port = " + mountPort);
        debug("nfs   port = " + nfsPort);
    }


    /**
     * This parses command line arguments
     */
    public void parse(String argv[]) {

        int i = 0;

        while (i < argv.length) {

            if (argv[i].toLowerCase().compareTo("-s") == 0)
                sleep_delay = new Integer(argv[++i]).intValue();
            else if (argv[i].toLowerCase().compareTo("--server") == 0)
                serverId = argv[++i];
            else if (argv[i].toLowerCase().compareTo("--name") == 0)
                serverName = argv[++i];
            else if (argv[i].toLowerCase().compareTo("--app") == 0)
                appName = argv[++i];
            else if (argv[i].toLowerCase().compareTo("--nfsport") == 0)
                nfsPort = new Integer(argv[++i]).intValue();
            else if (argv[i].toLowerCase().compareTo("--mountport") == 0)
                mountPort = new Integer(argv[++i]).intValue();

            i++;
        }

        // 				if(serverId == null)
        // 						util.fatal("You must provide the worker UID where the SunRPC server runs with '--server <UID>'");
    }

    /**
     * This connects RPC client to RPC server This transmits RPC client requests
     * to RPC server and forwards RPC server answers back to RPC client
     * 
     * It first determines RPC server to connect to, thanks to client RPC
     * message.
     * 
     * @param clientPacket is the client datagram packet
     */
    protected void udp(DatagramSocket clientSocket,
                       DatagramPacket clientPacket) throws Exception {

        mileStone.println("new packet received");

        debug("Callback received.length = " + clientPacket.getLength());

        Packet request = null;
        try {
            request = new Packet(clientPacket.getData(),
                                 clientPacket.getLength(), level, serverName);
        }
        catch(Exception e) {
            e.printStackTrace();
            throw e;
        }
        byte[] newDatas = request.getBuffer();

        debug("Callback length 01 = " + newDatas.length);

        byte[] datas = null;
        int prog = request.getProg();
        int version = request.getVersion();
        int method = request.getProc();
        String proc = null;

        switch (prog) {
        case rpcdefs.RPC_NFS:
            proc = rpcdefs.NFSPROC_TEXT[method];
            break;
        case rpcdefs.RPC_MOUNT:
            proc = rpcdefs.MOUNTPROC_TEXT[method];
            break;
        }

        // 				if (serverUID == null) {
        // 						warn("not using XtremWeb... Just running rpcxws!");
        // 						datas = startAndWait(newDatas, "" + prog + " " + version + " --udp", request.getLength());

        // 				} else {
        datas = xwForward(proc, newDatas,
                          "" + prog + " " + version + " --udp",
                          request.getLength());
        // 				}

        if (datas == null) {
            error("!?!?!?!?!?!?!?!?! datas is null !?!?!?!?!?!?!?!?!");
            return;
        }

        int nbBytes = datas.length;

        clientPacket.setData(datas);

        debug("forwarding answer " + clientPacket.getLength());

        clientSocket.send(clientPacket);

        mileStone.println("packet answered");
    }

    /**
     * This is for debug purposes only<br />
     * This sleeps sleep_delay seconds
     * 
     * @see #sleep_delay
     */
    protected void sleep() {

        try {
            info("sleeping " + sleep_delay + " s");
            Thread.sleep(sleep_delay * 1000);
        } catch (Exception e) {
        }
    }

    // 		/**
    // 		 * This is for debug purposes only<br />
    // 		 * This calls the RPCXW-S program This is typically called if serverId
    // 		 * is not set
    // 		 * 
    // 		 * @param commandLineOpts is the command line parameters (i.e. <SunRPC
    // 		 *        Prog Num> <SunRPC Version Num> [--udp])
    // 		 */
    // 		protected int startAndWait(String commandLineOpts) throws Exception {

    // 				Process process = null;
    // 				Runtime machine = Runtime.getRuntime();
    // 				String cmdLine = appName + " " + commandLineOpts;

    // 				util.debug(level, NAME, "Executing " + cmdLine);

    // 				process = machine.exec(cmdLine);
    // 				int retCode = process.waitFor();

    // 				util.debug(level, NAME, "Executed " + cmdLine + " : " + retCode);

    // 				return retCode;
    // 		}

    // 		/**
    // 		 * This is for debug purposes only<br />
    // 		 * This calls the RPCXW-S program This is typically called if serverId
    // 		 * is not set
    // 		 * 
    // 		 * @param newDatas is the packet to send
    // 		 * @param params is the prog parameters
    // 		 * @param len is the packet length (i.e. <SunRPC Prog Num> <SunRPC
    // 		 *        Version Num> [--udp])
    // 		 */
    // 		protected byte[] startAndWait(byte[] newDatas, String params, int len)
    // 				throws Exception {

    // 				Process process = null;
    // 				Runtime machine = Runtime.getRuntime();
    // 				String cmdLine = appName + " " + params;

    // 				File fin = new File(FILEIN);
    // 				fin.delete();

    // 				DataOutputStream inputServer = new DataOutputStream(new FileOutputStream(fin));

    // 				inputServer.write(newDatas, 0, newDatas.length);
    // 				inputServer.close();

    // 				File fout = new File(FILEOUT);
    // 				fout.delete();

    // 				util.debug(level, NAME, "Executing " + cmdLine);

    // 				process = machine.exec(cmdLine);
    // 				int retCode = process.waitFor();

    // 				util.debug(level, NAME, "Executed " + cmdLine + " : " + retCode);

    // 				DataInputStream resultServer = new DataInputStream(new FileInputStream(fout));
    // 				byte[] datas = new byte[len];
    // 				int nbBytes = resultServer.read(datas);
    // 				resultServer.close();

    // 				return datas;
    // 		}

    /**
     * This retreives the list of computed jobs This is typically needed by
     * the Cleaner
     * 
     * @see xtremweb.rpcd.client.Cleaner
     */
    public synchronized Vector getJobs() {
        Vector ret = null;
        synchronized(uids) {
            ret = (Vector) uids.clone();
            uids.clear();
        }
        return ret;
    }

    /**
     * This forwards the packet to XtremWeb.<br />
     * This is typically called if serverId is set
     * @param proc is the RPC proc name
     * @param newDatas is the packet to send
     * @param params is the prog parameters
     * @param len is the packet length (i.e. <SunRPC Prog Num> <SunRPC
     *        Version Num> [--udp])
     */
    protected byte[] xwForward(String proc, byte[] newDatas, String params, int len)
        throws Exception {

        throw new Exception("Callback::xwForward not implemented");

        /*

        if (serverUID == null) {
        System.err.println("comm not initialized");
        System.exit(Client.ERRCONNECTION);
        }

        mileStone.clear();

        UID jobUID = new UID();
        byte[] resultDatas = null;
        mileStone.println(proc + " received ", jobUID);

        //
        // Preparing the XtremWeb job
        //
        MobileWork job = new MobileWork(jobUID, logger.getEffectiveLevel());

        //				job.setServer(config.getCurrentServer());
        job.setApplication(appUID);
        job.setCmdLine(params);
        job.setExpectedHost(serverUID);

        if (newDatas.length > util.LONGFILESIZE) {
        util.warn(level, NAME, "newDatas is long file???");
        util.warn(level, NAME, "newDatas is long file???");
        util.warn(level, NAME, "newDatas is long file???");
        util.warn(level, NAME, "newDatas is long file???");
        return null;
        }
        else {
        //System.out.println("job dirin = " + newDatas.length);
        job.setDirin(newDatas);
        //System.out.println("job dirin name = " + FILEIN);
        job.setDirinName(FILEIN);
        }

        //
        // Sending the job
        //
        //				UID uid = null;

        mileStone.println(proc + " submitting", jobUID);

        try {
        comm.submit(job);
        }
        catch (Exception ce) {
        ce.printStackTrace();
        util.error(level, NAME, ce.toString());
        System.exit(Client.ERRCONNECTION);
        }

        mileStone.println(proc + " submitted", jobUID);

        //
        // Retreiving results
        //
        boolean finished = false;
        String dirname = null;

        while (finished == false) {


        try {
        comm.waitForCompletedWork(jobUID, config.timeout());
        }
        catch(InterruptedException i) {

        // we don't wait for ever!!!

        synchronized (uids) {
        // we delete this job too
        uids.add(jobUID);
        }

        jobUID = new UID();
        job.setUID(jobUID);
        mileStone.println(proc + " resubmitted", jobUID);

        try {
        comm.submit(job);
        }
        catch (Exception ce) {
        ce.printStackTrace();
        util.error(level, NAME, ce.toString());
        System.exit(Client.ERRCONNECTION);
        }
        continue;
        }

        MobileResult result = null;
        try {
        result = comm.getResult(jobUID);
        }
        catch (RemoteException ce) {
        ce.printStackTrace();
        util.error(level, NAME, ce.toString());
        System.exit(Client.ERRCONNECTION);
        }

        comm.close();

        if (result == null) {
        //
        // logger.debug (uid + " not COMPLETED yet");
        // try { Thread.sleep (2500); } catch
        // (InterruptedException e){ }
        //
        continue;
        }

        finished = true;

        if((result.getReturnCode() != 0) || (result.isError())) {
        util.error(level, NAME, serverName + "(" + serverUID + ") is not an NFS server!!!");
        System.exit(Client.ERRCONNECTION);
        }

        if (result.getResult() == null) {
        util.error(level, NAME, "result.getResult()  is null???");
        util.error(level, NAME, "result.getResult()  is null???");
        util.error(level, NAME, "result.getResult()  is null???");
        util.error(level, NAME, "result.getResult()  is null???");
        return null;
        }
        else {
        resultDatas = result.getResult();
        }

        synchronized (uids) {
        uids.add(jobUID);
        }
        }

        mileStone.println(proc + " done", jobUID);

        //
        // try { comm.disconnect (config.ids.user); } catch
        // (RemoteException ce) { logger.error (ce.toString ());
        // System.exit (Client.ERRCONNECTION); }
        //

        return resultDatas;

        */

    }

    /**
     * This is called on program termination (CTRL+C)
     * This deletes session from server
     */
    private void cleanup() {
        try {
            //            comm.removeSession(sessionUID);
            comm.remove(sessionUID);
        }
        catch(Exception e) {
            error("can't clean up");
        }
    }
}
