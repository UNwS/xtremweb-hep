package xtremweb.rpcd.client;

/**
 * Date    : Mar 25th, 2005
 * Project : RPCXW / RPCXW-C
 * File    : rpc.java
 *
 * @author <a href="mailto:lodygens_a_lal.in2p3.fr">Oleg Lodygensky</a>
 * @version
 */

import xtremweb.common.*;
import xtremweb.communications.*;
import xtremweb.services.rpc.rpcdefs;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This aims to fake sun RPC by interposing between RPC client and sun RPC This
 * reads input bytes from client, send them to sun RPC, wait for call to
 * complete, reads result bytes and send them back to client.
 * 
 * This automatically detects RPC ports on first client connection, using
 * portmapper.c jni library.
 * 
 * This virtual class must be derived
 *  
 */
public abstract class rpc extends LoggerableThread {

		/**
		 * This is the handler for RPC messages
		 */
		protected Callback callback;

		/**
		 * This is the handler for NFS messages
		 * 
		 * @see rpcdefs#RPC_NFS
		 */
		//protected Callback nfsd;

		/**
		 * This is the handler for MOUNT messages
		 * 
		 * @see rpcdefs#RPC_MOUNT
		 */
		//protected Callback mountd;

		/**
		 * This is the default handler for other programmes
		 */
		protected Callback piped;

		/**
		 * This implementes some standard communication methods
		 */
		//protected CommIO io;


		/**
		 * This is the transfert buffer size
		 */
		protected final int BUFSIZE = 8192;

		/**
		 * This is the command line argument
		 */
		String[] argv;

		/**
		 * This stores client config such as login, password, server addr etc.
		 */
		protected XWConfigurator config;

		/**
		 * This is the only constructor
		 * 
		 * @param n is this thread name
		 * @param a is the command line
		 * @param c is the XtremWeb config
		 */
		protected rpc(String n, String[] a, XWConfigurator c) {

				super(n, c.getLoggerLevel());
				config = c;

				argv = a;
				callback = new Callback(argv, c);
				if (parse(argv) == true)
						piped = new CallbackPipe(argv, c);
		}

		/**
		 * This parses command line arguments
		 */
		private boolean parse(String[] argv) {

				int i = 0;

				while (i < argv.length) {

						if (argv[i].toLowerCase().compareTo("--pipe") == 0)
								return true;
						i++;
				}
				return false;
		}

}// rpc
