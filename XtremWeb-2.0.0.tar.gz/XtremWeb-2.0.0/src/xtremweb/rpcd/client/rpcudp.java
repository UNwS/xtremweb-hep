package xtremweb.rpcd.client;

/**
 * Date    : Mar 25th, 2005
 * Project : RPCXW / RPCXW-C
 * File    : rpcudp.java
 *
 * @author <a href="mailto:lodygens_a_lal.in2p3.fr">Oleg Lodygensky</a>
 * @version
 */

import xtremweb.common.XWConfigurator;
import xtremweb.communications.Connection;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.DatagramPacket;


/**
 * This implements the RPC Proxy for the UDP protocol<br />
 *
 * RPC message structure on UDP :
 * <ul>
 * <li>  [0] 4 bytes : one 32 bits integer : XID
 * <li>  [1] 4 bytes : one 32 bits integer : MSG type (call, answer etc.)
 * <li>  [2] 4 bytes : one 32 bits integer : RPC version
 * <li>  [3] 4 bytes : one 32 bits integer : the prog number  (expected to auto detect port)
 * <li>  [4] 4 bytes : one 32 bits integer : the prog version (expected to auto detect port)
 * <li>  [5] 4 bytes : one 32 bits integer : the method number
 * <li>  [6] 4 bytes : one 32 bits integer : Credential flavour (1 = AUTH_UNIX)
 * <li>  [7] 4 bytes : one 32 bits integer : Credential length
 * <li>  [8] 4 bytes : one 32 bits integer : Credential stamp
 * <li>  [9] 4 bytes : one 32 bits integer : Credential machine name length
 * <li>  some bytes :                       Credential machine name
 * <li>  some bytes : name padding byte to (name = X * 4 bytes)
 * <li>  4 bytes : one 32 bits integer : UID user id
 * <li>  4 bytes : one 32 bits integer : GID group id
 * <li>  some more bytes follow
 *</ul>
 * Under UDP : [3] and [4] to determine RPC port
 *
 */
public class rpcudp extends rpc {

    /**
     * This is the Socket to accept client requests
     */
    private DatagramSocket clientSocket = null;

    private byte [] buf;

    /**
     * This is the only constructor
     * @param argv is the command line
     * @param c is the XtremWeb config
     */
    public rpcudp (String [] argv, XWConfigurator c) {

        super ("UDP", argv, c);
        buf = new byte [BUFSIZE];
    }

    /**
     * This creates a new ServerSocket and listen to
     */
    public void run () {

        int port = config.getPort(Connection.SUNRPC,
                                  Connection.SUNRPC.defaultPortValue());
        try{
            clientSocket = new DatagramSocket(port);
            System.out.println ("XtremWeb for SunRPC listening on UDP port: " + 
                                clientSocket.getLocalPort ());
        }
        catch (IOException e) {
            warn("Could not listen on UDP port " + port +
                 ". xtremweb.rpcd.client.rpcudp stops now." );
            throw new IllegalThreadStateException("Could not listen on UDP port " + port);
        }

        while (true) {

            try{
                debug ("accepting...");

                //                byte[] buf = new byte [BUFSIZE];
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                clientSocket.receive (packet);

                debug ("accepted...");

                /*
                  byte[] datas = packet.getData ();
                  int [] integers = io.bytes2integers (datas, datas.length);
                  int prog = integers [3];

                  logger.debug ("prog " + prog);

                  if (piped != null)
                  piped.udp (clientSocket, packet, integers);
                  else {
                  callback.udp(clientSocket, packet, integers);
                */
                if (piped != null)
                    piped.udp (clientSocket, packet);
                else {
                    callback.udp(clientSocket, packet);
                    /*
                      switch (prog) {
                      case rpcdefs.RPC_NFS:
                      //										nfsd = new CallbackNfsd (argv, config);
                      nfsd.udp (clientSocket, packet, integers);
                      break;
                      case rpcdefs.RPC_MOUNT:
                      //										mountd = new CallbackMountd (argv, config);
                      mountd.udp (clientSocket, packet, integers);
                      break;
                      }
                    */
                }
            }
            catch (Exception e) {
                e.printStackTrace ();
                error ("connect() exception " + e);
                if(debug())
                    e.printStackTrace ();
            }
        }
    }


    /**
     * This is the standard main function for debug purposes
     */
    public static void main (String [] argv) {

        rpcudp client;

        client = new rpcudp (argv, null);
        client.run ();
    }

}// rpcudp
