/**
 *  File : MacSaver.java
 *  Purpose : MacOSX activator implementation based on screen saver
 *  Author : Oleg Lodygensky
 *  Date : August, 12th 2004
 */

package xtremweb.worker;

import xtremweb.archdep.MacSaver;

/**
 * Mac OS X activator that checks if the screensaver is running to
 * decide if the worker can be started</p>
 * 
 * @author Oleg Lodygensky
 */
 
public class MacSaverActivator extends PollingActivator {
   
		/**
		 * This tells whether the worker can start computing, accordingly to the 
		 * local activation policy
		 * @return true if the work can start computing
		 */    
    protected boolean canStart () {
        int running = MacSaver.running ();
        System.out.println ("MacSaver = " + running);
        return running <= 0;
    }
    
		/**
		 * This tells whether the worker must stop computing, accordingly to the 
		 * local activation policy
		 * @return true if the work must stop computing
		 */    
    protected boolean mustStop () {
        return !canStart ();
    }
}
