package xtremweb.worker;

/**
 * RestartException.java
 * An exception causing all threads to shutdown
 *
 * Created: Sun Mar 25 18:49:43 2001
 *
 * @author Gilles Fedak
 */

public class RestartException extends Exception{
    public RestartException (){
    super();
    }

     public RestartException (String s){
    super(s);
    }
   

}// RestartException
