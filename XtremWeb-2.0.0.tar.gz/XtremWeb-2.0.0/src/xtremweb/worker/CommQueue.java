package xtremweb.worker;
/**
 * CommQueue.java
 *
 *
 * Created: Thu Nov 15 14:39:07 2001
 *
 * @author <a href="mailto: "Gilles Fedak</a>
 */

import xtremweb.common.*;

import java.io.*;
import java.util.*;
import java.lang.*;

/**
 * This abstract class defines message container : a class that
 * holds messages to compute
 */
abstract public class CommQueue extends Logger {

    /** This defines maximum number of simultaneous messages. Default value is 2 */
    public static final int MAX_COMMEVENT_INPROGRESS = 2;

    /** This insert a work request in message queue*/ 
    abstract public  void workRequest();
    /** This inserts a work request in message queue*/ 
    abstract public  void sendResult(Work w);
    /** 
     * This retreives the next message from queue 
     * @return the next available message, or null if none
     */ 
    //		abstract public  CommEvent getCommEvent() throws InterruptedException;
    abstract public  CommEvent getCommEvent();
    /**
     * This removes the message from queue
     * @param ce is the message to remove
     */ 
    abstract public  void removeCommEvent(CommEvent ce);
    /**
     * This returns the number of events in queue
     * @return the number of events in queue
     */
    abstract public int size();
    /**
     * This returns the number of events of the given type in queue
     * @param type is the type of the event
     * @return the number of events of the given type in queue		 
     */
    abstract public int size(int type);

}// CommQueue

			 
