package xtremweb.worker;

// TCPActivator.java
// 
// Created: Mon Apr 22 2002

import xtremweb.common.XWPropertyDefs;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.net.SocketException;
import java.io.InterruptedIOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.IOException;

/** <p>Simple Activator that reads its activity mask from a socket</p>
 * 
 * @author Samuel H&eacute;riard
 */
 
 
public class TCPActivator extends Activator implements Runnable {

    protected int default_port = 4567;
        
    protected int m_port ;
    protected InetAddress m_addr;
    protected boolean m_feedback;
        
    protected void setListen() throws UnknownHostException {
        String listen = Worker.config.getProperty("activator.tcp.listen");
        m_port = default_port;
        m_addr = InetAddress.getLocalHost();
        if (! (listen == null || listen.equals(""))) {
            try {
                int i = listen.indexOf(':');
                if (i < 0) {
                    try {
                        m_port = Integer.parseInt(listen);
                    } catch (NumberFormatException e) {
                        m_addr = InetAddress.getByName(listen);
                    }
                } else {

                    if (i > 1 || (i == 1 && listen.charAt(0) != '*')) {
                        m_addr = InetAddress.getByName(listen.substring(0, i));
                    } else {
                        m_addr = null;
                    }
                    m_port = Integer.parseInt(listen.substring(i+1, listen.length()));
                }
            } catch (UnknownHostException e) {
                throw e;
            } catch (Throwable e) {
                warn("can't parse 'activator.tcp.listen=" + listen + "' " + e);
                m_port = default_port;
                m_addr = InetAddress.getLocalHost();
            }
        }
    }
       
                    
    public TCPActivator() {
        try {
            this.setListen();
            debug ("TCPActivator will listen on " + m_addr + ":" + m_port);
            m_feedback = Worker.config.getBoolean(XWPropertyDefs.TCPACTIVATORFEEDBACK, true);
            if (m_feedback) 
                debug ("feedback enable");
        } catch (Exception e) {
            error("problem while reading config " + e);
        }
    }
    
    public void run() {
        ServerSocket servsock;
        int soTimeout = 0;
        try {
            servsock = new ServerSocket(m_port, 1, m_addr);
        } catch (IOException e) {
            error("Can't start " + e);
            return;
        }

        //(SHD)
        // Under Unix, accept raise an IOException when the thread is interrupted
        // but it's not the case under Windows (tested with NT4)
        //if (System.getProperty("os.name").equals("Windows NT") )
        //        soTimeout = 1000;
        // seems to be different of what I was thinking, with IBM JDKs, accept() raises an 
        // InterruptedIOException when the thread is interrupted, not with SUN JDKs
        soTimeout = 1000;
        while (! Thread.interrupted()) {
            Socket control;
            BufferedReader input;
            PrintWriter output;
            try { 
                servsock.setSoTimeout(soTimeout);
                control = servsock.accept();
            } catch (InterruptedIOException e) {
                continue;
            } catch (IOException e) {
                error("I/O error" + e);
                Thread.currentThread().interrupt();
                continue;
            }
            
            try {
                input = new BufferedReader(new InputStreamReader(control.getInputStream()));
                output = null;
                if (m_feedback) {
                    output = new PrintWriter(control.getOutputStream());
                    output.print("XW TCPActivator\r\n" + getMask() + "> ");
                    output.flush();
                }
            
                for (String line = input.readLine(); line != null; line = input.readLine()) {
                    try {
                        int mask = Integer.parseInt(line);
                        synchronized (this) { 
                            setMask(mask);
                            notify();
                        }
                        if (m_feedback) {
                            output.print("OK\r\n"  + getMask() + "> ");
                            output.flush();
                        }
                    } catch (NumberFormatException e) {
                        if (m_feedback) {
                            output.print("ERROR\r\n"  + getMask() + "> ");
                            output.flush();
                        }
                    }
                }
            } catch (IOException e) {
                error("a problem occured " + e);
                try { control.close(); } catch (IOException ie) {
                    error("can't close the socket " + ie);
                }
            }
        } // while
        try { servsock.close(); } catch (IOException ie) {
            error("can't close the socket " + ie);
        }
    }
}                    
                
