package xtremweb.worker;
// Activator.java
//
// Created: Thu Mar 21 2002.


import xtremweb.common.util;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.MileStone;
import xtremweb.common.Logger;
import xtremweb.common.LoggerLevel;

import java.util.Properties;


/**
 *  Subclasses of the <CODE>Activator</CODE> class can be used 
 *  to control the activity of the worker.
 *  The name of the class to be used must be given in the config file 
 *  with the key <CODE>activator.class</CODE>.
 *  <BR> 
 *  If the activator object implements the <CODE>Runable</CODE> interface, 
 *  the worker will launch a new thread to run it.
 *  
 *  @author Samuel Heriard.
 *  @version @VERSION@ 
 *
 */

public abstract class Activator extends Logger {
    
    public static int CPU_ACTIVITY = 1;
    public static int NETWORK_ACTIVITY = 1 << 1;
    public static int DISK_ACTIVITY = 1 << 2;
    public static int ALL_ACTIVITY = ~ 0;

    protected int activityMask;

    /**
     * This aims to display some time stamps
     */
    MileStone mileStone;
    /** 
     * This is the config properties.
     */
    protected Properties config;

    /**
     * This contains this activator parameter string
     */
    String params;

    
    public Activator() {
        level = LoggerLevel.INFO;

        try {
            mileStone = new MileStone(getClass().getName());
        }
        catch(Exception e) {
        }
        params = null;
    }
    
    /**
     * The <CODE>initialize</CODE> method is invoked after the 
     * instantiation of the <CODE>Activator</CODE> object.
     *
     * @param config a <CODE>Properties</CODE> object that can be used 
     *      to configure the activator. For now the global config 
     *      of the worker is passed.
     * @exception Exception is thrown on initialization error, depending on the Acivator implementation
     */
    public void initialize(Properties c) {
        config = c;
    }
    /**
     * This sets this activator parameters.
     */    
    public void setParams(String p) {
        params = p;
    }
    /**
     * This returns this activator parameters.
     * @return a String containing this activator parameters
     */    
    public String getParams() {
        return params;
    }
    /**
     * This does nothing
     * @see CpuActivator#raz ()
     */    
    public void raz() {
    }
    /**
     * Change the activity mask
     *
     * @param mask new activity mask
     */
    
    protected void setMask(int mask) {
        activityMask = mask;
    }

    /**
     * @return the actvity mask : 
     *  <CODE>getMask()&XXX_ACTIVITY == 0</CODE> means no XXX activity allowed.
     */
    public int getMask() {
        return activityMask;
    }

    public final int getMask(int filter) {
        return filter & getMask();
    }
    /**
     * Check if activity is allowed.
     * @param mask : mask of activity to test
     * @return true if all the activities specified are allowed
     */
    public final boolean allowed(int mask) {
        return ((~getMask() & mask) == 0);
    }
    
    /**
     * Check if activity is allowed.
     * @param mask : mask of activity to test
     * @return true if one of the activities specified is allowed
     */ 
    public final boolean anyAllowed(int mask) {
        return (getMask(mask) != 0);
    }
    
    /**
     * wait for a bit in the activity mask to become 0
     * @param filter : watch only bits not nul in <CODE>filter</CODE>
     * @return : the mask of watched bits that have changed
     */
    public int waitForSuspend(int filter) throws InterruptedException {
        int inactive = ~ getMask() & filter;
        if (inactive != 0) return 0;
        else return this.waitForEvent(filter);
    }
        
    /**
     * wait for a bit in the activity mask to be 1
     * @param filter watch only bits not nul in <CODE>filter</CODE>
     * @return the mask of watched bits that have changed
     (0 if an activity is already allowed)
    */
    public int waitForAllow(int filter) throws InterruptedException {
        int active = getMask() & filter;
        if (active != 0) return 0;
        else return this.waitForEvent(filter);
    }

    /**
     * Wait for any change in activity mask.
     *
     * This method wait for the activator object to be notified 
     * until the activityMask changes.
     * 
     * Subclasses can either override this method or let it unchanged and implement 
     * a <CODE>run</CODE> method to modify the activity mask and notify itself 
     * in a separate thread.
     *
     * @param mask set the event to wait for
     * @return : the mask of watched bits that have changed
     */
    public int waitForEvent(int mask) throws InterruptedException {
        int oldm = getMask(mask);
        int newm = oldm;
        
        while (oldm == newm) {
            try {
                synchronized (this) { 
                    this.wait(); 
                    notifyAll();
                }
            } catch (IllegalMonitorStateException e) { 
                util.fatal("unrecoverable exception" + e);
            } 
            newm = getMask(mask);
        }
        // oldm xor newm, c'est quoi xor en java ?
        return (oldm|newm)&~(oldm&newm);
    }
}
