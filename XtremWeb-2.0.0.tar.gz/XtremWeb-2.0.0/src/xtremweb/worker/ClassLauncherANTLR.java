package xtremweb.worker;

import xtremweb.common.*;



/**
 * File : ClassLauncherANTLR.java
 *
 * Created: May 26th, 2003
 *
 * @since v1r2-rc3 (RPC-V)
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 *
 * This tries to instanciate a class and run a specific method
 * Usage: java ClassLauncherANTLR 
 *       --exec 
 *         "[aFile.jar':']aClass'.'aMethod ['('type0 value0',' ...',' typeN valueN')']"
 *              where TypeN = a) SimpleType 
 *                                 'boolean' | 'char' | 'byte'  | 'short'  |
 *                                 'int'     | 'long' | 'float' | 'double' | 'String'
 *                            b) array (vector like)
 *                                 SimpleTypeint '['']'
 *                            b) array (matrice like)
 *                                 SimpleTypeint '['']''['']'
 *
 *              and valueN =  a) SimpleType 
 *                                 'true', 'false', '0', 'my string' etc.
 *                            b) array (VectorLike)
 *                                  '{'SimpleType';' ... '}'
 *                            b) array (matrice like)
 *                                  {VectorLike'\t'VectorLike'\t' ... }
 *
 *                            where '\t' is the tab character
 *
 *
 *      [--listmethods]
 *      [--verbose]
 *      [--help]
 *
 *
 * Examples : 
 * $> javac MyPrint.java
 * $> java -classpath ./ ClassLauncherANTLR --exec "MyPrint.add(int 4,int 1)"
 * 5
 * $>
 * $> jar cvfm MyPrint.manifest MyPrint.jar MyPrint.class
 * $> java -classpath ./ ClassLauncherANTLR --exec "MyPrint.jar:MyPrint.print(String a b.c)"
 * a b.c
 * $>
 * $> java -classpath ./ ClassLauncherANTLR --exec \
 *    "MyPrint.jar:MyPrint.print(int[] {100;200;300})"
 * 0 = 100
 * 1 = 200
 * 2 = 300
 * $>
 * $> java -classpath ./ ClassLauncherANTLR --exec \
 *    "MyPrint.jar:MyPrint.print(int[][] {{1;2}\t{3;4}\t{5;6}})"
 * 0,0 = 1
 * 0,1 = 2
 * 1,0 = 3
 * 1,1 = 4
 * 2,0 = 5
 * 2,1 = 6
 * $>
 */

import java.io.*;
import java.lang.reflect.*;
import java.text.ParseException;
import java.util.Vector;
import java.util.ArrayList;
import java.util.StringTokenizer;


public class ClassLauncherANTLR extends Logger {

    /**
     * This turns verbose mode on/off
     */
    private boolean verbose;
    /**
     * This tells to list methods
     */
    private boolean listMethod;
    /**
     * This contains method call definitions
     */
    private CallDef callDef;


    /**
     * This is the default constructor
     */
    private void ClassLauncherANTLR () {
        verbose = true;
        listMethod = false;
        callDef = null;
        level = LoggerLevel.INFO;
    }


    private void print (String str)
    {
        if (verbose )
            System.out.print (str);
    }


    private void println (String str)
    {
        if (verbose )
            System.out.println (str);
    }


    /**
     * This shows application usage
     */
    private void usage ()
    {
        System.out.println ("Available arguments :");
        System.out.println ("  --exec  \"[aFile.jar:]aClass.aMethod [(type0 arg0, ..., typeN argN)]\"");
        System.out.println ("  --help   | -h to get this help");
        System.out.println ("  --listmethods to list class methods");
        System.out.println ("  --verbose");
        System.exit (0);
    }


    /**
     * This parses the jar, class, method and method arguments
     * @param execCmdLine is a String containing
     * @exception ParseException
     * @see #usage()
     */
    private CallDef extractCallParams (String execCmdLine)
        throws ParseException, Exception {

        //MethodLexer lexer = new MethodLexer (new DataInputStream (System.in));
        MethodLexer lexer = 
            new MethodLexer (new ByteArrayInputStream (execCmdLine.getBytes ()));
        MethodParser parser = new MethodParser (lexer);

        try {
            return parser.methodCall ();
        } catch (Exception e) {
            println ("parsing exception");
            throw new Exception (e.toString ());
        }

    } // extractCallParams ()


    /**
     * This parses arguments provided on the command line
     * @param args is an array of String containing the arguments
     * @exception ParseException
     * @see #usage()
     */
    public void parseArgs(ArrayList args)
        throws ParseException, Exception {
        if (args == null)
            throw new Exception ("parsArgs() : args is null");

        String[] ret = new String [args.size ()];
        for (int i = 0; i < args.size (); i++) {
            ret [i] = (String)args.get (i);
            System.err.println ("ret["+ i +"] = " + ret[i]);
        }

        parseArgs (ret);

    } // parseAgrs (ArrayList)


    /**
     * This parses arguments provided on the command line
     * @param args is String containing the arguments
     * @exception ParseException
     * @see #usage()
     */
    public void parseArgs(String args)
        throws ParseException, Exception {

        int execIdx = -1;
        int paramsIdx = -1;
        int index = -1;
        String argsLowerCase = args.toLowerCase ();

        if ((args == null) || (args.length () == 0))
            throw new ParseException ("no arg provided", 0);

        execIdx = argsLowerCase.indexOf ("--exec");
        if (execIdx == -1)
            throw new ParseException ("'--exec' not found", 0);

        //
        // Retreive method to exec; its jar file, class and parameters
        //
        debug ("args to parse = " + args.substring (7));
        callDef = extractCallParams (args.substring (7));
        debug ("callDef = " + callDef.toString ());

    } // parseAgrs (String)


    /**
     * This parses arguments provided on the command line
     * @param args is an array of String containing the arguments
     * @exception ParseException
     * @see #usage()
     */
    public void parseArgs(String[] args)
        throws ParseException, Exception {

        if (args.length == 0)
            throw new ParseException ("no arg provided", 0);

        for (int i = 0; i < args.length;) {
            if (args [i].toLowerCase ().compareTo ("--verbose") == 0)
                verbose = true;
            /*
              else if ((args [i].toLowerCase ().compareTo ("-h") == 0) ||
              (args [i].toLowerCase ().compareTo ("--help") == 0)) {
              usage ();
              }
            */
            else if (args [i].toLowerCase ().compareTo ("--listmethod") == 0) {
                listMethod = true;
                verbose = true;
            }
            //
            // Retreive method to exec; its jar file, class and parameters
            //
            else if (args [i].toLowerCase ().compareTo ("--exec") == 0) {
                callDef = extractCallParams (args [++i]);
                println ("callDef = " + callDef.toString ());
            }
            i++;
        }

    } // end parseArgs (String [])


    public Object createObject(Constructor constructor, 
                               Object[] arguments) {

        println ("Constructor: " + constructor.toString());
        Object object = null;

        try {
            object = constructor.newInstance(arguments);
            println ("Object: " + object.toString());
            return object;
        } catch (InstantiationException e) {
            println(e.toString ());
            e.printStackTrace ();
        } catch (IllegalAccessException e) {
            println(e.toString ());
            e.printStackTrace ();
        } catch (IllegalArgumentException e) {
            println(e.toString ());
        } catch (InvocationTargetException e) {
            println(e.toString ());
            e.printStackTrace ();
        }
        return object;
    }


    /**
     * This display the methods array given as params
     * @param theMethods is an array of Method objects to dump
     */
    void showMethods(Method[] theMethods) {

        for (int i = 0; i < theMethods.length; i++) {
            String methodString = theMethods[i].getName();
            String returnString =
                theMethods[i].getReturnType().getName();

            print(returnString +" " + methodString + "(");

            Class[] parameterTypes = theMethods[i].getParameterTypes();
            for (int k = 0; k < parameterTypes.length; k ++) {
                String parameterString = parameterTypes[k].getName();
                print(parameterString);
                if (k != parameterTypes.length - 1)
                    print(", ");
            }
            println(")");
        }
    }


    /**
     * This runs a java class
     * @throws NoSuchFieldException if method (determined by the given signature)
     *                              is not found
     * @throws ClassNotFoundException if class or jar file are not found
     *                                in the provided class
     * @throws Exception on other error
     * @return the result of the computation encapsulated in an Object
     *         null for void method
     */
    protected Object executeJavaJob () 
        throws Exception, NoSuchFieldException, ClassNotFoundException {

        Object ret = null;

        try {
            String myJarName = Worker.config.binCachedPath + File.separator + callDef.getJarFileName ();
            String myClassName = callDef.getClassName ();
            Class myClass = null;

            if (myJarName != null) { // java -jar jjj.jar yyy.xxx.myClass  
                myJarName = (new File(myJarName)).getAbsolutePath();

                System.err.println ("\n\n\njar file = " + myJarName + "\n\n\n");
                JarClassLoader jarLoader = new JarClassLoader(myJarName);
                myClass = jarLoader.loadClass (myClassName, true);
            }
            else if (myClassName != null ) { // java yyy.xxx.myClass  

                NewClassLoader classLoader = new NewClassLoader();
                classLoader.addClassPath("./");
                myClass = classLoader.loadClass(myClassName, true); 
            }
            else {
                throw new ClassNotFoundException ("nor jar neither class provided (???)");
            }

            Method[] myMethods = null;
            boolean trouve = false;

            Object myObj = null;

            if (myClass != null ) {
                myMethods = myClass.getMethods();
                myObj = (Object)myClass.newInstance ();
            }

            if (listMethod )
                showMethods (myMethods);

            String methodName = callDef.getMethodName ();
            if (methodName == null)
                methodName = new String ("main");

            Class[] methodArgsType = callDef.getParamTypes ();
            if ((methodArgsType != null) && (methodArgsType.length == 0))
                methodArgsType = null;

            if (methodArgsType != null)
                println ("argsType = " + methodArgsType.toString());

            Method myMethod = null;

            try {
                myMethod = myClass.getMethod(methodName, methodArgsType);
            }
            catch (Exception e) {
                myMethod = null;
            }
            if (myMethod == null ) {
                throw new NoSuchFieldException ("can't find method " + methodName);
            }

            Object[] methodArgsValue = callDef.getParamValues ();
            if ((methodArgsValue != null) && (methodArgsValue.length == 0))
                methodArgsValue= null;

            if (methodArgsValue != null)
                println ("argsValue = " + methodArgsValue.toString());
            ret = myMethod.invoke(myObj, methodArgsValue);
        }
        catch (Exception e) {
            println (e.toString ());
            e.printStackTrace ();
            throw new Exception (e.toString ());
        }

        return ret;

    } //executeJavaJob ()


    /**
     * This is the standard java entry point
     */
    public static void main(String[] argv) {

        ClassLauncherANTLR launcher = null;

        try {
            launcher = new ClassLauncherANTLR();
            launcher.parseArgs (argv);
            Object result = launcher.executeJavaJob ();
            if (result != null)
                System.out.println (result.toString ());
        }
        catch (Exception e) {
            System.out.println (e.toString ());
            //if (launcher.verbose)
            e.printStackTrace ();
        }
    }

} //class ClassLauncherANTLR
