package xtremweb.worker;
/**
 *  AlwaysActive.java<br />
 *  This activator never suspends the worker; the worker is alays allowed to compute<br /> 
 *  Created on Fri Mar 22 2002.<br />
 *
 * @author heriard
 */

import xtremweb.common.MileStone;
import xtremweb.common.util;

import java.util.Properties;

public class AlwaysActive extends Activator {

    /** This is the default and only constructor */
    public AlwaysActive() {
        super();
    }

    public void initialize(Properties c) {
        super.initialize(c);
        setMask(ALL_ACTIVITY);
    }

    /**
     * This forces params to null
     * @param p is not used
     */    
    public void setParams(String p) {
        params = null;
    }
    /**
     * This returns null
     * @return always null
     */    
    public String getParams() {
        return null;
    }
    /**
     * This waits for ever since this class is the <b>AlwaysActive</b> activator ;)
     * @param filter not used
     * @return never
     * @see Activator#waitForAllow(int)
     * @exception InterruptedException is never thrown
     */
    public final int waitForSuspend(int filter) throws InterruptedException {

        while(true) {
            mileStone.println("waitForSuspend");
            try {
                synchronized (this) { 
                    this.wait(); 
                    notifyAll();
                }
            } catch (IllegalMonitorStateException e) { 
                util.fatal("unrecoverable exception" + e);
            } 
        }
    }
        
    /**
     * This waits nothing and returns immediatly since this class is the <b>AlwaysActive</b> activator ;)
     * @param filter is not used
     * @return always 0
     * @see Activator#waitForAllow(int)
     * @exception InterruptedException is never thrown
     */
    public final int waitForAllow(int filter) throws InterruptedException {
        mileStone.println("waitForAllow");
        return 0;
    }
}
