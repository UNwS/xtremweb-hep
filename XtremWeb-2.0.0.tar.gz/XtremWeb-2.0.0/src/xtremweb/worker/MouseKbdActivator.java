package xtremweb.worker;

//  MouseKbdActivator.java
//  
//  Created by heriard on Wed Apr 3 2002.


import xtremweb.archdep.ArchDepFactory;
import xtremweb.archdep.XWInterrupts;

/**
 * <CODE>MouseKbdActivator</CODE> 
 * activator for that monitors keyboard and mouse activity.
 * This activator use XWInterrupts to monitor activity.
 *
 * @author Samuel Heriard
 *
 */


public class MouseKbdActivator extends PollingActivator {

    /** interrupt counters */
    private int lastKey = 0;
    private int lastMouse = 0;
    private boolean initialized = false;

    private int remains = activationDelay;
    private XWInterrupts irq = ArchDepFactory.xwinterrupts();

    /**
     * This is the default contructor
     * This initializes IRQ counter
     */
    public MouseKbdActivator () {
				super();
				initialized = irq.initialize ();
				remains = activationDelay;
				if (remains <= 0)
						remains = 60000;
				debug("MouseKbdActivator " + initialized + 
                      activationDelay + " " + remains);
    }


    /** return true if the user is active */
    private boolean isActive() {
        int newKey;
        int newMouse;
        boolean differ = false;
        
        // TODO(shd): remove static reference to Worker.config
        //              (move hasKey and hasMouse to XWInterrupts)

        if (Worker.config.hasKeyboard) {
            newKey = irq.readKey();
            differ = differ || (newKey != lastKey);
						debug("isactive() key " + newKey + " " + lastKey + " " + differ);
            lastKey = newKey;
        }
        
        if (Worker.config.hasMouse) {
            newMouse  = irq.readMouse();
            differ = differ || (newMouse != lastMouse);
						debug("isactive() mouse " + newMouse + " " + lastMouse + " " + differ);
            lastMouse = newMouse;
        }

        return differ;
    }

		/**
		 * This tells whether the worker can start computing, accordingly to the 
		 * local activation policy
		 * @return true if the work can start computing
		 */    
    protected boolean canStart() {

        if (this.isActive()) {
            remains = activationDelay;
        }
				else {
            remains -= waitingProbeInterval;
        }
        info("activation in " + remains + " ms");

        return (remains <= 0);    

    }

		/**
		 * This tells whether the worker must stop computing, accordingly to the 
		 * local activation policy
		 * @return true if the work must stop computing
		 */    
    protected boolean mustStop() {
        boolean ret = isActive ();
        if (ret) {
            remains = activationDelay;
						lastKey--;
				}
				return ret;
    }

}
