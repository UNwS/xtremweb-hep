package xtremweb.worker;
import java.io.*;
/**
 *   Get Activity, that is the CPU state %of CPU time used by user
 */

import java.net.*;

public class Ps {
    private static int[] pid = new int[1000];
    private static int[] us = new int[1000];
    private static int[] sy = new int[1000];
    private static int id;
    private static long somme;
    private static long userTot;
    private static long niceTot;
    private static long systemTot;
    private static long idleTot;

    private static void stat() {
        Runtime machine;
        machine = java.lang.Runtime.getRuntime();
        String ligne;
        Process ls;
        BufferedReader input;
        long jiffies;
        int index, i, j;
    try {
        //on recupere la liste des process
        ls = machine.exec("ls -A1 /proc");
        ls.waitFor();
        input = new BufferedReader(new InputStreamReader(ls.getInputStream()));
        
        id = 0;
        while(input.ready()) {
        ligne = input.readLine();
        try {
            //on ne garde que ce qui est numerique (i.e. pid)
            pid[id]=Integer.valueOf(ligne).intValue();
            BufferedReader pidstat = new BufferedReader(new FileReader("/proc/"+pid[id]+"/stat"));
            ligne = pidstat.readLine();
            pidstat.close();
            index=0;
            for(i=0;i<13;i++) {
            index=ligne.indexOf(' ',index+1);
            }
            //on recupere les jiffies user et system du process
            us[id]=Integer.valueOf(ligne.substring(index,ligne.indexOf(' ',index+1)).trim()).intValue();
            index=ligne.indexOf(' ',index+1);
            sy[id]=Integer.valueOf(ligne.substring(index,ligne.indexOf(' ',index+1)).trim()).intValue();
            id++;
                    
        } catch (Exception e) {} //ce n'est pas numerique
        }

        //lecture de la premiere ligne de /proc/stat "cpu long:user long:nice long:sys long:idle"
        BufferedReader stat = new BufferedReader(new FileReader("/proc/stat"));
        ligne = stat.readLine();
        stat.close();
        ligne=ligne.trim();
        somme=0;
        userTot=0;
        niceTot=0;
        systemTot=0;
        idleTot=0;
        for(i=0;i<5;i++) {
        try {
            index=ligne.indexOf(' ');
            if(index!=-1) {
            jiffies=Long.valueOf(ligne.substring(0,index).trim()).longValue();
            } else {
            jiffies=Long.valueOf(ligne.trim()).longValue();
            }
            somme=somme+jiffies; //somme=user+nice+sys+idle
            if (i==1) {userTot=jiffies;}
            if (i==2) {niceTot=jiffies;}
            if (i==3) {systemTot=jiffies;}
            if (i==4) {idleTot=jiffies;}
        } catch (Exception e) {}
        try {
            ligne=ligne.substring(ligne.indexOf(' ')).trim();
        } catch (Exception e) {}
        }

          

    } catch (Exception e) {System.out.println("erreur: " + e.getMessage());}
    }


    public static int ps(int delai) {
        int idOld, user, system;
        long userTotOld;
        long niceTotOld;
        long systemTotOld;
        long idleTotOld;
        long sommeOld;
        int[] pidOld = new int[1000];
        int[] usOld = new int[1000];
        int[] syOld = new int[1000];

        sommeOld=0;
        userTotOld=0;
        niceTotOld=0;
        systemTotOld=0;
        idleTotOld=0;
        idOld=0;

    stat();

    //mise a jour des valeurs de depart
    idOld=id;
    pidOld=pid;
    usOld=us;
    syOld=sy;
    sommeOld=somme;
    userTotOld=userTot;
    niceTotOld=niceTot;
    systemTotOld=systemTot;
    idleTotOld=idleTot;

    try{
        java.lang.Thread.sleep(delai);
    } catch (Exception e) {}

    stat();

    //calcul du nombre de jiffies dans l'intervalle pour chaque process
    user=0;system=0;
    for(int i=0;i<id;i++) {
        for(int j=0;j<idOld;j++) {
        if(pid[i]==pidOld[j]) {
            user=user+us[i]-usOld[j];
            system=system+sy[i]-syOld[j];
        }
        }
    }

    return((int)((userTot-userTotOld)*100/(somme-sommeOld)));

    }
}
/*
                 System.out.println("%CPU user:"+user*100/(somme-sommeOld)+" system:"+system*100/(somme-sommeOld));
                  System.out.println("CPU states: "+(userTot-userTotOld)*100/(somme-sommeOld)+"% user, "+(systemTot-systemTotOld)*100/(somme-sommeOld)+"% system, "+(niceTot-niceTotOld)*100/(somme-sommeOld)+"% nice, "+(idleTot-idleTotOld)*100/(somme-sommeOld)+"% idle");
*/





