package xtremweb.worker;

import xtremweb.common.util;
import xtremweb.common.LoggerableThread;
import xtremweb.common.LoggerLevel;
import xtremweb.common.UID;
import xtremweb.common.UserRights;
import xtremweb.common.AppInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.CommonVersion;
import xtremweb.common.XWPropertyDefs;

import xtremweb.communications.CommClient;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Map;
import java.util.Iterator;
import java.util.Enumeration;
import java.util.Date;
import java.rmi.RemoteException;
import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.Response;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.handler.AbstractHandler;


/**
 * This handles incoming communications through HTTP.
 * This class aims to help the worker owner to configure its worker.
 * This owner can configure its worker via a web browser.<br />
 * 
 * Created: Octobre 2007
 *
 * @author Oleg Lodygensky
 * @version XWHEP 1.0.0
 */


public class HTTPStatHandler extends LoggerableThread 
    implements org.mortbay.jetty.Handler {

    Request request;
    HttpServletResponse response;
    Hashtable activators;
    Hashtable activatorHelps;
    Hashtable activatorParams;

    /** This is the default project : by default the worker accepts any project */
    private final static String DEFAULTPROJECT = "any";
    /** This is an HTML form input name */
    private final static String MAXJOBS = "maxJobs";
    /** This is an HTML form input name */
    private final static String STOPWORKER = "exit";
    /** This is an HTML form input name */
    private final static String DIVAIDE = "divAide";
    /** This is an HTML form input name */
    private final static String ACTIVATORSELECTOR = "selectActivator";
    /** This is an HTML form input name */
    private final static String ACTIVATORPARAMS   = "activatorParams";
    /** This is an HTML form input name */
    private final static String PROJECTSELECTOR   = "selectProject";
    /**
     * This is the client host name; for debug purposes only
     */
    protected String remoteName;
    /**
     * This is the client IP addr; for debug purposes only
     */
    protected String remoteIP;
    /**
     * This is the client port; for debug purposes only
     */
    protected int remotePort;
    /**
     * This has been constructed from config file
     */
    protected Date dater;
    /**
     * This is the default constructor which only calls super("HTTPStatHandler")
     */
    public HTTPStatHandler(){
        super("HTTPStatHandler");
        activators = new Hashtable();
        activatorHelps = new Hashtable();
        activatorParams = new Hashtable();
        activators.put("always", "xtremweb.worker.AlwaysActive");
        activators.put("crontab", "xtremweb.worker.DateActivator");

        activatorHelps.put("always", "This fully enables computation");
        activatorHelps.put("crontab", "This enables computation according to schedule gaps");

        activatorParams.put("always", new Boolean(false));
        activatorParams.put("crontab", new Boolean(true));
    }
    /**
     * This constructor call the default constructor and sets the logger level
     * @param l is the logger level
     * @see #HTTPStatHandler(XWConfigurator)
     */
    public HTTPStatHandler(LoggerLevel l) throws RemoteException {
        this();
        setLoggerLevel(l);
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.jetty.Handler
     */
    public void setServer(Server server) {
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.jetty.Handler
     */
    public Server getServer() {
        return null;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return true
     */
    public boolean isFailed() {
        return true;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isRunning() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStarted() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStarting() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return true
     */
    public boolean isStopped() {
        return true;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStopping() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     */
    public void start() {
    }
    /**
     * This cleans and closes communications
     */
    public void close(){
        //Clean up 
        debug("close");
    }
    /**
     * This handles incoming connections.
     * This is inherited from org.mortbay.jetty.Handler.
     * @see xtremweb.communications#XWPostParams
     */
    public void handle(String target, 
                       HttpServletRequest _request, 
                       HttpServletResponse _response, 
                       int dispatch)
        throws IOException, ServletException {

        request = (_request instanceof Request) ?
            (Request)_request : 
            HttpConnection.getCurrentConnection().getRequest();
        response = _response instanceof Response ?
            (Response)_response :
            HttpConnection.getCurrentConnection().getResponse();

        String path = request.getPathInfo();
        try {
            info("new connection");

            remoteName = request.getRemoteHost();
            remoteIP   = request.getRemoteAddr();
            remotePort = request.getRemotePort();
            
            org.mortbay.jetty.HttpConnection httpConnection = request.getConnection();

            if(request.getParameterMap().size() > 0)
                form();

            index();
            request.setHandled(true);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        response.getWriter().flush();
    }
    /**
     * This executes the HTML form<br />
     * Changes are stored in config file
     */
    private void form() throws IOException {
        Map paramsMap = request.getParameterMap();

        try {
            String stop = ((String[])paramsMap.get(STOPWORKER))[0];
            exit();
        }
        catch(NullPointerException e) {
            // stop is optionnal
        }

        String activator = ((String[])paramsMap.get(ACTIVATORSELECTOR))[0];

        if(activator != null)
            try {
                ThreadLaunch.instance.setupActivator(activator);

            }
            catch(InstantiationException e) {
                throw new IOException(e.toString());
            }

        String actParams = ((String[])paramsMap.get(ACTIVATORPARAMS))[0];
        ThreadLaunch.instance.getActivator().setParams(actParams);

        try {
            String maxjobs = ((String[])paramsMap.get(MAXJOBS))[0];
            if(maxjobs != null) {
                Worker.config.setProperty(XWPropertyDefs.COMPUTINGJOBS.toString(),
                                          "" + Integer.parseInt(maxjobs)); 
            }
        }
        catch(Exception e) {
            // ensure this is really an integer
        }
        try {
            String project   = ((String[])paramsMap.get(PROJECTSELECTOR))  [0];

            if(project != null) {
                if(project.compareToIgnoreCase(DEFAULTPROJECT) == 0)
                    project = "";
                Worker.config._host.setProject(project);
                Worker.config.setProperty(XWPropertyDefs.PROJECT.toString(), project);
            }
        }
        catch(NullPointerException e) {
            // project is optionnal
        }

        Worker.config.store();
    }
    /**
     * This display a last page informing that worker is now dead and exits
     */
    private void exit() throws IOException {
        response.setContentType("text/html");
        response.setStatus(HttpServletResponse.SC_OK);
        css();
        response.getWriter().println("<div class='warning' style='left:30%;top:10%;font-size:26px; width:50%;height:25%;vertical-align:middle;text-align:center;'>" +
                                     "<p>XWHEP Worker has been stopped</p>" + 
                                     "<p style='font-size:14px'><i>It will restart on next reboot (if installed)</i></p>" + 
                                     "</div>");
        response.getWriter().flush();
        request.setHandled(true);
        util.fatal("HTTPStatHandler : exit on user request");
    }
    /**
     * This display the default page
     */
    private void index() throws IOException {
        response.setContentType("text/html");
        response.setStatus(HttpServletResponse.SC_OK);

        css();
        javaScript();

       response.getWriter().println("<div class='titre'><p>XWHEP Worker configuration</p></div>");
        response.getWriter().println("<a style='color:white' href='?exit=1'><div style='left:900; width:90; height:75;background-color:red'><p>STOP<br />the worker now</p></div></a>");
        response.getWriter().println("<div class='resume'><table width='100%'><caption>Summary</caption>"
                                     + Worker.config._host.toHtml() + "</table></div>");

        response.getWriter().println("<div class='configuration'>");
        response.getWriter().println("<form id='workerForm'>");
        response.getWriter().println("<table width='100%'><caption>Configuration</caption>");
        response.getWriter().println("<tr><td class='param'>Uptime : </td><td class='value'>" + 
                                     Worker.config.upTime() + "</td></tr>");

        // we don't know user rights until we connect to server
        if(Worker.config._user.getRights().lowerOrEquals(UserRights.NONE)) {
            try {
                /*
                System.out.println("HTTPStatHandler#index : getuser(" + 
                                   Worker.config._user.getLogin() + ")");

                CommClient commClient = Worker.config.defaultCommClient();
                commClient.setConfig(Worker.config);
                commClient.initComm(Worker.config.getCurrentDispatcher());
                UserInterface user = (UserInterface)commClient.getUser(Worker.config._user.getLogin());
                Worker.config._user.setRights(user.getRights());                
                System.out.println("HTTPStatHandler#index : getuser(" + 
                                   Worker.config._user.getLogin() + ") = " + user.toXml());

                */
            }
            catch(Exception ce) {
                error(ce.toString());
            }
        }

        if(Worker.config._user.getRights().higherThan(UserRights.NONE)) {

            response.getWriter().println("<tr><td class='param'>Class : </td><td class='value'>" + 
                                         (Worker.config._user.getRights().higherOrEquals(UserRights.WORKER_USER) ?
                                          "public worker" : "private")
                                         + "</td></tr>");
        }

        response.getWriter().println("<tr><td class='param'>Active : </td><td class='value'>" + 
                                     Worker.config._host.isActive() +
                                     " : this worker is " + 
                                     (Worker.config._host.isActive() ? "enabled" : "disabled") +
                                     " (the server " + 
                                     (Worker.config._host.isActive() ? "" : "does not") +
                                     " accept to provide jobs to this worker)" + 
                                     "</td></tr>");
        response.getWriter().println("<tr><td class='param'>Available : </td><td class='value'>" + 
                                     ThreadLaunch.instance.available() +
                                     " : the local activation policy" + 
                                     (ThreadLaunch.instance.available() ? "" : " does not") +
                                     " allow computation</td></tr>");
        response.getWriter().println("<tr><td class='param'>Currently running : </td><td class='value'>");

        try {
            Vector runs = ThreadLaunch.instance.runningWorks();
            if(runs.size() <= 0 )
                response.getWriter().println("<i>nothing</i>");                
            else {
                for (Iterator it = runs.iterator (); it.hasNext(); ) {

                    System.out.println("HTTPStatHandler#index : getapp()");

                    CommClient commClient = Worker.config.defaultCommClient();
                    commClient.setConfig(Worker.config);
                    commClient.initComm(Worker.config.getCurrentDispatcher());

                    Work work = (Work)it.next();
                    if(work == null)
                        continue;
                    System.out.println("HTTPStatHandler#index : getapp(" + 
                                       work.getApplication() + ")");
                    AppInterface app = (AppInterface)commClient.get(work.getApplication());
                    System.out.println("HTTPStatHandler#index : getapp(" + 
                                       work.getApplication() + ") = " + app.toXml());
                    response.getWriter().println(" " + app.getName() + "; ");
                }
            }
        }
        catch(Exception e) {
        }

        response.getWriter().println("</td></tr>");

        project();

        response.getWriter().println("<tr><td class='param'>Already computed : </td><td class='value'>" + 
                                     Worker.config.nbJobs + "</td></tr>");

        response.getWriter().println("<tr><td class='param'>Max computations : </td><td class='value'>" + 
                                     "<input name='" + MAXJOBS + "' type='text' " +
                                     "value='" + 
                                     Worker.config.getInt(XWPropertyDefs.COMPUTINGJOBS,
                                                          Integer.parseInt(XWPropertyDefs.COMPUTINGJOBS.value())) + 
                                     "' onblur='hideHelp()' onfocus='showActHelp(this.form, 120, \"The worker stops when max jobs is reached.<br /> A negative value means no limit\")'>" + 
                                     "</td></tr>");

        activator();

        String actParams = ThreadLaunch.instance.getActivator().getParams();
        String actVisibility = "hidden";
        if(actParams != null)
            actVisibility = "visible";
        else
            actParams = "";

        response.getWriter().println("<tr><td class='param'>Activation parameters :</td>" +
                                     "<td class='value' id='" + ACTIVATORPARAMS +
                                     "' style='visibility:" + actVisibility + "' '>" +
                                     "<input name='" + ACTIVATORPARAMS + "' type='text' " +
                                     "value='" + actParams + "' " +
                                     "onblur='hideHelp()' onfocus='showActHelp(this.form, 102, \"e.g.: <li>each night from 8PM to 7AM <code><u><i>*&nbsp;20-7</i></u></code><li>full weekend computation <code><u><i>Sat-Sun&nbsp;*</i></u></code><li>the two previous combined <code><u><i>*&nbsp;20-7,Sat-Sun&nbsp;*</i></u></code>\")'>" + 
                                     "</td></tr></table>");

        response.getWriter().println("<div style='left:480px ;top:82px; width:130px' class='aide' id='" + DIVAIDE + "'></div>");
        response.getWriter().println("<div><input type='submit'></div>");
        response.getWriter().println("</form>");

        response.getWriter().println("</div>");
    }
    /**
     * This displays activator drop down list
     */
    private void activator() throws IOException {

        response.getWriter().println("<tr><td class='param'>Activation policy : </td><td class='value'>");

        Enumeration theEnum = activators.keys();

        response.getWriter().println("<select name='" + ACTIVATORSELECTOR +
                                     "' id='" + ACTIVATORSELECTOR + "'  onchange='showActHelp(this.form, 170)'>");

        String currAct = ThreadLaunch.instance.getActivatorName();

        while(theEnum.hasMoreElements()) {
            String act = (String)theEnum.nextElement();
            String actClassName = (String)activators.get(act);
            response.getWriter().print("<option value='" + actClassName + "'");

            boolean testAct = ((currAct != null) &&
                               (currAct.compareToIgnoreCase(actClassName) == 0));

            if(testAct == true) {
                response.getWriter().print(" selected='selected'");                    
            }

            response.getWriter().println(">" + act + "</option>");
        }

        response.getWriter().println("</select>");

        response.getWriter().println("</td></tr>");
    }
    /**
     * This displays projects drop down list
     */
    private void project() throws IOException {
        response.getWriter().println("<tr><td class='param'>Project : </td><td class='value'>");

        try {
            System.out.println("HTTPStatHandler#project : getusergroups()");
            CommClient commClient = Worker.config.defaultCommClient();
            commClient.setConfig(Worker.config);
            commClient.initComm(Worker.config.getCurrentDispatcher());
            Vector uids = commClient.getUserGroups();
            Enumeration theEnum = uids.elements();

            System.out.println("HTTPStatHandler#project : getusergroups() = " + uids.size());

            response.getWriter().println("<select name='" + PROJECTSELECTOR + "'>" +
                                         "<option value='" + DEFAULTPROJECT+ "'>" + DEFAULTPROJECT + "</option>");

            while(theEnum.hasMoreElements()) {

                UID uid =(UID)theEnum.nextElement();
                UserGroupInterface group = null;

                try {
                    System.out.println("HTTPStatHandler#project : get(" + 
                                       uid + ")");
                    group = (UserGroupInterface)commClient.get(uid);
                    System.out.println("HTTPStatHandler#project : get(" + 
                                       uid + ") = " + group.toXml());
                }
                catch(Exception ce) {
                    error(ce.toString());
                    continue;
                }

                if(group.isProject() == false)
                    continue;

                response.getWriter().print("<option value='" +
                                           group.getLabel() + "'");

                if((Worker.config._host.getProject() != null) &&
                   (Worker.config._host.getProject().compareToIgnoreCase(group.getLabel()) == 0)) {

                    response.getWriter().print("selected='selected'");
                }
                    
                response.getWriter().println(">" +
                                             group.getLabel() +
                                             "</option>");
            }

            response.getWriter().println("</select>");
        }
        catch(RemoteException e) {
            if((Worker.config._host.getProject() != null) &&
               (Worker.config._host.getProject().length() > 0))
                response.getWriter().println(Worker.config._host.getProject());
            else
                response.getWriter().println("<p class='warn'>all</p>");
        }
        catch(Exception e) {
            error(e.toString());
        }

        response.getWriter().println("</td></tr>");
    }
    /**
     * This sends the JavaScript script
     */
    private void javaScript() throws IOException{
        response.getWriter().println("<script type='text/javascript'>\n" +
                                     "// <![CDATA[\n" +
                                     "function showActHelp(form, top, helpText)\n" +
                                     "  {\n" +
                                     "  var aides = new Array();\n" + 
                                     "  var params = new Array();");

        Enumeration theEnum = activatorHelps.elements();
        int i = 0;
        while(theEnum.hasMoreElements()) {
            String help = (String)theEnum.nextElement();
            response.getWriter().println("  aides[" + i++ + "] = '" + help + "';");
        }

        theEnum = activatorParams.elements();
        i = 0;
        while(theEnum.hasMoreElements()) {
            boolean param = ((Boolean)theEnum.nextElement()).booleanValue();
            response.getWriter().println("  params[" + i++ + "] = " + param + ";");
        }

        response.getWriter().println("  var divAide = document.getElementById('" + DIVAIDE + "');\n" +
                                     "  var actParams = document.getElementById('" + ACTIVATORPARAMS + "');\n" +
                                     "  var Index = form." + ACTIVATORSELECTOR + ".selectedIndex;\n" +
                                     "\n" +
                                     "  if(divAide != null) {\n" +
                                     "    if(helpText != null)\n" +
                                     "      divAide.innerHTML = helpText;\n" +
                                     "    else\n" + 
                                     "      divAide.innerHTML = aides[Index];\n" +
                                     "    divAide.style.top = top;\n" +
                                     "    divAide.style.visibility = 'visible';\n" + 
                                     "  }\n" + 
                                     "  if(params[Index] == true)\n" +
                                     "    actParams.style.visibility = 'visible';\n" +
                                     "  else\n" +
                                     "    actParams.style.visibility = 'hidden';\n" +
                                     "  }\n" +
                                     "function hideHelp() {\n" +
                                     "  var divAide = document.getElementById('" + DIVAIDE + "');\n" +
                                     "  divAide.style.visibility = 'hidden';\n" +
                                     "}\n" +
                                     "\n" +
                                     "// ]]>\n" +
                                     "</script>");
    }
    /**
     * This sends the CSS
     */
    private void css() throws IOException{
        response.getWriter().println("<style type='text/css'>\n" +
                                     "<!--\n" +
                                     "body\n" +
                                     "{\n" +
                                     "  font-family : Times New Roman, Times;\n" +
                                     "  font-size : 16;\n" +
                                     "  background-color : #050064;\n" +
                                     "  color : #ffffff;\n" +
                                     "}\n" +
                                     "\n" +
                                     "div\n" +
                                     "{\n" +
                                     "  position : absolute;\n" +
                                     "  width: 100%;\n" +
                                     "  text-align : center;\n" +
                                     "}\n" +
                                     "\n" +
                                     ".titre\n" +
                                     "{\n" +
                                     "  width : 100%;\n" +
                                     "  font-size : 24px;\n" +
                                     "  text-align : center;\n" +
                                     "  background-color : #9999ff;\n" +
                                     "  color : #050064;\n" +
                                     "}\n" +
                                     "\n" +
                                     ".soustitre\n" +
                                     "{\n" +
                                     "  width : 75%;\n" +
                                     "  font-size : 16px;\n" +
                                     "  font-style : italic;\n" +
                                     "  text-align : center;\n" +
                                     "  background-color : #cccc66;\n" +
                                     "  color : #050064;\n" +
                                     "}\n" +
                                     "\n" +
                                     ".resume\n" +
                                     "{\n" +
                                     "  width : 50%;\n" +
                                     "  top : 160px;\n" +
                                     "  left : 20px;\n" +
                                     "  background-color : #6600cc;\n" +
                                     "}\n" +
                                     ""); 
        response.getWriter().println(".info\n" +
                                     "{\n" +
                                     "  background-color : green;\n" +
                                     "  font-style : italic;\n" +
                                     "}\n" +
                                     ""); 
        response.getWriter().println(".warning\n" +
                                     "{\n" +
                                     "  background-color : orange;\n" +
                                     "  font-style : italic;\n" +
                                     "}\n" +
                                     ""); 
        response.getWriter().println(".aide\n" +
                                     "{\n" +
                                     "  background-color : pink;\n" +
                                     "  color : gray;\n" +
                                     "  width : 100%;\n" +
                                     "  text-align : center;\n" +
                                     "}\n" +
                                     ""); 
        response.getWriter().println(".erreur\n" +
                                     "{\n" +
                                     "  background-color : red;\n" +
                                     "  font-style : italic;\n" +
                                     "}\n" +
                                     ""); 
        response.getWriter().println(".configuration\n" +
                                     "{\n" +
                                     "  width : 50%;\n" +
                                     "  top : 160px;\n" +
                                     "  left: 450px;\n" +
                                     "  background-color : #669933;\n" +
                                     "}\n" +
                                     "\n" +
                                     "caption\n" +
                                     "{\n" +
                                     "  width : 100%;\n" +
                                     "  font-size : 24px;\n" +
                                     "  text-indent:0.5cm;\n" +
                                     "	text-align : center;\n" +
                                     "	background-color : #9999FF;\n" +
                                     "	color : #050064;\n" +
                                     "}\n" +
                                     "\n" +
                                     "table\n" +
                                     "{\n" +
                                     "  caption-side : top;\n" +
                                     "  border : 1px;\n" +
                                     "  font-size : 18;\n" +
                                     "  text-indent:0.5cm;\n" +
                                     "	text-align : left;\n" +
                                     "}\n" +
                                     "\n" +
                                     ".param\n" +
                                     "{\n" +
                                     "	width : 3.2cm;\n" +
                                     "}\n" +
                                     ".value\n" +
                                     "{\n" +
                                     "	font-size : 14px;\n" +
                                     "	text-align : center;\n" +
                                     "	width : 4.0cm;\n" +
                                     "}\n" +
                                     "-->\n" +
                                     "</style>");
    }
}
