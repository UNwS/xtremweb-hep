package xtremweb.worker;

import xtremweb.common.util;
import xtremweb.common.UID;
import xtremweb.common.LoggerableThread;
import xtremweb.common.XWConfigurator;
import xtremweb.communications.CommClient;

import java.rmi.RemoteException;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Iterator;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.net.ConnectException;
import java.net.UnknownHostException;


/**
 *
 * This uses xtremweb.communications.HTTPClient as communication layer
 * since RMI is obsolete and UDP does not implement workAlive methods
 * <br/>
 *
 * Signal to the coordinator the worker is still there.<br />
 *
 * Historically, that signal was called 'Alive' since it was preminirarly only
 * used to signal the dispatcher this worker is still here. This processes a much more
 * than signalling only since RPC-V.<br>
 * Since that version, this communication channel is used to:
 * <ul>
 * <li> prevent job reschedulling by informing this worker is still here (as earlier versions)
 * <li> stop computing its current job, for any reason (as earlier versions)
 * <li> ensure safe result storage by keeping job results on this worker disk.
 *      This worker can then be asked to definitly remove its local job results copies
 *      on sucessfull job result storage on server side, or to resend them on server demand.
 * <li> update some informations :
 *   <ul>
 *   <li> alive period
 *   <li> traces parameters
 *   <li> servers list, including current server. If that last is set, this worker
 *        connects to the new current server
 *   </ul>
 * </ul>
 *
 * Created: Thu Jun 29 17:47:11 2000
 *
 * @author Gilles Fedak
 */

public class ThreadAlive extends LoggerableThread {

    /** Time between workAlive in seconds */
    private int alivePeriod = 300;

    /** This controls the main loop */
    protected boolean canRun = true;

    /** Communication layer */
    //    private CommClient commClient;
    XWConfigurator config ;
    /**
     * This is the only constructor
     * This initializes TCP communication layer whatever could be written in config file
     */
    public ThreadAlive(XWConfigurator conf) {
        super("ThreadAlive");

        config = conf;

        level = config.getLoggerLevel();

        alivePeriod = 300;

//         try {
//             commClient = commClient();
// //             comm = new HTTPClient();
// //             commClient.setConfig(config);
// //             commClient.initComm(config.getCurrentDispatcher());
//         }
//         catch(Exception e) {
//             reconnect("workAlive(UID)");
//         }
    }


    /**
     * This stops the execution of the thread
     */
    public void terminate() {
        canRun = false;
        this.interrupt();
    }

    
    /**
     * This is the thread execution method
     */
    public void run() {
        int sec = 0;

        info("Thread Alive started");

        while(canRun) {
            try {

                debug("Send alive");

                synchronize();


                // we don't sleep for the whole timeout as we need to
                // take care that the computation is still on.
                debug("Sleep until the next alive ("+alivePeriod+" seconds)");
                java.lang.Thread.sleep(alivePeriod * 1000);

                Vector wal = CommManager.instance.poolWork.getAliveWork();
                if(wal == null)
                    continue;


                debug(" wal size = " + wal.size());

                for(int i = 0; i < wal.size(); i++) {

                    Work w = (Work) wal.elementAt(i);
                    debug("ThreadAlive  calling checkJob()");
                    checkJob(w);

                }
            }
            catch(InterruptedException e) {
                break;
            }
        }

        debug("ThreadAlive terminating");

    } // run()


    /**
     * This checks the provided job accordingly to the server status
     * (i.e. should we continue computing the job ? )
     * @param theJob is the work to signal.
     */
    private void checkJob(Work theJob) {

        if(theJob == null) {
            debug("ThreadAlive::checkJob() : theJob = null");
            return;
        }

        try {

            Hashtable rmiResults;

            //
            // send job UID to the server and collect informations about that job
            //
            try {
                rmiResults = workAlive(theJob.getUID());
            }
            catch(Exception e) {
                error("connection error" + e);
                return;
            }

            if(rmiResults == null) {
                debug("ThreadAlive::checkJob() : rmiResults = null");
                return;
            }


            //
            // should this worker stop current computation ?
            //
            Boolean keepWorking = (Boolean) rmiResults.get("keepWorking");
            if(keepWorking != null) {

                String msg = "workAlive(" + theJob.getUID() + ")";

                if(keepWorking.booleanValue() == false) {

                    ThreadWork tw = ThreadLaunch.instance.getThreadByWork(theJob);

                    if(tw != null) {

                        info(msg + " stop working thread");
                        tw.stopProcess();
                    }
                    else {
                        warn(msg + " can't find working thread");
                    }
                    CommManager.instance.poolWork.removeWork(theJob.getUID());

                    ThreadLaunch.instance.raz();
                } else {
                    debug(msg + " ok");
                }
            }

        }
        catch(Exception e) {
            error("RMI workAlive() call err " + e.toString());
            e.printStackTrace();
        }

    } // checkJob()


    /**
     * This synchronizes with the server :
     * <ul>
     * <li> ping the server
     * <li> send the list of local results
     * <li> retrieve results status (can we definitly delete them ? should we re-send them ?)
     * </ul>
     * @see xtremweb.dispatcher.CommHandler#workAlive(IdServers, Hashtable)
     */
    private void synchronize() {

        try {

            ping();

            Hashtable rmiResults;
            Hashtable rmiParams = new Hashtable();

            //
            // retreive stored job results -- v1r3-rc8
            //
            Vector jobResults = new Vector();
            Vector savingWorks = CommManager.instance.poolWork.getSavingWork();

            Iterator li = savingWorks.iterator();

            while(li.hasNext()) {
                Work aWork = (Work) li.next();
                if(aWork == null)
                    continue;

                debug("threadAlive() : job results " + aWork.getUID());

                jobResults.add(aWork.getUID());
            }

            debug("threadAlive() : jobResults.size() = " + jobResults.size());
            rmiParams.put("jobResults", jobResults);

            //
            // send them to the server and retrieve some informations
            //
            try {
                rmiResults = workAlive(rmiParams);
            }
            catch(Exception e) {
                e.printStackTrace();
                error("workAlive : connection error " + e);
                return;
            }

            if(rmiResults == null) {
                debug("ThreadAlive::synchronize() : rmiResults = null");
                return;
            }

            //
            // RPC-V : retreive saved tasks and remove them from from PoolWork::savingTasks
            //
            Vector finishedTasks = (Vector) rmiResults.get("finishedTasks");

            if(finishedTasks != null) {
                debug("ThreadAlive() : finishedTasks.size() = " +
                             finishedTasks.size());
                li = finishedTasks.iterator();

                while(li.hasNext()) {
                    UID uid = (UID) li.next();
                    if(uid != null)
                        CommManager.instance.poolWork.removeWork(uid);
                }
            }

            //
            // RPC-V : retreive tasks which results are expected by the coordinator
            //
            Vector resultsExpected = (Vector) rmiResults.get("resultsExpected");

            if(resultsExpected != null) {
                debug("ThreadAlive() : resultsExpected.size() = " +
                             resultsExpected.size());

                li = resultsExpected.iterator();

                while(li.hasNext()) {
                    UID uid =(UID) li.next();
                    if(uid == null)
                        continue;

                    Work wResult = CommManager.instance.poolWork.getSavingWork(uid);
                    if(wResult != null) {
                        CommManager.instance.sendResult(wResult);
                    }
                    else {
                        error("ThreadAlive() : can't retreive saving work = " + uid);
                    }
                }
            }

            //
            // RPC-V : retreive new server to connect to
            //
            String newServer =(String) rmiResults.get("newServer");
            if(newServer != null) {
                debug("ThreadAlive() new server : " + newServer);
                //                CommManager.instance.setServer(newServer);
                config.addDispatcher(newServer);
            }

            //
            // traces collect configuration
            //
            Boolean traces =(Boolean) rmiResults.get("traces");
            String dbgMsg = "";
            if(traces != null) {
                if(traces.booleanValue())
                    dbgMsg = "tracing";
                else
                    dbgMsg = "stop tracing";
            } 

            Integer tracesSendResultDelay =(Integer) rmiResults.get("tracesSendResultDelay");
            int sDelay = 0;

            if(tracesSendResultDelay != null) {
                sDelay = tracesSendResultDelay.intValue();
                dbgMsg += " " + tracesSendResultDelay.intValue();
            }


            Integer tracesResultDelay =(Integer) rmiResults.get("tracesResultDelay");
            int rDelay = 0;
            if(tracesResultDelay != null) {
                rDelay = tracesResultDelay.intValue();
                dbgMsg += " " + tracesResultDelay.intValue();
            } 

            debug(dbgMsg);

            if(XWTracer.getInstance() != null)
                if(traces != null)
                    XWTracer.getInstance().setConfig(traces.booleanValue(), rDelay, sDelay);
                else
                    XWTracer.getInstance().setConfig(rDelay, sDelay);

            //
            // 1.5.1 : send alive period to worker
            //
            Integer newAlivePeriod = (Integer)rmiResults.get("alivePeriod");
            if(newAlivePeriod != null) {
                alivePeriod = newAlivePeriod.intValue();
                debug("Alive period from server = " + alivePeriod);
            }

        } catch(Exception e) {
            error("RMI workAlive() call err " + e.toString());
            e.printStackTrace();
        }

    } // synchronize()


    /**
     * This checks the provided job accordingly to the server status
     * @param jobUID is the UID of the currently computed job
     * @see #checkJob(Work)
     */
    public Hashtable workAlive(UID jobUID) throws InterruptedException {

        try {

            Hashtable result;
            CommClient commClient = commClient();
            result = commClient.workAlive(jobUID);
            return result;
        }
        catch(RemoteException ce) {
            error(ce.toString());
            if(debug())
                ce.printStackTrace();
            //            reconnect("workAlive(UID)");
        }
        catch(IOException ce) {
            error(ce.toString());
            if(debug())
                ce.printStackTrace();
            //            reconnect("workAlive(UID)");
        }
        /*
          catch(NullPointerException ce) {
          // this may happen at warm up(comm still not initialized)
          reconnect();
          }
        */
        return null;
    }

    /**
     * This synchronizes with the server
     * @param rmiParams is a Hashtable containing the list of local results
     * @see #synchronize()
     */
    public Hashtable workAlive(Hashtable rmiParams) throws InterruptedException {

        try {

            Hashtable result;
            config._host.setAvailable(ThreadLaunch.instance.available());
            CommClient commClient = commClient();
            result = commClient.workAlive(rmiParams);
            return result;
        }
        catch(RemoteException ce) {
            error(ce.getMessage());
            if(debug())
                ce.printStackTrace();
            //            reconnect("workAlive(Hashtable) [1]");
        }
        catch(Exception e) {
            error(e.getMessage());
            if(debug())
                e.printStackTrace();
            //            reconnect("workAlive(Hashtable) [2] ");
        }
        return null;
    }

    /**
     * This pings the server
     * @see #synchronize()
     */
    public void ping()  {

        try {
            long start = System.currentTimeMillis();
            CommClient commClient = commClient();
            commClient().ping();
            long end = System.currentTimeMillis();
            int pingdelai = (int)(end - start);
            info("pingdelai = " + pingdelai + 
                        "  end = " + end + 
                        "  start = " + start );
            config._host.incAvgPing(pingdelai);
        }
        catch(Exception e) {
            error(e.getMessage());
            if(debug())
                e.printStackTrace();
        }
    }

//     /**
//      * This tries to reconnect to the server
//      * @param msg is a message to display
//      */
//     public synchronized void reconnect(String msg) throws InterruptedException {

//         warn("<reconnect server=' " + config.getCurrentDispatcher() +
//                     "' msg='" + msg + "' status='connecting' />");

//         while(true) {
//             try {
//                 Thread.sleep(1000);
//                 commClient = commClient();
// //                commClient.initComm(config.getCurrentDispatcher());
//                 break;
//             } catch(Exception e) {
//             }
//         }
//         warn("<reconnect server=' " + config.getCurrentDispatcher() +
//                     "' status='connected' />");
//     }

    /**
     * This retreives the default comm client and initializes it
     * @return the default comm client
     */
    private CommClient commClient() 
        throws RemoteException, 
               UnknownHostException, 
               ConnectException {

        CommClient commClient = null;
        try {
            commClient = config.defaultCommClient();
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
        //        client.setConfig(config);
        commClient.initComm(config.getCurrentDispatcher());
        return commClient;
    }

} // class ThreadAlive
