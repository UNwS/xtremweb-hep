package xtremweb.worker;

/**
 * CommEvent.java
 *
 *
 * Created: Sat Jun  9 13:59:58 2001
 *
 * @author <a href="mailto: fedak@lri.fr> "Gilles Fedak</a>
 */

import xtremweb.communications.IdRpc;

public class CommEvent {

    private IdRpc rpc;
    private Work work = null;

    public CommEvent(IdRpc ct){
        rpc = ct;
    }

    public CommEvent(IdRpc ct, Work w) {
        rpc = ct;
        work = w;
    }

    IdRpc getCommType () {
        return rpc;
    }
    Work getWork () {
        return work;
    }

}
