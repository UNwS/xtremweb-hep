package xtremweb.worker;

// WinSaverActivator.java
//
// Created May 30 2002

import xtremweb.archdep.WinSaver;
/**
 * <p>Windows activator that checks if the screensaver is running to
 *    decide if the worker can be started</p>
 * 
 * @author Samuel Heriard
 */
 
public class WinSaverActivator extends PollingActivator {
   
		/**
		 * This tells whether the worker can start computing, accordingly to the 
		 * local activation policy
		 * @return true if the work can start computing
		 */    
    protected boolean canStart() {
        return WinSaver.screenSaverRunning();
    }
    
		/**
		 * This tells whether the worker must stop computing, accordingly to the 
		 * local activation policy
		 * @return true if the work must stop computing
		 */    
    protected boolean mustStop() {
        return !WinSaver.screenSaverRunning();
    }
}
