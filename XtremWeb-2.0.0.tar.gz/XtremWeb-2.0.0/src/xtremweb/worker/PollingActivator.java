package xtremweb.worker;

import xtremweb.common.XWPropertyDefs;

import java.util.Date;
import java.util.Properties;


/**
 *  <p>Abtract class for implementing polling activators</p>
 *
 *  <p><code>PollingActivator</code> contains methods common to activators 
 *  that polls the system to see if the worker is allowed to compute<br>
 *  Subclasses needs to implement the <code>isActive</code>method. This method
 *  is called every <code>waitingProbeInterval</code> milliseconds when the worker is sleeping.
 *  If it has returned false for </code>activationDelay</code> ms, then the worker is awaken
 *  and <code>isActive</code> is called every <code>workingProbeInterval</code> ms to see
 *  if the worker should be stopped.</p>
 *
 * Created May 30 2002 (from MouseKbdActivator.java)
 *
 *  @author Samuel Heriard
 */


public abstract class PollingActivator extends Activator {

    /** milliseconds to wait between each probe when the worker is active */
    protected long workingProbeInterval = 1000;
    /** milliseconds to wait between each probe when waiting for activation */
    protected long waitingProbeInterval = 10000;
    /** number of millisecond of inactivity to wait before allowing the worker to start 
     *  this can be set with the property activator.ua.delay (give the time in seconds)
     */
    protected int activationDelay = 0;

    /**
     * This tells whether the worker can start computing, accordingly to the 
     * local activation policy
     * @return true if the work can start computing
     */    
    protected abstract boolean canStart();
    /**
     * This tells whether the worker must stop computing, accordingly to the 
     * local activation policy
     * @return true if the work must stop computing
     */    
    protected abstract boolean mustStop();
    

    /** 
     * This initializes the activator accordingly to the config file
     * @param config is the Properties read from file
     * @exception Exception is thrown on initialization error, depending on the Acivator implementation
     */
    public void initialize(Properties c) {

        super.initialize(c);

        try {
            if (config.getProperty("activator.poll.delay") != null) 
                activationDelay = 60000 * 
                    Integer.parseInt(config.getProperty(XWPropertyDefs.ACTIVATORDELAY.toString()));
        } catch (NumberFormatException e) {
            warn("error in config file");
            warn("'activator.poll.delay' is not an integer (" 
                 + config.getProperty("activator.poll.delay") + ")");
        }

        if (activationDelay <= 0)
            activationDelay = 60000;

        debug("PollingActivator::initilize() " + activationDelay);

        setMask(~CPU_ACTIVITY);
    }

    /**
     * This wait for an event
     * @param mask is the event mask to wait for
     */    
    public int waitForEvent(int mask) throws InterruptedException {
         try {
            if ((getMask() & CPU_ACTIVITY) != 0) {

                // xtremweb running 
                warn ("PollingActivator : running");

                while (this.mustStop () == false) {
                    Thread.sleep (workingProbeInterval);
                    //										logger.debug ("PollingActivator : still running");
                }

                setMask (getMask () - CPU_ACTIVITY);
                debug ("PollingActivator (end running) : " + Integer.toHexString (getMask ()));

            }
            else {

                // xtremweb not running
                warn ("PollingActivator : sleeping");

                Thread.sleep (waitingProbeInterval);
                while (this.canStart () == false) {
                    debug ("PollingActivator : sleeping " + waitingProbeInterval);
                    Thread.sleep (waitingProbeInterval);
                }

                setMask (getMask () | CPU_ACTIVITY);
                debug ("PollingActivator (end sleeping) : " + Integer.toHexString (getMask ()));

                //Thread.sleep (15000);
            }
         }
         catch (InterruptedException e) {
             info("PollingActivator#waitForEvent() : interrupted");
             throw e;
//             return 0;
         }
        return CPU_ACTIVITY;
    }
    
}
