/**
 * Project : XTremWeb
 * File    : XWTracerThreadSend.java
 *
 * Initial revision : July 2001
 * By               : Anna Lawer
 *
 * New revision : January 2002
 * By           : Oleg Lodygensky
 * e-mail       : lodygens /at\ lal.in2p3.fr
 */

package xtremweb.worker;
import xtremweb.common.util;
import xtremweb.common.LoggerableThread;

import java.rmi.*;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.File;
import java.util.Date;




/**
 * The <CODE>XWTracerThreadSend</CODE> class describes the XtremWeb thread
 * which sends traces to server.
 */

public class XWTracerThreadSend extends LoggerableThread{
    /**
     * This variable stores date when current traces has been started.
     */
    private long dateStart;
    /**
     * This variable stores date when current traces has been ended.
     */
    private long dateEnd;
    /**
     * This variable stores traces file name.
     */
    private String fileName;


    /**
     * This is the only constructor.
     * @param start contains date when current traces has been started.
     * @param end contains date when current traces has been ended.
     */
    XWTracerThreadSend (String fName, long start, long end) {

        super ("XWTracerThreadSend");

        fileName = fName;
        dateStart = start;
        dateEnd   = end;

    }


    /**
     * This is the main method. It sends traces to server and exits.
     */
    public void run () {

        File f;
        FileInputStream fInpS;
        byte [] file;

        f = new File(fileName);
        file = new byte[(int)f.length()];

        try {
            fInpS = new FileInputStream(f);

            try {
                fInpS.read(file,0,(int)f.length());
                fInpS.close();
            }
            catch (IOException e) {
                error ("XWTracerThreadSend : can't read input file; " + e);
            }
        }
        catch(FileNotFoundException ff) {
            error ("XWTracerThreadSend : input file not found; " + ff);
        }
    
        try {
            /* 
             * Tracer initial revision by Anna
             *
             Worker.comm.tactivityMonitor (ServerProperties.ids.hostName,
             ServerProperties.ids.login, file); 
            */
            /* 
             * Tracer new revision by Oleg
             */
            CommManager.instance.tactivityMonitor (Worker.config._host.getName (),
                                                   Worker.config._user.getLogin (),
                                                   dateStart,
                                                   dateEnd,
                                                   file); 

            info ("Trace results sent");
        }
        catch (Exception e) {
            error ("Send trace error : " + e);
        }
    }

}
