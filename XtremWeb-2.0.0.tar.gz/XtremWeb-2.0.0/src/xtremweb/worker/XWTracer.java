/**
 * Project : XTremWeb
 * File    : XWTracer.java
 *
 * Initial revision : July 2001
 * By               : Anna Lawer
 *
 * New revision : January 2002
 * By           : Oleg Lodygensky
 * e-mail       : lodygens /at\ lal.in2p3.fr
 */

package xtremweb.worker;

import xtremweb.common.*;
import xtremweb.archdep.ArchDepException;
import xtremweb.archdep.ArchDepFactory;
import xtremweb.archdep.XWTracerNative;

import java.rmi.*;
import java.lang.*;
import java.io.*;
import java.io.FileInputStream;
import java.io.File.*;
import java.util.Date;


/**
 * The <CODE>XWTracer</CODE> class describes the XtremWeb tracer thread.
 * It has a single infinite loop, where it collects system
 * informations thanks to native (hence externals) methods.
 */

public class XWTracer extends LoggerableThread {

    private  boolean running = true;
    private  int resultDelay = 1000;    // 10 sec
    private  int sendResultDelay = 60;  // 60 * resultDelay = 10 mn
    private  long dateStart;
    private  int runningLoop = 0;
    private  static XWTracer instance = null;

    /** This is the default constructor  */
    XWTracer (boolean r, LoggerLevel l) {
        super ("XWTracerThreadSend", l);

        instance = this;
        running = r;
    }
  

    public static XWTracer getInstance () {
        return instance;
    }


    public void run() {

        String s;
        byte [] file;
        File f;
        FileInputStream fInpS;
        XWTracerNative tracerImpl = ArchDepFactory.xwtracer();

        tracerImpl.setOutputDir (Worker.config.getTmpDir ().toString ());

        info ("Tracing");


        // Just to be sure compiler don't complain 
        // about variables that might not have been initialized.
        //
        dateStart = System.currentTimeMillis();


        try {
            WorkerParameters params = CommManager.instance.getWorkersParameters ();
            resultDelay = params.resultDelay;
            sendResultDelay = params.sendResultDelay;
        }
        catch (Exception ex) {
            error ("XWTracer getworkersparams : " + ex);
        }

        while(! Thread.interrupted()) try {


            sleep (resultDelay);


            if (running == false) {
                runningLoop = 0;
                continue;
            }

            if(runningLoop <= 0) {

                dateStart = System.currentTimeMillis();
                tracerImpl.checkNodeState(0);
                tracerImpl.collectNodeConfig(0);
                /*
                 * Not implemented yet.
                 *
                 tracerImpl.checkNetwork(0);
                */

            }
            else {

                tracerImpl.checkNodeState(1);
                tracerImpl.collectNodeConfig(1);    
                /*
                 * Not implemented yet.
                 *
                 tracerImpl.checkNetwork(1);
                */
            }
	
            if(runningLoop >= sendResultDelay) {
                sendResult ();
            }

            runningLoop++;
        }
        catch (InterruptedException e) {
            break;
        }

        info ("[XWTracer] terminating");
    }  


    public void setConfig (boolean r, int rDelay, int sDelay)
    {
        if (instance == null)
            return;

        //
        //   we send results immediatly if we stop running 
        //   or if we change one of the params
        //
        if ((running && (r == false)) ||
            ((rDelay != -1) && (rDelay != resultDelay)) ||
            ((sDelay != -1) && (sDelay != sendResultDelay))) {

            sendResult ();
        }

        if (rDelay != -1)
            resultDelay = rDelay;

        if (sDelay != -1)
            sendResultDelay = sDelay;

        running = r;
    }


    public void setConfig (int rDelay, int sDelay) {

        if (instance == null)
            return;

        //
        //   we send results immediatly if we change one of the params
        //
        if (((rDelay != -1) && (rDelay != resultDelay)) ||
            ((sDelay != -1) && (sDelay != sendResultDelay)))
            sendResult ();

        if (rDelay != -1)
            resultDelay = rDelay;

        if (sDelay != -1)
            sendResultDelay = sDelay;

        debug ("setConfig(), sendresultDelay = " + sendResultDelay);
        debug ("setConfig(),     resultDelay = " + resultDelay);
    }


    private void sendResult ()
    {
        if (instance == null)
            return;

        long dateEnd = System.currentTimeMillis();

        runningLoop = -1;

        try {
            String fName = Worker.config.getTmpDir () + "/sta.zip";

            TracerZipFile z = new TracerZipFile (fName,
                                                 Worker.config._host,
                                                 resultDelay,
                                                 sendResultDelay);

            try {
                /*
                 * try to insert Unix traces
                 */

                z.addEntry ("mask",    Worker.config.getTmpDir () + "/mask");
                z.addEntry ("state",   Worker.config.getTmpDir () + "/sta");
                z.addEntry ("config",  Worker.config.getTmpDir () + "/config");
                z.addEntry ("console", Worker.config.getTmpDir () + "/console");
            }
            catch (Exception e) {
                try {
                    /*
                     * try to insert Win32 traces
                     */
                    z.addEntry ("", Worker.config.getTmpDir () + "");
                }
                catch (Exception e1) {
                    /*
                     * try to insert other traces (?)
                     */
                    throw new Exception ("zip traces err");
                }
            }

            z.close ();

            XWTracerThreadSend send;
            send = new XWTracerThreadSend (fName, dateStart, dateEnd);
            send.setDaemon(true);
            send.start();
        }
        catch (Exception e) {
            error ("can't send trace results");
        }

    } // end of sendResult ()

} // end of class XWTracer
