package xtremweb.worker;

/**
 * CommManager.java
 * This class manages communications on worker side
 *
 * Created: Sat Jun  9 14:31:58 2001
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version %I% %G%
 */

import xtremweb.common.URI;
import xtremweb.common.UID;
import xtremweb.common.LoggerableThread;
import xtremweb.common.MD5;
import xtremweb.common.StreamIO;
import xtremweb.common.CommonVersion;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.WorkerParameters;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.MileStone;
import xtremweb.common.util;
import xtremweb.common.XWStatus;
import xtremweb.communications.CommClient;
import xtremweb.communications.Connection;
import xtremweb.timeserv.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Iterator;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.activation.ActivationException;
import java.net.URL;
import java.net.ConnectException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class CommManager extends LoggerableThread {

    /**
     * How many time should we try to connect before switching to another server 
     */
    private static int connectionTries;
    /** 
     * Default to how many time should we try to connect before switching to another server
     * Default is 5
     */
    private static final int CONNECTIONTRY = 5;

    /**
     * This is a time stamp to keep how long we are waiting for a valid job
     * If(xtremweb.common.XWConfigurator#noopTimeout is set)
     *   and if (currentTime - firstWorkRequest > xtremweb.common.XWConfigurator#noopTimeout)
     *     then exit
     * @see xtremweb.common.XWConfigurator#noopTimeout
     * @since RPCXW v3
     */
    private long firstWorkRequest;


    private CommQueue commQueue = null;

    public static CommManager instance = null;
    protected boolean canRun = true;

    protected boolean reconnecting = false;

    /**
     * This aims to display some time stamps
     */
    private MileStone mileStone;
    /**
     * This is for debug purposes only; this tells whether we are connected
     */
    private boolean connected = true;
    /**
     * This manages works
     */
    public PoolWork poolWork;

    /**
     * This is the default and only constructor.
     * This installs communication layers and try to connect to server.
     *
     * The specialized error <CODE>UpdateException</CODE>, defined
     * in xtremweb.upgrade package, may occur while getting connected.
     * In such a case we have to download a new version of the worker
     * software and restart worker. This exception is not catched here,
     * so caller(typically <CODE>ThreadLaunch::run()</CODE>) can get it.
     */
    public CommManager() {

        super("CommManager");

        mileStone = new MileStone(getClass().getName());

        connectionTries = 0;

        instance = this;
        try {
            commQueue = new CommLL();
        } 
        catch(Error NoClassDefFoundError) {
            commQueue = new CommStack();
        }

        level = Worker.config.getLoggerLevel();

        firstWorkRequest = -1;

        // retreive results from FS
        poolWork = new PoolWork(level);
        Vector sWorks = poolWork.getSavingWork ();
        Iterator li = null;

        if (sWorks != null)
            li = sWorks.iterator ();
        if (li != null) {
            while (li.hasNext()) {
                Work w = (Work) li.next();
                if (w != null)
                    sendResult(w);
            }
        }

        // install shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread() {
                public void run() {
                    close();
                }
            });

    }


    private enum SleepEvent {
        NONE,
        NOCOMMEVENT,
        POOLWORKFULL,
        WORKREQUEST,
        SENDRESULT,
        NOWORKAVAILABLE,
        RECONNECTION;
    }

    private SleepEvent sleeping = SleepEvent.NONE;

    private void sleeping(SleepEvent s, String msg, int d) throws InterruptedException {
        if(sleeping != s) {
            sleeping = s;
            debug("sleeping (" + msg + ") " + d);
        }
        Thread.sleep(d);
    }

    /**
     * @see #message(boolean, String)
     */
    private void message(boolean lost) {
        message(lost, null);
    }
    /**
     * This prints a message on connection/deconnection events.
     * This prints out a single message for several equivalent events
     * in order to reduce outputs.
     * This sets the connected attribute.
     * @param lost tells whether connection is lost or not
     * @param trailer is an optionnal message trailer
     * @see #connected
     */
    private void message(boolean lost, String trailer) {
        if(lost == false) {
            if(connected == false)
                error("XWHEP Worker (" +
                      CommonVersion.getCurrent().full() +
                      ") connected to \"" +
                      Worker.config.getCurrentDispatcher() +
                      (trailer == null ? "\"" : "\" : " + trailer));
            connected = true;
        }
        else {
            if(connected )
                error("XWHEP Worker (" +
                      CommonVersion.getCurrent().full() + ") " +
                      " connection lost from \"" +
                      Worker.config.getCurrentDispatcher() +
                      (trailer == null ? "\"" : "\" : " + trailer));
            connected = false;
        }
    }

    /**
     * This inserts a work request event on event queue
     */
    public void workRequest() {
        commQueue.workRequest();
    }

    /**
     * This inserts a send result event on event queue
     */
    public void sendResult(Work w) {
        System.out.println("CommManager#sendResult() " + w.getResult());
        commQueue.sendResult(w);
    }

    /**
     * This retreives the first available event from queue
     */
    public CommEvent getCommEvent() throws InterruptedException {
        return commQueue.getCommEvent();
    }

    /**
     * This removes the first available event from queue
     */
    public void removeCommEvent(CommEvent ce) {
        commQueue.removeCommEvent(ce);
    }

    /**
     * This closes communication channel
     */
    private void close() {
        try {
            commClient().close();
        }
        catch(Exception e) {
        }
    }

    /**
     * This retreives some parameters from server
     */
    public WorkerParameters getWorkersParameters() {
        error("CommManager::getWorkerBin() not implemented yet");
        /*
          try {
          return commClient.getWorkersParameters();
          } catch(Exception e) {
          try {
          reconnect("getWorkersParameters");
          }
          catch(Exception t1) {
          util.error(t1.toString());
          }
          }
        */
        return null;
    }


    /**
     * This asks the server for a new worker version
     */
    public WorkInterface getWorkerBin(HostInterface host) throws RemoteException {

        throw new RemoteException("CommManager::getWorkerBin() not implemented yet");
        /*
          try {
          return commClient.getWorkerBin(wid);
          } catch(Exception e) {
          try {
          reconnect();
          }
          catch(Exception t1) {
          util.error(t1.toString());
          }
          }
          return null;
        */
    }

    /**
     * This sends traces to the server
     */
    public void tactivityMonitor(String hostName, String login, long start,
                                 long end, byte[] file) throws RemoteException {
        throw new RemoteException("CommManager::tactivityMonitor() not implemented yet");
        /*
        try {
            commClient.tactivityMonitor(start, end, file);
            message(false);
        } catch(Exception e) {
            try {
                reconnect("tactivityMonitor");
            }
            catch(Exception t1) {
                util.error(t1.toString());
            }
        }
        */
    }


    /**
     * This initializes the communication layer.
     */
    /*
    private void initCommLayer()
        throws ConnectException, RemoteException, UnknownHostException {

        firstWorkRequest = -1;

        commClient.initComm (Worker.config.getCurrentDispatcher());
    }
    */

    public void terminate() {
        canRun = false;
        this.interrupt();
    }

    /**
     * This retreives the default comm client and initializes it
     * @return the default comm client
     */
    public CommClient commClient() 
        throws RemoteException, 
               UnknownHostException, 
               ConnectException {

        CommClient commClient = null;
        try {
            commClient = Worker.config.defaultCommClient();
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
        commClient.setConfig(Worker.config);
        commClient.initComm(Worker.config.getCurrentDispatcher());

        return commClient;
    }
    /**
     * This retreives the comm client for the given URI and initializes it
     * @param uri is the uri to retreive comm client for
     * @return the expected comm client 
     */
    public CommClient commClient(URI uri) 
        throws RemoteException, 
               UnknownHostException, 
               ConnectException {

        CommClient commClient = null;
        try {
            commClient = Worker.config.getCommClient(uri);
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
//        commClient.setConfig(Worker.config);

        debug("CommManager#commClient(" + uri +
              ") : uri.port = " + uri.getPort());

        if(uri.getPort() > 0)
            commClient.initComm(uri.getHost(), uri.getPort());
        else
            if(Connection.HTTPSCHEME.compareTo(uri.getScheme()) == 0)
                commClient.initComm(uri.getHost(), Connection.WEBDEFAULTPORT);
            else
                commClient.initComm(uri.getHost());

        return commClient;
    }

    /**
     * This connects to server to request a new work
     */
    private WorkInterface getWork()
        throws ClassNotFoundException, 
               RemoteException,
               UnknownHostException, 
               ConnectException,
               IOException {

        return commClient().workRequest(Worker.config._host);
    }
    /**
     * This retreives the app for the given UID
     * @param uid is the app uid
     * @return the app
     */
    private AppInterface getApp(UID uid)
        throws ClassNotFoundException, 
               RemoteException,
               UnknownHostException, 
               ConnectException,
               IOException {

        AppInterface app = (AppInterface)commClient().get(uid);
        if(app == null)
            throw new IOException("application not found");
        return app;
    }
    /**
     * This retreives the app
     * This also retreives all app files contents (bin, stdin, dirin...)
     * @param uid is the data uid
     */
    private void downloadApp(UID uid) 
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        AppInterface app = getApp(uid); 

        URI uri = app.getBinary(Worker.config._host.getCpu(), 
                                Worker.config._host.getOs());

        if(uri == null)
            throw new IOException("binary not defined");

        try {
            downloadData(uri);
        }
        catch(Exception e) {
            e.printStackTrace();
            throw new IOException("can't download binary : " + uri);
        }

        uri = app.getBaseDirin();
        if(uri != null)
            try {
                downloadData(uri);
            }
            catch(Exception e) {
                throw new IOException("can't download base dirin : " + uri);
            }
        uri = app.getDefaultDirin();
        if(uri != null)
            try {
                downloadData(uri);
            }
            catch(Exception e) {
                throw new IOException("can't download default dirin : " + uri);
            }
        uri = app.getDefaultStdin();
        if(uri != null)
            try {
                downloadData(uri);
            }
            catch(Exception e) {
                throw new IOException("can't download default stdin : " + uri);
            }
    }
    /**
     * This retreives the data for the given URI
     * @param uri is the data uri
     * @return the data
     */
    private DataInterface getData(URI uri) 
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        return getData(uri, true);
    }
    /**
     * This retreives the data for the given URI
     * @param uri is the data uri
     * @return the data
     */
    private DataInterface getData(URI uri, boolean bypass) 
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        CommClient commClient = commClient(uri);
        DataInterface data = (DataInterface)commClient.get(uri, bypass);

        if(data == null)
            throw new IOException("can't retreive data " + uri);

        return data;
    }
    /**
     * This retreives the data for the given URI
     * This finally retreives the data content for the given URI
     * @param uri is the data uri
     */
    private void uploadData(URI uri) 
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        DataInterface data = getData(uri); 

        long start = System.currentTimeMillis();
        long fsize = commClient().getContentFile(uri).length();

        commClient(uri).uploadData(uri, commClient().getContentFile(uri));

        long end = System.currentTimeMillis();
        float bandwidth = fsize / (end - start);
        Worker.config._host.setUploadBandwidth(bandwidth);
    }
    /**
     * This calls downloadData(uri, true)
     * @see #downloadData(URI, boolean)
     */
    private void downloadData(URI uri)
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        downloadData(uri, true);
    }
    /**
     * This does nothing if uri parameter is null.
     * This retreives the data from a server
     * Depending on download parameter, this downloads the data content, 
     * if not already in cache.
     * This first tries to call downloadData(new URL(uri), download) to 
     * try to download data from an HTTP server if uri is an URL
     * @param uri is the data uri
     * @param download if false, data content is not downloaded if data already in cache;
     *                 if true, data content is downloaded even if data already in cache
     */
    private void downloadData(URI uri, boolean download)
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        if(uri == null)
            return;

        CommClient commClient = commClient(uri);
        commClient.addToCache(uri);

        try {
            // maybe it is an URL and not an XWHEP URI...
            downloadData(uri, new URL(uri.toString()), download);
            return;
        }
        catch(Exception e) {
        }

        DataInterface data = getData(uri, download); 

        debug("CommManager#downloadData(" + uri + ") ");

        if(download == false)
            return;

        File fdata = commClient().getContentFile(uri);
        if(fdata == null)
            throw new IOException(uri.toString() + " can't cache data");

        long start = System.currentTimeMillis();
        long fsize = fdata.length();

        commClient.downloadData(uri, fdata);

        long end = System.currentTimeMillis();
        float bandwidth = fsize / (end - start);
        Worker.config._host.setDownloadBandwidth(bandwidth);

        if(data.getMD5() == null)
            throw new IOException(uri.toString() + " MD5 is null ?!?!");
        if(data.getMD5().compareTo(MD5.asHex(MD5.getHash(fdata))) != 0)
            throw new IOException(uri.toString() + " MD5 differs");
    }
    /**
     * This does nothing if url parameter is null.
     * This retreives the data from an HTTP server
     * Depending on download parameter, this downloads the data content, 
     * if not already in cache
     * @param uri is the data uri
     * @param url is the data url
     * @param download if false, data content is not downloaded if data already in cache;
     *                 if true, data content is downloaded even if data already in cache
     */
    private void downloadData(URI uri, URL url, boolean download)
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        if(url == null)
            return;

        CommClient commClient = commClient(uri);
        commClient.addToCache(uri);
        File fdata = commClient().getContentFile(uri);
        if(fdata == null)
            throw new IOException(uri.toString() + " can't cache data");

        long start = System.currentTimeMillis();
        long fsize = fdata.length();

        StreamIO io = null;
        try {
            mileStone.println("Reading file " + fdata);
            io = new StreamIO(null,
                              new DataInputStream(url.openStream()),
                              level, 
                              false);

            io.readFileContent(fdata);
            io.close();
            mileStone.println("Read file " + fdata);
        }
        catch(Exception e) {
            if(io != null)
                io.close();
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }

        long end = System.currentTimeMillis();
        float bandwidth = fsize / (end - start);
        Worker.config._host.setDownloadBandwidth(bandwidth);
    }
    /**
     * This is the main loop
     * This pools out a communication event and process it
     */    
    public void run() {

        // RPCXW
        int initWorkTimeOut = Integer.parseInt(Worker.config.getProperty(XWPropertyDefs.TIMEOUT.toString()));
        int nullWorkTimeOut = initWorkTimeOut;
        int maxWorkTimeOut = Worker.config.maxTimeout();

        while(canRun) {

            boolean success = false;


            nullWorkTimeOut = (nullWorkTimeOut * 2);
            if(nullWorkTimeOut > maxWorkTimeOut)
                nullWorkTimeOut = maxWorkTimeOut;

//             System.out.println("TIMEOUT = " + nullWorkTimeOut +
//                                " ; INITTIMEOUT = " + initWorkTimeOut +
//                                " ; MAXTIMEOUT = " + maxWorkTimeOut);

            try {
                mileStone.clear();
                CommEvent ce = commQueue.getCommEvent();
                if(ce == null) {
                    sleeping(SleepEvent.NOCOMMEVENT, "no comm event", nullWorkTimeOut);
                    continue;
                }

                commQueue.removeCommEvent(ce);

                switch(ce.getCommType()) {

                case WORKREQUEST:

                    WorkInterface mw = null;

                    //
                    // We don't ask more than poolwork capacity
                    // 
                    // Jan 19th, 2005 : We don't ask if not allowed to compute
                    //
                    if(poolWork.isFull() || !ThreadLaunch.instance.available()) {

                        sleeping(SleepEvent.POOLWORKFULL, "PoolWork full", nullWorkTimeOut);

                        commQueue.workRequest();
                        continue;
                    }

                    success = false;
                    while(!success) {
                        try {
                            long noopTimeout = Worker.config.getInt(XWPropertyDefs.NOOPTIMEOUT,
                                                                    Integer.parseInt(XWPropertyDefs.NOOPTIMEOUT.value()));
                            if((noopTimeout > 0)
                               && (firstWorkRequest > 0)) {
                                //
                                // should we continue to wait for a valid work?
                                // (Worker.config.noopTimeout is in seconds)
                                //
                                long current = System.currentTimeMillis() / 1000;
                                long delai = current - firstWorkRequest;
                                if(delai > noopTimeout) {
                                    System.out.println("XWHEP Worker (" +
                                                       CommonVersion.getCurrent().full() +
                                                       ") [" + new Date () +
                                                       "] ended : not waiting any longer (" +
                                                       delai + " > " + noopTimeout + ")");
                                    System.exit(0);
                                }
                            }

                            mw = getWork();

                            success = true;

                            message(false);
                        }
                        catch(Exception e) {
                            if(debug())
                                e.printStackTrace();
                            close();
                            //                            reconnect("run::workRequest");
                            sleeping(SleepEvent.WORKREQUEST, e.toString(), nullWorkTimeOut);
//                             mileStone.println("wake up get new work exception");
//                             nullWorkTimeOut = initWorkTimeOut;

                            mw = null; 
                       }

                        nullWorkTimeOut = (nullWorkTimeOut * 2);
                        if(nullWorkTimeOut > maxWorkTimeOut)
                            nullWorkTimeOut = maxWorkTimeOut;

                    } // while(!success)



                    //
                    // We got nothing to compute
                    //
                    // RPCXW : if server is "real time", this should never happen with TCP layer
                    //         since the server holds the worker until a work is available
                    if(mw == null) {

//                         nullWorkTimeOut = (nullWorkTimeOut * 2);
//                         if(nullWorkTimeOut > maxWorkTimeOut)
//                             nullWorkTimeOut = maxWorkTimeOut;

                        sleeping(SleepEvent.NOWORKAVAILABLE, "no work avalaible", nullWorkTimeOut);

                        if(firstWorkRequest == -1)
                            firstWorkRequest = System.currentTimeMillis() / 1000;

                        commQueue.workRequest();

                        continue;
                    }

                    //
                    // We got something to compute
                    //

                    // increment job counter

                    Worker.config.nbJobs++;
                    if (Worker.config.stopComputing()) {
                        if(commQueue.size() < 1) {
                            System.out.println("XWHEP Worker ("
                                               + CommonVersion.getCurrent().full()
                                               + ") [" + new Date ()
                                               + "] ended : enough computings ("
                                               + Worker.config.nbJobs + " > " + 
                                               Worker.config.getInt(XWPropertyDefs.COMPUTINGJOBS,
                                                                    Integer.parseInt(XWPropertyDefs.COMPUTINGJOBS.value())) + ")");
                            System.exit(0);
                        }

                        warn("Enough jobs! (" + Worker.config.nbJobs + " already downloaded)" +
                             " but there's still " + commQueue.size() + " results to send");

                        continue;
                    }

                    // download any other needed file

                    firstWorkRequest = -1;

                    mileStone.println("got new work");

                    try {
                        // ensure everything is downloaded
                        mw.setStatus(XWStatus.WAITING);

                        Work newWork = poolWork.addWork(mw);
                        //                        cache.add(newWork);

                        downloadApp(newWork.getApplication());
                        downloadData(newWork.getStdin());
                        downloadData(newWork.getDirin());

                        mileStone.println("got new work files");

                        newWork.setPending();
                    }
                    catch(Exception e) {

                        close();

                        error("error " + e);
                        if(debug())
                            e.printStackTrace();

                        Work w = null;
                        try {
                            w = new Work(mw, false);
                            w.setError();
                            w.setErrorMsg("IOError : " + e);

                            sendResult(w);
                        }
                        catch(Exception e1) {
                            close();
                            error("I can't do more... :(");
                        }
                    }

                    nullWorkTimeOut = initWorkTimeOut;

                    break;

                case UPLOADDATA :

                    try {
                        uploadResults(ce.getWork());
                    }
                    catch(Exception e) {
                        close();
                        if(debug())
                            e.printStackTrace();

//                        nullWorkTimeOut = initWorkTimeOut;
                        sleeping(SleepEvent.SENDRESULT, e.toString(), nullWorkTimeOut);
                    }

                    break;

                default:
                    info("Unknown Communication type");
                    //commQueue.removeCommEvent(ce);
                    break;
                } // end of switch()
            }
            catch(InterruptedException e) {
                close();
                //                nullWorkTimeOut = initWorkTimeOut;
                e.printStackTrace();
                debug(e.toString());
                //e.printStackTrace();
                continue;
            }

        } // while()

        warn("CommManager terminating");
    }

    /**
     * This uploads result to server and updates job to server
     */
    protected void uploadResults(Work theWork) 
        throws RemoteException, IOException, ClassNotFoundException {

        if(theWork == null) {
            error("CommManager#uploadResults : theWork is null");
            return;
        }

        if(theWork.getResult() == null) {
            info("CommManager#uploadResults : no result to upload");
            commClient().send(theWork);
            return;
        }

        DataInterface data = getData(theWork.getResult());
        if(data == null) {
            error("CommManager#uploadResults : can't retreive data from cache");
            return;
        }

//         System.out.println("00 CommManage#uploadResults() " + 
//                            theWork.getResult() + " " +
//                            commClient().getContentFile(theWork.getResult()));

        if(commClient().getContentFile(theWork.getResult()).exists() == true) {

            boolean success = false;
            while(!success) {
                try {
                    debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                    debug("Sending data" + data.toXml());
                    commClient(theWork.getResult()).send(data);
                    debug("Retreiving data");
                    getData(theWork.getResult());
                    debug("Data retreived");
                    debug("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
                    success = true;
                }
                catch(Exception e) {
                    debug("Data not ready");
                    debug("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
                    try{
                        Thread.sleep(50);
                    }
                    catch(Exception s) {
                    }
                    // data not ready yet
                }
            }

            debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            debug("Upload data = " + theWork.getResult());
            uploadData(theWork.getResult());
        }
        else {
            commClient(theWork.getResult()).remove(theWork.getResult().getUID());
            URI uri = new URI(Worker.config.getCurrentDispatcher(),
                              UID.NULLUID);
            debug("work setResult(" + uri + ")");
            theWork.setResult(uri);
        }

        debug("Sending work status = " + theWork.getStatus());
        debug("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
        commClient(theWork.getResult()).send(theWork);

        poolWork.saveWork(theWork);
    
        if (Worker.config.stopComputing()) {
            System.err.println("XWHEP Worker ("
                               + CommonVersion.getCurrent().full()
                               + ") [" + new Date ()
                               + "] ended : enough computings ("
                               + Worker.config.nbJobs + " > " + 
                               Worker.config.getInt(XWPropertyDefs.COMPUTINGJOBS, 
                                                    Integer.parseInt(XWPropertyDefs.COMPUTINGJOBS.value())) + ")");

            System.exit(0);
        }
        
        message(false);
        
        mileStone.println("results sent");
    }

    /**
     * This tries to reconnect to the server
     * @param msg is a message to display
     * @see #catchConnectException(Exception)
     */
    /*
    protected void reconnect(String msg) throws  InterruptedException {

        boolean doReconnect;    // true if this thread must perform the reconnection
        // the first thread to get the lock on this will perform the reconnection
        //				synchronized(this) {
        if(!reconnecting) {
            reconnecting = true;
            doReconnect = true;
        } else {
            doReconnect = false;
        }
        //				}
        if(doReconnect) {
            try {
                try {
                    Worker.config._host.setNbConnections(Worker.config._host.getNbConnections() + 1);
                }
                catch(Exception e) {
                    util.error(e.toString());
                }

                while(true) try {
                    //                    initCommLayer();
                    initTimeService();
                    break;

                }
                catch(ConnectException e) {
                    System.out.println(e.toString());
                    catchConnectException(e);
                }
                catch(RemoteException e) {
                    System.out.println(e.toString());
                    catchConnectException(e);
                }
                catch(IOException e) {
                    System.out.println(e.toString());
                    // java.net.ConnectException
                    // java.net.UnknonHostException
                    catchConnectException(e);
                }

                message(true, msg);

            } finally {
                //								Thread.yield();
                //								synchronized(this) {
                reconnecting = false;
                //										notifyAll();
                //								}
            }
        } else {
            //						synchronized(this) {
            util.warn("Waiting reconnection");
            while(reconnecting) {
                this.wait();
            }
            util.warn("Reconnected");
            //						}
        }
    }
*/

    /**
     * This catches communication exception; this may lead to switch to another server
     * @see #connectionTries
     */
    private void catchConnectException(Exception e)
        throws InterruptedException {

        sleeping(SleepEvent.RECONNECTION, "reconnection", 2500);
        mileStone.println("wake up connection exception");
        connectionTries =(connectionTries + 1) % CONNECTIONTRY;
        if(connectionTries == 0) {
            Worker.config.getNextDispatcher();
        }
    }


    private void initTimeService() {
        /*
          try {
          CommRMItimeserv commTimeserv = new CommRMItimeserv();
          commTimeserv.initComm(Worker.config.getCurrentDispatcher(), rmiPort, "timeserv");
          long ts = System.currentTimeMillis();	
          long time1= commTimeserv.myTime(Long.parseLong(Worker.config.ids.host.getUID()),ts);
          long ts2 = System.currentTimeMillis();
          util.debug("  " + ts + " " + time1 + " " + ts2);
          } catch(Exception e) {
          util.fatal("GOING TO STOP HERE " + e);
          } // end of try-catch
        */	
    }

}
