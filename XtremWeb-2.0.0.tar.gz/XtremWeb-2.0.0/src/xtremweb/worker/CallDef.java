/**
 * @file   : CallDef.java
 * @author : Oleg Lodygensky (lodygens /at\ lal.in2p3.fr)
 * @date   : May 14th, 2003
 * @since  : v1r2-rc3 (RPC-V)
 *
 */

package xtremweb.worker;

import java.util.Vector;

/**
 * This encapsulates a java method call definition; the jar file , class,
 * method names as well as the method params
 * @see ParamDef
 */
public class CallDef {

    private String jarFileName;
    private String className;
    private String methodName;
    private Vector params;
    private boolean debug;


    public CallDef () {
        jarFileName = null;
        className = null;
        methodName = null;
        params = null;
        debug = false;
    }
    
    public CallDef (boolean b) {
        this ();
        debug = b;
    }

    private void println (String str) {
        if (debug)
            System.out.println (str);
    }

    private void print (String str) {
        if (debug)
            System.out.print (str);
    }

    public String toString () {
        String ret = new String ();

        if (jarFileName != null)
            ret = ret. concat(jarFileName + " ");
        if (className != null)
            ret = ret. concat(className + " ");
        if (methodName != null)
            ret = ret. concat(methodName + " (");

        if (params != null) {
            for (int i = 0 ; i < params.size (); i++) {

                ParamDef p = (ParamDef)params.elementAt (i);

                ret = ret.concat (p.toString ());
                if (i < params.size () - 1)
                    ret = ret.concat (",");
            }
        }

        ret = ret.concat (")");
        return ret;
    }


    public void setJarFileName (String v) {
        jarFileName = v;
        System.err.println ("\n\n\nset jar file = " + jarFileName + "\n\n\n");
        if (jarFileName == null)
            return;

        if (jarFileName.toLowerCase ().indexOf (".jar") == -1) {
            jarFileName = jarFileName.concat (".jar");
        }
    }

    public void setClassName (String v) {
        className = v;
    }

    public void setMethodName (String v) {
        methodName = v;
    }

    public void setParams (Vector v) {
        params = v;
    }

    public String getJarFileName () {
        return jarFileName;
    }

    public String getClassName () {
        return className;
    }

    public String getMethodName () {
        return methodName;
    }

    public Vector getParams () {
        return params;
    }

    public Class[] getParamTypes () {

        Class[] types;

        if (params == null)
            return null;

        types = new Class [params.size ()];

        for (int i = 0 ; i < params.size (); i++) {
            ParamDef p = (ParamDef)params.elementAt (i);
            types [i] = p.getType ();
            println ("type[" + i + "] = " + types[i].toString());
        }

        return types;
    }

    public Object[] getParamValues () {

        Object[] values;

        if (params == null)
            return null;

        values = new Object [params.size ()];

        for (int i = 0 ; i < params.size (); i++) {
            ParamDef p = (ParamDef)params.elementAt (i);
            values [i] = p.getValue ();
            println ("value[" + i + "] = " + values[i].toString());
        }

        return values;
    }

}
