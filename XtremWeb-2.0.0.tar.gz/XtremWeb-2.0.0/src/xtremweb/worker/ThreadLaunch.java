package xtremweb.worker;

import xtremweb.common.UID;
import xtremweb.common.LoggerableThread;
import xtremweb.common.LoggerLevel;
import xtremweb.common.util;
import xtremweb.common.XWPropertyDefs;

import java.io.IOException;
import java.util.Vector;
import java.util.Iterator;
import java.lang.reflect.Method;



/**
 * The <CODE>ThreadLaunch</CODE> class determines whether worker should compute or not.
 * @see Activator
 */

public class ThreadLaunch extends LoggerableThread {

    /**
     * This
     */
    public static ThreadLaunch instance = null;

    /**
     * This is the thread associated to the activator
     */
    Thread activatorThread;
    /**
     * This is the policy activator which defines the activation policy
     * (detects whether the worker can compute)
     */
    private Activator activator = null;
    /**
     * This retreives the actual activator
     */
    public Activator getActivator() {
        return activator;
    }
    /**
     * This retreives the actual activator name
     */
    public String getActivatorName() {
        return activator.getClass().getName();
    }
    /**
     * This sets the activator
     */
    public void setActivator(Activator act) {
        activator = act;
    }

    /**
     * This contains the information reported by the activator.
     * This is true if the worker is not available and must wait before it can cumpute.
     * This is set to false if the worker can compute.
     * This is sent to the dispatcher through the alive signal
     */
    private boolean  unavailable;

    private Vector threadWorkPool;

    //    public static PoolWork poolWork;


    /**
     * This is the default constructor
     */
    ThreadLaunch(LoggerLevel l)
        throws  InterruptedException,
                InstantiationException{

        super("ThreadLaunch", l);
        unavailable = true;

        threadWorkPool = new Vector();

        activatorThread = null;
        setupActivator();

        if(instance == null)
            instance = this;
    }

    protected boolean canRun = true;

    public void terminate() {
        canRun = false;
        this.interrupt();
    }

    /**
     * This resets the activator, if any.
     */  
    public void raz () {
        if (activator != null)
            activator.raz ();
    }


    /**
     * This is the main loop
     * It waits for computation to be allowed, accordingly to activity policy
     * and resume any suspended jobs; it then waits until computation is not allowed
     * and suspend any running jobs.
     * And it loops for ever.
     */
    public  void run() {

        while (canRun) {

            try {

                //								if(Worker.config.realTime() == false) {
                activator.waitForAllow(Activator.CPU_ACTIVITY);
                info ("wait for allow");
                raz ();
                // 								}

                /*
                 * we ask new jobs here only (see constructor comments)
                 */
                for (int i = CommManager.instance.poolWork.getSize (); 
                     i < Worker.config.workPoolSize; 
                     i++) {

                    //debug ("requesting job " + i);
                    CommManager.instance.workRequest();
                }

                synchronized (this) {
                    unavailable = false;
                    info ("allowed!");
                    notify();
                }

                checkThreadPoolSanity();

                for(Iterator it = threadWorkPool.iterator();
                    it.hasNext();) {
                    ThreadWork threadWork = (ThreadWork)it.next() ;
                    threadWork.resumeProcess();
                }

                try {
                    //										Thread.sleep (3000);
                    Thread.sleep(Long.parseLong(Worker.config.getProperty(XWPropertyDefs.TIMEOUT.toString())));

                }
                catch (InterruptedException ie) {
                    info("interrupted");
                }

                // 								if(Worker.config.realTime() == false) {
                debug("wait for suspend");
                raz ();
                activator.waitForSuspend(Activator.CPU_ACTIVITY);
                // 								}

                synchronized (this) {
                    unavailable = true;
                    info("not allowed!");
                    notify();
                }

                for (Iterator it = threadWorkPool.iterator ();
                     it.hasNext();) {
                    ThreadWork threadWork = (ThreadWork)  it.next() ;
                    if (threadWork != null) 
                        threadWork.suspendProcess();
                }
            }
            catch (InterruptedException e) {
                info ("interrupted " + e.getMessage());
                unavailable = true;
            }
            catch (RuntimeException e) {
                warn("run time exception " + e.getMessage());
            }
        }
        //info("terminating");
    }

    /**
     * This tells whether this worker is available.
     * This is deprecated and should not be used any longer.
     * @return always false
     * @deprecated
     * @see #available()
     */  
    public boolean allowToCompute() {
        return false;
    }

    /**
     * This tells whether this worker is available
     * @return true if this worker is allowed to compute, accordingly to its local activation policy
     * @since 1.3.12
     */
    public boolean available() {
        return !unavailable;
    }

    /**
     * This returns a vector of running works
     */
    public Vector runningWorks() {

        Vector ret = new Vector();

        for (Iterator it = threadWorkPool.iterator ();
             it.hasNext(); ) {
            ThreadWork threadWork = (ThreadWork)it.next();
            Work work = threadWork.getWork();
            if ((threadWork != null) &&
                (work != null) &&
                (work.isRunning()== true)) {
                ret.add(work);
            }
        }

        return ret;
    }
    /**
     * This returns the ThreadWork executing the provided work
     */
    public ThreadWork getThreadByWork(Work w) {

        try {
            for (Iterator it = threadWorkPool.iterator ();
                 it.hasNext(); ) {
                ThreadWork threadWork = (ThreadWork)it.next();
                if ((threadWork != null) &&
                    (threadWork.getWork() != null) &&
                    (threadWork.getWork().getUID().toString().compareTo(w.getUID().toString()) == 0))
                    return threadWork;
            }
            error("getThreadByWork() can't find work " + w.getUID());
        }
        catch(IOException e) {
        }
        return null;
    }
  
    /**
     * Verify the right number of threads
     */
    private void  checkThreadPoolSanity() {

        //				int threadsToCreate = Worker.config.ids.host.getCpuNb () - threadWorkPool.size();
        int threadsToCreate = Worker.config.workPoolSize - threadWorkPool.size();

        for (int i=0; i < threadsToCreate ; i++) {
            ThreadWork threadWork = new ThreadWork();
            threadWork.setDaemon(true);
            threadWork.start();
            threadWorkPool.addElement(threadWork);
        }
    }

    /**
     * This instantiates a new activator as defined in config file
     * @since XWHEP 1.0.0
     * @see #activator
     * @see #setupActivator(String)
     */
    private void setupActivator()
        throws InstantiationException {
        setupActivator(Worker.config.getProperty(XWPropertyDefs.ACTIVATOR.toString()));
    }
    /**
     * This instantiates a new activator
     * @param activatorClassName is the activator class name to instantiate
     * @since XWHEP 1.0.0
     * @see #activator
     * @see #initActivator()
     */
    public void setupActivator(String activatorClassName)
        throws InstantiationException {
        try {
            if(activatorThread != null)
                activatorThread.wait();
            activator = null;
            Class actClass = Class.forName(activatorClassName);
            Worker.config.setProperty(XWPropertyDefs.ACTIVATOR.toString(),
                                      activatorClassName);
            activator = (Activator) actClass.newInstance();
            initActivator();
        }
        catch(InterruptedException e) {
            throw new InstantiationException("Error while instanciating activator "
                                             + activatorClassName
                                             + e);
        }
        catch(IllegalAccessException e) {
            throw new InstantiationException("Error while instanciating activator "
                                             + activatorClassName
                                             + e);
        }
        catch(ClassNotFoundException e) {
            throw new InstantiationException("Error while instanciating activator "
                                             + activatorClassName
                                             + e);
        }
    }
    /**
     * This initializes the activator and its associated thread
     * @since XWHEP 1.0.0
     * @see #activator
     * @see #activatorThread
     */
    private void initActivator()
        throws InstantiationException {
        try {
            activator.initialize(Worker.config);
            if(activator instanceof Runnable) {
                if(activatorThread != null) {
                    activatorThread.notify();
                    activatorThread.interrupt();
                }
                else {
                    activatorThread = new Thread((Runnable)activator);
                    activatorThread.setDaemon(true);
                    activatorThread.start();
                }
            }

            this.interrupt();

            debug("Activator = " +
                         activator.getClass().getName());
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new InstantiationException("Error while instanciating activator " +
                                             activator.getClass().getName() + " " + e);
        }
    }
}
