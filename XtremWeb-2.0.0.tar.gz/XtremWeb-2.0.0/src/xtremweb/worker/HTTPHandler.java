package xtremweb.worker;

import xtremweb.common.util;
import xtremweb.common.LoggerLevel;
import xtremweb.common.UID;
import xtremweb.common.StreamIO;
import xtremweb.common.BytePacket;
import xtremweb.common.XMLVector;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLable;
import xtremweb.common.XWOSes;
import xtremweb.common.MD5;
import xtremweb.common.XWConfigurator;

import xtremweb.communications.IdRpc;
import xtremweb.communications.CommHandler;
import xtremweb.communications.XWPostParams;
import xtremweb.communications.XMLRPCCommand;
import xtremweb.communications.XMLRPCCommandActivateHost;
import xtremweb.communications.XMLRPCCommandBroadcastWork;
import xtremweb.communications.XMLRPCCommandDisconnect;
import xtremweb.communications.XMLRPCCommandDownloadData;
import xtremweb.communications.XMLRPCCommandGet;
import xtremweb.communications.XMLRPCCommandGetApps;
import xtremweb.communications.XMLRPCCommandGetDatas;
import xtremweb.communications.XMLRPCCommandGetGroups;
import xtremweb.communications.XMLRPCCommandGetGroupWorks;
import xtremweb.communications.XMLRPCCommandGetHosts;
import xtremweb.communications.XMLRPCCommandGetSessions;
import xtremweb.communications.XMLRPCCommandGetSessionWorks;
import xtremweb.communications.XMLRPCCommandGetTasks;
import xtremweb.communications.XMLRPCCommandGetTraces;
import xtremweb.communications.XMLRPCCommandGetUserByLogin;
import xtremweb.communications.XMLRPCCommandGetUsers;
import xtremweb.communications.XMLRPCCommandGetUserGroups;
import xtremweb.communications.XMLRPCCommandGetWorks;
import xtremweb.communications.XMLRPCCommandRemove;
import xtremweb.communications.XMLRPCCommandSendApp;
import xtremweb.communications.XMLRPCCommandSendData;
import xtremweb.communications.XMLRPCCommandSendGroup;
import xtremweb.communications.XMLRPCCommandSendHost;
import xtremweb.communications.XMLRPCCommandSendTrace;
import xtremweb.communications.XMLRPCCommandSendTask;
import xtremweb.communications.XMLRPCCommandSendUser;
import xtremweb.communications.XMLRPCCommandSendUserGroup;
import xtremweb.communications.XMLRPCCommandSendSession;
import xtremweb.communications.XMLRPCCommandSendWork;
import xtremweb.communications.XMLRPCCommandUploadData;
import xtremweb.communications.XMLRPCCommandWorkAlive;
import xtremweb.communications.XMLRPCCommandWorkAliveByUID;
import xtremweb.communications.XMLRPCCommandWorkRequest;
import xtremweb.communications.XMLRPCCommandPing;

import java.io.IOException;
import java.io.File;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.nio.channels.DatagramChannel;
import java.net.SocketAddress;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.rmi.RemoteException;
import java.util.Iterator;
import java.util.Enumeration;
import java.util.Map;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mortbay.jetty.Connector;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.Response;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.bio.SocketConnector;
import org.mortbay.jetty.handler.AbstractHandler;


/**
 * This handles incoming communications through HTTP.<br>
 * This answers request from HTTPClient as well as any web browser
 *
 * Created: Octobre 2007
 *
 * @see xtremweb.communications.TCPClient
 * @author Oleg Lodygensky
 * @version RPCXW
 */


public class HTTPHandler extends xtremweb.worker.CommHandler {

    protected StreamIO io;
    Request request;
    HttpServletResponse response;

    IdRpc idRpc;
    UserInterface user;

    /**
     * This is the default constructor which only calls super("HTTPHandler")
     */
    public HTTPHandler(){
        super("HTTPHandler");
        user = null;
        idRpc = null;
    }
    /**
     * This is the default constructor which only calls super("HTTPHandler")
     */
    public HTTPHandler(XWConfigurator c){
        this("HTTPHandler", c);
    }
    
    /**
     * This is the default constructor which only calls super("HTTPHandler")
     */
    public HTTPHandler(String n, XWConfigurator c){
        super(n, c);
        user = null;
        idRpc = null;
    }
    
    /**
     * This constructor call the default constructor and sets the logger level
     * @param l is the logger level
     * @see #HTTPHandler(XWConfigurator)
     */
    public HTTPHandler(LoggerLevel l, XWConfigurator c) throws RemoteException {
        this(c);
        setLoggerLevel(l);
    }
    
    /**
     * This constructor call the previous constructor 
     * @param socket is not used
     * @param l is the logger level 
     * @see #HTTPHandler(Level, XWConfigurator)
     */
    public HTTPHandler(Socket socket, LoggerLevel l, XWConfigurator c) throws RemoteException {
        this(l, c);
    }

    /**
     * This does nothing
     */
    public void setSocket(Socket s) throws RemoteException{
    }
    /**
     * This throws an exception since setPacket() is dedicated to UDP comms
     * @exception RemoteException is always thrown since this method is dedicated to UDP comms
     */
    public void setPacket(DatagramSocket s, DatagramPacket p) throws RemoteException{
        throw new RemoteException("HTTPHandler#setPacket() TCP can't set packet");
    }
    /**
     * @see xtremweb.communications.CommHandler#setSocket(Socket)
     * @exception RemoteException is always thrown since this method is dedicated to UDP comms
     */
    public void setPacket(DatagramChannel c, SocketAddress r, BytePacket p) throws RemoteException {
        throw new RemoteException("HTTPHandler#setPacket() TCP can't set packet");
    }

    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.jetty.Handler
     */
    public void setServer(Server server) {
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.jetty.Handler
     */
    public Server getServer() {
        return null;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return true
     */
    public boolean isFailed() {
        return true;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isRunning() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStarted() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStarting() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return true
     */
    public boolean isStopped() {
        return true;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStopping() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     */
    public void start() {
    }


    protected void write(XMLable cmd) {
        try {
            if(response == null) {
                error("Can't write : this.response is not set");
                return;
            }

            System.out.println("HTTPHandler#write(" + cmd.toXml() + ")");
            response.setContentType("text/xml");
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().println(XMLable.XMLHEADER + cmd.toXml());
        }
        catch(Exception e) {
            if(debug())
               e.printStackTrace();
        }
    }
    /**
     * This is not implemented and always throws an IOException
     */
    public void writeFile(File f) throws IOException {
        throw new IOException("HTTPHandler#writeFile not implemented");
    }
    /**
     * This is not implemented and always throws an IOException
     */
    public void readFile(File f) throws IOException {
        throw new IOException("HTTPHandler#readFile not implemented");
    }
    /**
     * This handles incoming connections.
     * This is inherited from org.mortbay.jetty.Handler.
     * <br />
     * This expects a POST parameter : XWPostParams.COMMAND
     * @see xtremweb.communications#XWPostParams
     */
    public void handle(String target, 
                       HttpServletRequest _request, 
                       HttpServletResponse _response, 
                       int dispatch)
        throws IOException, ServletException {
    }
    /**
     * This does nothing since everything is done in HttpClient
     */
    public void run() {
        /*
          try {
          remoteName = socket.getInetAddress().getHostName();
          remoteIP   = socket.getInetAddress().getHostAddress();
          remotePort = socket.getPort();
          io = new StreamIO(new DataOutputStream(socket.getOutputStream()),
          new DataInputStream(socket.getInputStream()),
          socket.getSendBufferSize(), 
          logger.getEffectiveLevel(),
          Context.instance.nio());
          
          info("new connection");
          XMLRPCCommand cmd = XMLRPCCommand.newCommand(io.input());
          //println("command received " + cmd.toXml());
          super.run(cmd);
          }
          catch(Exception e) {
          e.printStackTrace();
          }
        */
    } // run()
    
    /**
     * This cleans and closes communications
     */
    public void close(){
        //Clean up 
        debug("close");
        io.close();
    }
}
