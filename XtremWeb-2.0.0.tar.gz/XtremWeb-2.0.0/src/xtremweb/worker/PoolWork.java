package xtremweb.worker;

/**
 * PoolWork.java
 *
 *
 * Created: Sat Jun 02 14:29:49 2001
 *
 * @author <a href="mailto: fedak@lri.fr">Gilles Fedak</a>
 */

import xtremweb.common.LoggerLevel;
import xtremweb.common.Logger;
import xtremweb.common.util;
import xtremweb.common.WorkInterface;
import xtremweb.common.UID;
import xtremweb.common.XWStatus;

import java.io.File;
import java.io.IOException;
import java.awt.Color;
import java.util.Vector;
import java.util.Iterator;


/**
 * This class describes works managed by worker as a vector
 */
public class PoolWork extends Logger {

    /** Number of works in the pool */
    private static int MAX_WORK = Worker.config.workPoolSize;

    /** This is the vector of works (ready to be or beeing computed). */
    private Vector poolWorks;

    /** 
     * This stores works being saved.
     * @since v1r2-rc0 (RPC-V)
     */
    private Vector savingWorks;

    /**
     * This is the default constructor.
     * This erases any old data.
     */
    public PoolWork(LoggerLevel l) {
        super(l);

        poolWorks = new Vector();
        savingWorks = new Vector();

        File worksDir = Worker.config.getWorksDir();

        try {
            util.deleteDir(worksDir);
            util.checkDir(worksDir);
        }
        catch(IOException e) {
            e.printStackTrace();
            util.fatal("unrecoverable exception " + e);
        }

    }
    /**
     * This tests whether pool is ful
     * @return true is pool is full, false otherwise
     */
    public synchronized boolean isFull() {
        printSize("isFull");
        boolean ret = (poolWorks.size() >= MAX_WORK);
        notify();
        return ret;
    }

    private int lastSize = -1;

    private void printSize(String msg) {
        if(lastSize != poolWorks.size()) {
            debug(msg + " " + poolWorks.size() + " " + MAX_WORK);
            lastSize = poolWorks.size();
        }
    }

    /**
     * This calculates pool size
     * @return an integer containing the pool size
     */
    public synchronized int getSize() {
        int ret =  poolWorks.size();
        notify();
        return ret;
    }


    /**
     * This stores provided work to the list of computing ones; i.e. the
     * list of works being computed by the worker.
     * This is typically called as a new work is provided by the server
     * @see CommManager#run()
     * @param mw is the description of the work to create
     * @return the new inserted Work from the MobileWork
     * @exception Exception is thrown on I/O error
     */
    public synchronized Work addWork(WorkInterface mw) 
        throws Exception {

        Work work;

        debug("PoolWork::addWork ()");

        work = new Work(mw);
        poolWorks.addElement(work);
        printSize("addWork");

        debug("PoolWork::addWork() added");

        notify();
        return work;
    }


    /**
     * This stores the given work to the list of saving ones; i.e. the
     * list of finished works which results are being saved to the coordinator
     * This is called when provided work computation is finished and results can
     * then been sent to the server.
     * @param w is the work to save
     * @see #removeWork(UID)
     * @since v1r2-rc0 (RPC-V)
     */
    public synchronized void saveWork(Work w) {
        try {
            debug("PoolWork::saveWork(" + w.getUID() + ")");
        }
        catch(IOException e) {
            warn("saveWork can't find uid???");
            //						notify();
            return;
        }

        savingWorks.addElement(w);
        poolWorks.remove(w);
        CommManager.instance.workRequest();
        printSize("saveWork");

        notify();
    }


    /**
     * This retreives works being saved
     * @return a vector containing the saving works
     * @since v1r2-rc0(RPC-V)
     */
    public synchronized Vector getSavingWork() {
        Vector ret = savingWorks;
        notify();
        return ret;
    }


    /**
     * This retreives a work being saved
     * @param uid is the task UID to retreive
     * @return the saving work
     * @since v1r2-rc0(RPC-V)
     */
    public synchronized Work getSavingWork(UID uid) {

        Iterator li = savingWorks.iterator();

        while(li.hasNext()) {
            Work theWork =(Work) li.next();
            try {
                if((theWork != null) && theWork.getUID().equals(uid)) {
                    debug("PoolWork::getSavingWork() : task found " + uid);
                    notify();
                    return theWork;
                }
            }
            catch(IOException e) {
                warn("PoolWork::getSavingWork() error ???");
            }
        }
        notify();
        return null;
    }


    /**
     * This remove provided work from saving list.
     * This is called when work results have been successfully saved
     * by the server, or when the work is in unrecoverable error state.
     * @param uid is the task UID to remove
     */
    public synchronized void removeWork(UID uid) {

        Iterator theIterator = savingWorks.iterator();
        debug("PoolWork::removeWork(" + uid + ")");

        while(theIterator.hasNext()) {
            Work theWork =(Work) theIterator.next();
            try {
                if((theWork != null) && theWork.getUID().equals(uid)) {
                    debug("PoolWork::removeWork() : removing " + uid);
                    theWork.clean();
                    theIterator.remove();
                }
            }
            catch(IOException e) {
                warn("PoolWork::removeWork() error ???");
            }
        }

        notify();

    }


    /**
     * This retreives works beeing computed
     * @return a vector containing the saving beeing computed
     * @since v1r2-rc0(RPC-V)
     */
    public synchronized Vector getAliveWork() {
        Vector worksAlive = new Vector();
        Iterator theIterator = poolWorks.iterator();

        // Oleg's hack to enable work alive signal to be **always** sent
        //    while(worksAlive.isEmpty()) {

        while(theIterator.hasNext()) {
            Work w =(Work) theIterator.next();
            if(w.getResult() == null)
                debug("PoolWork::getAliveWork() w.mr is null ");
            else {
                try {
                    debug("PoolWork::getAliveWork() " + w.getUID() + " is " +
                                 w.getStatus().toString());
                }
                catch(Exception e) {
                    warn("PoolWork::getAliveWork() error ???");
                }
            }

            if(w.isRunning()) {
                worksAlive.addElement(w);
            }
        }


        debug("PoolWork::getAliveWork()  worksAlive size = " + worksAlive.size());

        if(worksAlive.isEmpty())
            worksAlive = null;

        notify();
        return worksAlive;

    } // getAliveWork()


    /**
     * This finalize work computation
     * It updates work description to disk and prepare result transfert
     */
    // 		public synchronized void setFinishedWork(Work w) {
    // 				CommManager.instance.sendResult(w);
    // 				notify();
    //     }

    /**
     * This retreives the next available work to compute
     * This returns only when a work to compute is found!
     * @return next available work to compute if any
     */
    public synchronized Work getNextWorkToCompute() {

        Iterator li = poolWorks.iterator();

        while(li.hasNext()) {

            Work w =(Work) li.next();

            if(w.isPending()) {
                w.setStatus(XWStatus.RUNNING);
                notify();
                return w;
            }
        }

        notify();
        return null;

    }


    public synchronized String toString() {

        String workString = "";
        Iterator li = poolWorks.iterator();

        while(li.hasNext()) {

            Work w =(Work) li.next();

            try {
                workString += " Work : " + w.getUID() + " " + 
                    w.getStatus().toString() + "\n";
            }
            catch(Exception e) {
            }

        }

        notify();
        return workString;
    }


}// PoolWork
