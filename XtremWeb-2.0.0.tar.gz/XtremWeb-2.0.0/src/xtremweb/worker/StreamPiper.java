package xtremweb.worker;

import java.io.*;

public class StreamPiper implements Runnable {

    protected BufferedReader  input;
    protected BufferedWriter output;
    protected boolean canRun = true;
    
    public StreamPiper(InputStream in, OutputStream out) {

        input = new BufferedReader (new InputStreamReader (in));
        output = new BufferedWriter (new OutputStreamWriter (out));
    }

    
    public  void terminate() {
        canRun = false;
    }

    
    public void run() {
        try {
            int byteRead = input.read();
            while (canRun && byteRead >= 0) {
                char c = (char)byteRead;
                output.write (byteRead);
                //                output.flush ();
                byteRead = input.read ();
            }
            input.close ();
            output.close ();
        } catch (IOException e) {
            e.printStackTrace ();
            System.err.println("stream piper error " + e);
        }
    }
}
