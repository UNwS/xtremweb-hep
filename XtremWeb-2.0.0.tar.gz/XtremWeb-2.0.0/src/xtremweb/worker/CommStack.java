package xtremweb.worker;

/**
 * CommPool.java
 *
 *
 * Created: Sat Jun  9 13:55:12 2001
 *
 * @author <a href="mailto: fedak@lri.fr> "Gilles Fedak</a>
 */


import xtremweb.common.util;
import xtremweb.communications.IdRpc;

import java.util.Vector;
import java.util.Stack;

public class CommStack extends CommQueue {

    private Stack  poolQueue;
    private Vector commEventInProgress;
    private int size;

    public CommStack(){
        size = 0;
        poolQueue = new Stack();
        commEventInProgress = new Vector(MAX_COMMEVENT_INPROGRESS);
        level = Worker.config.getLoggerLevel();
    }


    // 		public synchronized void workRequest() {
    // 				size++;
    // 				poolQueue.push(new CommEvent(COMM_GETWORK));
    // 				notifyAll();
    // 		}
    public void workRequest() {
        size++;
        poolQueue.push(new CommEvent(IdRpc.WORKREQUEST));
    }


    // 		public synchronized void sendResult(Work w) {
    // 				//logger.debug("Added Communcation : SEND RESULT " + w.getWid());
    // 				size++;
    // 				poolQueue.push(new CommEvent(COMM_SENDRESULT,w));
    // 				notifyAll();
    // 		}
    public void sendResult(Work w) {
        //logger.debug("Added Communcation : SEND RESULT " + w.getWid());
        size++;
        poolQueue.push(new CommEvent(IdRpc.UPLOADDATA,w));
    }


    // 		public synchronized CommEvent getCommEvent() {
    // 				while(poolQueue.isEmpty() || commEventInProgress.size()
    // 							> MAX_COMMEVENT_INPROGRESS) {

    // 						try {
    // 								wait(1000);
    // 						} 
    // 						catch(InterruptedException ie) {
    // 								continue;
    // 						}
    // 				}

    // 				size--;
    // 				CommEvent ce =(CommEvent) poolQueue.pop();
    // 				commEventInProgress.addElement(ce);
    // 				notifyAll();
    // 				return ce;
    // 		}

    public CommEvent getCommEvent() {
        if((poolQueue.isEmpty()) || 
           (commEventInProgress.size() > MAX_COMMEVENT_INPROGRESS))
            return null;

        size--;
        CommEvent ce =(CommEvent) poolQueue.pop();
        commEventInProgress.addElement(ce);
        return ce;
    }


    // 		public synchronized void removeCommEvent(CommEvent ce) {
    // 				commEventInProgress.removeElement(ce);
    // 				notifyAll();
    // 		}
    public void removeCommEvent(CommEvent ce) {
        commEventInProgress.removeElement(ce);
    }

    public int size() {
        return size;
    }
    public int size(int type) {
        return size;
    }

}
