package xtremweb.worker;

import xtremweb.common.util;
import xtremweb.common.LoggerLevel;
import xtremweb.common.LoggerableThread;


import java.io.*;
import java.net.*;



/**
 * ThreadLock.java
 * This Thread Launch the screen saver
 *
 * Created: Thu Jun 29 17:47:11 2000
 *
 * @author Gilles Fedak
 */

public class ThreadLock extends LoggerableThread {

    private Process xlockProcess;
    
    ThreadLock(LoggerLevel l) {
        super ("ThreadLock", l);
    }

    public void run() {

        info("ThreadLock: started");

        String screensaverPath = Worker.config.getProperty("activator.screensaver.path");
        if (screensaverPath == null) { 
            warn ("ScreenSaver not found in the config file (key activator.screensaver.path)");
            return; 
        }
        try {
            Runtime machine   = java.lang.Runtime.getRuntime();
            String[] cmd = {"/bin/sh","-c",screensaverPath};
            //      String[] cmd = {"/bin/sh","-c","xmessage xlock  started"};
            xlockProcess = machine.exec( cmd );
        }  catch (Exception e) {
            error("erreur: " + e.getMessage());
        }

        // Wait until end of computation
        while (!ThreadLaunch.instance.available ()) {
            yield();
        }
    
        xlockProcess.destroy();
    }
}
