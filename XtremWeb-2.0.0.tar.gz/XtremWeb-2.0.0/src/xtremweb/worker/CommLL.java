package xtremweb.worker;

/**
 * CommPool.java
 *
 *
 * Created: Sat Jun  9 13:55:12 2001
 *
 * @author <a href="mailto: fedak@lri.fr> "Gilles Fedak</a>
 * @version %I% %G%
 */


import xtremweb.common.util;
import xtremweb.communications.IdRpc;

import java.io.IOException;
import java.util.Vector;


/**
 * This class implements the CommQueue class as a linked list
 */
public class CommLL extends CommQueue {

    private Vector poolQueue;
    private Vector commEventInProgress;

    public CommLL(){
        poolQueue = new Vector(MAX_COMMEVENT_INPROGRESS);
        commEventInProgress = new Vector(MAX_COMMEVENT_INPROGRESS);
        level = Worker.config.getLoggerLevel();
    }

    // 		public synchronized void workRequest() {
    // 				poolQueue.addLast(new CommEvent(COMM_GETWORK));
    // 				notifyAll();
    // 		}
    public void workRequest() {
        poolQueue.add(new CommEvent(IdRpc.WORKREQUEST));
    }

    // 		public synchronized  void sendResult(Work w) {
    // 				try {
    // 						info("Added Communcation : SENDRESULT " + w.getUID());
    // 				}
    // 				catch(IOException e) {
    // 				}
    // 				poolQueue.addFirst(new CommEvent(COMM_SENDRESULT,w));
    // 				notifyAll();
    // 		}
    public void sendResult(Work w) {
        try {
            info("Added Communcation : SENDRESULT " + w.getUID());
        }
        catch(IOException e) {
        }
        poolQueue.add(0, new CommEvent(IdRpc.UPLOADDATA,w));
    }

    // 		public synchronized CommEvent getCommEvent() throws InterruptedException {

    // 				while(poolQueue.isEmpty() || commEventInProgress.size() > MAX_COMMEVENT_INPROGRESS) 
    // 						wait(1000);
    // 				CommEvent ce =(CommEvent) poolQueue.removeFirst();
    // 				commEventInProgress.add(ce);
    // 				notifyAll();
    // 				return ce;
    // 		}
    public CommEvent getCommEvent() {

        if(poolQueue.isEmpty() || 
           (commEventInProgress.size() > MAX_COMMEVENT_INPROGRESS))
            return null;

        CommEvent ce =(CommEvent) poolQueue.remove(0);
        commEventInProgress.add(ce);
        return ce;
    }

    // 		public synchronized void removeCommEvent(CommEvent ce) {
    // 				commEventInProgress.remove(ce);
    // 				notifyAll();
    // 		}
    public void removeCommEvent(CommEvent ce) {
        commEventInProgress.remove(ce);
    }

    public int size() {
        return poolQueue.size();
    }
    public int size(int type) {
        return poolQueue.size();
    }

}// CommPool
