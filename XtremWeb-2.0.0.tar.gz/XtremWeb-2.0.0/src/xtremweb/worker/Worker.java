package xtremweb.worker;

// Worker.java
// XtremWeb Worker main class.
// Created: Thu Jun 29 17:47:11 2000


import xtremweb.common.Logger;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.XWConfigurator;
import xtremweb.common.CommandLineOptions;
import xtremweb.common.CommandLineParser;
import xtremweb.common.CommonVersion;
import xtremweb.common.util;
import xtremweb.communications.HTTPServer;

import java.util.Properties;
import java.util.Date;
import java.util.jar.JarFile;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;


/**
 * This class describes the XtremWeb Worker.
 * It has a single infinite loop, where it creates a new
 * <CODE>ThreadLaunch</CODE>, starts it and waits for it to die.
 *
 * @author Gilles Fedak, Oleg Lodygensky
 * @version @VERSION@
 */

public class Worker extends Logger{

    /**
     * This stores and tests the command line parameters
     */
    private CommandLineParser args;
    /**
     * The <CODE>config</CODE> variable implements the environment as
     * read from disk.
     */
    public static XWConfigurator config;
    private static int NEEDS_INIT = 1;
    private static int NEEDS_CHECK_ALONE = 2;
    private int status = NEEDS_INIT;

    /**
     * This is the default constructor
     */
    public Worker() {
        // second find a place to store cached files
        if (System.getProperty("xtremweb.cache") == null) {
            System.setProperty("xtremweb.cache", (new File("cache")).getAbsolutePath());
        }
    }


    /**
     * This shows application usage
     * @see xtremweb.common.CommandLineOptions#usage()
     */
    private void usage() {
        args.usage("XWHEP computing element.", CommandLineOptions.CONFIG);
    }

    public void initialize(String[] argv) {

        try {
            args = new CommandLineParser(argv);
        }
        catch(Exception e){
            usage();
        }

//         // let preload RPC service now
//         xtremweb.services.Interface obj = null;
//         String classname = "xtremweb.services.rpc.rpc";
//         logger.debug("executService " + classname);

//         try {
//         obj = (xtremweb.services.Interface)Class.forName(classname).newInstance();
//         }
//         catch(Exception e) {
//         util.fatal("Worker::initialize () : can't init RPCXW service (" + e + ")");
//         }

        // create directory that are required
        try {
            util.checkDir(System.getProperty("xtremweb.cache"));
            util.checkDir(System.getProperty("xtremweb.cache") + "/logs");
        } catch (IOException e) {
            util.fatal("Worker::initialize () : unrecoverable exception " + e.toString());
        }
        if (System.getProperty("xtremweb.alone") == null)
            status |= NEEDS_CHECK_ALONE;
    }

    /**
     * The <CODE>main</CODE> method contains a infinite loop to start and wait
     * for a single <CODE>ThreadLaunch</CODE>.
     */
    public static void main(String[] argv) {
        Worker worker = new Worker();
        worker.initialize(argv);
        worker.run();
    }

    public void run() {

        boolean firstime = 0 != (status & NEEDS_CHECK_ALONE);
        String fullrev = CommonVersion.getCurrent().full();

        if ((status & NEEDS_INIT) != 0) {

            Properties defaults = new Properties();

            try {

                InputStream def = this.getClass().getClassLoader()
                    .getResourceAsStream("data/config.defaults");

                if (def == null) {

                    throw new IOException();
                }
                defaults.load(def);
            } catch (IOException e) {
                //                logger.info ("Worker::run () datas/default.config not found in XWW.jar");
            }


            String configFileName = null;

            try {
                config = (XWConfigurator)args.getOption(CommandLineOptions.CONFIG);
            }
            catch(Exception e) {
                util.fatal("can retreive config file");
            }
            level = ((XWConfigurator)config).getLoggerLevel();
        }

        config.dump(System.out, "XWHEP Worker started ");

        CommManager commThread = new CommManager ();
       
        commThread.setDaemon (true);
        commThread.start();


        ThreadLaunch launch = null;
        try {
            launch = new ThreadLaunch(level);
        } 
        catch (Exception ex) { 
            util.fatal("Worker::run () uncaught exception" + ex);
        }

        ThreadAlive aliveThread = new ThreadAlive(config);
        aliveThread.setDaemon(true);
        aliveThread.start();

        if(config.http() == true) {
            try {
                // This opens HTTP communication
                HTTPServer httpServer = new HTTPServer(level);
                httpServer.initComm(config,
                                    new HTTPHandler(level,
                                                    config));
                httpServer.addHandler(new HTTPStatHandler(level));
                httpServer.start();
            } 
            catch (Exception ex) { 
                if(debug())
                    ex.printStackTrace ();
                System.err.println("Worker::run () can't init HTTP Server : " + ex);
            }
        }

        // Init tracer thread
        if (config._host.isTracing()) {
            XWTracer tracerThread = new XWTracer(true, level);
            tracerThread.setDaemon(true);
            tracerThread.start();
        }

        /*
         * main loop
         */
        while(true) {
            try {
	    
                if (launch == null)
                    try {
                        launch = new ThreadLaunch(level);
                    } 
                    catch (Exception ex) { 
                        util.fatal("Worker::run () uncaught exception " + ex);
                    }

                launch.start();
                // destroy
                launch.join();
		 
            }
            catch (InterruptedException e) {
		
            } // end of try-catch

		
        }
	
    }
}
