package xtremweb.worker;

/**
 *  File   : CpuActivator.java
 *  Date   : June 15th, 2004.
 *  Author : Oleg Lodygensky (lodygens /at\ lal.in2p3.fr)
 */


import xtremweb.archdep.ArchDepFactory;
import xtremweb.archdep.XWUtil;
import xtremweb.common.util;

import java.util.Properties;


/**
 * <CODE>CpuActivator</CODE> monitors CPU activity
 *
 * @author Oleg Lodygensky
 *
 */


public class CpuActivator extends PollingActivator {


    private int remains = 0;
    private XWUtil irq = null;


    /**This is for debug purposes only*/
    private boolean lastState;

    /**
     * This is the default contructor
     * This initializes IRQ counter
     */
    public CpuActivator () {

        irq = ArchDepFactory.xwutil ();

        irq.getCpuLoad ();
        irq.getProcessLoad ();

        lastState = false;
    }


    /** 
     * This initializes the activator accordingly to the config file
     * @param config is the Properties read from file
     * @see PollingActivator#initialize(java.util.Properties)
     */
    public void initialize (Properties config) {

        super.initialize (config);

        remains = activationDelay;
        raz ();
    }


    /**
     * This resets all
     * @see xtremweb.archdep.XWUtilLinux#raz()
     */
    public void raz () {
        irq.raz ();
    }


    /**
     * This detect this host activity
     * @see xtremweb.common.XWConfigurator#cpuLoad
     * @return true if the machine is loaded and XWWorker should top computing
     */
    private boolean isActive() {

        boolean ret = true;
        int cpuLoad = irq.getCpuLoad ();
        int processLoad = irq.getProcessLoad ();
        int i = 0;

        for (i = 0; 
             ((cpuLoad < 0)     || (cpuLoad > 100) || 
              (processLoad < 0) || (processLoad > 100));) {

            try {
                Thread.sleep (1);
            }
            catch (Exception e) {
            }

            cpuLoad = irq.getCpuLoad ();
            processLoad = irq.getProcessLoad ();

            if (++i > 50)
                break;
        }


        int others = Math.abs (cpuLoad - processLoad);

        if (Worker.config.cpuLoad() > others)
            ret = false;

        if (ret != lastState) {
            debug ("  %CPU(host) "+ cpuLoad + "  %CPU(worker) = " + 
                   processLoad + "  %CPU(others) = " + others);

            debug ("Cpu " + (ret == false ? "not" : "") +
                   " available : " + Worker.config.cpuLoad() + " > " + others);

            lastState = ret;
        }

        System.gc ();

        return ret;
    }

    /**
     * This tells whether the worker can start computing, accordingly to the 
     * local activation policy
     * @return true if the work can start computing
     */    
    protected boolean canStart () {

        if (this.isActive()) {
            remains = activationDelay;
        }
        else {
            remains -= waitingProbeInterval;
        }
        info("activation in " + remains + " ms");

        return (remains <= 0);    

    }


    /**
     * This tells whether the worker must stop computing, accordingly to the 
     * local activation policy
     * @return true if the work must stop computing
     */    
    protected boolean mustStop () {

        boolean ret = isActive ();
        int i;

        // let try 3 times to ensure this is not due to a peack only...

        for (i = 0; (i < 3) && ret; i++) {

            try {
                Thread.sleep (500);
            }
            catch (Exception e) {
            }

            ret = isActive ();
        }

        if (ret) {
            remains = activationDelay;
        }
        return ret;
    }

}
