package xtremweb.worker;

import xtremweb.common.DataType;
import xtremweb.common.LoggerableThread;
import xtremweb.common.LoggerLevel;
import xtremweb.common.URI;
import xtremweb.common.util;
import xtremweb.common.UID;
import xtremweb.common.MD5;
import xtremweb.common.XWOSes;
import xtremweb.common.XWCPUs;
import xtremweb.common.util;
import xtremweb.common.XWStatus;
import xtremweb.common.MileStone;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.Zipper;
import xtremweb.common.StreamIO;
import xtremweb.common.XWPropertyDefs;
import xtremweb.communications.Connection;
import xtremweb.exec.*;
import xtremweb.archdep.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;


/**
 * ThreadWork.java Launch a java Work
 * 
 * Created: Thu Jun 29 17:47:11 2000
 *
 * @author Gilles Fedak, V. Neri
 * @version %I% %G%
 */

public class ThreadWork extends LoggerableThread {

    /**
     * This tells whether the process has been killed If false, the process is
     * has terminated just by itself(it reached its "normal" endpoint)
     */
    private boolean killed = false;

    /** This is the native running process */
    private Process workProcess = null;

    /** This is the process work */
    private Work work;

    /** This manages zip files */
    Zipper zipper;

    /** This contains processes return code */
    private int processReturnCode;

    /**
     * This aims to display some time stamps
     */
    MileStone mileStone;

    /**
     * This manages processes
     * 
     * @deprecated since we now use exec variable
     * @see #exec
     */
    private Runtime machine = Runtime.getRuntime();

    /**
     * This manages processes
     * 
     * @see xtremweb.exec.Executor
     */
    private Executor exec;

    private AlwaysActive alwaysActive;

    /**
     * This stores XtremWeb services in order to minimize class loadings
     */
    Hashtable services;

    /**
     * This is the default and only constructor
     */
    ThreadWork() {
        super("ThreadWork");
        //debug("new threadwork created");
        alwaysActive = new xtremweb.worker.AlwaysActive();	
        mileStone = new MileStone(getClass().getName());

        level = Worker.config.getLoggerLevel();

        zipper = new Zipper(level);

        services = new Hashtable();

        xtremweb.services.Interface obj = null;
        String classname = "xtremweb.services.rpc.rpc";
        try {
            obj = (xtremweb.services.Interface)Class.forName(classname).newInstance();
            obj.setLoggerLevel(level);
            services.put(classname, obj);
        } 
        catch(Exception e) {
           error("cant preload " + classname + " : " + e);
        }

    }

    private synchronized void waitForCompute() throws InterruptedException {
        if(ThreadLaunch.instance.getActivator() instanceof AlwaysActive) {
            //debug("is AlwaysActive");
            notify();
            return;
        }

        while(!ThreadLaunch.instance.available()) {
            //info("ThreadWork : wait to compute");
            this.wait();
            //info("ThreadWork : compute allowed");
        }
        notify();
    }

    public void run() {

        XWStatus status = XWStatus.RUNNING;

        //info("Waiting for jobs");

        while(true) {
            try {

                if(Worker.config.realTime() == false)
                    waitForCompute();

                work = CommManager.instance.poolWork.getNextWorkToCompute();

                if(work == null) {
                    try {
                        sleep(Long.parseLong(Worker.config.getProperty(XWPropertyDefs.TIMEOUT.toString())));
                    }
                    catch(InterruptedException e) {
                    }
                    continue;
                }

                try {
                    UID uid = work.getUID();
                    //info("Computing Work :" + uid);
                    work.setRunning();
                    //		    work.write();

                    mileStone.println("executing", uid);
                    status = executeJob();
                    mileStone.println("executed", uid);
                }
                catch(Exception e) {
                    error("job launch error : " + e.toString());
                    status = XWStatus.ERROR;
                    work.clean();
                    work.setErrorMsg(e.toString());
                }

                work.setStatus(status);

                if(status != XWStatus.PENDING) {

                    CommManager.instance.sendResult(work);
                }

                work = null;

            } 
            catch(InterruptedException e) {
                warn(e.toString());
            }
        }
    }

    public Work getWork() {
        return work;
    }

    public void suspendProcess() {
        stopProcess();
    }

    /**
     * This stops the running process, if any
     */
    public void stopProcess() {
        //debug("stop process");
        if(exec != null) {
            if(exec.isRunning()) {
                try {
                    exec.stop();
                    killed = true;
                    //debug("stopping process : " + exec.destroy());
                    exec = null;
                    //debug("Really stopped");
                    ThreadLaunch.instance.raz();
                } catch(Exception e) {
                    error("ThreadWork.stopProcess() error " + e);
                }
            } else {
                error("ThreadWork.stopProcess() invoked with no process");
            }
        }
        //rajouter du code pour detruire la JVM qui lance le byte code
    }

    protected void finalize() throws Throwable {
        //debug("ThreadWork finalized");
        stopProcess();
        super.finalize();
    }

    /**
     * This restarts the current process, if any Mar 16th, 2005 : we don't
     * restart a process which status is LONGFILE
     * 
     * @see #executeJob()
     */
    public synchronized void resumeProcess() {
        //info("resuming process");
        killed = false;

        if(work != null) {
            try {
                work.prepareDir();
            }
            catch(Exception e) {
                error("can't prepare dir " + e);
                e.printStackTrace();
                try {
                    this.finalize();
                }
                catch(Throwable t) {
                }
            }
        }

        notifyAll();
    }

    /**
     * This dispatches native(i.e. binary) and Java jobs
     * 
     * @see #executeJavaJob(ArrayList)
     * @see #executeNativeJob(ArrayList)
     * @see #sendResult()
     * @return mobile work status : - XWStatus.LONGFILE or -
     *         XWStatus.COMPLETED Mar 16th, 2005 : when computing is
     *         done, we mark the job as LONGFILE since zipping may be long
     *         stopProcess() followed by resumeProcess() may be called while
     *         zipping/saving and we don't want to restart a zipping/saving
     *         process
     * 
     * Not mentionning that resumeProcess() calls work.prepareDir() which
     * erases all dir structure, hence the zipping fails. The job and the worker
     * are then considered faulty : job will not be reschedulled; the worker is
     * deactivated. :(
     * 
     * resumeProcess() has been modified accordingly
     * 
     * This clearly means that CPU can not be released from zipping/saving
     * processing even if the user ask its CPU :(
     * 
     * @see #resumeProcess()
     */
    private XWStatus executeJob() throws Exception {

        XWStatus ret = XWStatus.PENDING;

        //				zipper = new Zipper(logger.getEffectiveLevel());
        zipper.setCreation(false);

        killed = false;

        //				String appName = work.getMobileWork().getApplicationName();

        Vector cmdLine = null;
        if(work.isService() == false) {

            prepareWorkingDirectory();

            cmdLine = getCmdLine();

            // Oct 22th, 2003 : we sleep 250 millisec to be sure there will be a
            // difference in file.lastMofified()(see src/common/Zipper.java::generate())
            if(Worker.config.realTime() == false) {
                int attente = 250;
                sleep(attente);
            }

            //debug("Try to execute Job " + work.getUID());

            //debug(appName);
        }

        if(work.isService()) {
            ret = executeService(cmdLine);
        }
        else {
            executeNativeJob(cmdLine);
        }

        ThreadLaunch.instance.raz();

        mileStone.println("managing result", work.getUID());

        if(!killed) {
            //debug(work.getUID() + " not killed");

            try {
                if(work.isService() == false) {
                    zipResult();
                    ret = XWStatus.COMPLETED;
                }
                try {
//                     if(CommManager.instance.commClient().getContentFile(work.getResult()).exists())
//                         System.out.println("************** 00 ThreadWork resultFile exists");
//                     else
//                         System.out.println("************** 00 ThreadWork resultFile does not exists");

                    util.deleteDir(work.getScratchDir());

//                     if(CommManager.instance.commClient().getContentFile(work.getResult()).exists())
//                         System.out.println("************** 01 ThreadWork resultFile exists");
//                     else
//                         System.out.println("************** 01 ThreadWork resultFile does not exists");

                } 
                catch(Exception ioe) {
                    error("uuhh ? deleteDir() : " + ioe);
                }
            } 
            catch(Exception e) {
                ret = XWStatus.ERROR;
                work.clean();
                //                if(looger.getEffectiveLevel() == Level.DEBUG)
                    e.printStackTrace();
                work.setErrorMsg("Worker result error : " + e);
                error("Result error(" + work.getUID() + ") : " + e);
            }
        } else {
            ret = XWStatus.ABORTED;
            work.clean();
            warn("Aborted : " + work.getUID());
        }

        mileStone.println("result managed", work.getUID());

        killed = false;

        return ret;
    }

    /**
     * This retreives the current process binary path
     */
    protected File getBinPath() throws IOException {
        try {
            AppInterface app = 
                (AppInterface)CommManager.instance.commClient().get(work.getApplication());
            URI bin = app.getBinary(Worker.config._host.getCpu(), 
                                    Worker.config._host.getOs());
            return CommManager.instance.commClient().getContentFile(bin);
        }
        catch(Exception e) {
            e.printStackTrace();
            throw new IOException(e.toString());
        }
    }

    /**
     * This retreives the current process command line
     */
    protected Vector getCmdLine() throws IOException{
        Vector cmdline = new Vector();

        if(Worker.config.useSandbox) {
            cmdline = util.split(Worker.config.sandboxName);
        }

        cmdline.add(getBinPath().getAbsolutePath());

        if(work.getCmdLine() != null) {
            cmdline.addAll(util.split(work.getCmdLine()));
        }
        return cmdline;
    }
    /**
     * This installs data from cache to home directory.
     * If data content is a ZIP file, it is unzipped to home dir, otherwise it is copied
     * @param uri is the data URI 
     * @param home is the directory to install data content
     */
    protected void installFile(URI uri, File home) 
        throws IOException {

        File fData = null;
        DataInterface theData = null;
        
        try {
            fData = CommManager.instance.commClient().getContentFile(uri);
            theData = (DataInterface)CommManager.instance.commClient(uri).get(uri);
        }
        catch(Exception e) {
            e.printStackTrace();
            return;
        }

        debug("installFile = " + fData);

        zipper.setFileName(fData.getAbsolutePath());
        if(zipper.unzip(home.getAbsolutePath()) == false) {
            // this is not a zip file
            // copy content from cache to pwd
            File fout = new File(home,
                                 (String)(theData.getName() != null ? 
                                          theData.getName() :
                                          theData.getUID().toString()));
            FileOutputStream fos = new FileOutputStream(fout);
            DataOutputStream output = new DataOutputStream(fos);
            StreamIO io = new StreamIO(output, null, 10240, 
                                       level, 
                                       Worker.config.nio());
            io.writeFile(fData);
            io.close();
        }
    }
    /**
     * This prepares the job environment (i.e. unzip/copy expected files)
     * This unzip/copies:
     * <ul>
     * <li> app base dirin
     * <li> app default dirin if job dirin is not defined
     * <li> app default stdin if job stdin is not defined
     * <li> job dirin
     * <li> job stdin
     * </ul>
     * @exception IOException is thrown on I/O error
     */
    protected void prepareWorkingDirectory() throws IOException {

        debug("prepareWorkingDirectory : scratchDir = " + work.getScratchDir());

        util.checkDir(work.getScratchDir());

        AppInterface app = null;
        try {
            app = (AppInterface)CommManager.instance.commClient()
                .get(work.getApplication());
        }
        catch(Exception e) {
            e.printStackTrace();
            app = null;
        }
        if(app == null)
            throw new IOException("work defines now application");

        if(app.getBaseDirin() != null) {
            debug("prepareWorkingDirectory : using base app dirin");
            installFile(app.getBaseDirin(), work.getScratchDir());
        }

        //
        // don't install app default dirin if job defined its own one
        //
        if(work.getDirin() == null) {
            if(app.getDefaultDirin() != null) {
                debug("prepareWorkingDirectory : using app default dirin");
                installFile(app.getDefaultDirin(), work.getScratchDir());
            }
        }
        else {
            debug("prepareWorkingDirectory : don't use app default dirin");
            if(work.getDirin().isNull() == false) {
                // maybe job defined dirin to NULLUID 
                // to ensure app default is not used
                // in such a case, job has no dirin
                installFile(work.getDirin(), work.getScratchDir());
            }
            else
                debug("prepareWorkingDirectory : job has no dirin");
        }
        //
        // don't install app default stdin if job defined its own one
        //
        if(work.getStdin() == null) {
            if(app.getDefaultStdin() != null) {
                debug("prepareWorkingDirectory : using app default stdin");
                installFile(app.getDefaultStdin(), work.getScratchDir());
            }
        }
        else {
            debug("prepareWorkingDirectory : don't use app default stdin");
            //
            // maybe job defined stdin to NULLUID 
            // to ensure app default is not used
            // in such a case, job has no stdin
            //
            if(work.getStdin().isNull() == false)
                installFile(work.getStdin(), work.getScratchDir());
            else
                debug("prepareWorkingDirectory : job has no stdin");
        }
        zipper.resetFilesList();
        zipper.setFilesList(work.getScratchDir());
    }

    /**
     * This prepares the job result(i.e. zip the job result)
     * 
     * @exception Exception is thrown on I/O error
     */
    public void zipResult() throws Exception {

        mileStone.println("start zipping", work.getUID());

        if(zipper.getFileName() != null) {
            File f = new File(zipper.getFileName());
            if(f.exists())
                f.delete();
        }
		
        DataInterface data = null;
        if(work.getResult() == null) {

            UID newUID = new UID();
            URI uri = new URI(Worker.config.getCurrentDispatcher(),
                              newUID);
            debug("work setResult(" + uri + ")");
            work.setResult(uri);
            data =  new DataInterface(newUID);
            data.setCpu(XWCPUs.getCpu());
            data.setOs(XWOSes.getOs());
        }
        else {
            data = (DataInterface)CommManager.instance.commClient(work.getResult()).get(work.getResult());
            if(data == null) {
                data = new DataInterface(work.getResult().getUID());
                data.setCpu(XWCPUs.getCpu());
                data.setOs(XWOSes.getOs());
            }
        }

        if((data.getName() == null) || (data.getName().length() <= 0))
            if((work.getLabel() == null) || (work.getLabel().length() <= 0))
                data.setName(DataType.RESULTHEADER + work.getUID());
            else
                data.setName(DataType.RESULTHEADER + work.getLabel());
        data.setOwner(work.getUser());

        // insure it is in the cache : put and get
        //        CommManager.instance.commClient(work.getResult()).addToCache(work.getResult());
        CommManager.instance.commClient().send(data);

        //
        // it may happen (especially when debugging the full platform on a single machine)
        // that the data we have just sent are not immediatly ready
        // this loop allows a delay
        //
        boolean wecanwait = true;
        int essai = 0;
        while(wecanwait == true){
            try {
                CommManager.instance.commClient().get(work.getResult());
                wecanwait = false;
            }
            catch(Exception e) {
                System.out.println("we can wait " + essai);
                if(essai++ > 10)
                    throw e;

                try {
                    Thread.sleep(1000); // sleep 1 second
                }
                catch(InterruptedException ie) {
                }
            }
        }

        File resultFile = CommManager.instance.commClient().getContentFile(work.getResult());
//         System.out.println("00 ThreadWork#zipResult() " + 
//                            work.getResult() + " " +
//                            "resultFile = " + resultFile);

        //
        // We don't keep stdout nor stderr if empty
        //
        File out = new File(work.getScratchDir(), util.STDOUT);
        File err = new File(work.getScratchDir(), util.STDERR);

//        System.out.println("ThreadWork#zipResult : resultFile " + resultFile.getCanonicalPath());

        if(out.exists() && (out.length() == 0)) {
//            System.out.println("%%%%%%%%%%%%%%%%%%% deleting " + out.getAbsolutePath());
            out.delete();
        }
//         else {
//             System.out.println("ThreadWork#zipResult : stdout " + out.getAbsolutePath() +
//                                " ; exists = " + out.exists() +
//                                " ; length = " + out.length());
//         }
        if(err.exists() &&(err.length() == 0)) {
//            System.out.println("%%%%%%%%%%%%%%%%%%% deleting " + err.getAbsolutePath());
            err.delete();
        }
//         else {
//             System.out.println("ThreadWork#zipResult : stderr " + err.getAbsolutePath() +
//                                " ; exists = " + err.exists() +
//                                " ; length = " + err.length());
//         }

        String[] resultDirName = new String[1];
        resultDirName[0] = new String(work.getScratchDirName());
//        System.out.println("resultDirName[0] = " + resultDirName[0]);

//         if(new File(resultDirName[0]).exists() == false) {
//             System.out.println("01 ThreadWork#zipResult() dirname = " + 
//                                resultDirName[0] + " does not exist");
//         }

        //debug("Try to zip: " + resultDirName[0]);
        zipper.setFileName(resultFile.getCanonicalPath());

        data = (DataInterface)CommManager.instance.commClient().get(work.getResult());

        if(zipper.zip(resultDirName,
                      Worker.config.getBoolean(XWPropertyDefs.OPTIMIZEZIP,
                                               true)) == true) {

//            System.out.println("02 ThreadWork#zipResult() zipped");

            data.setType(DataType.ZIP);
        }
        else {
            data.setType(DataType.NONE);

            if(zipper.getFileName() != null) {
                
                /*
                System.out.println("02 ThreadWork#zipResult() fileCopy("
                                   + zipper.getFileName() +", " +
                                   resultFile.getAbsolutePath() + ")");

                System.out.println("scratchdir = " + work.getScratchDirName());
                System.out.println("scratchdir.length = " + work.getScratchDirName().length());
                System.out.println("z.filename = " + zipper.getFileName());
                System.out.println("z.filename.length = " + zipper.getFileName().length());
                System.out.println("z.substring = " + zipper.getFileName().substring((int)(work.getScratchDirName().length() + 1)));
                */

                data.setName(zipper.getFileName().substring((int)(work.getScratchDirName().length() + 1)));

                if(zipper.getFileName().endsWith(DataType.TEXT.getFileExtension())) {
                    data.setType(DataType.TEXT);
                }

                File sourceResult = new File(zipper.getFileName());
                if(sourceResult.exists()) {
                    
                    //                    System.out.println("02 ThreadWork#zipResult() source file exists");
                    util.fileCopy(new File(zipper.getFileName()),resultFile);
                }
//                 else
//                     System.out.println("02 ThreadWork#zipResult() source file does not exist");
//                 if(resultFile.exists())
//                     System.out.println("02 ThreadWork#zipResult() resultFile exists");
//                 else
//                    System.out.println("02 ThreadWork#zipResult() resultFile does not exist");
            }
//            System.out.println("02 ThreadWork#zipResult() not zipped");
        }
        if(resultFile.exists() == true) {
//            System.out.println("02 ThreadWork#zipResult() resultFile exists");
            data.setMD5(MD5.asHex(MD5.getHash(resultFile)));
            data.setSize((long)resultFile.length());
        }
//         else
//             System.out.println("02 ThreadWork#zipResult() resultFile does not exist");

        data.setOwner(work.getUser());

//        System.out.println("ThreadWork#zipResult() send(" + data.toXml() + ")");
        CommManager.instance.commClient().send(data);

        mileStone.println("end zipping", work.getUID());
    }

    /**
     * This executes a native job
     * 
     * @param cmdLine command line for execution
     * @exception WorkException is thrown on execution error
     */
    protected void executeNativeJob(Vector cmdLine) 
        throws WorkException, IOException {

        String fullBinName = getBinPath().getAbsolutePath();

        ArchDepFactory.xwutil().chmodpx(fullBinName);

        mileStone.println("preparing execution", work.getUID());

        debug("Execute Native Job " + work.getUID());
        String[] cmd = new String[cmdLine.size()];
        String command = new String();
        for(int i = 0; i < cmdLine.size(); i++) {
            cmd[i] =(String) cmdLine.get(i);
            if(cmd[i] != null)
                command += cmd[i] + " ";
        }
        System.out.println(work.getUID() + " launches " + command);

        File stdin = null;
        try {
            stdin =
                CommManager.instance.commClient().getContentFile(work.getStdin());
            util.checkDir(work.getScratchDir());
        }
        catch(Exception e) {
            e.printStackTrace();
            throw new IOException(e.toString());
        }

        System.out.println("" +work.getUID() + " executing on dir "
                           + work.getScratchDirName() + " stdin " +
                           (stdin == null ? "null" : stdin.getAbsolutePath()));
        FileInputStream in = null;
        if(stdin != null)
            in = new FileInputStream(stdin);
        FileOutputStream out = new FileOutputStream(new File(work.getScratchDir(), util.STDOUT));
        FileOutputStream err = new FileOutputStream(new File(work.getScratchDir(), util.STDERR));
        exec = new Executor(command,
                            work.getScratchDirName(), in, out, err,
                            Long.parseLong(Worker.config.getProperty(XWPropertyDefs.TIMEOUT.toString())));

        try {
            if((Boolean.getBoolean(Worker.config.getProperty(XWPropertyDefs.JAVARUNTIME.toString())))
               && (stdin == null)) {
                mileStone.println("executing (Runtime)", work.getUID());
                Runtime machine = Runtime.getRuntime();
                Process process = machine.exec(command, null, work.getScratchDir());
                process.waitFor();
                processReturnCode = process.exitValue();
            }
            else {
                mileStone.println("executing (Executor)", work.getUID());
                processReturnCode = exec.startAndWait();
            }
        }
        catch(Throwable e) {
            error(e.toString());
            processReturnCode = -1;
        }

        mileStone.println("executed", work.getUID());

        debug(work.getUID() + " process exited with code "
                     + processReturnCode);


        if(processReturnCode == 129) {
            killed = true;
        }
        if(!killed) {
            work.setReturnCode(processReturnCode);
        }

        workProcess = null;
        debug("end of executeNativeJob() " + work.getUID());

    } // executeNativeJob()


    /**
     * This executes an embedded services
     * 
     * @param cmdLine command line for execution
     * @exception WorkException is thrown on execution error
     */
    protected XWStatus executeService(Vector cmdLine) throws WorkException, IOException {

        throw new IOException("ThreadWork::executeService not implemented");

        /*

        mileStone.println("preparing execution", work.getUID());
				
        String classname = work.getMobileWork().getServiceName();

        debug("executService " + classname);

        xtremweb.services.Interface obj = null;

        try {
        obj = (xtremweb.services.Interface)services.get(classname);
        if(obj == null) {
        mileStone.println("instanciating service", work.getUID());
        obj = (xtremweb.services.Interface)Class.forName(classname).newInstance();
        obj.setLevel(logger.getEffectiveLevel());
        }
        }
        catch(Exception e) {
        throw new WorkException(e.toString());
        }

        mileStone.println("executing service", work.getUID());

        int rc = obj.exec(work.getMobileWork().getCmdLine(),
        work.getMobileWork().getStdin(),
        work.getMobileWork().getDirin());

        // 				System.out.println("executeService rc = " + rc);
        // 				System.out.println("executeService r  = " + 
        // 													 (obj.getResult() == null ? "null" : obj.getResult().length));

        mileStone.println("service executed", work.getUID());

        work.setReturnCode(rc);
        work.setResult(obj.getResult());

        // 				System.out.println("executeService w.rc = " + work.getReturnCode());
        //  				System.out.println("executeService w.r  = " + 
        //  													 (work.getResult() == null ? "null" : "" + obj.getResult().length));


        if(work.getResult() != null) {
        String rFile = work.getMobileWork().getUID() + ".bin";
        work.setResultFileName(rFile);
        }

        mileStone.println("service result retreived", work.getUID());

        if(rc != 0) {
        work.setResultFileName(null);
        return XWStatus.ERROR;
        }

        return XWStatus.COMPLETED;

        */

    }


    /**
     * This executes a native job
     * 
     * @param cmdLine command line for execution
     * @exception WorkException is thrown on execution error
     */
    protected void executeJavaJob(Vector cmdLine) throws WorkException {
        int i1;
        try {
            String[] arguments = null;
            String myJarName = null;
            Class myClass;
            debug("cmdLine: " + cmdLine.toString());
            if(cmdLine.get(1).equals("-jar")) {
                // java -jar xxx.jar
                myJarName =(new File(work.getScratchDir(),(String) cmdLine
                                     .get(2))).getAbsolutePath();
                arguments = new String[cmdLine.size() - 3];
                for(i1 = 3; i1 < cmdLine.size(); i1++) {
                    arguments[i1 - 3] =(String) cmdLine.get(i1);
                }
                JarClassLoader jarLoader = new JarClassLoader(myJarName);
                String mainClassName = jarLoader.getMainClassName();
                myClass = jarLoader.loadClass(mainClassName, true);
            } 
            else {
                // java yyy.xxx.myClass
                arguments = new String[cmdLine.size() - 2];
                for(i1 = 2; i1 < cmdLine.size(); i1++) {
                    arguments[i1 - 2] =(String) cmdLine.get(i1);
                }
                String mainClassName =(String) cmdLine.get(1);
                NewClassLoader classLoader = new NewClassLoader();
                classLoader
                    .addClassPath(work.getScratchDir().getAbsolutePath());
                myClass = classLoader.loadClass(mainClassName, true);
            }
            Method[] myMethods = myClass.getMethods();
            boolean trouve = false;
            for(i1 = 0; i1 < myMethods.length; i1++) {
                if(myMethods[i1].getName().equals("main")) {
                    trouve = true;
                    break;
                }
            }
            if(trouve) {
                //FIXME(shd)
                // ceci est plantog\x{00E8}ne sur un biproc et meme en
                // g\x{00E9}n\x{00E9}ral
                // si des op\x{00E9}ration sur des noms de fichiers relatifs
                // sont effectu\x{00E9}es
                // en m\x{00EA}me temps.
                try {
                    ArchDepFactory.xwutil().cd(
                                               work.getScratchDir().getAbsolutePath());
                    myMethods[i1].invoke(myClass, new Object[] { arguments });
                } 
                catch(InvocationTargetException e) {
                    error("ThreadWork::executeJavaJob() : exception by task ");
                    throw new WorkException(e.toString());
                }
                finally {
                    ArchDepFactory.xwutil().cd(System.getProperty("user.dir"));
                }
            }
            else { //if(! trouve)
                error("ThreadWork::executeJavaJob() : main method not found in "
                             + myJarName);
                throw new WorkException("main method not found in " + myJarName);
            }
        } 
        catch(Exception e) {
            error("ThreadWork::executeJavaJob() : " + e.toString());
            throw new WorkException(e.toString());
        }
        workProcess = null;
        debug("end of executeJavaJob()");
    }

}

class WorkException extends Exception {
    public WorkException() {
        super();
    }

    public WorkException(String s) {
        super(s);
    }
}
