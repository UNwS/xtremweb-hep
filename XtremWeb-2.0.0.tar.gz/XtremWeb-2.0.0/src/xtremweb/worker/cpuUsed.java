package xtremweb.worker;
// NO COMMENT
// Should replace PS.java

import java.io.*;
import java.net.*;
   
public class cpuUsed {
   
    public static void main(String[] args) {
        Runtime machine;
        machine = java.lang.Runtime.getRuntime();
        String name="a.out";
        String pname;
        String ligne;
        Process ls;
        BufferedReader input;
        int index, i, j;
        int pid;
        long user, system;
        long jiffies;
        long us=0, usOld=0;
        long somme=0, sommeOld=0;
  
  
        while(true) {
            try {
                //on recupere la liste des process
                ls = machine.exec("ls -A1 /proc");
                ls.waitFor();
                input = new BufferedReader(new
            InputStreamReader(ls.getInputStream()));
  
                while(input.ready()) {
                    ligne = input.readLine();
                    try {
                        //on ne garde que ce qui est numerique (i.e. pid)
                        pid=Integer.valueOf(ligne).intValue();
                        BufferedReader pidstat = new BufferedReader(new
                FileReader("/proc/"+pid+"/stat"));
                        ligne = pidstat.readLine();
                        pidstat.close();
  
            pname=ligne.substring(ligne.indexOf('(')+1,ligne.indexOf(')'));
                        if(pname.equals(name)) {
                            index=0;
                            System.out.println(pname);
                            for(i=0;i<13;i++) {
                                index=ligne.indexOf(' ',index+1);
                            }                                                   
                            //on recupere les jiffies user et system du process

                us=Integer.valueOf(ligne.substring(index,ligne.indexOf('+',index+1)).trim()).intValue();
                        }                                                       
                    } catch (Exception e) {} //ce n'est pas numerique           
                }                                                               
        
                //lecture de la premiere ligne de /proc/stat "cpu long:user+long:nice long:sys long:idle"
                BufferedReader stat = new BufferedReader(new
            FileReader("/proc/stat"));
                ligne = stat.readLine();
                stat.close();
                ligne=ligne.trim();
                somme=0;
                for(i=0;i<5;i++) {
                    try {
                        index=ligne.indexOf(' ');
                        if(index!=-1) {
            
                jiffies=Long.valueOf(ligne.substring(0,index).trim()).longValue(); 
                        } else {                                                
                jiffies=Long.valueOf(ligne.trim()).longValue();
                        }                                                        
                        somme = somme+jiffies; //somme=user+nice+sys+idle
                    } catch (Exception e) {}                                    
                    try { 
            ligne=ligne.substring(ligne.indexOf(' ')).trim();
                    } catch (Exception e) {}                                    
                }                                                                
             
                /*calcul du nombre de jiffies dans l'intervalle pour
         * chaque process
         */
        user=us-usOld;

        System.out.println("%CPU user:"+user*100/(somme-sommeOld));

        //intervalle en ms.
        java.lang.Thread.sleep(1000);

        //mise a jour des valeurs de depart
        usOld=us;
        sommeOld=somme;

        } catch (Exception e) {System.out.println("erreur: " +e.getMessage());}                                                              
        }
    }
}                                                                                
       
