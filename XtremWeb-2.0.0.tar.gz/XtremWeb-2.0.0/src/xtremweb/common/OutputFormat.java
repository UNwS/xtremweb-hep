package xtremweb.common;

import java.io.IOException;

/**
 * OutputFormat.java
 *
 *
 * Created: Thu May 31 10:03:43 2001
 *
 * @author <a href="mailto: fedak@lri.fr">Gilles Fedak</a>
 * @version %I% %G%
 */

public enum OutputFormat {

    CSV,
    TEXT,
    HTML,
    XML;

    public static void main(String[] argv) {
	for (OutputFormat i : OutputFormat.values())
	    System.out.println(i.toString() + " = " + i.ordinal() + " valueOf() = " + i.valueOf(i.toString()));
    }

}
