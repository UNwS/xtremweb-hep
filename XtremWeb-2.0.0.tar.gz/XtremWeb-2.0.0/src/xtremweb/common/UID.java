package xtremweb.common;


import java.util.UUID;
import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;

import org.xml.sax.SAXException;
import org.xml.sax.Attributes;


/**
 * This class describes an extension of java.rmi.server.UID so that
 * we can create a new UID from a String representation.<br />
 * This is typically needed to re-create an UID from its string value
 * stored in database 
 */
public class UID extends XMLable {

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "uid";
    /**
     * This defines the null UID so that we can differenciate
     * a null value (where value is not defined) to a empty value
     * where value is defined to be empty<br />
     * This is especially usefull to force works.STDIN to null even if apps.STDIN is defined
     */
    public static final UID NULLUID = newUID("00000000-0000-0000-0000-000000000000");
    /**
     * Tests if the argument is equal to NULLUID
     * @param anUid is the uid to test
     * @return true if argument is equal to NULLUID
     * @see #NULLUID
     */
    public static boolean isNull(UID anUid) {
        return NULLUID.equals(anUid);
    }
    /**
     * Tests if this UID is null
     * @see #isNull(UID)
     */
    public  boolean isNull() {
        return isNull(myUid);
    }
    /**
     * This defines a new default UID at boot time
     */
    public static UID myUid = new UID();

    /**
     * This is the unic identifier
     */
    private UUID uid;
    /** 
     * This is the UID column index
     * @see XMLable#columns
     */
    private static final int UID = FIRST_ATTRIBUTE;

    /** 
     * This constructs a new object, instancianting a new java.rmi.serverUID
     */
    public UID() {
        super(THISTAG, UID);
        this.uid = UUID.randomUUID();
        columns[UID]  = new String("UID");
    }
    /** 
     * This constructs a new instance from a UID String representation
     * @param value is the UID String representation
     * @exception IOException is thrown if parameter does not represents an UID
     */
    private static UID newUID(String value) {
        try {
            return new UID(value);
        }
        catch(Exception e) {
            util.fatal(e.toString());
            return null;
        }
    }
    /** 
     * This constructs a new instance from a UID String representation
     * @param value is the UID String representation
     * @exception IOException is thrown if parameter does not represents an UID
     */
    public UID(String value) throws IOException{
        fromString(value);
    }
    /**
     * This constructs a new object by receiving XML representation 
     * from input stream 
     * @param in is the input stream
     * @exception IOException is thrown on XML parsing error
     */
    public UID(DataInputStream in) throws IOException {
        this();
        fromXml(in);
    }
    /**
     * This compares this UID to provided one
     * @param uid2 is the object to compare to
     * @return false if uid2 is null or if uid2 differs from this
     */
    public boolean equals(UID uid2) {
        if(uid2 == null)
            return false;
        return (uid2.toString().compareTo(this.toString()) == 0);
    }
    /**
     * This calls toString(false)
     */
    public String toString() {
        return toString(false);
    }
    /**
     * This calls java.util.UUID.toString()
     * @param csv is never used
     */
    public String toString(boolean csv) {
        return uid.toString();
    }
    /**
     * This retreives an UID from String representation<br />
     * This uses java.rmi.server.UID#read(DataInput) method 
     * which algorithm is like:
     * <ol>
     *  <li> DataInput.readInt()
     *  <li> DataInput.readLong()
     *  <li> DataInput.readShort()
     * </ol>
     * @param value is the UID String representation
     * @exception IOException is thrown if parameter does not represents an UID
     * @see java.rmi.server.UID#read(DataInput)
     */
    public void fromString(String value) throws IOException{
        try {
            this.uid = UUID.fromString(value);
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }
    /**
     * This retreives this object XML representation
     * @return this object XML representation
     */
    public String toXml() {
        String ret = "<" + XMLTAG + " " + 
            columns[UID] + "=\"" + uid.toString()   + "\" />";
        return ret;
    }
    /**
     * This writes this object XML representation to output stream
     * @param o is the output stream to write to
     */
    public void toXml(DataOutputStream o) throws IOException {
        String ret = "<" + XMLTAG + " " + 
            columns[UID] + "=\"" + uid.toString()   + "\" />";
        o.writeUTF(ret);
    }
    /**
     * This retreives attributes from XML attributes
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

        if(attrs == null) {
            throw new IOException("attrs is null");
        }

        String infoSetType = null;

        debug("    UID nb attributes  : " + attrs.getLength());

        for(int a = 0; a < attrs.getLength(); a++) {
            String attribute = attrs.getQName(a);
            String value = attrs.getValue(a);
            debug("     attribute #" + a + 
                  ": name=\"" + attribute + "\"" +
                  ", value=\"" + value + "\"");

            if(attribute.compareToIgnoreCase(columns[UID]) == 0)
                fromString(value);
        }
    }
    /**
     * This return this objet hash code.
     * @return uid.hashCode() if uid is not null, NULLUID.hashCode() otherwise
     * @see #uid
     * @see #NULLUID
     */
    public int hashCode() {
        if(uid != null)
            return uid.hashCode();
        else
            return NULLUID.hashCode();
    }
    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler#startElement(String, String, String, Attributes)
     */
    public void xmlElementStart(String uri, String tag, String qname, 
                                Attributes attrs)
        throws IOException {

        //				debug("Start element - " + qname);

        if(qname.compareToIgnoreCase(XMLTAG) == 0)
            fromXml(attrs);
    }
}
