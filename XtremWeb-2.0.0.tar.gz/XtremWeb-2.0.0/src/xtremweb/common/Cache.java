package xtremweb.common;

import xtremweb.communications.Connection;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.EOFException;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Enumeration;


// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * This class caches datas from/to server.
 * Datas are written/retreived to/from local disk.<br />
 * <br />
 * Objects are cached with their URI as key.<br />
 * The cache file is sequential and contains every event.<br />
 * <br />
 * Example : the following execution
 * <ul>
 * <li> add(anObject1); this adds
 * <li> add(anObject1); this updates
 * <li> add(anObject2); this adds
 * <li> remove(anObject1); this deletes from cache
 * <li> add(anObject2); this updates
 * </ul>
 * Gives the following cache file : <code>
 *   <anObject1 /><anObject1 /><anObject1 isDeleted="true" /><anObject2 />
 * </code>
 * <br />
 * <br />
 * The constructor of this cache sequentially reads the cache file to retreive 
 * the cache content; in our example the cache finally contains anObject2 only
 * since the last action on anObject1 has been deletion. <br />
 * The constructor finally writes the cache content to cache file to remove 
 * duplicated or unecessary entries. In our example the cache file finally
 * contains : <code>
 * <anObject2 />
 * </code>
 *
 * @author Oleg Lodygensky (lodygens lal.in2p3.fr)
 * @since 2.0.0
 */
public class Cache extends XMLable {

    /**
     * This class defines a cache entry
     */
    protected class CacheEntry extends XMLable {
        /**
         * This is the XML tag
         */
        private static final String THISTAG = "XWCacheEntry";
        /**
         * This is the size of this entry : needed bytes amount
         * to write this TableInterface description to disk
         */
        private long size;
        /**
         * This is the cached objet interface
         */
        private TableInterface itf;
        /**
         * This is the original URI where the entry came form
         */
        private URI uri;
        /**
         * This is the size column index
         */
        private static final int SIZE = 0;
        /**
         * This stores attribute values, if any
         */
        private Object[] values;

        /**
         * This constructs a new entry.
         * This associates a new URI to that TableInterface, calling newURI(itf.getUID())
         * @see #newURI(UID)
         * @exception IOException is thrown if no UID is defined in parameter
         */
        public CacheEntry() throws IOException{
            super(THISTAG, SIZE);

            itf = null;
            uri = null;
            LAST_ATTRIBUTE = SIZE;
            MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

            values  = new String[MAX_ATTRIBUTE];
            columns[SIZE] = "SIZE";
        }
        /**
         * This constructs a new entry.
         * This associates a new URI to that TableInterface, calling newURI(itf.getUID())
         * @param ti defines this entry object
         * @see #newURI(UID)
         * @exception IOException is thrown if no UID is defined in parameter
         */
        public CacheEntry(TableInterface ti) throws IOException{
            this();
            itf = ti;
            uri = newURI(itf.getUID());
        }
        /**
         * This constructs a new entry.
         * @param ti defines this entry object
         * @param u is the TableInterace URI
         * @exception IOException is thrown if no UID is defined in parameter
         */
        public CacheEntry(TableInterface ti, URI u) throws IOException{
            this();
            itf = ti;
            uri = u;
        }
        /**
         * This constructs a new object from XML attributes 
         * received from input stream
         * @param input is the input stream
         * @see TableInterface#fromXml(DataInputStream)
         * @throws IOException on XML error
         */
        public CacheEntry(DataInputStream input) throws IOException{
            this();
            super.fromXml(input);
        }
        /**
         * This retreives this object attributes
         * @param attrs contains attributes XML representation
         */
        public void fromXml(Attributes attrs) throws IOException {

            if(attrs == null) {
                throw new IOException("attrs is null");
            }

            String infoSetType = null;

            for(int a = 0; a < attrs.getLength(); a++) {
                String attribute = attrs.getQName(a);
                String value = attrs.getValue(a);
                debug("     attribute #" + a + 
                      ": name=\"" + attribute + "\"" +
                      ", value=\"" + value + "\"");

                if(attribute.compareToIgnoreCase(columns[SIZE]) == 0)
                    values[SIZE] = value;
            }
        }
        /**
         * This serializes this object to a String as an XML object<br />
         * @return a String containing this object definition as XML
         * @see #fromXml(Attributes)
         */
        public String toXml() {

            String ret = new String("<" + THISTAG + " " + 
                                    "SIZE=\"" + size + "\" >");
            if (uri != null)
                ret += uri.toXml();
            if (itf != null)
                ret += itf.toXml();
            ret += "</" + THISTAG + ">";

            return ret;
        }
        /**
         * This writes this object XML representation to output stream
         * @param o is the output stream to write to
         */
        public void toXml(DataOutputStream o) throws IOException {

            String ret = new String("<" + THISTAG + " " + 
                                    "SIZE=\"" + size + "\" >");
            o.writeUTF(ret);

            if (uri != null)
                uri.toXml(o);
            if (itf != null)
                itf.toXml(o);

            ret = "</" + THISTAG + ">";

            o.writeUTF(ret);
        }
        /**
         * This is called to decode XML elements
         * @see xtremweb.common.XMLable.DescriptionHandler
         */
        public void xmlElementStart(String saxuri, String tag, String qname, 
                                    Attributes attrs)
            throws IOException {

            debug("  xmlElementStart()   qname=\"" + qname + "\"");

            if(qname.compareToIgnoreCase(THISTAG) == 0)
                fromXml(attrs);
            else if(qname.compareToIgnoreCase(URI.THISTAG) == 0) {
                this.uri = new URI();
                this.uri.fromXml(attrs);
            }
            else
                itf = TableInterface.newInterface(saxuri, tag, qname, attrs);
        }
        /**
         * This does nothing.
         * @see xtremweb.common.XMLable.DescriptionHandler#endElement(String, String, String)
         */
        public void xmlElementStop(String saxuri, String tag, String qname)
            throws IOException {

            debug("     xmlElementStop()  qname=\"" + qname + "\"");
            
            if(uri == null) {
                throw new IOException("URI was not defined");
            }
        }
        /**
         * This retreives this entry UID
         * @return this entry UID
         */
        public UID getUID() {
            try {
                return itf.getUID();
            }
            catch(Exception e) {
                return null;
            }
        }
        /**
         * This retreives this entry URI
         * @return this entry URI
         */
        public URI getURI() {
            return uri;
        }
        /**
         * This retreives this entry UID
         * @return this entry TableInterface
         */
        public TableInterface getInterface() {
            try {
                return itf;
            }
            catch(Exception e) {
                return null;
            }
        }
        /**
         * This calls toString(false)
         */
        public String toString() {
            return toString(false);
        }
        /**
         * This retreives String representation
         * @return this object String representation
         * @see xtremweb.common.TableInterface#toString(boolean)
         */
        public String toString(boolean csv) {
            String ret = new String();

            if (itf != null)
                ret += itf.toString(csv);

            return ret;
        }
    }

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "XWCache";
    /**
     * This stores attribute values, if any
     */
    protected Object[] values;
    /**
     * This is the cache SIZE
     */
    private int size = 0;
    /**
     * This is the size column index
     */
    private static final int SIZE = 0;
    /**
     * This stores objects using UID as keys
     */
    protected Hashtable cache;
    /**
     * This is the configuration as read from config file
     */
    private XWConfigurator config;
    /**
     * This is the cache file name
     */
    public final String CACHENAME = "XWHEP." + XWRole.myRole + ".cache";
    /**
     * This is the cache file name
     */
    public final String CONTENTDIRNAME = "XWHEP." + XWRole.myRole + ".cache.contents";
    /**
     * This is the cache file
     */
    private File cacheFile;
    /**
     * This is the directory where data contents are stored
     */
    private File contentDir;
    /**
     * This helps to read/write cache file
     */
    StreamIO io;

    /**
     * This constructs a new cache and retreives stored values from disk
     * @param c is the configuration as read from config file
     * @see #read()
     */
    public Cache(){
        super(THISTAG, SIZE);
        LAST_ATTRIBUTE = SIZE;
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        values  = new String[MAX_ATTRIBUTE];
        columns[SIZE] = "SIZE";

        config = null;
        cache = new Hashtable(100);
        cacheFile = null;
        contentDir = null;
        io = null;

        level = LoggerLevel.INFO;

        Runtime.getRuntime().addShutdownHook(new Thread("XWCacheCleaner") {
                public void run() {
                    flush();
                }
            });
    }
    /**
     * This is called on program termination (CTRL+C)
     * This flushes and closes cache file
     */
    protected void flush() {
        try {
            debug("XWCacheCleaner");
            if(cacheFile.exists() && (cacheFile.length() > 0)) {
                io.writeBytes("</" + THISTAG + ">");
                io.close();
            }
        }
        catch(Exception e) {
            debug(e.toString());
            if(debug())
                e.printStackTrace();
            error("can't clean up");
        }
        io = null;
    }
    /**
     * This constructs a new cache and retreives stored values from disk
     * @param c is the configuration as read from config file
     * @see #read()
     */
    public Cache(XWConfigurator c){
        this();
        config = c;
        cache = new Hashtable(100);
        level = config.getLoggerLevel();
        cacheFile = new File(config.getCacheDir(), CACHENAME);
        contentDir = new File(config.getCacheDir(), CONTENTDIRNAME);
        try {
            util.checkDir(contentDir);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        io = null;
        read();
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public Cache(DataInputStream input) throws IOException{
        this();
        super.fromXml(input);
    }
    /**
     * This retreives this cache keys
     */
    public Enumeration keys() {
        return cache.keys();
    }
    /**
     * This clears cache : memory and disk
     */
    public void clear() {
        cache.clear();
        flush();
        write();
        try {
            util.deleteDir(contentDir);
            util.checkDir(contentDir);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * This retreives this object attributes
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

        if(attrs == null) {
            throw new IOException("attrs is null");
        }

        for(int a = 0; a < attrs.getLength(); a++) {
            String attribute = attrs.getQName(a);
            String value = attrs.getValue(a);
            debug("     attribute #" + a + 
                  ": name=\"" + attribute + "\"" +
                  ", value=\"" + value + "\"");
        }
    }
    /**
     * This serializes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    public String toXml() {

        String ret = new String("<" + THISTAG + " " + 
                                "SIZE=\"" + size + "\" >");
        for(Object entry : cache.values()) {
            try {
                ret += ((CacheEntry)entry).toXml();
            }
            catch(Exception e) {
                error(e.toString());
            }
        }

        ret += "</" + THISTAG + ">";

        return ret;
    }
    /**
     * This writes this object XML representation to output stream
     * @param o is the output stream to write to
     */
    public void toXml(DataOutputStream o) throws IOException {

        String ret = new String("<" + THISTAG + " " + 
                                "SIZE=\"" + size + "\" >");

        o.writeUTF(ret);

        for(Object entry : cache.values()) {
            try {
                ((CacheEntry)entry).toXml(o);
            }
            catch(Exception e) {
                error(e.toString());
            }
        }

        ret = "</" + THISTAG + ">";

        o.writeUTF(ret);
    }

    /**
     * This is current CacheEntry beeing retreived from XML description
     */
    CacheEntry currentEntry = null;
    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public void xmlElementStart(String uri, String tag, String qname, 
                                Attributes attrs)
        throws IOException {

        debug("  xmlElementStart()   qname=\"" + qname + "\"");

        if(qname.compareToIgnoreCase(THISTAG) == 0)
            fromXml(attrs);
        else {
            if(currentEntry == null)
                currentEntry = new CacheEntry();
            currentEntry.xmlElementStart(uri, tag, qname, attrs);
        }
    }
    /**
     * This does nothing.
     * @see xtremweb.common.XMLable.DescriptionHandler#endElement(String, String, String)
     */
    public void xmlElementStop(String saxuri, String tag, String qname)
        throws IOException {

        debug("     xmlElementStop()  qname=\"" + qname + "\"");

        if(qname.compareToIgnoreCase(CacheEntry.THISTAG) == 0) {

            currentEntry.xmlElementStop(saxuri, tag, qname);

            URI uri = currentEntry.getURI();
            debug("Cache#xmlElementStop removing " + uri.getUID());
            cache.remove(uri.toString());
            if(currentEntry.getInterface().isDeleted() == false) {
                debug("Cache#xmlElementStop inserting " + uri.getUID());
                put(currentEntry);
            }
            currentEntry = null;
        }
    }
    /**
     * This creates a new normalized URI as follows :
     * <code>new URI(config.getCurrentDispatcher(),uid)</code>
     * @return this entry URI
     */
    protected URI newURI(UID uid)  {
        return new URI(config.getCurrentDispatcher(),
                       uid);
    }
    /**
     * This retreives this cache content from cache file.
     * This rewrites cache to file to remove duplicated and unecessary entries
     * @see #io
     */    
    protected void read() {
        if(cacheFile.exists() && (cacheFile.length() > 0)) {
            try {

                FileInputStream fis = new FileInputStream(cacheFile);
                DataInputStream input = new DataInputStream(fis);
                try {
                    fromXml(input);
                }
                catch(EOFException e) {
                    io.close();
                    debug("XWHEP Cache : " + cache.size() + " objects cached");
                }
            }
            catch(IOException e) {
                if(debug())
                    e.printStackTrace();
            }
        }

        //
        // let rewrite cache file, removing multiple entries
        //
        write();
    }
    /**
     * This writes this cache content to cache file
     */    
    protected void write() {
        try {
            if(io == null) {
                //
                // let initialize StreamIO for writing since we will not read any more
                //
                FileOutputStream fos = new FileOutputStream(cacheFile);
                DataOutputStream output = new DataOutputStream(fos);
                io = new StreamIO(output, null, 10240, 
                                  level, config.nio());
            }

            io.writeBytes(new String("<" + THISTAG + " " + 
                                     "SIZE=\"" + size + "\" >"));
            for(Object entry : cache.values()) {
                try {
                    write((CacheEntry)entry);
                }
                catch(Exception e) {
                    error(e.toString());
                }
            }
        }
        catch(IOException e) {
            if(debug())
                e.printStackTrace();
        }
    }
    /**
     * This appends the argument to cache file
     * @param itf is the object to write
     */    
    protected void write(CacheEntry entry) throws IOException {
        debug("Writing to cache : " + entry.getUID());
        io.writeBytes(entry.toXml());
    }
    /**
     * This adds/updates a new entry to cache and appends it to cache file
     * This creates an new URI for this TableInterface
     * @param itf is the interface to cache
     * @see CacheEntry#newURI(UID)
     * @see #write(TableInterface)
     */
    public void add(TableInterface itf) throws IOException {
        if(itf == null)
            return;
        CacheEntry entry = new CacheEntry(itf);
        remove(entry.getURI());
        write(entry);
        put(entry);
    }
    /**
     * This adds/updates a new entry to cache and appends it to cache file.
     * If uri is an XtremWeb one, this downloads data from XtremWeb server.
     * If uri is not an XtremWeb one (http etc.), this creates a new empty DataInterface
     * @param uri is the uri to cache
     * @see #write(TableInterface)
     */
    public void add(URI uri) throws IOException {

        if(uri == null)
            return;

        remove(uri);

        DataInterface data = new DataInterface();

        if(uri.getUID() == null)
            data.setUID(new UID());
        else
            data.setUID(uri.getUID());

        CacheEntry entry = new CacheEntry(data, uri);
        write(entry);
        put(entry);
    }
    /**
     * This puts an entry into cache
     */
    private synchronized void put(CacheEntry entry) {
        URI uri = entry.getURI();
//        debug("000000 Cache#put(" + uri + ", " + entry.getUID() +")");
        cache.put(uri.toString(), entry);
//         try {
//             debug("000000 Cache#get(" + uri + ") = " + get(uri).getUID());
//         }
//         catch(Exception e) {
//             debug("000000 Cache#get(" + uri + ") can't retreive ?!?!?!");
//         }

        notifyAll();
    }
    /**
     * This retreives an entry from cache
     */
    public TableInterface get(UID uid) {
        if(uid == null)
            return null;
        return get(newURI(uid));
    }
    /**
     * This retreives an entry from cache
     */
    public TableInterface get(URI uri) {
        if(uri == null)
            return null;
        CacheEntry entry = (CacheEntry)cache.get(uri.toString());
        if(entry == null) {
//            debug("Cache#get(" + uri + ") retreives nothing");
            return null;
        }
//        debug("Cache#get(" + uri + ") retreives " + entry.getUID());
        return entry.getInterface();
    }
    /**
     * This retreives content file for the given UID
     * The object must be already cached
     * @return a File where to store content for the cached object, null otherwise
     */
    public File getContentFile(UID uid) throws IOException {
        if(uid == null) {
            System.out.println("Cache#getContentFile : uid is null");
            return null;
        }
        return getContentFile(newURI(uid));
    }
    /**
     * This retreives content file for the given UID
     * The object must be already cached
     * @return a File where to store content for the cached object, null otherwise
     */
    public File getContentFile(URI uri) throws IOException {
        if(uri == null) {
            System.out.println("Cache#getContentFile : uid is null");
            return null;
        }

        TableInterface itf = get(uri);
        if(itf == null) {
//            debug("Cache#getContentFile(" + uri +") = null");
            return null;
        }

//        debug("Cache#getContentFile(" + uri +") = " + get(uri).getUID());

        UID uid = itf.getUID();
        File contentFile = new File(util.createDir(contentDir, uid), uid.toString());

//        debug("Cache#getContentFile " + uid + " = " + contentFile.getCanonicalPath());

        return contentFile;
    }
    /**
     * This retreives an entry from cache
     */
    public void remove(UID uid) throws IOException {
        if(uid == null)
            return;
        remove(newURI(uid));
    }
    /**
     * This removes an entry from cache
     */
    public synchronized void remove(URI uri) throws IOException {
        CacheEntry entry = (CacheEntry)cache.get(uri.toString());
        if(entry == null) {
            notifyAll();
            return;
        }
//        debug("Cache#remove(" + uri.getUID() + ")");
        TableInterface itf = entry.getInterface();
        itf.setDeleted(true);
        write(entry);
        cache.remove(uri.toString());
        notifyAll();
    }
    /**
     * This dumps this cache content to stdout
     */
    public void dump() {
        System.out.println("XWHEP cache");
        for(Object entry : cache.values()) {
            try {
                System.out.println(((CacheEntry)entry).getInterface().toXml());
            }
            catch(Exception e) {
                error(e.toString());
            }
        }
    }
    /**
     * This calls toString(false)
     */
    public String toString() {
        return toString(false);
    }
    /**
     * This retreives String representation
     * @return this object String representation
     * @see xtremweb.common.TableInterface#toString(boolean)
     */
    public String toString(boolean csv) {
        String ret = new String();

        for(Object entry : cache.values()) {
            try {
                ret += (((CacheEntry)entry).getInterface().toXml());
            }
            catch(Exception e) {
                error(e.toString());
            }
        }

        return ret;
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {

        try {

            if(argv.length < 1) {
                System.out.println("Usage : java -cp xtremweb.jar <configFile> [anXmlDefinition]");
                System.exit(1);
            }

            XWConfigurator config = new XWConfigurator(argv[0], false);
            Cache cache = new Cache(config);

            if(argv.length > 1) {
                TableInterface itf = TableInterface.newInterface(argv[1]);
                if(itf.getUID() == null)
                    itf.setUID(new UID());
                cache.add(itf);
                itf.setDeleted(true);
                TableInterface itf2 = cache.get(itf.getUID());
                cache.flush();
            }

            cache.dump();
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
