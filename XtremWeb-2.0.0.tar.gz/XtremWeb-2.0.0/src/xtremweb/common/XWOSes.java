package xtremweb.common;

import xtremweb.common.CommandLineParser;

import java.io.IOException;

/**
 * XWOses.java<br />
 *
 * This defines XtremWeb compatible OSes<br />
 *
 * Created: 29 janvier 2007
 *
 * @author <a href="mailto: lodygens *a**t* lal.in2p3.fr">Oleg Lodygensky</a>
 * @version %I% %G%
 */

public enum XWOSes {

    NONE,
    LINUX,
    WIN32,
    MACOSX,
    OSF1,
    SOLARIS,
    JAVA;

    public static final XWOSes LAST = JAVA;
    public static final int SIZE = LAST.ordinal() + 1;

    public static XWOSes fromInt(int v) throws IllegalArgumentException {
        for (XWOSes i : XWOSes.values()) {
            if(i.ordinal() == v)
                return i;
        }
        throw new IllegalArgumentException("unvalid XWOSes value " + v);
    }
    /**
     * This retreives the OS name
     * If this OS is not supported by XtremWeb, this forces the program to immediatly stop
     * @see #getOsName(String)
     */
    public static String getOsName() {
        try {
            return getOsName(System.getProperty("os.name").trim());}
        catch(Exception e) {
            util.fatal(e.toString());
        }
        return null;
    }

    /**
     * This forces os name to predefined values to avoid confusion
     * Example : "Windows 2000" and "Windows XP" are summurized as "win32"
     * @param osName the OS name
     * @exception ClassNotFound exception is thrown if osName is not supported by XtremWeb
     */
    public static String getOsName(String osName)
	throws IllegalArgumentException {

        if((osName.toUpperCase().indexOf("WINDOWS") != -1) ||
           (osName.compareToIgnoreCase(WIN32.toString()) == 0))
            return WIN32.toString();
        if(osName.compareToIgnoreCase(LINUX.toString()) == 0)
            return LINUX.toString();
        if(osName.compareToIgnoreCase(SOLARIS.toString()) == 0)
            return SOLARIS.toString();
        if(osName.compareToIgnoreCase(JAVA.toString()) == 0)
            return JAVA.toString();
        if((osName.compareToIgnoreCase(MACOSX.toString()) == 0) ||
           (osName.compareToIgnoreCase("mac os x") == 0))
            return MACOSX.toString();

        throw new IllegalArgumentException (osName + " not supported");
    }

    /**
     * This retreives this host OS name
     * @see #getOs(String)
     */
    public static XWOSes getOs() {
        try {
            return getOs(System.getProperty("os.name").trim());
        }
        catch(Exception e) {
            util.fatal(e.toString());
        }
        return null;
    }
    /**
     * This forces os name to predefined values to avoid confusion
     * Example : "Windows 2000" and "Windows XP" are summurized as "win32"
     * @param osName the OS name
     * @exception ClassNotFound exception is thrown if osName is not supported by XtremWeb
     */
    public static XWOSes getOs(String osName)
    throws IllegalArgumentException {

        return valueOf(getOsName(osName));
    }


    /**
     * This tests whether OS is Win32
     */
    public boolean isWin32() {
        return (this.valueOf(getOsName()) == WIN32);
    }
    /**
     * This tests whether OS is Linux
     */
    public boolean isLinux() {
        return (this.valueOf(getOsName()) == LINUX);
    }
    /**
     * This tests whether OS is Solaris
     */
    public boolean isSolaris() {
        return (this.valueOf(getOsName()) == SOLARIS);
    }
    /**
     * This tests whether OS is Solaris
     */
    public boolean isOsf1() {
        return (this.valueOf(getOsName()) == OSF1);
    }
    /**
     * This tests whether OS is Mac OS
     */
    public boolean isMacosx() {
        return (this.valueOf(getOsName()) == MACOSX);
    }

    /**
     * This array stores enum as string 
     */
    public static String[] labels = null;
    /**
     * This retreives this enum string representation
     * @return a array containing this enum string representation
     */
    public static String[] getLabels() {
        if(labels != null)
            return labels;

        labels = new String[SIZE];
        for (XWOSes c : XWOSes.values())
            labels[c.ordinal()] = c.toString();
        return labels;
    }

    public static void main(String[] argv) {
        for (XWOSes i : XWOSes.values())
            System.out.println(i.toString() + " = " + i.ordinal() +
                               " valueOf() = " + i.valueOf(i.toString()));
    }

}
