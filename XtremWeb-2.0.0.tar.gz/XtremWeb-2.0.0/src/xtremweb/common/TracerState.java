/**
 * Project : XTremWeb
 * File    : TracerState.java
 *
 * Date   : March 2002
 * By     : Oleg Lodygensky
 * e-mail : lodygens /at\ .in2p3.fr
 */

package xtremweb.common;

public class TracerState
{
  public int cpuUser;
  public int cpuNice;
  public int cpuSystem;
  public int cpuIdle;
  public int cpuAidle;
  public short loadOne;
  public short loadFive;
  public short loadFifteen;
  public short procRun;
  public short procTotal;
  public int  memFree;
  public int  memShared;
  public int  memBuffers;
  public int  memCached;
  public int  swapFree;
  public int time;
}
