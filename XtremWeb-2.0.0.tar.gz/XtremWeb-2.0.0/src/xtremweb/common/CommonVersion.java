package xtremweb.common;

//
//  Common Version.java
//

import java.util.jar.JarFile;
import java.util.jar.Attributes;


public class CommonVersion {
    private static Version current = new Version("1.0.25", "head", "200804251346");
//    private static Version current = new Version("1.0.25", "head");
    public static Version getCurrent() {
        return current;
    }
    public static Version getFromJar(JarFile jf) throws Exception {
        Attributes mf = jf.getManifest().getMainAttributes();
        jf.close();
        return new Version( mf.getValue("XW-rev"),
                            mf.getValue("XW-branch"),
                            mf.getValue("XW-build"));
    }
}


