package xtremweb.common;

import java.io.IOException;
import java.io.EOFException;
import java.io.File;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.nio.MappedByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.channels.FileChannel;
import java.nio.channels.Channels;
//import java.rmi.RemoteException;
import java.util.Vector;
import java.util.Hashtable;


/**
 * This class implements some basic stream I/O<br />
 * Created: Jun 1st, 2005<br />
 *
 * @author Oleg Lodygensky
 * @version RPCXW
 */

public class StreamIO extends Logger{

    /**
     * This flag tells to use NIO or not
     */
    protected static boolean nio;
    /**
     * This aims to display some time stamps
     */
    MileStone mileStone;
    /**
     * This is the output stream
     */
    private DataOutputStream output= null;
    /**
     * This is the input stream
     */
    private DataInputStream  input = null;
    /**
     * This is the default buffer length; it is set to 20K.
     */
    protected static final int DEFLENGTH = util.PACKETSIZE;
    /**
     * This is the buffer to ue for I/O
     */
    protected byte [] buffer = null;


    /**
     * This constructor initiates I/O streams and buffer
     * @param o is the output stream to write to
     * @param i is the input stream to read for
     * @param n is the buffer length to use
     * @param l is the logger level
     * @param newio tells to use nio or not
     */
    public StreamIO(DataOutputStream o, DataInputStream i, int n, LoggerLevel l, boolean newio) {
        super(l);
        buffer = new byte [n];
        output = o;
        input = i;
        try {
            mileStone = new MileStone(getClass().getName());
        }
        catch(Exception e) {
            // this may occurs
        }
        nio = newio;
    }
    /**
     * This constructor initiates I/O streams and sets the buffer length to DEFLENGTH
     * @param o is the output stream to write to
     * @param i is the input stream to read for
     * @param l is the logger level
     * @param newio tells to use nio or not
     */
    public StreamIO(DataOutputStream o, DataInputStream i, LoggerLevel l, boolean newio) {
        this(o, i, DEFLENGTH, l, newio);
    }
    /**
     * This constructor initiates I/O streams and sets the buffer length to DEFLENGTH
     * This sets nio to true
     * @param o is the output stream to write to
     * @param i is the input stream to read for
     * @param l is the logger level
     */
    public StreamIO(DataOutputStream o, DataInputStream i, LoggerLevel l) {
        this(o, i, l, true);
    }

    /**
     * This retreives the data input stream<br />
     * This is needed to receive object as XML
     */
    public DataInputStream input() {
        return input;
    }
    /**
     * This retreives the data output stream<br />
     * This is needed to send object as XML
     */
    public DataOutputStream output() {
        return output;
    }

    /**
     * This sets the logger level
     * @param l is the logger level
     */
    public void setLevel(LoggerLevel l) {
        level = l;
    }
    /**
     * This sets the logger level
     * @param l is the logger level
     */
    public void close() {
        try {
            if(input != null)
                input.close();
            if(output != null) {
                output.flush();
                output.close();
            }
        }
        catch(IOException ioe) {
        }
    }

    /**
     * This writes the given array to the given file
     * This does not use this object attributes since it is a static method
     * @param array is the byte array to write
     * @param fname is the file name to write array to
     * @exception IOException is thrown on I/O error or if the provided file does not exist
     */
    public static void array2file(byte[] array, String fname) throws IOException {
        array2file(array, new File(fname));
    }


    /**
     * This is used by array2file() only
     */
    static byte[] arraybuf = new byte[20480];
    /**
     * This writes the given array to the given file
     * This does not use this object attributes since it is a static method
     * @param array is the byte array to write
     * @param file is the file to write array to
     * @exception IOException is thrown on I/O error or if the provided file does not exist
     */
    public static void array2file(byte[] array, File file) throws IOException {
        if(nio == false) {
            ByteArrayInputStream bis = new ByteArrayInputStream(array);
            DataInputStream  dis = new DataInputStream (bis);
            DataOutputStream dos = new DataOutputStream(new FileOutputStream(file));
            //            try {
                for(int nread = dis.read(arraybuf); nread > 0; nread = dis.read(arraybuf)) {
                    dos.write(arraybuf, 0, nread);
                }
                dos.close();
                /*
            }
            catch(Exception e) {
                throw new RemoteException(e.toString());
            }
                */
        }
        else {
            //            try {
                ByteArrayInputStream bis = new ByteArrayInputStream(array);
                ReadableByteChannel inChannel = Channels.newChannel(bis);
                FileChannel outChannel = new FileOutputStream(file).getChannel();

                MappedByteBuffer bb = outChannel.map(FileChannel.MapMode.READ_WRITE,
                                                     0,
                                                     array.length);
                outChannel.write(bb);
                inChannel.close();
                outChannel.close();
                /*
            }
            catch(Exception e) {
                throw new RemoteException(e.toString());
            }
                */
        }
    }

    /**
     * This reads the given file and returns the content in a byte array
     * This does not use this object attributes since it is a static method
     * @param fname is the name of the file to read
     * @return a byte array containing the content file
     * @exception IOException is thrown on I/O error or if the provided file 
     *            does not exist
     * @exception ArrayIndexOutOfBoundsException is thrown if file content size
     *            if more than util.LONGFILESIZE
     * @exception IOException is thrown on I/O error
     * @see util#LONGFILESIZE
     */
    public static byte[] file2array(String fname) throws ArrayIndexOutOfBoundsException, IOException {
        return file2array(new File(fname));
    }

    /**
     * This reads the given file and returns the content in a byte array
     * This does not use this object attributes since it is a static method
     * @param file is the file to read
     * @return a byte array containing the content file
     * @exception IOException is thrown on I/O error or if the provided file 
     *            does not exist
     * @exception ArrayIndexOutOfBoundsException is thrown if file content size 
     *            if more than util.LONGFILESIZE
     * @exception IOException is thrown on I/O error
     * @see util#LONGFILESIZE
     */
    public static byte[] file2array(File file) throws ArrayIndexOutOfBoundsException, IOException {
        byte[] contents;
        FileInputStream fis = new FileInputStream(file);

        if(nio == false) {
            if (file.length() > util.LONGFILESIZE) {
                throw new ArrayIndexOutOfBoundsException("too huge size : " + file.length());
            }
            else {
                contents = new byte[(int) file.length()];
                fis.read(contents);
                fis.close();
                return contents;
            }
        }
        else {
            //            try {
                ByteArrayOutputStream bos = new ByteArrayOutputStream((int)file.length());
                WritableByteChannel outChannel = Channels.newChannel(bos);
                FileChannel inChannel = new FileInputStream(file).getChannel();

                MappedByteBuffer bb = inChannel.map(FileChannel.MapMode.READ_ONLY,
                                                    0,
                                                    inChannel.size());
                outChannel.write(bb);

                inChannel.transferTo(0, file.length(), outChannel);
                inChannel.close();
                outChannel.close();
                return bos.toByteArray();
                /*
            }
            catch(Exception e) {
                throw new RemoteException(e.toString());
            }
                */
        }
    }

    /**
     * This writes a String to output stream. 
     * The written string may be read by readString().
     * @param v is the value to write
     * @exception Exception is thrown on on I/O error
     * @see #readString()
     * @see #writeBytes()
     */
    public void writeString(String v) throws IOException {
        //        try {
            output.writeUTF(v);
            output.flush();
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }
    /**
     * This reads a String from input stream
     * @return the read String
     * @exception Exception is thrown on on I/O error
     */
    public String readString() throws IOException {
        return input.readUTF();
    }

    /**
     * This needs some clues<br />
     * StreamIO#writeObject(XMLable) now calls XMLable#toXml(DataOutputStream)
     * and not DataOutputStream#writeUTF(XMLable#toXml()) 
     * because UTF does not accept huge strings.<br />
     * Hence XMLable#toXml(DataOutputStream) is recursivly called 
     * and DataOutputStream#writeUTF() is then called several times.<br />
     * Then, finally, here we must calls StreamIO#readString() several times too.<br />
     * How to determine how many time to call this method ?<br />
     * We must partially parse received strings as long as needed: if we find an
     * opening xml tag, we expect the closing one too.
     */
    public String readXmlString() throws IOException {

        try {
            String xmlString = readString();

            //            System.out.println("00 xmlString = " + xmlString);

            if(xmlString.indexOf("/>") != -1)
                return xmlString;

            int xmlHeaderIdx = 0;
            if(xmlString.startsWith(XMLable.XMLHEADER) == true)
                xmlHeaderIdx = XMLable.XMLHEADER.length();

            int opentag_openIdx = xmlString.indexOf('<', xmlHeaderIdx);
            int opentag_spcIdx = xmlString.indexOf(' ', opentag_openIdx);
            if(opentag_spcIdx < 0)
                opentag_spcIdx = xmlString.length();
            int opentag_closeIdx = xmlString.indexOf('>', opentag_openIdx);
            if(opentag_closeIdx < 0)
                opentag_closeIdx = xmlString.length();
            String opentag = xmlString.substring(opentag_openIdx + 1, 
                                                 Math.min(opentag_spcIdx,
                                                          opentag_closeIdx));

            //            System.out.println("opentag = " + opentag);

            while(true) {
                String str = readString();
                xmlString += str;

                //                System.out.println("str = " + str);
                //                System.out.println("xmlString = " + xmlString);

                int closetag_openIdx = str.indexOf("</");

                //                System.out.println("closetag_openIdx  = " + closetag_openIdx);

                if(closetag_openIdx < 0) {
                    try {
                        Thread.sleep(10);
                    }
                    catch(InterruptedException itr){
                    }
                    continue;
                }

                int closetag_spcIdx = str.indexOf(' ', closetag_openIdx);
                if(closetag_spcIdx < 0)
                    closetag_spcIdx = str.length();
                int closetag_closeIdx = str.indexOf('>', closetag_openIdx);
                if(closetag_closeIdx < 0)
                    closetag_closeIdx = str.length();

                //                System.out.println("closetag_spcIdx   = " + closetag_spcIdx);
                //                System.out.println("closetag_closeIdx = " + closetag_closeIdx);

                String closetag = str.substring(closetag_openIdx + 2, 
                                                Math.min(closetag_spcIdx,
                                                         closetag_closeIdx));

                //                System.out.println("closetag = " + closetag);

                if(opentag.compareToIgnoreCase(closetag) == 0) {
                    //                    System.out.println("xmlString = " + xmlString);
                    return xmlString;
                }
            }
        }
        catch(EOFException e) {
	    if(debug())
		e.printStackTrace();
            throw new IOException(e.toString());
        }
    }

    /**
     * This writes the string as a sequence of byte.
     * @param v is the value to write
     * @exception Exception is thrown on I/O error
     * @since 2.0.0
     */
    public void writeBytes(String v) throws IOException {
        //        try {
            output.writeBytes(v);
            output.flush();
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }
    /**
     * This writes a byte
     * @param v is the value to write
     * @exception Exception is thrown on I/O error
     */
    public void writeByte(byte v) throws IOException {
        //        try {
            output.writeByte(v);
            output.flush();
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }
    /**
     * This reads a byte
     * @return the read byte
     * @exception Exception is thrown on I/O error
     */
    public byte readByte() throws IOException {
        //        try {
            return input.readByte();
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }

    /**
     * This writes an integer
     * @param v is the value to write
     * @exception Exception is thrown on I/O error
     */
    public void writeInt(int v) throws IOException {
        //        try {
            output.writeInt(v);
            output.flush();
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }

    /**
     * This reads an integer from input stream
     * @return the read integer
     * @exception Exception is thrown on I/O error
     */
    public int readInt() throws IOException {
        //        try {
            return input.readInt();
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }

    /**
     * This reads a long integer from input stream
     * @return the read long integer
     * @exception Exception is thrown on I/O error
     */
    public long readLong() throws IOException {
        //        try {
            return input.readLong();
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }

    /**
     * This writes a long integer
     * @param v is the value to write
     * @exception Exception is thrown on I/O error
     */
    public void writeLong(long v) throws IOException {
        //        try {
            output.writeLong(v);
            output.flush();
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }


    /**
     * This writes a byte array to output stream.
     * This first writes the array size, then the array content itself.<br />
     * If v is null a single 0 is only sent
     * @param v is the array to write to output stream
     * @exception Exception is thrown on I/O error or if the provided file does not exist
     * @see #readArray()
     */
    public void writeArray(byte[] v) throws IOException {
        //        try {
            if(v == null) {
                writeInt(0);
                return;
            }

            writeInt(v.length);

            output.write(v, 0, v.length);
            output.flush();
            /*
        }
        catch(Exception e) {
            if(logger.getEffectiveLevel() == Level.DEBUG)
                e.printStackTrace();
            throw new RemoteException(e.toString());
            }
            */
    }

    /**
     * This reads a byte array from input stream.
     * This first reads the array size, then the array content itself.
     * @return a byte array, of null if the read array size is 0
     * @exception IOException is thrown on I/O error or if the provided file does not exist
     * @see #writeArray(byte[])
     */
    public byte[] readArray() throws IOException {
        //        try {
            int length = readInt();
            if(length == 0)
                return null;

            byte[] ret = new byte[length];

            input.readFully(ret, 0, length);
            return ret;
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }

    /**
     * This writes a file content to output stream
     * This first writes the file size, then the file content itself
     * If parameter is null a single 0 is only sent
     * @param file denotes the file to write to output stream
     * @exception IOException is thrown on I/O error or if the provided file does not exist
     */
    public void writeFile(File file) throws IOException {
        //        try {
            if(file == null) {
                writeLong(0);
                return;
            }

            if(!file.exists()) {
                writeLong(0);
                throw new IOException("file not found");
            }

            long length = file.length();

            if(nio == false) {
                FileInputStream fis= new FileInputStream(file);
                writeLong(length);

                int nfis = 0;
                for(long written = 0; written < length; written += nfis) {
                    nfis = fis.read(buffer);
                    output.write(buffer, 0, nfis);
                }
                output.flush();
            }
            else {
                writeLong(length);

                WritableByteChannel outChannel = Channels.newChannel(output);
                FileChannel inChannel = new FileInputStream(file).getChannel();
                inChannel.transferTo(0, length, outChannel);
                inChannel.close();
                output.flush();
                outChannel.close();
            }
            /*
        }
        catch(Exception e) {
            if(logger.getEffectiveLevel() == Level.DEBUG)
                e.printStackTrace();
            throw new RemoteException(e.toString());
        }
            */
    }

    /**
     * This reads a file content from input stream and stores it to file
     * The file size is first read, then the file content itself
     * @param file denotes the file to store content from input stream
     * @exception IOException is thrown on I/O error
     */
    public void readFile(File file) throws IOException {

        long length = readLong();
        if(length == 0) {
            return;
        }

        long start = System.currentTimeMillis();

        if(nio == false) {
            //            try {
                FileOutputStream fos = new FileOutputStream(file);
								
                long written;
                int n = 0;
                for(written = 0 ; written < length; written+=n ) {
                    n = input.read(buffer);
                    if(n != -1) 
                        fos.write(buffer,0,n); 
                }
                debug("StreamIO#readFile : written = " + written);
                fos.close();
                /*
            }
            catch(Exception e) {
                if(logger.getEffectiveLevel() == Level.DEBUG)
                    e.printStackTrace();
                throw new RemoteException(e.toString());
            }
                */
        }
        else {
            //            try {
                ReadableByteChannel inChannel = Channels.newChannel(input);
                FileChannel outChannel = new FileOutputStream(file).getChannel();
                outChannel.transferFrom(inChannel, 0, length);
                inChannel.close();
                outChannel.close();
                /*
            }
            catch(Exception e) {
                if(logger.getEffectiveLevel() == Level.DEBUG)
                    e.printStackTrace();
                throw new RemoteException(e.toString());
            }
                */
        }

        long end   = System.currentTimeMillis();
        long delta = end - start;
        debug("readFile (" + nio + ") : " + start + " - " + end + " = " + delta);

    }

    /**
     * This reads a file content from input stream and stores it to file
     * @param file denotes the file to store content from input stream
     */
    public void readFileContent(File file) throws IOException {

        long start = System.currentTimeMillis();
//         try {
//             debug("StreamIO#readFileContent : " + file.getCanonicalPath());
//         }
//         catch(IOException e) {
//             debug("StreamIO#readFileContent");
//         }

        if(nio == false) {
            FileOutputStream fos = new FileOutputStream(file);

            long written = 0;
            int n = 0;
            while (n != -1) {
                n = input.read(buffer);
                if(n != -1) {
                    fos.write(buffer,0,n); 
                    written += n;
                }
            }
            debug("StreamIO#readFileContent : written = " + written);
            fos.close();

        }
        else {
            throw new IOException("StreamIO#readFileContent is not implemented with java.nio");
        }

        long end   = System.currentTimeMillis();
        long delta = end - start;
        debug("readFileContent (" + nio + ") : " + start + " - " + end + " = " + delta);

    }

    /**
     * This reads a serializable object from input stream
     * @return a serializable object
     * @exception Exception is thrown on I/O error
     */
    public Hashtable readHashtable() throws IOException {

        try {
            ObjectInputStream ois = new ObjectInputStream(input);
            return (Hashtable)ois.readObject();
        }
        catch(ClassNotFoundException e) {
            throw new IOException(e.toString());
        }
    }

    /**
     * This writes a serializable object to output stream
     * @param o is the object to write
     * @exception IOException is thrown on I/O error
     */
    public void writeObject(Hashtable o) throws IOException {

        //        try {
            ObjectOutputStream oos = new ObjectOutputStream(output);
            oos.writeObject(o);
            output.flush();
            /*
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
            */
    }

    /**
     * This writes an Vector to output stream; this first writes vector size
     * following by vector datas, if any<br />
     * If v is null, this writes a single 0
     * @param v is the Vector to send
     * @exception IOException is thrown on I/O error
     */
    public void writeObject(Vector v) throws IOException {

        if(v == null) {
            writeInt(0);
            return;
        }

        writeInt(v.size());
        for(int i = 0; i < v.size(); i++)
            writeString(v.elementAt(i).toString());
    }
    /**
     * This reads an Vector from input stream; this first reads vector size
     * then vector datas, if any<br />
     * This tries to store received objects as UID into Vector; 
     * if received objects are not UID, they are stored as String 
     * into returned Vector
     * @return a Vector of UID, or a Vector of String, or an empty Vector
     * @exception IOException is thrown on I/O error
     */
    public Vector readVector() throws IOException {

        Vector ret = new Vector();

        int size = readInt();

        if(size == 0)
            return ret;

        for(int i = 0; i < size; i++) {
            String str = readString();
            //            try {
                ret.add(new UID(str));
                /*
            }
            catch(Exception e) {
                ret.add(str);
            }
                */
        }
        return ret;
    }
    /**
     * This writes an object XML representation to output stream
     * @param o is the object to write
     * @exception IOException is thrown on I/O error
     */
    public void writeObject(XMLable o) throws IOException {
        /*
        String xml = o.toXml();
        writeString(xml);
        */
        o.toXml(output);
    }
    /**
     * This pipes a String from input stream to a new input stream<br />
     * This is needed to receive XML object representations
     * @see #stream(String)
     * @return the input stream where the string has been pushed
     * @exception IOException is thrown on IO error
     */
    public DataInputStream stream() throws IOException {
        //        try {
            return stream(readString());
            /*
        }
        catch(RemoteException e) {
            //            if(logger.getEffectiveLevel() == Level.DEBUG)
                e.printStackTrace();
            throw new IOException(e.toString());
        }
            */
    }
    /**
     * This pipes a String to an input stream
     * @param in is the String to pipe
     * @return the input stream where the string has been pushed
     * @exception IOException is thrown on IO error
     */
    public static DataInputStream stream(String in) throws IOException{
        return new DataInputStream(new ByteArrayInputStream(in.getBytes()));
    }

    /**
     * This is the standard main method; this is for debugging only
     */
    public static void main(String[] argv) {

        try {
            File fin = new File(argv[0]);
            File fout = new File("outtemp_nio");
            FileOutputStream fos = new FileOutputStream(fout);
            DataOutputStream output = new DataOutputStream(fos);

            StreamIO io = new StreamIO(output, null, LoggerLevel.DEBUG);

            long t0 = System.currentTimeMillis();
            io.writeFile(fin);
            long t1 = System.currentTimeMillis();

            long d0 = t1 - t0;
            System.out.println((io.nio ? "with" : "w/o ") +
                               " NIO; Size =  " + fin.length() + " ; dT = " + d0);

            fout.delete();

            File fout2 = new File("outtemp_no_nio");
            FileOutputStream fos2 = new FileOutputStream(fout2);
            DataOutputStream output2 = new DataOutputStream(fos2);
            io = new StreamIO(output2, null, LoggerLevel.DEBUG);
            io.nio = !io.nio;

            t0 = System.currentTimeMillis();
            io.writeFile(fin);
            t1 = System.currentTimeMillis();

            d0 = t1 - t0;
            System.out.println((io.nio ? "with" : "w/o ") +
                               " NIO; Size =  " + fin.length() + " ; dT = " + d0);
            fout2.delete();

            // 2000 chars
            String long2000Chars ="01234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789";

            fout = new File("longString.txt");
            fos = new FileOutputStream(fout);
            output = new DataOutputStream(fos);

            io = new StreamIO(output, null, LoggerLevel.DEBUG);
            io.writeString(long2000Chars);

            fin = new File("longString.txt");
            FileInputStream fis = new FileInputStream(fout);
            DataInputStream input = new DataInputStream(fis);

            io = new StreamIO(null, input, LoggerLevel.DEBUG);
            System.out.println("\nread = " + io.readString());

            fout.delete();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
