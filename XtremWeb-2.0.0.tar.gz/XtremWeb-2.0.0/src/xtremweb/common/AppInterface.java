package xtremweb.common;

import xtremweb.common.StreamIO;
import xtremweb.common.LoggerLevel;

import java.io.IOException;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.util.StringTokenizer;
import java.sql.ResultSet;
import java.text.ParseException;
import java.security.AccessControlException;

import org.xml.sax.Attributes;

/**
 * AppInterface.java
 *
 * Created: Feb 19th, 2002
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This class describes a row of the apps SQL table.
 */
public class AppInterface
    extends xtremweb.common.TableInterface {

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "app";

    /**
     * This enumerates this interface columns
     */
    public enum Columns {
        /**
         * This is the column index of the UNIQUE ID
         * It <b>must</b> be the first attribute since we use it as primary key.
         * @see TableInterface
         */
        UID,
        /**
         * This is the column index of the user UID, if any
         * @see xtremweb.common.UID
         */
        OWNERUID,
        /**
         * This is the column index of the application name, this is a unic
         * index in the DB so that client can refer application with its name
         * which is more user friendly than UID ;)
         */
        NAME,
        /**
         * This is the column index of the flag which tells whether this 
         * application is a service<br />
         * A service is a java code inserted in the platform at compile time<br />
         * At launch time, the server inserts its embedded services into database
         * @since RPCXW
         */
        ISSERVICE,
        /**
         * This is the column index of the flag to tell whether this
         * has been deleted
         * @since 2.0.0
         */
        ISDELETED,
        /**
         * This is the access rights a la unix (user + group + other)
         * @see xtremweb.common#AccessRights
         */
        ACCESSRIGHTS,
        /**
         * This is the average execution time; this is calculated as finished
         * jobs return
         */
        AVGEXECTIME,
        /**
         * This is the column index of the minimum memory needed to run job
         * for this application<br />
         */
        MINMEMORY,
        /**
         * This is the column index of the minimum CPU spped needed to run job
         * for this application<br />
         */
        MINCPUSPEED,
        /**
         * This is the column index of the number of executed jobs for this application
         */
        NBJOBS,
        /**
         * This is the column index of the default stdin, if any.
         * If this is set, any job with no stdin defined receives this
         * @see WorkInterface#STDINURI
         */
        DEFAULTSTDINURI,
        /**
         * This is the column index of the base dirin, if any
         * If this is set, all jobs receive this
         * @see WorkInterface#DIRIN
         */
        BASEDIRINURI,
        /**
         * This is the column index of the default dirin, if any
         * If this is set, any job with no dirin defined receives this
         * @see WorkInterface#DIRIN
         */
        DEFAULTDIRINURI,
        /**
         * This is the column index of the linux ix86 library, if any.
         * This is a data URI.<br />
         * I know this is ugly in DB point of view. 
         * I should rather create a data relation, but I'm affraid such a solution would
         * overload the platform
         */
        LDLINUX_IX86URI,
        /**
         * This is the column index of the linux amd64 library, if any.
         */
        LDLINUX_AMD64URI,
        /**
         * This is the column index of the linux ppc library, if any.
         */
        LDLINUX_PPCURI,
        /**
         * This is the column index of the Mac OS X ix86 library, if any.
         */
        LDMACOS_IX86URI,
        /**
         * This is the column index of the Mac OS X ppc library, if any.
         */
        LDMACOS_PPCURI,
        /**
         * This is the column index of the Mac OS X ix86 library, if any.
         */
        LDWIN32_IX86URI,
        /**
         * This is the column index of the Mac OS X ppc library, if any.
         */
        LDWIN32_AMD64URI,
        /**
         * This is the column index of the OSF1 alpha library, if any.
         */
        LDOSF1_ALPHAURI,
        /**
         * This is the column index of the OSF1 alpha library, if any.
         */
        LDOSF1_SPARCURI,
        /**
         * This is the column index of the SOLARIS alpha library, if any.
         */
        LDSOLARIS_ALPHAURI,
        /**
         * This is the column index of the SOLARIS alpha library, if any.
         */
        LDSOLARIS_SPARCURI,
        /**
         * This is the column index of the linux ix86 binary, if any.
         */
        LINUX_IX86URI,
        /**
         * This is the column index of the linux amd64 binary, if any.
         */
        LINUX_AMD64URI,
        /**
         * This is the column index of the linux ppc binary, if any.
         */
        LINUX_PPCURI,
        /**
         * This is the column index of the Mac OS X ix86 binary, if any.
         */
        MACOS_IX86URI,
        /**
         * This is the column index of the Mac OS X ppc binary, if any.
         */
        MACOS_PPCURI,
        /**
         * This is the column index of the Mac OS X ix86 binary, if any.
         */
        WIN32_IX86URI,
        /**
         * This is the column index of the Mac OS X ppc binary, if any.
         */
        WIN32_AMD64URI,
        /**
         * This is the column index of the Java binary, if any.
         */
        JAVAURI,
        /**
         * This is the column index of the OSF1 alpha binary, if any.
         */
        OSF1_ALPHAURI,
        /**
         * This is the column index of the OSF1 alpha binary, if any.
         */
        OSF1_SPARCURI,
        /**
         * This is the column index of the SOLARIS alpha binary, if any.
         */
        SOLARIS_ALPHAURI,
        /**
         * This is the column index of the SOLARIS alpha binary, if any.
         */
        SOLARIS_SPARCURI;

        public static final Columns LAST = SOLARIS_SPARCURI;
        public static final int SIZE = LAST.ordinal() + 1;

        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns c : Columns.values()) {
                if(c.ordinal() == v)
                    return c;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[SIZE];
            for (Columns c : Columns.values())
                labels[c.ordinal()] = c.toString();
            return labels;
        }
    }

    /**
     * This is the default constructor
     */
    public AppInterface() {

        super(THISTAG);

        LAST_ATTRIBUTE = Columns.LAST.ordinal();
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values  = new Object[MAX_ATTRIBUTE];
        setService(false);
        setDeleted(false);
        setAccessRights(XWAccessRights.DEFAULT);
    }
    /**
     * This constructs a new object providing its primary key value
     * @param uid is this new object UID
     */
    public AppInterface(UID uid) throws IOException {
        this();
        setUID(uid);
    }
    /**
     * This constructor reads this object definition from an SQL request result
     * @param rs is an SQL request result
     * @exception IOException
     */
    public AppInterface(ResultSet rs) throws IOException {

        this();

        try {
            setUID(new UID(rs.getString(Columns.UID.toString())));

            try {
                setOwner(new UID(rs.getString(Columns.OWNERUID.toString())));
            }
            catch(Exception e) {
                // owner is optionnal
                // access is free is not set
            }
            try {
                setJava(new URI(rs.getString(Columns.JAVAURI.toString())));
            }
            catch(Exception e) {
                // java is optionnal
            }
            try {
                setWin32_ix86(new URI(rs.getString(Columns.WIN32_IX86URI.toString())));
            }
            catch(Exception e) {
                // win32 ix86 is optionnal
            }
            try {
                setWin32_amd64(new URI(rs.getString(Columns.WIN32_AMD64URI.toString())));
            }
            catch(Exception e) {
                // win32 amd64 is optionnal
            }
            try {
                setLinux_ix86(new URI(rs.getString(Columns.LINUX_IX86URI.toString())));
            }
            catch(Exception e) {
                // linux ix86 is optionnal
            }
            try {
                setLinux_amd64(new URI(rs.getString(Columns.LINUX_AMD64URI.toString())));
            }
            catch(Exception e) {
                // linux amd64 is optionnal
            }
            try {
                setLinux_ppc(new URI(rs.getString(Columns.LINUX_PPCURI.toString())));
            }
            catch(Exception e) {
                // linux ppc is optionnal
            }
            try {
                setMacos_ix86(new URI(rs.getString(Columns.MACOS_IX86URI.toString())));
            }
            catch(Exception e) {
                // macos ix86 is optionnal
            }
            try {
                setMacos_ppc(new URI(rs.getString(Columns.MACOS_PPCURI.toString())));
            }
            catch(Exception e) {
                // macos ppc is optionnal
            }
            try {
                setOsf1_sparc(new URI(rs.getString(Columns.OSF1_SPARCURI.toString())));
            }
            catch(Exception e) {
                // osf1 sparc is optionnal
            }
            try {
                setOsf1_alpha(new URI(rs.getString(Columns.OSF1_ALPHAURI.toString())));
            }
            catch(Exception e) {
                // osf1 alpha is optionnal
            }
            try {
                setSolaris_sparc(new URI(rs.getString(Columns.SOLARIS_SPARCURI.toString())));
            }
            catch(Exception e) {
                // solaris sparc is optionnal
            }
            try {
                setSolaris_alpha(new URI(rs.getString(Columns.SOLARIS_ALPHAURI.toString())));
            }
            catch(Exception e) {
                // solaris alpha is optionnal
            }
            try {
                setLDWin32_ix86(new URI(rs.getString(Columns.LDWIN32_IX86URI.toString())));
            }
            catch(Exception e) {
                // LDwin32 ix86 is optionnal
            }
            try {
                setLDWin32_amd64(new URI(rs.getString(Columns.LDWIN32_AMD64URI.toString())));
            }
            catch(Exception e) {
                // LDwin32 amd64 is optionnal
            }
            try {
                setLDLinux_ix86(new URI(rs.getString(Columns.LDLINUX_IX86URI.toString())));
            }
            catch(Exception e) {
                // LDlinux ix86 is optionnal
            }
            try {
                setLDLinux_amd64(new URI(rs.getString(Columns.LDLINUX_AMD64URI.toString())));
            }
            catch(Exception e) {
                // LDlinux amd64 is optionnal
            }
            try {
                setLDLinux_ppc(new URI(rs.getString(Columns.LDLINUX_PPCURI.toString())));
            }
            catch(Exception e) {
                // LDlinux ppc is optionnal
            }
            try {
                setLDMacos_ix86(new URI(rs.getString(Columns.LDMACOS_IX86URI.toString())));
            }
            catch(Exception e) {
                // LDmacos ix86 is optionnal
            }
            try {
                setLDMacos_ppc(new URI(rs.getString(Columns.LDMACOS_PPCURI.toString())));
            }
            catch(Exception e) {
                // LDmacos ppc is optionnal
            }
            try {
                setLDOsf1_sparc(new URI(rs.getString(Columns.LDOSF1_SPARCURI.toString())));
            }
            catch(Exception e) {
                // LDosf1 sparc is optionnal
            }
            try {
                setLDOsf1_alpha(new URI(rs.getString(Columns.LDOSF1_ALPHAURI.toString())));
            }
            catch(Exception e) {
                // LDosf1 alpha is optionnal
            }
            try {
                setLDSolaris_sparc(new URI(rs.getString(Columns.LDSOLARIS_SPARCURI.toString())));
            }
            catch(Exception e) {
                // LDsolaris sparc is optionnal
            }
            try {
                setLDSolaris_alpha(new URI(rs.getString(Columns.LDSOLARIS_ALPHAURI.toString())));
            }
            catch(Exception e) {
                // LDsolaris alpha is optionnal
            }
            try {
                setDefaultStdin(new URI(rs.getString(Columns.DEFAULTSTDINURI.toString())));
            }
            catch(Exception e) {
                // defaultstdin is optionnal
            }
            try {
                setDefaultDirin(new URI(rs.getString(Columns.DEFAULTDIRINURI.toString())));
            }
            catch(Exception e) {
                // dirin is optionnal
            }
            try {
                setBaseDirin(new URI(rs.getString(Columns.BASEDIRINURI.toString())));
            }
            catch(Exception e) {
                // dirin is optionnal
            }

            setAccessRights(new XWAccessRights(rs.getInt(Columns.ACCESSRIGHTS.toString())));
            setNbJobs(new Integer(rs.getInt(Columns.NBJOBS.toString())));
            setAvgExecTime(new Integer(rs.getInt(Columns.AVGEXECTIME.toString())));
            setMinMemory(new Integer(rs.getInt(Columns.MINMEMORY.toString())));
            setMinCpuSpeed(new Integer(rs.getInt(Columns.MINCPUSPEED.toString())));

            setName(rs.getString(Columns.NAME.toString()));

            setService(new Boolean(rs.getString(Columns.ISSERVICE.toString())));
            try {
                setDeleted(new Boolean(rs.getString(Columns.ISDELETED.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }
    /**
     * This calls this(StreamIO.stream(input));
     * @param input is a String containing an XML representation
     */
    public AppInterface(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public AppInterface(DataInputStream input) throws IOException{
        this();
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public AppInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This tests an attribute
     * @return true if this is attribute is set, false otherwise
     */
    public boolean isService() {
        try {
            return((Boolean)getValue(Columns.ISSERVICE)).booleanValue();
        }
        catch(NullPointerException e) {
            setService(false);
            return false;
        }
    }

    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This get the owner
     * @return this client UID
     */
    public UID getOwner() {
        return (UID)getValue(Columns.OWNERUID);
    }
    /**
     * This retreives the URI to get application binary accordingly to OS ane CPU
     * @param cpu is the cpu for the expected binary
     * @param os  is the os  for the expected binary
     * @return binary URI or null
     */
    public URI getBinary(XWCPUs cpu, XWOSes os) {
        switch(os) {
        case LINUX:
            switch(cpu) {
            case IX86:
                return getLinux_ix86();
            case PPC:
                return getLinux_ppc();
            case AMD64:
                return getLinux_amd64();
            }
            break;
        case WIN32:
            switch(cpu) {
            case IX86:
                return getWin32_ix86();
            case AMD64:
                return getWin32_amd64();
            }
            break;
        case MACOSX:
            switch(cpu) {
            case IX86:
                return getMacos_ix86();
            case PPC:
                return getMacos_ppc();
            }
            break;
        case OSF1:
            switch(cpu) {
            case SPARC:
                return getSolaris_sparc();
            case ALPHA:
                return getSolaris_alpha();
            }
            break;
        case SOLARIS:
            switch(cpu) {
            case SPARC:
                return getOsf1_sparc();
            case ALPHA:
                return getOsf1_alpha();
            }
            break;
        case JAVA:
            return getJava();
        }
        return null;
    }
    /**
     * This retreives the URI to get application library accordingly to OS ane CPU
     * @param cpu is the cpu for the expected binary
     * @param os  is the os  for the expected binary
     * @return library URI or null
     */
    public URI getLibrary(XWCPUs cpu, XWOSes os) {
        switch(os) {
        case LINUX:
            switch(cpu) {
            case IX86:
                return getLDLinux_ix86();
            case PPC:
                return getLDLinux_ppc();
            case AMD64:
                return getLDLinux_amd64();
            }
            break;
        case WIN32:
            switch(cpu) {
            case IX86:
                return getLDWin32_ix86();
            case AMD64:
                return getLDWin32_amd64();
            }
            break;
        case MACOSX:
            switch(cpu) {
            case IX86:
                return getLDMacos_ix86();
            case PPC:
                return getLDMacos_ppc();
            }
            break;
        case OSF1:
            switch(cpu) {
            case SPARC:
                return getLDSolaris_sparc();
            case ALPHA:
                return getLDSolaris_alpha();
            }
            break;
        case SOLARIS:
            switch(cpu) {
            case SPARC:
                return getLDOsf1_sparc();
            case ALPHA:
                return getLDOsf1_alpha();
            }
            break;
        }
        return null;
    }
    /**
     * This retreives the URI to get application binary for linux ix86
     * @return a data URI
     */
    public URI getLinux_ix86() {
        return (URI)getValue(Columns.LINUX_IX86URI);
    }
    /**
     * This retreives the URI to get application binary for linux amd64
     * @return a data URI
     */
    public URI getLinux_amd64() {
        return (URI)getValue(Columns.LINUX_AMD64URI);
    }
    /**
     * This retreives the URI to get application binary for linux ppc
     * @return a data URI
     */
    public URI getLinux_ppc() {
        return (URI)getValue(Columns.LINUX_PPCURI);
    }
    /**
     * This retreives the URI to get application binary for win32 ix86
     * @return a data URI
     */
    public URI getWin32_ix86() {
        return (URI)getValue(Columns.WIN32_IX86URI);
    }
    /**
     * This retreives the URI to get application binary for win32 amd64
     * @return a data URI
     */
    public URI getWin32_amd64() {
        return (URI)getValue(Columns.WIN32_AMD64URI);
    }
    /**
     * This retreives the URI to get application binary for mac os ix86
     * @return a data URI
     */
    public URI getMacos_ix86() {
        return (URI)getValue(Columns.MACOS_IX86URI);
    }
    /**
     * This retreives the URI to get application binary for mac os ppc
     * @return a data URI
     */
    public URI getMacos_ppc() {
        return (URI)getValue(Columns.MACOS_PPCURI);
    }
    /**
     * This retreives the URI to get application binary for java
     * @return a data URI
     */
    public URI getJava() {
        return (URI)getValue(Columns.JAVAURI);
    }
    /**
     * This retreives the URI to get application binary for solaris sparc
     * @return a data URI
     */
    public URI getSolaris_sparc() {
        return (URI)getValue(Columns.SOLARIS_SPARCURI);
    }
    /**
     * This retreives the URI to get application binary for solaris alpha
     * @return a data URI
     */
    public URI getSolaris_alpha() {
        return (URI)getValue(Columns.SOLARIS_ALPHAURI);
    }
    /**
     * This retreives the URI to get application binary for osf1 sparc
     * @return a data URI
     */
    public URI getOsf1_sparc() {
        return (URI)getValue(Columns.OSF1_SPARCURI);
    }
    /**
     * This retreives the URI to get application binary for osf1 alpha
     * @return a data URI
     */
    public URI getOsf1_alpha() {
        return (URI)getValue(Columns.OSF1_ALPHAURI);
    }
    /**
     * This retreives the URI to get application library for linux ix86
     * @return a data URI
     */
    public URI getLDLinux_ix86() {
        return (URI)getValue(Columns.LDLINUX_IX86URI);
    }
    /**
     * This retreives the URI to get application library for linux amd64
     * @return a data URI
     */
    public URI getLDLinux_amd64() {
        return (URI)getValue(Columns.LDLINUX_AMD64URI);
    }
    /**
     * This retreives the URI to get application library for linux ppc
     * @return a data URI
     */
    public URI getLDLinux_ppc() {
        return (URI)getValue(Columns.LDLINUX_PPCURI);
    }
    /**
     * This retreives the URI to get application library for win32 ix86
     * @return a data URI
     */
    public URI getLDWin32_ix86() {
        return (URI)getValue(Columns.LDWIN32_IX86URI);
    }
    /**
     * This retreives the URI to get application library for win32 amd64
     * @return a data URI
     */
    public URI getLDWin32_amd64() {
        return (URI)getValue(Columns.LDWIN32_AMD64URI);
    }
    /**
     * This retreives the URI to get application library for mac os ix86
     * @return a data URI
     */
    public URI getLDMacos_ix86() {
        return (URI)getValue(Columns.LDMACOS_IX86URI);
    }
    /**
     * This retreives the URI to get application library for mac os ppc
     * @return a data URI
     */
    public URI getLDMacos_ppc() {
        return (URI)getValue(Columns.LDMACOS_PPCURI);
    }
    /**
     * This retreives the URI to get application library for solaris sparc
     * @return a data URI
     */
    public URI getLDSolaris_sparc() {
        return (URI)getValue(Columns.LDSOLARIS_SPARCURI);
    }
    /**
     * This retreives the URI to get application library for solaris alpha
     * @return a data URI
     */
    public URI getLDSolaris_alpha() {
        return (URI)getValue(Columns.LDSOLARIS_ALPHAURI);
    }
    /**
     * This retreives the URI to get application library for osf1 sparc
     * @return a data URI
     */
    public URI getLDOsf1_sparc() {
        return (URI)getValue(Columns.LDOSF1_SPARCURI);
    }
    /**
     * This retreives the URI to get application library for osf1 alpha
     * @return a data URI
     */
    public URI getLDOsf1_alpha() {
        return (URI)getValue(Columns.LDOSF1_ALPHAURI);
    }
    /**
     * This get the user group
     * @return this application access rights
     */
    public XWAccessRights getAccessRights() {
        try {
            return (XWAccessRights)getValue(Columns.ACCESSRIGHTS);
        }
        catch(Exception e) {
        }
        setAccessRights(XWAccessRights.DEFAULT);
        return XWAccessRights.DEFAULT;
    }
    /**
     * This get the number of jobs; 
     * if not set it is forced to 0
     * @return nbjobs or 0 if not set
     */
    public int getNbJobs() {
        Integer ret =(Integer)getValue(Columns.NBJOBS);
        if(ret != null)
            return ret.intValue();
        setNbJobs(0);
        return 0;
    }
    /**
     * This get the average execution time;
     * if not set it is forced to 0
     * @return exec average time or 0 if not set
     */
    public int getAvgExecTime() {
        Integer ret =(Integer)getValue(Columns.AVGEXECTIME);
        if(ret != null)
            return ret.intValue();
        setAvgExecTime(0);
        return 0;
    }
    /**
     * This retreives an attribute;
     * if not set it is forced to 0
     * @return the attribute or 0 if not set
     */
    public int getMinMemory() {
        Integer ret =(Integer)getValue(Columns.MINMEMORY);
        if(ret != null)
            return ret.intValue();
        setMinMemory(0);
        return 0;
    }
    /**
     * This retreives an attribute;
     * if not set it is forced to 0
     * @return the attribute or 0 if not set
     */
    public int getMinCpuSpeed() {
        Integer ret =(Integer)getValue(Columns.MINCPUSPEED);
        if(ret != null)
            return ret.intValue();
        setMinCpuSpeed(0);
        return 0;
    }
    /**
     * This retreives the UID, if already set
     * @return this attribute, or null if not set
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getUID() throws IOException {
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("AppInterface#getUID() : UID not set");
        }
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getName() {
        return(String)getValue(Columns.NAME);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public URI getDefaultStdin() {
        return (URI)getValue(Columns.DEFAULTSTDINURI);
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public URI getBaseDirin() {
        return (URI)getValue(Columns.BASEDIRINURI);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public URI getDefaultDirin() {
        return (URI)getValue(Columns.DEFAULTDIRINURI);
    }
    /**
     * This gets an attribute<br />
     * This attr is forced to false if not set
     * @return this attribute
     * @since 2.0.0
     */
    public boolean isDeleted() {
        try {
            Boolean ret = (Boolean)getValue(Columns.ISDELETED);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setDeleted(false);
            return false;
        }
    }
    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) 
        throws IllegalArgumentException {

        return setValue(Columns.valueOf(attribute.toUpperCase()), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the column to set 
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     */
    protected boolean setValue(Columns column, Object val) {
        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), val);

        String v = val.toString();

        switch(column) {
        case UID :
        case OWNERUID :
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case LINUX_IX86URI :
        case LINUX_AMD64URI :
        case LINUX_PPCURI :
        case WIN32_IX86URI :
        case WIN32_AMD64URI :
        case MACOS_IX86URI :
        case MACOS_PPCURI :
        case SOLARIS_ALPHAURI :
        case SOLARIS_SPARCURI :
        case OSF1_ALPHAURI :
        case OSF1_SPARCURI :
        case LDLINUX_IX86URI :
        case LDLINUX_AMD64URI :
        case LDLINUX_PPCURI :
        case LDWIN32_IX86URI :
        case LDWIN32_AMD64URI :
        case LDMACOS_IX86URI :
        case LDMACOS_PPCURI :
        case LDSOLARIS_ALPHAURI :
        case LDSOLARIS_SPARCURI :
        case LDOSF1_ALPHAURI :
        case LDOSF1_SPARCURI :
        case JAVAURI :
        case DEFAULTSTDINURI:
        case BASEDIRINURI:
        case DEFAULTDIRINURI:
            try {
                value = new URI(v);
            }
            catch(Exception e) {
            }
            break;
        case ACCESSRIGHTS :
            try {
                value = new XWAccessRights(v);
            }
            catch(Exception e) {
            }
            break;
        case NBJOBS :
        case AVGEXECTIME :
        case MINMEMORY :
        case MINCPUSPEED :
            value = new Integer(Integer.parseInt(v));
            break;
        case NAME :
            // sql query safety : removing spaces and quotes
            value = v.replaceAll("[\\n\\s\'\"]+", "_");
            break;
        case ISSERVICE :
        case ISDELETED :
            value = new Boolean(v);
            break;
        }
        return super.setValue(column.ordinal(), value);
    }
    /**
     * This sets this application user UID
     * @param v is the client UID
     * @return true if value has changed, false otherwise
     */
    public boolean setOwner(UID v) {
        return setValue(Columns.OWNERUID, v);
    }
    /**
     * This sets the URI to retreive application binary for linux ix86 
     * @return  true if value has changed, false otherwise
     */
    public boolean setBinary(XWCPUs cpu, XWOSes os, URI v)
        throws ParseException {

        switch(os) {
        case LINUX:
            switch(cpu) {
            case IX86:
                return setLinux_ix86(v);
            case PPC:
                return setLinux_ppc(v);
            case AMD64:
                return setLinux_amd64(v);
            }
            break;
        case WIN32:
            switch(cpu) {
            case IX86:
                return setWin32_ix86(v);
            case AMD64:
                return setWin32_amd64(v);
            }
            break;
        case MACOSX:
            switch(cpu) {
            case IX86:
                return setMacos_ix86(v);
            case PPC:
                return setMacos_ppc(v);
            }
            break;
        case OSF1:
            switch(cpu) {
            case SPARC:
                return setSolaris_sparc(v);
            case ALPHA:
                return setSolaris_alpha(v);
            }
            break;
        case SOLARIS:
            switch(cpu) {
            case SPARC:
                return setOsf1_sparc(v);
            case ALPHA:
                return setOsf1_alpha(v);
            }
            break;
        case JAVA:
            return setJava(v);
        }
        throw new ParseException("invalid OS or CPU type", 0);
    }
    /**
     * This sets the URI to retreive application library accordingly to parameters
     * @param cpu is the cpu type
     * @param os is the OS type
     * @param v is the library URI
     * @return  true if value has changed, false otherwise
     */
    public boolean setLibrary(XWCPUs cpu, XWOSes os, URI v)
        throws ParseException {

        switch(os) {
        case LINUX:
            switch(cpu) {
            case IX86:
                return setLDLinux_ix86(v);
            case PPC:
                return setLDLinux_ppc(v);
            case AMD64:
                return setLDLinux_amd64(v);
            }
            break;
        case WIN32:
            switch(cpu) {
            case IX86:
                return setLDWin32_ix86(v);
            case AMD64:
                return setLDWin32_amd64(v);
            }
            break;
        case MACOSX:
            switch(cpu) {
            case IX86:
                return setLDMacos_ix86(v);
            case PPC:
                return setLDMacos_ppc(v);
            }
            break;
        case OSF1:
            switch(cpu) {
            case SPARC:
                return setLDSolaris_sparc(v);
            case ALPHA:
                return setLDSolaris_alpha(v);
            }
            break;
        case SOLARIS:
            switch(cpu) {
            case SPARC:
                return setLDOsf1_sparc(v);
            case ALPHA:
                return setLDOsf1_alpha(v);
            }
            break;
        }
        throw new ParseException("invalid OS or CPU type", 0);
    }
    /**
     * This sets the URI to retreive application binary for linux ix86 
     * @return  true if value has changed, false otherwise
     */
    public boolean setLinux_ix86(URI v) {
        return setValue(Columns.LINUX_IX86URI, v);
    }
    /**
     * This sets the URI to retreive application binary for linux amd64 
     * @return  true if value has changed, false otherwise
     */
    public boolean setLinux_amd64(URI v) {
        return setValue(Columns.LINUX_AMD64URI, v);
    }
    /**
     * This sets the URI to retreive application binary for linux ppc
     * @return  true if value has changed, false otherwise
     */
    public boolean setLinux_ppc(URI v) {
        return setValue(Columns.LINUX_PPCURI, v);
    }
    /**
     * This sets the URI to retreive application binary for win32 ix32
     * @return  true if value has changed, false otherwise
     */
    public boolean setWin32_ix86(URI v) {
        return setValue(Columns.WIN32_IX86URI, v);
    }
    /**
     * This sets the URI to retreive application binary for win32 amd64
     * @return  true if value has changed, false otherwise
     */
    public boolean setWin32_amd64(URI v) {
        return setValue(Columns.WIN32_AMD64URI, v);
    }
    /**
     * This sets the URI to retreive application binary for mac os ix86
     * @return  true if value has changed, false otherwise
     */
    public boolean setMacos_ix86(URI v) {
        return setValue(Columns.MACOS_IX86URI, v);
    }
    /**
     * This sets the URI to retreive application binary for mac os ppc
     * @return  true if value has changed, false otherwise
     */
    public boolean setMacos_ppc(URI v) {
        return setValue(Columns.MACOS_PPCURI, v);
    }
    /**
     * This sets the URI to retreive application binary for java
     * @return  true if value has changed, false otherwise
     */
    public boolean setJava(URI v) {
        return setValue(Columns.JAVAURI, v);
    }
    /**
     * This sets the URI to retreive application binary for solaris sparc
     * @return  true if value has changed, false otherwise
     */
    public boolean setSolaris_sparc(URI v) {
        return setValue(Columns.SOLARIS_SPARCURI, v);
    }
    /**
     * This sets the URI to retreive application binary for solaris alpha
     * @return  true if value has changed, false otherwise
     */
    public boolean setSolaris_alpha(URI v) {
        return setValue(Columns.SOLARIS_ALPHAURI, v);
    }
    /**
     * This sets the URI to retreive application binary for osf1 sparc
     * @return  true if value has changed, false otherwise
     */
    public boolean setOsf1_sparc(URI v) {
        return setValue(Columns.OSF1_SPARCURI, v);
    }
    /**
     * This sets the URI to retreive application binary for osf1 alpha
     * @return  true if value has changed, false otherwise
     */
    public boolean setOsf1_alpha(URI v) {
        return setValue(Columns.OSF1_ALPHAURI, v);
    }
    /**
     * This sets the URI to retreive application binary for linux ix86 
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDLinux_ix86(URI v) {
        return setValue(Columns.LDLINUX_IX86URI, v);
    }
    /**
     * This sets the URI to retreive application binary for linux amd64 
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDLinux_amd64(URI v) {
        return setValue(Columns.LDLINUX_AMD64URI, v);
    }
    /**
     * This sets the URI to retreive application binary for linux ppc
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDLinux_ppc(URI v) {
        return setValue(Columns.LDLINUX_PPCURI, v);
    }
    /**
     * This sets the URI to retreive application binary for win32 ix32
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDWin32_ix86(URI v) {
        return setValue(Columns.LDWIN32_IX86URI, v);
    }
    /**
     * This sets the URI to retreive application binary for win32 amd64
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDWin32_amd64(URI v) {
        return setValue(Columns.LDWIN32_AMD64URI, v);
    }
    /**
     * This sets the URI to retreive application binary for mac os ix86
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDMacos_ix86(URI v) {
        return setValue(Columns.LDMACOS_IX86URI, v);
    }
    /**
     * This sets the URI to retreive application binary for mac os ppc
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDMacos_ppc(URI v) {
        return setValue(Columns.LDMACOS_PPCURI, v);
    }
    /**
     * This sets the URI to retreive application binary for solaris sparc
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDSolaris_sparc(URI v) {
        return setValue(Columns.LDSOLARIS_SPARCURI, v);
    }
    /**
     * This sets the URI to retreive application binary for solaris alpha
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDSolaris_alpha(URI v) {
        return setValue(Columns.LDSOLARIS_ALPHAURI, v);
    }
    /**
     * This sets the URI to retreive application binary for osf1 sparc
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDOsf1_sparc(URI v) {
        return setValue(Columns.LDOSF1_SPARCURI, v);
    }
    /**
     * This sets the URI to retreive application binary for osf1 alpha
     * @return  true if value has changed, false otherwise
     */
    public boolean setLDOsf1_alpha(URI v) {
        return setValue(Columns.LDOSF1_ALPHAURI, v);
    }
    /**
     * This sets this application access rights
     * @param v is the application access rights
     * @return true if value has changed, false otherwise
     */
    public boolean setAccessRights(XWAccessRights v) {
        return setValue(Columns.ACCESSRIGHTS, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setNbJobs(int v) {
        return setValue(Columns.NBJOBS, new Integer(v));
    }
    /**
     * This increments the number of executed jobs for this application
     */
    public void incNbJobs() {
        setNbJobs(getNbJobs() + 1);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setAvgExecTime(int v) {
        return setValue(Columns.AVGEXECTIME, new Integer(v));
    }
    /**
     * This increments NbJobs and recalculates avg exec time
     * @param v is the last execution time
     */
    public void incAvgExecTime(int v) {
        int nbJobs = getNbJobs();
        int avg = getAvgExecTime();

        if(v <= 0)
            v = 0;
        if(avg <= 0)
            avg = 0;
        if(nbJobs <= 0)
            nbJobs = 0;

        int total =(avg * nbJobs) + v;
        setAvgExecTime((int)(total / (nbJobs + 1)));
        incNbJobs();
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setMinMemory(int v) {
        return setValue(Columns.MINMEMORY, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setMinCpuSpeed(int v) {
        return setValue(Columns.MINCPUSPEED, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setName(String v) {
        return setValue(Columns.NAME, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setUID(UID v) {
        return setValue(Columns.UID, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setService(boolean v) {
        return setValue(Columns.ISSERVICE, new Boolean(v));
    }
    /**
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v) {
        return setValue(Columns.ISDELETED, new Boolean(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setDefaultStdin(URI v) {
        return setValue(Columns.DEFAULTSTDINURI, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setBaseDirin(URI v) {
        return setValue(Columns.BASEDIRINURI, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setDefaultDirin(URI v) {
        return setValue(Columns.DEFAULTDIRINURI, v);
    }
    /**
     * This tests user access rights
     * @param user is the UID of the user who try to access
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean checkUserAccessRights(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getOwner(), user, XWAccessRights.USERALL);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean checkGroupAccessRights(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPALL);
    }
    /**
     * This tests access rights
     * @return true if others have access rights
     */
    public boolean checkOtherAccessRights()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERALL);
    }
    /**
     * This tests if user can read
     * @param user is the UID of the user who try to read
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanRead(UID user)
        throws AccessControlException, IOException {
        /*
        System.out.println("AppInterface#userCanRead()");
        System.out.println("  owner = " + getOwner());
        System.out.println("  user  = " + getOwner());
        */
        return checkUserRights(getOwner(), user, XWAccessRights.USERREAD);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanRead(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPREAD);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanRead()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERREAD);
    }
    /**
     * This tests if user can write
     * @param user is the UID of the user who try to write
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanWrite(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getOwner(), user, XWAccessRights.USERWRITE);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to write
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanWrite(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPWRITE);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanWrite()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERWRITE);
    }

    /**
     * This tests if user can exec
     * @param user is the UID of the user who try to exec
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanExec(UID user)
        throws AccessControlException, IOException {
        /*
        System.out.println("AppInterface#userCanExec()");
        System.out.println("  owner = " + getOwner());
        System.out.println("  user  = " + getOwner());
        */
        return checkUserRights(getOwner(), user, XWAccessRights.USEREXEC);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to exec
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanExec(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPEXEC);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanExec()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHEREXEC);
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            AppInterface app = new AppInterface();
            app.setUID(UID.myUid);
            app.DUMPNULLS = true;
            System.out.println(app.toXml());
            FileOutputStream fos = new FileOutputStream(new File("app.xml"));
            DataOutputStream output = new DataOutputStream(fos);
            StreamIO io = new StreamIO(output, null, LoggerLevel.DEBUG);
            io.writeString(app.toXml());
            io.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
