package xtremweb.common;

import java.io.IOException;
import java.io.DataInputStream;
import java.sql.ResultSet;
import java.util.Date;
import java.util.StringTokenizer;

import org.xml.sax.Attributes;


/**
 * TraceInterface.java
 *
 * Created: Feb 19th, 2002
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This class describes a row of the traces SQL table.
 */
public class TraceInterface
    extends xtremweb.common.TableInterface {

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "trace";

    /**
     * This enumerates this interface columns
     */
    public enum Columns {
        UID,
        HOSTUID,
        LOGIN,
        ARRIVALDATE,
        STARTDATE,
        ISDELETED,
        ENDDATE,
        FILE;

        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns c : Columns.values()) {
                if(c.ordinal() == v)
                    return c;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[FILE.ordinal() + 1];
            for (Columns c : Columns.values())
                labels[c.ordinal()] = c.toString();
            return labels;
        }
    }

    /**
     * This is the default constructor
     */
    public TraceInterface() {

        super(THISTAG);

        LAST_ATTRIBUTE = Columns.FILE.ordinal();;
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values  = new Object[MAX_ATTRIBUTE];
        setDeleted(false);
    }
    /**
     * This constructor reads its definition from an SQL request result
     * @param rs is an SQL request result
     * @exception IOException
     */
    public TraceInterface(ResultSet rs) throws IOException {

        this();

        try {

            setHost(new UID(rs.getString(Columns.HOSTUID.toString())));
            setLogin(rs.getString(Columns.LOGIN.toString()));
            setFile(new URI(rs.getString(Columns.FILE.toString())));
            setUID(new UID(rs.getString(Columns.UID.toString())));

            try {
                setDeleted(new Boolean(rs.getString(Columns.ISDELETED.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setStartDate(util.getSQLDateTime(rs.getString(Columns.STARTDATE.toString())));
            }
            catch(Exception e) {
            }
            try {
                setArrivalDate(util.getSQLDateTime(rs.getString(Columns.ARRIVALDATE.toString())));
            }
            catch(Exception e) {
            }
            try {
                setEndDate(util.getSQLDateTime(rs.getString(Columns.ENDDATE.toString())));
            }
            catch(Exception e) {
            }
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }
    /**
     * This calls this(StreamIO.stream(input));
     * @param input is a String containing an XML representation
     */
    public TraceInterface(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public TraceInterface(DataInputStream input) 
        throws IOException{
        this();
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public TraceInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This retreives the UID
     * @return UID
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getUID() throws IOException{
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("HostInterface#getUID() : attribute not set");
        }
    }
    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public UID getHost() {
        return(UID)getValue(Columns.HOSTUID);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getLogin() {
        return(String)getValue(Columns.LOGIN);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getArrivalDate() {
        return(Date)getValue(Columns.ARRIVALDATE);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getStartDate() {
        return(Date)getValue(Columns.STARTDATE);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getEndDate() {
        return(Date)getValue(Columns.ENDDATE);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public URI getFile() {
        return(URI)getValue(Columns.FILE);
    }
    /**
     * This gets an attribute<br />
     * This attr is forced to false if not set
     * @return this attribute
     * @since 2.0.0
     */
    public boolean isDeleted() {
        try {
            Boolean ret = (Boolean)getValue(Columns.ISDELETED);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setDeleted(false);
            return false;
        }
    }
    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) {
        return setValue(Columns.valueOf(attribute.toUpperCase()), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the column to set 
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     */
    public boolean setValue(Columns column, Object val) {
        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), null);

        String v = val.toString();

        switch(column) {
        case UID :
        case HOSTUID :
        case FILE :
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case LOGIN :
            // sql query safety : removing spaces and quotes
            value = v.replaceAll("[\\n\\s\'\"]+", "_");
            break;
        case ARRIVALDATE :
        case STARTDATE :
        case ENDDATE :
            value = util.getSQLDateTime(v);
            break;
        case ISDELETED :
            value = new Boolean(v);
            break;
        }
        return super.setValue(column.ordinal(), value);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setUID(UID v) {
        return setValue(Columns.UID, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setHost(UID v) {
        return setValue(Columns.HOSTUID, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setLogin(String v) {
        return setValue(Columns.LOGIN, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setArrivalDate(Date v) {
        return setValue(Columns.ARRIVALDATE, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setStartDate(Date v) {
        return setValue(Columns.STARTDATE, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setEndDate(Date v) {
        return setValue(Columns.ENDDATE, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setFile(URI v) {
        return setValue(Columns.FILE, v);
    }
    /**
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v) {
        return setValue(Columns.ISDELETED, new Boolean(v));
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            TraceInterface trace = new TraceInterface();
            trace.setUID(UID.myUid);
            trace.DUMPNULLS = true;
            System.out.println(trace.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
