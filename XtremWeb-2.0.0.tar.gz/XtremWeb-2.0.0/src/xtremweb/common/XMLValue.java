package xtremweb.common;

import xtremweb.common.*;

import java.io.*;
import java.util.Vector;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLValue.java
 *
 * Created: March 22nd, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class (un)marshal object to/from XML
 * This is used by XMLHashtable, XMLVector
 * @see XMLHashtable
 * @see XMLVector
 */
public class XMLValue extends XMLObject {

    public static final String THISTAG = "XMLVALUE";

    /**
     */
    public XMLValue() {
	super();
	XMLTAG = THISTAG;
    }
    /**
     * This calls XMLable(String, int)
     * @see XMLable(String, int)
     */
    public XMLValue(String tag, int last) {
	super(tag, last);
    }
    /**
     */
    public XMLValue(Object v) {
	super(v);
	XMLTAG = THISTAG;
    }
    /**
     * This calls toString()
     * @param csv is never used
     * @see TableInterface#toString(boolean)
     */
    public String toString(boolean csv) {
	return toString();
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLValue(DataInputStream input) throws Exception{
	super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     */
    public XMLValue(Attributes attrs) throws IOException{
	this();
	XMLTAG = THISTAG;
	fromXml(attrs);
    }
}
