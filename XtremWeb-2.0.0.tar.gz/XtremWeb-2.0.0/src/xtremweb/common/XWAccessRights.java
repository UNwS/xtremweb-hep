package xtremweb.common;

import java.text.ParseException;
import java.io.PrintStream;

/**
 * XWAccessRights.java
 *
 * Created: Oct 26, 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This class describes static variables that define access rights
 */

public class XWAccessRights
    implements java.io.Serializable {

    private int value;

    /** 
     * This is the regular expression to change mode.<br />
     * This reg exp is <code>[auog]{1,4}[+|-][rwx]{1,3}</code>
     */
    private String REGEXP = "[auog]{1,4}[+|-][rwx]{1,3}";

    /** user can do everything value */
    public final static int            USERALL_INT   = 0x0700;
    /** user can do everything */
    public final static XWAccessRights USERALL       = new XWAccessRights(USERALL_INT);
    /** can user exec flag value */
    public final static int            USEREXEC_INT  = 0x0100;
    /** can user exec flag */
    public final static XWAccessRights USEREXEC      = new XWAccessRights(USEREXEC_INT);
    /** can user write flag value */
    public final static int            USERWRITE_INT = 0x0200;
    /** can user write flag */
    public final static XWAccessRights USERWRITE     = new XWAccessRights(USERWRITE_INT);
    /** can user read/list flag value */
    public final static int            USERREAD_INT  = 0x0400;
    /** can user read/list flag */
    public final static XWAccessRights USERREAD      = new XWAccessRights(USERREAD_INT);

    /** group user can do everything value */
    public final static int            GROUPALL_INT  = 0x0070;
    /** group user can do everything */
    public final static XWAccessRights GROUPALL      = new XWAccessRights(GROUPALL_INT);
    /** can group user exec flag value */
    public final static int            GROUPEXEC_INT = 0x0010;
    /** can group user exec flag */
    public final static XWAccessRights GROUPEXEC     = new XWAccessRights(GROUPEXEC_INT);
    /** can group user write flag value */
    public final static int            GROUPWRITE_INT = 0x0020;
    /** can group user write flag */
    public final static XWAccessRights GROUPWRITE    = new XWAccessRights(GROUPWRITE_INT);
    /** can group user read/list flag value */
    public final static int            GROUPREAD_INT = 0x0040;
    /** can group user read/list flag */
    public final static XWAccessRights GROUPREAD     = new XWAccessRights(GROUPREAD_INT);

    /** other user can do everything value */
    public final static int            OTHERALL_INT  = 0x0007;
    /** other user can do everything */
    public final static XWAccessRights OTHERALL      = new XWAccessRights(OTHERALL_INT);
    /** can other user exec flag value */
    public final static int            OTHEREXEC_INT = 0x0001;
    /** can other user exec flag */
    public final static XWAccessRights OTHEREXEC     = new XWAccessRights(OTHEREXEC_INT);
    /** can other user write flag value */
    public final static int            OTHERWRITE_INT = 0x0002;
    /** can other user write flag */
    public final static XWAccessRights OTHERWRITE    = new XWAccessRights(OTHERWRITE_INT);
    /** can other user read/list flag value */
    public final static int            OTHERREAD_INT = 0x0004;
    /** can other user read/list flag */
    public final static XWAccessRights OTHERREAD     = new XWAccessRights(OTHERREAD_INT);


    /** nothing can be done value */
    public final static int            NONE_INT      = 0;
    /** nothing can be done */
    public final static XWAccessRights NONE          = new XWAccessRights(NONE_INT);
    /** everything can be done value */
    public final static int            ALL_INT       = USERALL_INT | GROUPALL_INT | OTHERALL_INT;
    /** everything can be done */
    public final static XWAccessRights ALL           = new XWAccessRights(ALL_INT);
    /** everything can be done */
    public final static int            DEFAULT_INT   = USERALL_INT | 
        GROUPREAD_INT | GROUPEXEC_INT | 
        OTHERREAD_INT | OTHEREXEC_INT ;
    /** everything can be done */
    public final static XWAccessRights DEFAULT       = new XWAccessRights(DEFAULT_INT);


    public XWAccessRights(int v) {
        value = v & ALL_INT;
    }

    public XWAccessRights(String v) throws ParseException {
        value = NONE_INT;
        chmod(v);
    }

    public void chmod(String v) throws ParseException {

        v = v.toLowerCase();

        try {
            if(v.startsWith("0x"))
                value = Integer.parseInt(v.substring(2),16) & ALL_INT;
            else
                value = Integer.parseInt(v,16) & ALL_INT;
        }
        catch(NumberFormatException e) {
            if(v.matches(REGEXP) == false)
                throw new ParseException(v + " is not a valid mod", 0);

            if((v.indexOf("a") != -1) || (v.indexOf("u") != -1)) {
                if(v.indexOf("r") != -1) {
                    if(v.indexOf("+") != -1)
                        value |= USERREAD_INT;
                    else if(v.indexOf("-") != -1)
                        value &= ~USERREAD_INT;
                }
                if(v.indexOf("w") != -1) {
                    if(v.indexOf("+") != -1)
                        value |= USERWRITE_INT;
                    else if(v.indexOf("-") != -1)
                        value &= ~USERWRITE_INT;
                }
                if(v.indexOf("x") != -1) {
                    if(v.indexOf("+") != -1)
                        value |= USEREXEC_INT;
                    else if(v.indexOf("-") != -1)
                        value &= ~USEREXEC_INT;
                }
            }
            if((v.indexOf("a") != -1) || (v.indexOf("g") != -1)) {
                if(v.indexOf("r") != -1) {
                    if(v.indexOf("+") != -1)
                        value |= GROUPREAD_INT;
                    else if(v.indexOf("-") != -1)
                        value &= ~GROUPREAD_INT;
                }
                if(v.indexOf("w") != -1) {
                    if(v.indexOf("+") != -1)
                        value |= GROUPWRITE_INT;
                    else if(v.indexOf("-") != -1)
                        value &= ~GROUPWRITE_INT;
                }
                if(v.indexOf("x") != -1) {
                    if(v.indexOf("+") != -1)
                        value |= GROUPEXEC_INT;
                    else if(v.indexOf("-") != -1)
                        value &= ~GROUPEXEC_INT;
                }
            }
            if((v.indexOf("a") != -1) || (v.indexOf("o") != -1)) {
                if(v.indexOf("r") != -1) {
                    if(v.indexOf("+") != -1)
                        value |= OTHERREAD_INT;
                    else if(v.indexOf("-") != -1)
                        value &= ~OTHERREAD_INT;
                }
                if(v.indexOf("w") != -1) {
                    if(v.indexOf("+") != -1)
                        value |= OTHERWRITE_INT;
                    else if(v.indexOf("-") != -1)
                        value &= ~OTHERWRITE_INT;
                }
                if(v.indexOf("x") != -1) {
                    if(v.indexOf("+") != -1)
                        value |= OTHEREXEC_INT;
                    else if(v.indexOf("-") != -1)
                        value &= ~OTHEREXEC_INT;
                }
            }
        }
    }

    public int value() {
        return value;
    }
    public String toString() {
        return "0x" + Integer.toHexString(value);
    }

    /**
     * This dumps enums to stdout
     */
    public static void main(String[] argv) {
        PrintStream out = new PrintStream(System.out);
        out.printf("%04X : allow read  by owner.\n", USERREAD_INT);
        out.printf("%04X : allow write by owner.\n", USERWRITE_INT);
        out.printf("%04X : allow exec  by owner.\n", USEREXEC_INT);
        out.printf("%04X : allow read  by group.\n", GROUPREAD_INT);
        out.printf("%04X : allow write by group.\n", GROUPWRITE_INT);
        out.printf("%04X : allow exec  by group.\n", GROUPEXEC_INT);
        out.printf("%04X : allow read  by others.\n", OTHERREAD_INT);
        out.printf("%04X : allow write by others.\n", OTHERWRITE_INT);
        out.printf("%04X : allow exec  by others.\n", OTHEREXEC_INT);
        System.out.println("");
        System.out.println("Regular expression to change rights : " + USERALL.REGEXP + " where :");
        System.out.println("u       The user permission bits in the original mode of the file.");
        System.out.println("g       The group permission bits in the original mode of the file.");
        System.out.println("o       The other permission bits in the original mode of the file.");
        System.out.println("a       is equivalent to ugo.");
        System.out.println("+       This sets   mode.");
        System.out.println("-       This clears mode.");
        System.out.println("r       The read    bits.");
        System.out.println("w       The write   bits.");
        System.out.println("x       The execute bits.");
    }
}
