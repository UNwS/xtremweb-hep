/**
 * Date : March 13th, 2007<br />
 * @author Oleg Lodygensky (lodygens a t lal.in2p3.fr)
 *
 * This defines properties than can be read from config files.
 * @since 2.0.0
 */

package xtremweb.common;


public enum XWDBs {

    MYSQL,
    HSQL,
    HSQLMEM;

    /**
     * This array defines possible database vendor names for config file.
     * This is indexed by DB_* constants
     */
    public static final String[] labels = {
        "mysql",
        "hsqldb",
        "hsqldb:mem"
    };


    public static final XWDBs DEFAULT = MYSQL;

    /** 
     * This converts database vendor to a String.
     * @param s is the value to convert
     * @return a string containing boolean value
     */
    public static String toString(XWDBs db)
        throws ArrayIndexOutOfBoundsException {

        try {
            return labels[db.ordinal()];
        }
        catch (Exception e) {
        }
        throw new ArrayIndexOutOfBoundsException("unknown database vendor : " + db);
    }

    public static final String HSQLUSER ="sa";
    public static final String HSQLPASSWORD ="";

    /**
     * This dumps enums to stdout
     */
    public static void main(String[] argv) {
        for (XWPropertyDefs i : XWPropertyDefs.values())
            System.out.println(i.toString() + " = " + i.ordinal() +
                               " valueOf() = " + i.valueOf(i.toString()));
    }
}
