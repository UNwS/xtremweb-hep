package xtremweb.common;

import java.util.*;
import java.io.*;


/**
 ** NewClassLoader provides a minimalistic ClassLoader which shows how to
 ** load a class which resides in a .class file.
 <br><br>
 **
 ** @author Gilles Fedak
 **
 ** @version %I% %G%
 **
 **/

public class NewClassLoader extends MultiClassLoader
{
    //The added class paths
    private Vector paths;

    public NewClassLoader ()
    {
    
        paths = new Vector();
    }

		public void addClassPath(String path) {
				paths.addElement(path);
    
		}
    
		public void removeClassPath(String path) {
				for(Enumeration e = paths.elements(); e.hasMoreElements();) {
						String p = (String)e.nextElement();
						if (p.equals(path)) {
								paths.removeElement(p);
								break;
						}
				}
		}
		protected byte[] getClassFromAddedClassPaths(String className) {

				byte result[] = null;
				byte block[] = null;
				int rb, chunk, size;

				try {
						String fsep = System.getProperty("file.separator");
						String fileName = formatClassName(className);
      

						// Lookup the class into all the added class paths
						for(Enumeration e = paths.elements(); e.hasMoreElements();) {
								String path = (String)e.nextElement();
    
								File f = new File(path + fsep + fileName);
								if (f.exists()) {
										FileInputStream fis = new FileInputStream(f);
          
										size = (int)f.length();
										result = new byte[(int)size];
										rb=0;
										chunk=0;
										while (((int)size - rb) > 0) {
												chunk=fis.read(result,rb,(int)size - rb);
												if (chunk==-1){
														break;
												}
												rb+=chunk;
										}
      
										break;
								}
						}
				} catch (Exception e) {
				}
				return result;
		}

    protected byte[] loadClassBytes (String className)
    {
    
				return (getClassFromAddedClassPaths(className));
    }


    
    
}   // End of Class NewClassLoader.
