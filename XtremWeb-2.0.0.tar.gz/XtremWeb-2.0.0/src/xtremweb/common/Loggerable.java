
package xtremweb.common;


/** 
 * Loggerable.java
 *
 * Created : 15 avril 2008
 *
 * @author Oleg Lodygensky
 */

public interface Loggerable {


    LoggerLevel getLoggerLevel();
    void setLoggerLevel(LoggerLevel l);

    /**
     * This logs out a message
     */
    void printLog(String msg);

    /**
     * This tells whether debug level is set to DEBUG
     * @return true if debug level is set to DEBUG
     */
    boolean debug();
    /**
     * This logs out a DEBUG message
     */
    void debug(String msg);
    /**
     * This tells whether debug level is set to INFO
     * @return true if debug level is set to INFO
     */
    boolean info();
    /**
     * This logs out an INFO message
     */
    void info(String msg);
    /**
     * This tells whether debug level is set to WARN
     * @return true if debug level is set to WARN
     */
    boolean warn();
    /**
     * This logs out a WARN message
     */
    void warn (String msg);
    /**
     * This tells whether debug level is set to ERROR
     * @return true if debug level is set to ERROR
     */
    boolean error();
    /**
     * This logs out an ERROR message
     */
    void error(String msg);
}
