package xtremweb.common;

import xtremweb.communications.Connection;

import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.URL;
import java.net.URISyntaxException;

import org.xml.sax.SAXException;
import org.xml.sax.Attributes;


/**
 * This class describes an encapsulation of java.net.URI to ensure
 * XtremWeb is formed like :
 * <code>Connection.XWSCHEME + "://" + serverName + "/" + UID</code>
 * @author Oleg Lodygensky
 * @since 2.0.0
 */
public class URI extends XMLable {

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "uri";
    /**
     * This is the URI
     */
    private java.net.URI uri;
    /**
     * This is the UID, if this is an XtremWeb URI
     */
    private UID uid;
    /** 
     * This is the URI column index
     * @see XMLable#columns
     */
    private static final int URI = FIRST_ATTRIBUTE;

    /**
     * This tests if this contains a null UID
     * @see UID#isNull()
     */
    public boolean isNull() {
        return uid.isNull();
    }

    /** 
     * This constructs a new empty object
     */
    public URI() {
        super(THISTAG, URI);
        this.uri = null;
        columns[URI]  = new String("URI");
        uri = null;
        uid = null;
    }
    /** 
     * This constructs a new URI from string
     * @param value is the URI String representation
     * @exception IOException is thrown if parameter does not represents an UID
     */
    public URI(String value) throws IOException{
        this();
        fromString(value);
    }
    /**
     * This constructs a new URI
     * @param server is the xtremweb server name
     * @param uid is the referenced object uid
     */
    //    public URI(String server, int port, UID _uid) {
    public URI(String server, UID _uid) {
        this();
        try {
            uid = _uid;
            uri = new java.net.URI(Connection.XWSCHEME + Connection.SCHEMESEPARATOR +
//                                   server + ":" + port + "/" +
                                   server + "/" +
                                   uid.toString());
            uri.normalize();
        }
        catch(Exception e) {
            warn("xtremweb/common/URI#URI(" + server + "," + _uid + ") : " + e.toString());
        }
    }
    /**
     * This constructs a new object by receiving XML representation 
     * from input stream 
     * @param in is the input stream
     * @exception IOException is thrown on XML parsing error
     */
    public URI(DataInputStream in) throws IOException {
        this();
        fromXml(in);
    }
    /**
     * This returns a java.rmi.server.UID String representation
     */
    public boolean equals(URI uri2) {
        return (uri2.toString().compareToIgnoreCase(uri.toString()) == 0);
    }
    /**
     * This returns a java.rmi.server.UID String representation
     */
    public UID getUID() {
        return uid;
    }
    /**
     * This returns the host part of this URI
     */
    public String getHost() {
        return uri.getHost();
    }
    /**
     * This returns the port part of this URI
     */
    public int getPort() {
        return uri.getPort();
    }
    /**
     * This returns the scheme part of this URI
     */
    public String getScheme() {
        return uri.getScheme();
    }
    /**
     * This returns the path part of this URI
     */
    public String getPath() {
        return uri.getPath();
    }
    /**
     * This check whether scheme is XtremWeb one
     * @return true if scheme is XtremWeb one 
     * @see #xtremweb.communications.Connection#XWSCHEME
     */
    public boolean isXtremWeb() {
        return (uri.getScheme().compareToIgnoreCase(Connection.XWSCHEME) == 0);
    }
    /**
     * This check whether scheme is http one
     * @return true if scheme is http one 
     * @see #xtremweb.communications.Connection#HTTPSCHEME
     */
    public boolean isHttp() {
        URL url = null;
        try {
            url = new URL(uri.toString());
        }
        catch(Exception e) {
            return false;
        }
        return (url.getProtocol().compareToIgnoreCase(Connection.HTTPSCHEME) == 0);
    }
    /**
     * This calls toString(false)
     */
    public String toString() {
        return toString(false);
    }
    /**
     * This calls java.util.UUID.toString()
     * @param csv is never used
     */
    public String toString(boolean csv) {
        return uri.toString();
    }
    /**
     * This retreives an URI from String representation.
     * This tries to extract UID form URI, if this is an XtremWeb URI
     * @param value is the UID String representation
     * @exception IOException is thrown if parameter does not represents an UID
     */
    public void fromString(String value) throws IOException{
        try {
            uri = new java.net.URI(value);
            uri.normalize();
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
        try {
            String path = uri.getPath();
            if(path.length() > 1)
                path = path.substring(1);
            uid = new UID(path);
        }
        catch(Exception e) {
            debug("invalid uid : " + e);
            uid = null;
        }
    }

    /**
     * This retreives this object XML representation
     * @return this object XML representation
     */
    public String toXml() {
        return new String("<" + THISTAG + " " + 
                          columns[URI] + "=\"" + uri.toString()   + "\" />");
    }
    /**
     * This writes this object XML representation to output stream
     * @param o is the output stream to write to
     */
    public void toXml(DataOutputStream o) throws IOException {
        String ret = new String("<" + THISTAG + " " + 
                                columns[URI] + "=\"" + uri.toString()   + "\" />");
        o.writeUTF(ret);
    }

    /**
     * This retreives attributes from XML attributes
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

        if(attrs == null) {
            throw new IOException("attrs is null");
        }

        String infoSetType = null;

        for(int a = 0; a < attrs.getLength(); a++) {
            String attribute = attrs.getQName(a);
            String value = attrs.getValue(a);
            debug("     attribute #" + a + 
                  ": name=\"" + attribute + "\"" +
                  ", value=\"" + value + "\"");

            if(attribute.compareToIgnoreCase(columns[URI]) == 0)
                fromString(value);
        }
    }

    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler#startElement(String, String, String, Attributes)
     */
    public void xmlElementStart(String uri, String tag, String qname, 
                                Attributes attrs)
        throws IOException {
        if(qname.compareToIgnoreCase(THISTAG) == 0)
            fromXml(attrs);
    }
}
