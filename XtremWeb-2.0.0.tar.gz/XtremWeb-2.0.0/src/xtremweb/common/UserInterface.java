package xtremweb.common;

import java.io.IOException;
import java.io.DataInputStream;
import java.util.Date;
import java.util.StringTokenizer;
import java.sql.ResultSet;
import java.security.AccessControlException;

import org.xml.sax.Attributes;


/**
 * Created: Feb 19th, 2002<br />
 * This class describes a row of the works SQL table.
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

public class UserInterface
    extends xtremweb.common.TableInterface {

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "user";

    /**
     * This enumerates this interface columns
     */
    public enum Columns {
        /**
         * These are the attributes row number.<br>
         * The primary key MUST be the first attribute
         * @see TableInterface
         */
        UID,
        /**
         * This is the column index of the auto incremented code
         */
        USERGROUPUID,
        /**
         * This is the column index of the user group UID, if any
         */
        LOGIN,
        /**
         * This is the column index of the login
         */
        PASSWORD,
        /**
         * This is the column index of the password
         */
        EMAIL,
        /**
         * This is the column index of hte first name
         */
        FNAME,
        /**
         * This is the column index of the last name
         */
        LNAME,
        /**
         * This is the column index of the country
         */
        COUNTRY,
        /**
         * This is the column index of the executed job amount
         */
        NBJOBS,
        /**
         * This is the column index of the flag to tell whether this
         * has been deleted
         * @since 2.0.0
         */
        ISDELETED,
        /**
         * This is the column index of the user rights
         */
        RIGHTS;

        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns c : Columns.values()) {
                if(c.ordinal() == v)
                    return c;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[RIGHTS.ordinal() + 1];
            for (Columns c : Columns.values())
                labels[c.ordinal()] = c.toString();
            return labels;
        }
    }

    /**
     * This is the default constructor
     */
    public UserInterface() throws IOException{

        super(THISTAG);

        LAST_ATTRIBUTE = Columns.RIGHTS.ordinal();
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values  = new Object[MAX_ATTRIBUTE];

        setDeleted(false);
        setRights(UserRights.NONE);
    }

    /**
     * This is a copy constructor
     * @param src is the UserInterface to duplicate
     */
    public UserInterface(UserInterface src) throws IOException{
        this();
        setUID(src.getUID());
        setGroup(src.getGroup());
        setLogin(src.getLogin());
        setPassword(src.getPassword());
        setEMail(src.getEMail());
        setFirstName(src.getFirstName());
        setLastName(src.getLastName());
        setCountry(src.getCountry());
        setNbJobs(src.getNbJobs());
        setDeleted(src.isDeleted());
        setRights(src.getRights());
    }

    /**
     * This constructs a new object providing its primary key value
     * @param uid is this new object UID
     */
    public UserInterface(UID uid) throws IOException{
        this();
        setUID(uid);
    }

    /**
     * This constructs a new object providing its user login and password
     * @param l is the login
     * @param p is the password
     */
    public UserInterface(String l, String p) throws IOException{
        this();
        setLogin(l);
        setPassword(p);
    }
    /**
     * This constructs a new object from XML attributes
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public UserInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This calls this(StreamIO.stream(input));
     * @param input is a String containing an XML representation
     */
    public UserInterface(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public UserInterface(DataInputStream input) throws IOException{
        this();
        super.fromXml(input);
    }
    /**
     * This constructor reads its definition from an SQL request result
     * @param rs is an SQL request result
     * @exception IOException
     */
    public UserInterface(ResultSet rs) throws IOException {

        this();

        try {

            setNbJobs(new Integer(rs.getInt(Columns.NBJOBS.toString()))); 
            setRights(UserRights.valueOf(rs.getString(Columns.RIGHTS.toString()))); 
            setUID(new UID(rs.getString(Columns.UID.toString())));
            try {
                setGroup(new UID(rs.getString(Columns.USERGROUPUID.toString())));
            }
            catch(Exception e) {
            }
            setLogin(rs.getString(Columns.LOGIN.toString()));
            setPassword(rs.getString(Columns.PASSWORD.toString()));
            setEMail(rs.getString(Columns.EMAIL.toString()));
            setFirstName(rs.getString(Columns.FNAME.toString()));
            setLastName(rs.getString(Columns.LNAME.toString()));
            setCountry(rs.getString(Columns.COUNTRY.toString()));
            try {
                setDeleted(new Boolean(rs.getString(Columns.ISDELETED.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }
    }

    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This gets the user rights<br />
     * If not set, this attr is forced to 0
     * @return user rights or UserRights.NONE if not set
     */
    public UserRights getRights() {
        UserRights ret = (UserRights)getValue(Columns.RIGHTS);
        if(ret != null)
            return ret;
        setRights(UserRights.NONE);
        return UserRights.NONE;
    }
    /**
     * This retreives the UID
     * @return UID
     * @exception IOException is thrown is attribute is not set, neither well formed
     */
    public UID getUID() throws IOException{
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("UserInterface#getUID() : attribute not set");
        }
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     * @exception IOException is thrown is attribute is not well formed
     */
    public UID getGroup() throws IOException{
        try {
            return (UID)getValue(Columns.USERGROUPUID);
        }
        catch(NullPointerException e) {
            return null;
        }
    }
    /**
     * This gets the amount of already executed jobs for this user<br />
     * If not set, this attr is forced to 0
     * @return the attribute, or 0 is not set
     */
    public int getNbJobs() {
        Integer ret =(Integer)getValue(Columns.NBJOBS);
        if(ret != null)
            return ret.intValue();
        setNbJobs(0);
        return 0;
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getFirstName() {
        return(String)getValue(Columns.FNAME);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getLastName() {
        return(String)getValue(Columns.LNAME);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getEMail() {
        return(String)getValue(Columns.EMAIL);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getLogin() {
        return(String)getValue(Columns.LOGIN);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getPassword() {
        return(String)getValue(Columns.PASSWORD);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getCountry() {
        return(String)getValue(Columns.COUNTRY);
    }
    /**
     * This gets an attribute<br />
     * This attr is forced to false if not set
     * @return this attribute
     * @since 2.0.0
     */
    public boolean isDeleted() {
        try {
            Boolean ret = (Boolean)getValue(Columns.ISDELETED);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setDeleted(false);
            return false;
        }
    }
    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) {
        return setValue(Columns.valueOf(attribute.toUpperCase()), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the column to set 
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     */
    public boolean setValue(Columns column, Object val) {
        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), null);

        String v = val.toString();

        switch(column) {
        case UID :
        case USERGROUPUID :
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case RIGHTS :
            value = UserRights.valueOf(v);
            break;
        case NBJOBS :
            value = new Integer(Integer.parseInt(v));
            break;
        case LOGIN :
        case PASSWORD :
        case EMAIL :
        case FNAME :
        case LNAME :
        case COUNTRY :
            // sql query safety : removing spaces and quotes
            value = v.replaceAll("[\\n\\s\'\"]+", "_");
            break;
        case ISDELETED :
            value = new Boolean(v);
            break;
        }
        return super.setValue(column.ordinal(), value);
    }
    /**
     * This sets the rights
     * @return true is value has changed
     * @see xtremweb.common.UserRights
     */
    public boolean setRights(UserRights r) {
        return setValue(Columns.RIGHTS, r);
    }
    /**
     * This sets amout of executed jobs
     * @return true is value has changed
     */
    public boolean setNbJobs(int v) {
        return setValue(Columns.NBJOBS, new Integer(v));
    }
    /**
     * This sets the UID
     * @return true is value has changed
     */
    public boolean setUID(UID v) {
        return setValue(Columns.UID, v);
    }
    /**
     * This sets the group
     * @return true is value has changed
     */
    public boolean setGroup(UID v) {
        return setValue(Columns.USERGROUPUID, v);
    }
    /**
     * This sets first name
     * @return true is value has changed
     */
    public boolean setFirstName(String v) {
        return setValue(Columns.FNAME, v);
    }
    /**
     * This sets last name
     * @return true is value has changed
     */
    public boolean setLastName(String v) {
        return setValue(Columns.LNAME, v);
    }
    /**
     * This sets the login
     * @return true is value has changed
     */
    public boolean setLogin(String v) {
        return setValue(Columns.LOGIN, v);
    }
    /**
     * This sets password
     * @return true is value has changed
     */
    public boolean setPassword(String v) {
        return setValue(Columns.PASSWORD, v);
    }
    /**
     * This sets email
     * @return true is value has changed
     */
    public boolean setEMail(String v) {
        return setValue(Columns.EMAIL, v);
    }
    /**
     * This sets the country
     * @return true is value has changed
     */
    public boolean setCountry(String v) {
        return setValue(Columns.COUNTRY, v);
    }
    /**
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v) {
        return setValue(Columns.ISDELETED, new Boolean(v));
    }

    /**
     * This tests user access rights
     * @param user is the UID of the user who try to access
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean checkUserAccessRights(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getUID(), user, XWAccessRights.USERALL);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean checkGroupAccessRights(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPALL);
    }
    /**
     * This tests access rights
     * @return true if others have access rights
     */
    public boolean checkOtherAccessRights()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERALL);
    }
    /**
     * This tests if user can read
     * @param user is the UID of the user who try to read
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanRead(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getUID(), user, XWAccessRights.USERREAD);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanRead(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPREAD);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanRead()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERREAD);
    }
    /**
     * This tests if user can write
     * @param user is the UID of the user who try to write
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanWrite(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getUID(), user, XWAccessRights.USERWRITE);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to write
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanWrite(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPWRITE);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanWrite()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERWRITE);
    }
    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            UserInterface user = new UserInterface();
            user.setUID(UID.myUid);
            user.DUMPNULLS = true;
            System.out.println(user.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
