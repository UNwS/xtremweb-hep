package xtremweb.common;

import java.io.IOException;
import java.io.DataInputStream;
import java.util.Date;
import java.sql.ResultSet;
import java.util.StringTokenizer;

import org.xml.sax.Attributes;


/**
 * TaskInterface.java
 *
 * Created: Feb 19th, 2002
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This class describes a row of the tasks SQL table.
 */
public class TaskInterface
    extends xtremweb.common.TableInterface {

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "task";

    /**
     * This enumerates this interface columns
     */
    public enum Columns {
        /**
         * This is the column index of the task UID
         */
        UID,
        /**
         * This is the column index of the running worker UID
         */
        HOSTUID,
        /**
         * This is the column index of the flag which tells if this row has been deleted
         * @since 2.0.0
         */
        ISDELETED,
        /**
         * This is the column index of the amount of tries
         */
        TRIAL,
        /**
         * This is the column index of the status
         */
        STATUS,
        /**
         * This is the column index of the insertion date
         */
        INSERTIONDATE,
        /**
         * This is the column index of the start date
         */
        STARTDATE,
        /**
         * This is the column index of the last start date
         */
        LASTSTARTDATE,
        /**
         * This is the column index of the alive count
         */
        ALIVECOUNT,
        /**
         * This is the column index of the last alive date
         */
        LASTALIVE,
        /**
         * This is the column index of the removal date
         */
        REMOVALDATE,
        /**
         * This is the column index of the duration
         */
        DURATION;


        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns c : Columns.values()) {
                if(c.ordinal() == v)
                    return c;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[DURATION.ordinal() + 1];
            for (Columns c : Columns.values())
                labels[c.ordinal()] = c.toString();
            return labels;
        }
    }


    /**
     * This is the default constructor
     */
    public TaskInterface() {

        super(THISTAG);

        LAST_ATTRIBUTE = Columns.DURATION.ordinal();
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values  = new Object[MAX_ATTRIBUTE];
        setDeleted(false);
    }

    /**
     * This constructor reads its definition from a String provided as
     * argument where each field is separated by a '\t' character.
     *
     * Such a String has typically been created with an SQL command like :
     *       $> mysql -e "select * from tasks" > aTextFile
     *
     *
     * @param data is a String containing this object definition where
     * each field is separated by a tab, a space or a comma character
     */
    public TaskInterface(String data) {

        this();

        StringTokenizer tokenizer = new StringTokenizer(data,
                                                        "\t ,");

        for(int attr = FIRST_ATTRIBUTE;
            tokenizer.hasMoreTokens();
            attr++) {
            String elem = tokenizer.nextToken();
            setValue(Columns.fromInt(attr), elem);
        }
    }


    /**
     * This constructor reads its definition from an SQL request result
     * @param rs is an SQL request result
     * @exception IOException
     */
    public TaskInterface(ResultSet rs) throws IOException{

        this();

        try {

            setTrial(new Integer(rs.getInt(Columns.TRIAL.toString()))); 
            setAliveCount(new Integer(rs.getInt(Columns.ALIVECOUNT.toString())));
            setDuration(new Integer(rs.getInt(Columns.DURATION.toString())));
            setDeleted(new Boolean(rs.getString(Columns.ISDELETED.toString())));
            setUID(new UID(rs.getString(Columns.UID.toString())));

            try {
                setHost(new UID(rs.getString(Columns.HOSTUID.toString())));
            }
            catch(Exception e) {
            }
            try {
                setStatus(XWStatus.valueOf(rs.getString(Columns.STATUS.toString())));
            }
            catch(Exception e) {
            }
            try {
                setStartDate(util.getSQLDateTime(rs.getString(Columns.STARTDATE.toString())));
            }
            catch(Exception e) {
            }
            try {
                setLastStartDate(util.getSQLDateTime(rs.getString(Columns.LASTSTARTDATE.toString())));
            }
            catch(Exception e) {
            }
            try {
                setLastAlive(util.getSQLDateTime(rs.getString(Columns.LASTALIVE.toString())));
            }
            catch(Exception e) {
            }
            try {
                setRemovalDate(util.getSQLDateTime(rs.getString(Columns.REMOVALDATE.toString())));
            }
            catch(Exception e) {
            }
            try {
                setInsertionDate(util.getSQLDateTime(rs.getString(Columns.INSERTIONDATE.toString())));
            }
            catch(Exception e) {
            }
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }

    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public TaskInterface(DataInputStream input)
        throws IOException{
        this();
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public TaskInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This sets parameter
     * @return true if value has changed, false otherwise
     */
    public boolean incAliveCount() {
        if(getValue(Columns.ALIVECOUNT) == null)
            setValue(Columns.ALIVECOUNT, new Integer(1));
        else {
            int count =((Integer)getValue(Columns.ALIVECOUNT)).intValue();
            setValue(Columns.ALIVECOUNT, new Integer(count++));
        }
        return true;
    }

    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This retreives the job duration<br />
     * If this attr is not set, it os forced to 0
     * @return this attribute or 0 if not set
     */
    public int getDuration() {
        Integer ret =(Integer)getValue(Columns.DURATION);
        if(ret != null)
            return ret.intValue();
        setDuration(0);
        return 0;
    }
    /**
     * This retreives the number of trials<br />
     * If this attr is not set, it os forced to 0
     * @return this attribute of 0 if not set
     */
    public int getTrial() {
        Integer ret =(Integer)getValue(Columns.TRIAL);
        if(ret != null)
            return ret.intValue();
        setTrial(0);
        return 0;
    }
    /**
     * This retreives the status
     * @exception IOException is thrown if status is not set
     * @return this attribute
     */
    public XWStatus getStatus() throws IOException{
        try {
            return (XWStatus)getValue(Columns.STATUS);
        }
        catch(NullPointerException e) {
            return null;
        }
    }
    /**
     * This reterives the alive counter<br />
     * If this attr is not set, it os forced to 0
     * @return this attribute or 0 if not set
     */
    public int getAliveCount() {
        Integer ret =(Integer)getValue(Columns.ALIVECOUNT);
        if(ret != null)
            return ret.intValue();
        setAliveCount(0);
        return 0;
    }
    /**
     * This retreives the UID
     * @return UID
     * @exception IOException is thrown is attribute is not set, neither well formed
     */
    public UID getUID() throws IOException{
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("TaskInterface#getUID() : attribute not set");
        }
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     * @exception IOException is thrown is attribute is not well formed
     */
    public UID getHost() throws IOException{
        try {
            return  (UID)getValue(Columns.HOSTUID);
        }
        catch(NullPointerException e) {
            return null;
        }
    }
    /**
     * This retreives the deleted flag.
     * If this attr is not set, it os forced to false
     * @since 2.0.0
     */
    public boolean isDeleted()  {
        try {
            return((Boolean)getValue(Columns.ISDELETED)).booleanValue();
        }
        catch(NullPointerException e) {
            setDeleted(false);
            return false;
        }
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getInsertionDate() {
        return(Date)getValue(Columns.INSERTIONDATE);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getStartDate() {
        return(Date)getValue(Columns.STARTDATE);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getLastStartDate() {
        return(Date)getValue(Columns.LASTSTARTDATE);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getLastAlive() {
        return(Date)getValue(Columns.LASTALIVE);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getRemovalDate() {
        return(Date)getValue(Columns.REMOVALDATE);
    }


    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) {
        return setValue(Columns.valueOf(attribute.toUpperCase()), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the column to set 
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     */
    public boolean setValue(Columns column, Object val) {
        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), null);

        String v = val.toString();

        switch(column) {
        case TRIAL :
        case ALIVECOUNT :
        case DURATION :
            value = new Integer(Integer.parseInt(v));
            break;
        case UID :
        case HOSTUID :
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case STATUS :
            value = XWStatus.valueOf(v);
            break;
        case INSERTIONDATE :
        case STARTDATE :
        case LASTSTARTDATE :
        case LASTALIVE :
        case REMOVALDATE :
            if(val instanceof java.util.Date) {
                value = val;
            }
            else {
                value = util.getSQLDateTime(v);
            }
            break;
        case ISDELETED:
            value = new Boolean(v);
            break;
        }
        return super.setValue(column.ordinal(), value);
    }

    /**
     * This sets the duration 
     * @return true if value has changed
     */
    public boolean setDuration(int v) {
        return setValue(Columns.DURATION, new Integer(v));
    }
    /**
     * This sets the trial values (how many times have we tried)
     * @return true if value has changed
     */
    public boolean setTrial(int v) {
        return setValue(Columns.TRIAL, new Integer(v));
    }
    /**
     * This sets the  task status
     * @return true if value has changed
     */
    public boolean setStatus(int v)
        throws ArrayIndexOutOfBoundsException {
        return setStatus(XWStatus.fromInt(v));
    }
    /**
     * This sets the  task status
     * @return true if value has changed
     */
    public boolean setStatus(XWStatus v)
        throws ArrayIndexOutOfBoundsException {
        return setValue(Columns.STATUS, v);
    }
    public boolean setAliveCount(int v) {
        return setValue(Columns.ALIVECOUNT, new Integer(v));
    }
    /**
     * This sets the UID
     * @return true if value has changed
     */
    public boolean setUID(UID v) {
        return setValue(Columns.UID, v);
    }
    public boolean setHost(UID v) {
        return setValue(Columns.HOSTUID, v);
    }
    public boolean setInsertionDate(Date v) {
        return setValue(Columns.INSERTIONDATE, v);
    }
    public boolean setStartDate(Date v) {
        return setValue(Columns.STARTDATE, v);
    }
    public boolean setLastStartDate(Date v) {
        return setValue(Columns.LASTSTARTDATE, v);
    }
    public boolean setLastAlive(Date v) {
        return setValue(Columns.LASTALIVE, v);
    }
    public boolean setRemovalDate(Date v) {
        return setValue(Columns.REMOVALDATE, v);
    }
    /**
     * This set the deleted flag
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v)  {
        return setValue(Columns.ISDELETED, new Boolean(v));
    }
    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            TaskInterface task = new TaskInterface();
            task.setUID(UID.myUid);
            task.DUMPNULLS = true;
            System.out.println(task.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
