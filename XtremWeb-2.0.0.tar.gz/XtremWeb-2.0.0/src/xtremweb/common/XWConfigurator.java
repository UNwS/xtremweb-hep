
package xtremweb.common;


/** 
 * XWConfigurator.java
 * XW Worker and Client Config
 *
 * Created : Mon Mar 25 2002
 *
 * @author Samuel Heriard
 */

import xtremweb.archdep.ArchDepFactory;
import xtremweb.archdep.XWNotify;
import xtremweb.communications.CommClient;
import xtremweb.communications.Connection;

import java.util.Vector;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.TimeZone;
import java.io.IOException;
import java.io.File;
import java.io.PrintWriter;
import java.io.PrintStream;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.net.MalformedURLException;


// a shorter ServerProperties
// using java's builtin property parser 
 
public class XWConfigurator extends LoggerableProperties  {

    /**
     * This is the config file to read/write properties
     */
    public File configFile;
    /** 
     * This is the launch date
     * @since XWHEP 1.0.0
     */
    private Date upTime;
    /** 
     * This retreives the launch date
     * @return the up time date
     * @since XWHEP 1.0.0
     */
    public Date upTime() {
        return upTime;
    }
    /** 
     * This is the current dispatcher index
     * @since v1r2-rc1(RPC-V)
     */
    private int currentDispatcher;

    /** 
     * This is the current data server index
     * @since XWHEP 1.0.0
     */
    private int currentDataServer;

    /**
     * This is the minimum timeout
     * <ul>
     * <li>server : timeout to pool the database
     * <li>worker : timeout to request a new work
     * <li>client : timeout to check a result
     * </ul>
     * This is set to 10ms
     * @since RPCXW
     */
    public static final int MINTIMEOUT = 10;
    /**
     * This is the maximum timeout; this is only use by the worker to ensure
     * the worker comes back sometime to request a new work
     * <ul>
     * <li>worker : timeout to request a new work
     * </ul>
     * This is set to 5mn
     * @since XWHEP
     */
    public static final int MAXTIMEOUT = 300000;
    /** 
     * This is the default timeout in milliseconds to pool the database<br />
     * Default is 20000 (20 sec)
     * @since RPCXW
     */
    public static final int DEFTIMEOUT = 20000;
    /** 
     * This vector contains a set of XtremWeb server adresses.
     * This is used for replication; this list contains dispatchers
     * read from conf file and provided by server at connections time.
     *
     * @since v1r2-rc1(RPC-V)
     */
    public Vector dispatchers;
    /** 
     * This is the max number of dispatchers the worker may know.
     * This is used for replication; this list contains dispatchers
     * read from conf file and provided by server at connections time.
     * @since v1r2-rc1(RPC-V)
     */
    private final int MAXDISPATCHERS = 50;

    /** 
     * This vector contains a set of XtremWeb server adresses.
     * This is used for replication; this list contains dataServers
     * read from conf file and provided by server at connections time.
     *
     * @since v1r2-rc1(RPC-V)
     */
    private Vector dataServers;
    /** 
     * This is the max number of dataServers the worker may know.
     * This is used for replication; this list contains dataServers
     * read from conf file and provided by server at connections time.
     * @since v1r2-rc1(RPC-V)
     */
    private final int MAXDATASERVERS = 50;

    /**
     * This is the amount of jobs this worker has already computed
     * @see #maxJobs
     * @since RPCXW
     */
    public int nbJobs;
    /**
     * This is the maximum jobs this worker will compute before dying
     * This is expecially usefull to deploy workers over Grids
     * @see #MAXJOBSDEFAULT
     * @since RPCXW
     */
    public boolean stopComputing() {
        int maxJobs = getInt(XWPropertyDefs.COMPUTINGJOBS, 
                             Integer.parseInt(XWPropertyDefs.COMPUTINGJOBS.value()));
        return ((maxJobs > 0 ) && (nbJobs > maxJobs));
    }
    /**
     * This returns the max timeout to wait between two work requests.
     * This is only used by the worker like this (src/common/CommManager.java) :
     *      nullWorkTimeOut = (nullWorkTimeOut * 2) % config.maxTimeout()
     *
     * @see #realTime()
     * @see #MINTIMEOUT
     * @see #MAXTIMEOUT
     * @return if(realTime()) MINTIMEOUT, timeout * 40 otherwise; 
     *         if timeout is not set, this returns MAXTIMEOUT, 
     * @since RPCXW
     */
    public int maxTimeout() {
        try {
            if(realTime() == true) 
                return MINTIMEOUT;
            else
                return Integer.parseInt(getProperty(XWPropertyDefs.TIMEOUT.toString())) * 40;
        }
        catch(Exception e) {
            setProperty(XWPropertyDefs.TIMEOUT.toString(), "" + MAXTIMEOUT);
            return MAXTIMEOUT;
        }
    }
    /**
     * This test whether we try "real time"
     * @since RPCXW
     */
    public boolean realTime() {
        try {
            return Long.parseLong(getProperty(XWPropertyDefs.TIMEOUT.toString())) <= MINTIMEOUT;
        }
        catch(Exception e) {
            return false;
        }
    }


    /** This is the host identification */
    public HostInterface _host;
    /** This is the user identification */
    public UserInterface _user;

    /** various hardware configuration flag */
    public boolean hasKeyboard = true;  
    public boolean hasMouse    = true;
    //public int     nbProc      = 0;

    /** This is the base of tmp dir(default is /tmp) */
    protected  String tmpDirBase;

    /** This is the dir name where binaries are stored*/
    public  String binCachedPath;

    /** This is the max amout of binaries stored on worker side */
    public final int MAX_BIN = 5;

    // Name of the certificate file
    public String certFile;

    /** This tells whether we use a Sandbox */	
    public boolean useSandbox = false;
    /** This tells if the sandbox is included in the jar file*/
    public boolean sandboxEmbedded = false;
    /** This is the sandbox name */
    public String sandboxName = null;
    /** This is the sandbox args */
    public String sandboxArgs = null;

    private static File sandbox;

    /** notify configuration */
    public boolean useNotify = false;

    /** size of the work pool*/
    public int workPoolSize;

    /**
     * This tells whether to load system dependant libraries
     * default is true; must be set to false for the client
     */
    private boolean loadLibraries;

    /**
     * Use java NIO ?
     * @since XWHEP 1.0.0
     */
    public boolean nio() {
        return getBoolean(XWPropertyDefs.NIO, Boolean.parseBoolean(XWPropertyDefs.NIO.value()));
    }
    /**
     * Start HTTP server ?
     * @since XWHEP 1.0.0
     */
    public boolean http() {
        return getBoolean(XWPropertyDefs.SERVERHTTP, 
                          Boolean.parseBoolean(XWPropertyDefs.SERVERHTTP.value()));
    }
    /**
     * @since XWHEP 1.0.0
     */
    public URL launcherURL() throws MalformedURLException {
        return new URL(getProperty(XWPropertyDefs.LAUNCHERURL.toString()));
    }
    public boolean hsqldb() {
        return getProperty(XWPropertyDefs.DBVENDOR.toString()).startsWith(XWDBs.toString(XWDBs.HSQL));
    }
    public boolean hsqldbmem() {
        return getProperty(XWPropertyDefs.DBVENDOR.toString()).compareToIgnoreCase(XWDBs.toString(XWDBs.HSQLMEM)) == 0;
    }
    /**
     * This is the default cpu load
     */
    //    public static final int CPULOADDEFAULT = 30;
    /**
     * This is the maximum cpu load dedicated to XWWorker
     * This should be understood as follow :
     *      IF   this.cpuLoad > XWWorkerEffectiveCpuLoad
     *      THEN the worker stop computing
     * because the cpu is expected for other processes than XWWorker
     *
     * XWWorker can not load cpu more than this.cpuLoad if the cpu is expected by its owner
     * @see #CPULOADDEFAULT
     */
    public int cpuLoad() {
        return getInt(XWPropertyDefs.CPULOAD, Integer.parseInt(XWPropertyDefs.CPULOAD.value()));
    }

    public LoggerLevel getLoggerLevel() {
        try {
            return LoggerLevel.valueOf(getProperty(XWPropertyDefs.LOGGERLEVEL.toString()).toUpperCase());
        }
        catch(Exception e) {
            setProperty(XWPropertyDefs.LOGGERLEVEL.toString(),
                        XWPropertyDefs.LOGGERLEVEL.value());
            return LoggerLevel.valueOf(XWPropertyDefs.LOGGERLEVEL.value());
        }
    }

    /**
     * This initializes default values.
     * This is used to be able to launch the client GUI without any config file
     */
    public XWConfigurator() {
        super();
        upTime = new Date();
        dispatchers = new Vector();
        dataServers = new Vector();
        try {
            addDispatcher("localhost");
            setCurrentDispatcher("localhost");
            _host = new HostInterface();
            _host.setName(util.getLocalHostName());
            _user = new UserInterface();
        }
        catch(Exception e) {
        }
    }

    /**
     * This contructs XtremWeb client side(XWClient, XWWorker..) properties.<br>
     * Properties may be read from several places:
     * <ol>
     * <li> the file which name is provided as arguments;
     * <li> some 'standard' files from
     *      <ol>
     *      <li> $HOME/.xtremweb/xtremweb.worker.conf
     *      <li> $HOME/.xtremweb/config.defaults
     *      <li> /etc/xwrc
     *      <li> file pointed by the environment variable 'xtremweb.config'
     *      <ol>
     * <li> the file included in the JAR file
     * </ol>
     * @param cfn is the name of the config file, or null if none
     * @param firstTime is used to know whether the worker has upgrade
     */
    public XWConfigurator(String cfn, boolean firstTime) {

        this();

        String configFileName = cfn;

        String[] arguments = null;
        Properties defaults = new Properties();
        configFile = null;


        if(configFileName != null) {
            configFile = new File(configFileName);
            setProperty(XWPropertyDefs.CONFIGFILE.toString(), configFileName);
        }

        if((configFile == null) || (configFile.exists() == false)) {

            String fname = "xtremweb." + XWRole.myRole.toString().toLowerCase() + ".conf" ;
            String[] stdLoc = {
                getProperty(XWPropertyDefs.USERHOME.toString()) + 
                File.separator + ".xtremweb" + File.separator + fname,
                getProperty(XWPropertyDefs.USERHOME.toString()) + File.separator +
                ".xtremweb" + File.separator + "config.defaults",
                "/etc/" + fname,
                getProperty(XWPropertyDefs.CONFIGFILE.toString())
            };
            for(int i = 0; i < stdLoc.length ; i++) {
                try {
                    configFile = new File(stdLoc[i]);
                    if(configFile.exists()) {
                        setProperty(XWPropertyDefs.CONFIGFILE.toString(),
                                    configFileName);
                        break;
                    }
                }
                catch(Exception e) {
                }
                configFile = null;
            }
        }


        try {

            InputStream def = null;

            if((configFile == null) || (configFile.exists() == false)) {
                def = getClass().getResourceAsStream("/data/config.defaults");
            }
            else {
                def =(InputStream)new FileInputStream(configFile);
            }

            load(def);
            def.close();

        }
        catch(Exception e) {
            System.err.println("Can't open config file " + configFileName + " : " + e.toString());
            System.exit(-1);
        }


        // don't forget to update the config
        // i.e. sync the instances variables with the Properties object
        try {
            refresh(firstTime);
            setProperty(XWPropertyDefs.ALONE.toString(), XWPropertyDefs.ALONE.value());
        } catch(Exception e) { 
            e.printStackTrace();
            System.err.println("error in config file : " + e);
            System.exit(-1);
        }

        currentDispatcher = 0;
        currentDataServer = 0;
        loadLibraries = true;
    }

    /**
     * This sets the loadLibraries member attribute
     * @param a tells to load libraries or not; must be false for the client
     */
    public void loadLibrary(boolean a) {
        loadLibraries = a;
    }

    /**
     * This updates all the fields using 
     * the current values of the Properties object
     * This sets some default values if not defined in the config file:
     * <ul>
     * <li>activator.date="* 19-8"
     * </ul>
     * @param firstTime is used to know whether the worker has upgrade
     */
    private void refresh(boolean firstTime) throws Exception {

        // init values : set default if not set, trim() otherwise
        for (XWPropertyDefs p : XWPropertyDefs.values()) {
            if(getProperty(p.toString()) == null) {
                if(p.value() != null)
                    setProperty(p.toString(), p.value());
            }
            else {
                setProperty(p.toString(), getProperty(p.toString()).trim());
            }
        }

        //
        // set role
        //
        XWRole.setRole(XWRole.fromString(getProperty(XWPropertyDefs.ROLE.toString())));
//        debug("XWRole = " + XWRole.myRole.toString());

        tmpDirBase = getPath(XWPropertyDefs.TMPDIR, 
                             System.getProperty(XWPropertyDefs.JAVATMPDIR.toString()));
        if(tmpDirBase.endsWith(File.separator) == false)
            tmpDirBase = tmpDirBase.concat(File.separator);
        System.setProperty(XWPropertyDefs.JAVATMPDIR.toString(), tmpDirBase);

        currentDispatcher = 0;
        currentDataServer = 0;
        dispatchers = getServerNames(XWPropertyDefs.DISPATCHERS.toString());
        dataServers = getServerNames(XWPropertyDefs.DATASERVERS.toString());
        retreiveDispatchers();
        retreiveDataServers();

        if((dispatchers == null) || (dispatchers.size() == 0)) {
            if(XWRole.isDispatcher() == true) {
                dispatchers = new Vector();
                dispatchers.add(util.getLocalHostName());
            }
            else
                throw new Exception ("No XWHEP Server Found(key = " +
                                     XWPropertyDefs.DISPATCHERS.toString() + ")");
        }

        if(dataServers == null) {
            info("no data servers found; using dispatchers as data servers");
            dataServers = dispatchers;
        }

        if(!isAlone() && firstTime)
            if(XWRole.isWorker() == true)
                throw new Exception ("Another instance of the worker is already running");
            else 
                setProperty(XWPropertyDefs.ALONE.toString(), 
                            XWPropertyDefs.ALONE.value());

        if(getProperty(XWPropertyDefs.CACHEDIR.toString()) == null) {
            setProperty(XWPropertyDefs.CACHEDIR.toString(),
                        getCacheDir().getAbsolutePath());
        }

        binCachedPath = getCacheDir().getAbsolutePath() + File.separator + "bin";
        util.checkDir(binCachedPath);   
    
        certFile = getPath(XWPropertyDefs.KEYSTORE, null);
        if(certFile == null || !(new File(certFile)).exists()) {
            try {
                extractResource("data/keystore.worker", "keystore.worker");
            }
            catch(Exception e) {
//                debug("can't extract keystore");
            }
        }

        /*
         * alive period
         */
        int defalive = Integer.parseInt(XWPropertyDefs.ALIVE.value());
        int alive = defalive;
        try {
            String aliveStr = getProperty(XWPropertyDefs.ALIVE.toString()).trim();
            if((aliveStr == null) || (aliveStr == ""))
                alive = defalive;
            else
                alive = Integer.parseInt(aliveStr);
        }
        catch(NumberFormatException e) {
            alive = defalive;
        }

        setProperty(XWPropertyDefs.ALIVE.toString(), "" + alive);
        setProperty(XWPropertyDefs.ALIVETIMEOUT.toString(), "" + (alive * 3));

        if(XWRole.isDispatcher() == false) {
            //
            //Find user configuration
            // 1- login
            // 2- password
            // 3- version
            //
            String astring = getProperty(XWPropertyDefs.LOGIN.toString());
            if(astring == null)
                throw new Exception("No login name provided"); 

            setProperty(XWPropertyDefs.LOGIN.toString(), astring);
            astring = getProperty(XWPropertyDefs.PASSWORD.toString()); 
            if((astring == null) && (XWRole.isDispatcher() == false))
                throw new Exception("You must provide a Passsword");

            setProperty(XWPropertyDefs.PASSWORD.toString(), astring);
        }

        Version version = CommonVersion.getCurrent(); 


        long timeout = getInt(XWPropertyDefs.TIMEOUT, 
                              Integer.parseInt(XWPropertyDefs.TIMEOUT.value()));
        if(timeout < MINTIMEOUT)
            timeout = MINTIMEOUT;

        setProperty(XWPropertyDefs.TIMEOUT.toString(), 
                    "" + getInt(XWPropertyDefs.TIMEOUT, 
                                Integer.parseInt(XWPropertyDefs.TIMEOUT.value())));

        setProperty(XWPropertyDefs.NOOPTIMEOUT.toString(), 
                    "" + getInt(XWPropertyDefs.NOOPTIMEOUT, 
                                Integer.parseInt(XWPropertyDefs.NOOPTIMEOUT.value())));

        nbJobs = 0;

        try {
            String commLayer = getProperty(XWPropertyDefs.COMMLAYER.toString());
            if(commLayer != null)
                setProperty(XWPropertyDefs.COMMLAYER.toString(),
                            commLayer.trim());
        }
        catch(Exception e) {
            warn("Comm layer definition error " + e);
            setProperty(XWPropertyDefs.COMMLAYER.toString(),XWPropertyDefs.COMMLAYER.value());
            warn("Comm layer set to '" + getProperty(XWPropertyDefs.COMMLAYER.toString()) + "'");
        }

        String classes = getProperty(XWPropertyDefs.MILESTONES.toString());
//        debug("mileStoning " + classes);
        if(classes == null)
            classes = new String();
        new MileStone(util.split(classes));

        _user.setLogin(getProperty(XWPropertyDefs.LOGIN.toString()));
        _user.setPassword(getProperty(XWPropertyDefs.PASSWORD.toString()));

        try {
            UID uid = UID.myUid;
            try {
                String uidStr = getProperty(XWPropertyDefs.UID.toString());
                if(uidStr != null)
                    uid = new UID(uidStr);
            }
            catch(IOException e) {
                uid = UID.myUid;
            }
            setProperty(XWPropertyDefs.UID.toString(), uid.toString());
            _host.setUID(uid);
        }
        catch(Exception e) {
            util.fatal("can't set this worker UID ???");
        }

        String ip;
        try {
            ip = InetAddress.getLocalHost().getHostAddress();
        } 
        catch(Exception e) {
            try {
                ip = java.net.InetAddress.getByName ("localhost").getHostAddress ();
            } 
            catch(Exception e2) {
                throw new Exception("can't determine IP address: " + e2);
            }
        }

        _host.setNatedIPAddr(ip);
        _host.setIPAddr(ip);
        _host.setHWAddr("");
        _host.setTimeZone(TimeZone.getDefault().getID());
        _host.setProject(getProperty(XWPropertyDefs.PROJECT.toString()));
        _host.setTimeOut(Integer.parseInt(getProperty(XWPropertyDefs.TIMEOUT.toString())));
        _host.setVersion(version.full());

        _host.setCpuNb(1);
        _host.setCpuSpeed(0);
        _host.setCpuModel("unknown");
        _host.setTotalMem(0);
        _host.setTotalSwap(0);
        _host.setOs(XWOSes.getOs());
        _host.setCpu(XWCPUs.getCpu());
        _host.setAvailable(false);

        if(!XWRole.isWorker())
            return;

        _host.setAcceptBin(getBoolean(XWPropertyDefs.ACCEPTBIN, 
                                      Boolean.parseBoolean(XWPropertyDefs.ACCEPTBIN.value())));

        if(ArchDepFactory.xwutil() != null) {
            _host.setCpuNb(ArchDepFactory.xwutil().getNumProc());
            _host.setCpuSpeed(ArchDepFactory.xwutil().getSpeedProc());
            _host.setCpuModel(ArchDepFactory.xwutil().getProcModel());
            _host.setTotalMem(ArchDepFactory.xwutil().getTotalMem());
            _host.setTotalSwap(ArchDepFactory.xwutil().getTotalSwap());
        }
        else
            util.fatal("can't load xwutil library");

        /**
         * Configuration of the Sandbox
         * 1- boolean to specifye the use of a sandboxing mechanism
         * 2- full name of the sandboxing mechanism
         */

        useSandbox = getBoolean(XWPropertyDefs.SANDBOX, Boolean.parseBoolean(XWPropertyDefs.SANDBOX.value()));
        sandboxEmbedded = getBoolean(XWPropertyDefs.SANDBOXEMBEDDED, Boolean.parseBoolean(XWPropertyDefs.SANDBOXEMBEDDED.value()));
        sandboxName = getProperty(XWPropertyDefs.SANDBOXPATH.toString(), "");
        if(useSandbox && sandboxEmbedded && XWOSes.getOs().isLinux()){
            try {
                if(sandbox == null) {
                    if(sandboxName.length()==0) 
                        sandboxName = "bin/sandbox-linux";
                    InputStream sandboxStream = getClass().getClassLoader().getResourceAsStream(sandboxName);
                    sandbox = File.createTempFile("XWSandBox", "");
                    sandbox.deleteOnExit();
                    FileOutputStream sandboxLocation = new FileOutputStream(sandbox);
                    BufferedInputStream bin = new BufferedInputStream(sandboxStream);
                    BufferedOutputStream bout = new BufferedOutputStream(sandboxLocation);
                    byte buffer[] = new byte[1024];
                    int read = -1;
                    while((read = bin.read(buffer, 0, 1024)) != -1)
                        bout.write(buffer, 0, read);
                    bout.flush();
                    bout.close();
                    bin.close();
                    String[] args = new String[3];
                    args[0] = "chmod";
                    args[1] = "700";
                    args[2] = sandbox.toString();
                    java.lang.Runtime.getRuntime().exec(args, null, null);
                }
                sandboxName = sandbox.toString();
                sandboxArgs = "";
            }catch(Exception e){
                useSandbox = false;
            }
        }else if(useSandbox) {
            sandboxName = getProperty(XWPropertyDefs.SANDBOXNAME.toString());
            // Perform some sanity check
            if(!(new File( sandboxName )).exists() ) 
                throw new Exception("The SandBox Path given does not correspond to any file. Check your configuration file(key: sandbox.name )");
            sandboxArgs = getProperty(XWPropertyDefs.SANDBOXARGS.toString());
        }

        /**
         * Configuration of the tracer 
         */
	
        _host.setTracing(getBoolean(XWPropertyDefs.TRACES, 
                                    Boolean.parseBoolean(XWPropertyDefs.TRACES.value())));

        loadLibrary(XWRole.isWorker());

        /**
         * Configuration of the activation
         */
        if(loadLibraries) {
            String act = getProperty(XWPropertyDefs.ACTIVATOR.toString());
            if(act == null) {
                act = XWPropertyDefs.ACTIVATOR.value();
                _host.setAvailable(true);
            }
            setProperty(XWPropertyDefs.ACTIVATOR.toString(), act);
            String actDate = getProperty(XWPropertyDefs.ACTIVATIONDATE.toString());
            if(actDate == null) {
                setProperty(XWPropertyDefs.ACTIVATIONDATE.toString(), "* 19-7");
            }
            debug(XWPropertyDefs.ACTIVATIONDATE.toString() + "= " +
                  getProperty(XWPropertyDefs.ACTIVATIONDATE.toString()));

            if(act.compareTo("xtremweb.worker.CpuActivator") == 0) {
                if(XWOSes.getOs().isWin32())
                    act = new String("xtremweb.worker.WinSaverActivator");
                else if(XWOSes.getOs().isMacosx())
                    act = new String("xtremweb.worker.DateActivator");
                else
                    act = new String("xtremweb.worker.AlwaysActive");

                warn("xtremweb.worker.CpuActivator is not avaible;" +
                            " sorry for inconveniences");
            }

            /*
              try { 
              activator = Class.forName(act);
              } 
              catch(ClassNotFoundException e) {
              throw new Exception("Can't find activator class : " + act);
              }
            */
        }

        // Update coonfiuration
        //				restartCommand = getProperty("update.restartCommand");
    
        /*
         * Configuration of the notifier(trail icon under windows)
         */
     
        useNotify = getBoolean(XWPropertyDefs.SYSTRAY, 
                               Boolean.parseBoolean(XWPropertyDefs.SYSTRAY.value()));
        if(useNotify) {

            String iconFile = new String("xw.ico");
            try {
                extractResource("data/" + iconFile, iconFile);
            }
            catch(Exception e) {
                try {
                    extractResource("data/" + iconFile, iconFile);
                }
                catch(Exception e2) {
                    warn("can't extract resource " + iconFile);
                    useNotify = false;
                }
            }

            String icon = binCachedPath + File.separator + iconFile;
            XWNotify xwNotify = ArchDepFactory.xwnotify();
            xwNotify.updateNotify(icon, "XWHEP Worker");
        }

        workPoolSize = getInt(XWPropertyDefs.POOLSIZE, _host.getCpuNb());
        if(workPoolSize < 1)
            workPoolSize = 1;
    }


    public CommClient defaultCommClient() 
        //        throws ClassNotFoundException {
         throws ClassNotFoundException,
                InstantiationException,
                IllegalAccessException {

        CommClient.setConfig(this);
        CommClient ret = CommClient.getClient(Connection.XWSCHEME);
        return ret;
    }
    public CommClient getCommClient(URI uri) 
        //        throws ClassNotFoundException {
         throws ClassNotFoundException,
                InstantiationException,
                IllegalAccessException {

        CommClient.setConfig(this);
        CommClient ret = CommClient.getClient(uri);
        return ret;
    }
    /**
     * This extracts a ressource from JAR file
     * @param resName is the ressource name to extract
     * @param fileName is the file to extract ressource from
     */  
    void extractResource(String resName, String fileName) throws Exception{

//        debug("Extracting " + resName);
        InputStream ls = getClass().getClassLoader().getResourceAsStream(resName);

        if(ls == null) {
            throw new NullPointerException(resName + " not found");
        }

        byte[] buf = new byte[1024];
        FileOutputStream lf = new FileOutputStream(binCachedPath + File.separator + fileName );
        for(int n = ls.read(buf); n > 0; n = ls.read(buf)) {
            lf.write(buf, 0, n);
        }
        ls.close();
        lf.close();
//         debug(resName + " extracted to " + 
//                      binCachedPath + File.separator + fileName);
    }


    /**
     * This retreives the default temp dir
     */
    public File getTmpDir() {
        File d = new File(tmpDirBase, "XW." +
                          System.getProperty(XWPropertyDefs.USERNAME.toString()) + "." +
                          (String)dispatchers.elementAt(currentDispatcher));
        return d;       
    }

    /**
     * This retreives the default cache dir; it is created if necessary
     */
    public File getCacheDir() {

        String c = getTmpDir().getAbsolutePath() + ".cache";

        File d = new File(c);

        if(!d.exists())
            d.mkdirs();

        return d;
    }


    /**
     * This retreives the default works dir; it is created if necessary
     */
    public File getWorksDir() {
        File d = new File(getTmpDir(), "works");
        return d;
    }

    /** 
     * use <CODE>getProperty()</CODE> to get a port number 
     * and check it is valid  
     * @param name : key to retrieve the port number
     * @param defaultp : default value to return if <CODE>name</CODE> is not in the dictionary
     */     
    public int getPort(Connection port, int defaultp) {
        String s = getProperty(port.propertyName());

        if(s == null)
            return defaultp;

        try {   
            int p = Integer.parseInt(s);
            if(!(p > 0 && p < 1 << 15)) {
                util.fatal("Invalid port number (" + port + ") = " + s);
            }
            return p;
        }
        catch(NumberFormatException e) { 
            util.fatal("Invalid port number (" + port + ") = " + s);
        }
        return -1;
    }

    /** 
     * This retreives a key as an integer. It uses <CODE>getProperty()</CODE>.
     * and check it is valid  
     * @param name : key name to retrieve
     * @param defaulti : default value to return if <CODE>key</CODE> is not in the dictionary
     * @return the integer value of the key
     */     
    public long getLong(String name, long defaulti)  {
        String s = getProperty(name);
        if(s == null) return defaulti;
        try {
            return Long.parseLong(s);
        } catch(NumberFormatException e) { 
            warn("Invalid long number for property " + name + " (" + s + ") using default :"  + defaulti); 
        }
        return defaulti;
    }
    /** 
     * This retreives a key as an integer. It uses <CODE>getProperty()</CODE>.
     * and check it is valid  
     * @param key is the key to retrieve
     * @param defaulti : default value to return if <CODE>key</CODE> is not in the dictionary
     * @return the integer value of the key
     */     
    public int getInt(XWPropertyDefs key, int defaulti)  {
        String s = getProperty(key.toString());
        if(s == null) return defaulti;
        try {   
            return Integer.parseInt(s);
        } catch(NumberFormatException e) { 
            warn("Invalid int number for property " + key + " (" + s + ") using default :"  + defaulti); 
        }
        return defaulti;
    }

    /**
     * This retreives a key as a boolean. It uses <CODE>getProperty()</CODE>.
     * @param key : key name to retrieve
     * @param defaultb : default value to return if <CODE>key</CODE> is not in the dictionary
     * @return the boolean value of the key
     */
    public boolean getBoolean(XWPropertyDefs key, boolean defaultb) {
        String value = getProperty(key.toString());

        if(value == null) 
            return defaultb;

        Boolean ret = null;
        try {
            ret = new Boolean(value);
        }
        catch(Exception e) {
            warn("not a boolean : " + key + "=" + value + " set to default (" + defaultb + ")");
            ret = new Boolean(defaultb);
        }
        return ret.booleanValue();
    }
  
    /**
     * use <CODE>getProperty()</CODE> to get a path.
     * the path is made absolute if it is not
     *
     * @param key the key to retrieve the path
     * @param def default return value
     */
    protected String getPath(XWPropertyDefs key, String def) {
        String s = getProperty(key.toString());
        if(s == null) return def;
        File f = new File(s);
        return f.getAbsoluteFile().toString();
    }
   
    /**
     * Check whether another worker is already running 
     * @return false if an other worker with the same parameters is running
     */
    public boolean isAlone() throws IOException {
        File dir = getTmpDir();
        if(!dir.exists()) {
            dir.mkdir();
            return true;
        }

        if((!loadLibraries) || (getBoolean(XWPropertyDefs.INSTANCES, Boolean.parseBoolean(XWPropertyDefs.INSTANCES.value()))))
            return true;

        File pid = new File(dir, "pid");
        if(pid.exists()) {
            try {
                BufferedReader pidf = new BufferedReader(new FileReader(pid));
                String line = pidf.readLine();
                if(line != null) {
                    int i = Integer.parseInt(line);
                    if(i == ArchDepFactory.xwutil().getPid()) 
                        info("config file reload or update");
                    else if(ArchDepFactory.xwutil().isRunning(i)) return false;
                }
            } catch(NumberFormatException e) {
                warn("ignoring corrupted pid file : " + pid);
            }
            pid.delete(); 
        } 
        pid.createNewFile();
        PrintWriter pidf = new PrintWriter(new FileOutputStream(pid));
        pidf.println(Integer.toString(ArchDepFactory.xwutil().getPid()));
        pidf.close();
        return true;
    }

    /** 
     * This returns the server list
     * @return a Vector of known dispatchers
     * @since v1r2-rc1(RPC-V)
     */
    public Vector getDispatchers() {
        return dispatchers;
    }

    /** 
     * This returns the data server list
     * @return a Vector of known data servers
     * @since XWHEP 1.0.0
     */
    public Vector getDataServers() {
        return dataServers;
    }

    /** 
     * This retreives the current dispatcher
     * @return a String containing current server name
     * @since v1r2-rc1(RPC-V)
     */
    public String getCurrentDispatcher() {
        return(String)dispatchers.elementAt(currentDispatcher);
    }

    /** 
     * This retreives the current data server
     * @return a String containing current server name
     * @since v1r2-rc1(RPC-V)
     */
    public String getCurrentDataServer() {
        return(String)dataServers.elementAt(currentDataServer);
    }

    /** 
     * This determines the current dispatcher
     * @param srv is a String containing server name to make current one
     * @return an integer containing current server index;
     *         -1 if the server is not known
     * @since v1r2-rc1(RPC-V)
     */
    public synchronized int setCurrentDispatcher(String srv) 
        throws IOException {
        String hn = util.getHostName(srv);
        currentDispatcher = dispatchers.indexOf(hn);
        if(currentDispatcher == -1) {
            warn("Can't change current server to : " + hn);
        }
        //        debug("setCurrentDispatcher() : " + getCurrentDispatcher());
        notifyAll();
        return currentDispatcher;
    }

    /** 
     * This determines the current data server
     * @param srv is a String containing server name to make current one
     * @return an integer containing current server index;
     *         -1 if the server is not known
     * @since XWHEP 1.0.0
     */
    public synchronized int setCurrentDataServer(String srv)
        throws IOException {
        String hn = util.getHostName(srv);
        currentDataServer = dataServers.indexOf(hn);
        if(currentDataServer == -1) {
            warn("Can't change current server to : " + hn);
        }
        //        debug("setCurrentDataServer() : " + getCurrentDataServer());
        notifyAll();
        return currentDataServer;
    }

    /** 
     * This returns the next available server name
     * @return a String containing the next available server name
     * @since v1r2-rc1(RPC-V)
     */
    public String getNextDispatcher() {
        nextDispatcher();
        return(String)dispatchers.elementAt(currentDispatcher);
    }

    /** 
     * This increments the dispatcher
     * @since v1r2-rc1(RPC-V)
     */
    private synchronized void nextDispatcher() {
        currentDispatcher =(currentDispatcher + 1) % dispatchers.size();
        notifyAll();
    }

    /** 
     * This returns the next available dispatcher
     * @return a String containing the next available dispatcher
     * @since v1r2-rc1(RPC-V)
     */
    public String getNextDataServer() {
        nextDataServer();
        return(String)dataServers.elementAt(currentDataServer);
    }

    /** 
     * This increments the data server
     * @since XWHEP 1.0.0
     */
    private synchronized void nextDataServer() {
        currentDataServer =(currentDataServer + 1) % dataServers.size();
        notifyAll();
    }

    /** 
     * This adds a server to server list, if not already present
     * @param srv is a String containing a new server name
     * @return true if new server inserted, false if server name already known
     * @since XWHEP 1.0.0
     */
    public synchronized boolean addServer(Vector v, String srv)
        throws IOException {

        boolean ret = false;

        String hn = util.getHostName(srv);
        if(v.contains(srv) == false) {
            //            debug(srv + " inserted");
            v.add(hn);
            ret = true;
        }

        notifyAll();
        return ret;
    }

    /** 
     * This adds a server to server list, if not already present
     * @param srv is a String containing a new server name
     * @return true if new server inserted, false if server name already known
     * @since XWHEP 1.0.0
     */
    public boolean addDispatcher(String srv) throws IOException {
        return addServer(dispatchers, srv);
    }

    /** 
     * This adds a server to server list, if not already present
     * @param srv is a String containing a new server name
     * @return true if new server inserted, false if server name already known
     * @since XWHEP 1.0.0
     */
    public boolean addDataServer(String srv) throws IOException {
        return addServer(dataServers, srv);
    }

    /** 
     * This adds some server to list, if not already present
     * @param srv is a String array  containing new server names
     * @return true if at least one new server inserted, false otherwise
     * @since v1r2-rc1(RPC-V)
     */
    private boolean addServers(Vector v, String[] srv) throws IOException  {

        boolean ret = false;

        for(int i = 0; i < srv.length; i++) {
            debug("server " + srv[i] + " added");
            if(addServer(v, srv[i]))
                ret = true;
        }
        return ret;
    }

    /** 
     * This adds some dispatchers to dispatchers list, if not already present
     * @param srv is a String array  containing new server names
     * @return true if at least one new server inserted, false otherwise
     * @since v1r2-rc1(RPC-V)
     */
    public boolean addDispatchers(String[] srv) throws IOException {
        return addServers(dispatchers, srv);
    }

    /** 
     * This adds some data servers to list, if not already present
     * @param srv is a String array  containing new server names
     * @return true if at least one new server inserted, false otherwise
     * @since XWHEP 1.0.0
     */
    public boolean addDataServers(String[] srv) throws IOException {
        return addServers(dataServers, srv);
    }

    /** 
     * This print dispatchers to a string
     * @return a String containing server names in(tag:name) pair
     * @since v1r2-rc1(RPC-V)
     */
    protected synchronized String serversToString(Vector servers) {

        String ret = new String("");

        if(servers == null){
            notifyAll();
            return ret;
        }

        for(int i = 0; i < servers.size(); i++)
            ret = ret.concat(servers.elementAt(i) + " ");

        notifyAll();
        return ret;
    }
    /** 
     * This print dispatchers to a string
     * @return a String containing server names in(tag:name) pair
     * @since v1r2-rc1(RPC-V)
     */
    public String dispatchersToString() {

        return "" + XWPropertyDefs.DISPATCHERS.toString() + "=" +
            serversToString(dispatchers);
    }
    /** 
     * This print dispatchers to a string
     * @return a String containing server names in(tag:name) pair
     * @since v1r2-rc1(RPC-V)
     */
    public String dataServersToString() {

        return "" + XWPropertyDefs.DISPATCHERS.toString() + "=" +
            serversToString(dataServers);
    }
    /** 
     * This retreives a set of servers.
     * @since XWHEP 1.0.0
     */
    private Vector getServerNames(String property) {

        Vector ret = null;
        ret = util.split(getProperty(property));
        if(ret == null)
            return null;
        for(int i = 0; i < ret.size(); i++)
            try {
                ret.setElementAt(util.getHostName((String)ret.elementAt(i)), i);
            }
            catch(IOException e) {
                warn(e.toString());
            }
        return ret;
    }
    /** 
     * This determines dispatchers file
     * @since v1r2-rc1(RPC-V)
     */
    private synchronized File dispatchersFile() {
        File d = new File(tmpDirBase + "XW." + 
                          "known_dispatchers");
        return d;       
    }
   
    /** 
     * This determines dispatchers file
     * @since XWHEP 1.0.0
     */
    private synchronized File dataServersFile() {
        File d = new File(tmpDirBase + "XW." + 
                          "known_dataservers");
        return d;       
    }
   
    /** 
     * This writes server list to disk
     * @since XWHEP 1.0.0
     */
    private synchronized void saveServers(File server, String servers) {

        if(server.exists() )
            server.delete();

        try { 
            FileWriter fw = new FileWriter(server);
            fw.write(servers);
            fw.flush();
            fw.close();

        } catch(Exception e) {
            error("Exception: " + e);
        } 

    }
   
    /** 
     * This writes dispatcher list to disk
     * @since v1r2-rc1(RPC-V)
     */
    public void saveDispatchers() {
        saveServers(dispatchersFile(), dispatchersToString());
    }
   
    /** 
     * This writes dispatcher list to disk
     * @since XWHEP 1.0.0
     */
    public void saveDataServers() {
        saveServers(dataServersFile(), dataServersToString());
    }
   
    /** 
     * This read server list from disk
     * @since XWHEP 1.0.0
     */
    private void retreiveServers(Vector v, File file) {

        try { 
            BufferedReader bufferFile = new BufferedReader(new
                                                           FileReader(file));
            String l = bufferFile.readLine();
      
            Vector newSrv = util.split(l.substring(l.indexOf 
                                                   (new String("="))+1).trim());
            if(newSrv == null)
                return;

            String[] newSrvArray = new String[newSrv.size()];
            addServers(v, newSrvArray);

        }
        catch(Exception e) {
//            debug("retreiveSErver xception: " + e);
        } 
    }

    /** 
     * This read dispatcher list from disk
     * @since XWHEP 1.0.0
     */
    public void retreiveDispatchers() {
        retreiveServers(dispatchers, dispatchersFile());
    }

    /** 
     * This read data server list from disk
     * @since XWHEP 1.0.0
     */
    public void retreiveDataServers() {
        retreiveServers(dataServers, dataServersFile());
    }
    /**
     * This writes properites
     * This insert a header containing the storage date
     * @see #store(String)
     */
    public void store() {
        store("# XWHEP configuration file\n" + 
              "# XWHEP version : " + CommonVersion.getCurrent().full() + "\n" +
              "# Saved on " + new Date());
    }
    /**
     * This writes properites
     * @param header is written at the beginning to the file
     */
    public void store(String header) {
        store(header, configFile);
    }
    /**
     * This writes properites
     * @param header is written at the beginning to the file
     */
    public void store(String header, File out) {
        try {
            store(new FileOutputStream(out), header);
        }
        catch(Exception e) {
            error("Can't store config " + e);
        }
    }
    /**
     * This writes properties
     */
    public void dump(PrintStream out, String header) {
        if(header != null)
            out.println(header + " " + new java.util.Date().toString());

        out.println("Name             : " + util.getLocalHostName());
        out.println("Identity         : " + _user.getLogin());
        out.println("XWRole           : " + XWRole.myRole.toString());
        out.println("Started on       : " + upTime());
        out.println("Project          : " + 
                    getProperty(XWPropertyDefs.PROJECT.toString()));
        out.println("Server HTTP      : " + 
                    getProperty(XWPropertyDefs.SERVERHTTP.toString()));
        out.println("Alive            : " + 
                    getProperty(XWPropertyDefs.ALIVE.toString()));
        out.println("Alive time out   : " + 
                    getProperty(XWPropertyDefs.ALIVETIMEOUT.toString()));
        if(XWRole.isWorker()) {
            out.println("Activator        : " + 
                        getProperty(XWPropertyDefs.ACTIVATOR.toString()));
            out.println("workPool size    : " + workPoolSize);
            out.println("Noop Time out    : " + 
                        getProperty(XWPropertyDefs.NOOPTIMEOUT.toString()));
            out.println("Max jobs         : "  +
                        getProperty(XWPropertyDefs.COMPUTINGJOBS.toString()));
            out.println("Runtime.exec()   : " + 
                        getProperty(XWPropertyDefs.JAVARUNTIME.toString()));
            out.println("Multiple instances : " + 
                        getProperty(XWPropertyDefs.INSTANCES.toString()));
        }
        out.println("Polling time out         : " + 
                    Long.parseLong(getProperty(XWPropertyDefs.TIMEOUT.toString())));
        out.println("Optimize zip     : " + 
                    getBoolean(XWPropertyDefs.OPTIMIZEZIP, 
                               Boolean.parseBoolean(XWPropertyDefs.OPTIMIZEZIP.value())));
        out.println("Optimize network : " + 
                    getProperty(XWPropertyDefs.OPTIMIZENET.toString()));
        out.println("NIO              : " + 
                    getProperty(XWPropertyDefs.NIO.toString()));
        out.println("Comm layer       : " + 
                    getProperty(XWPropertyDefs.COMMLAYER.toString()));
        out.println("Socket time out  : " + 
                    getInt(XWPropertyDefs.SOTIMEOUT, 
                           Integer.parseInt(XWPropertyDefs.SOTIMEOUT.value())));
        out.println("Connection mode  : " + 
                    (getBoolean(XWPropertyDefs.CONNECTIONLESS, 
                                Boolean.parseBoolean(XWPropertyDefs.CONNECTIONLESS.value())) ?
                     "connectionless" : 
                     "connected"));
        out.println("TCP port   : " + 
                    getPort(Connection.TCP,
                            Connection.TCP.defaultPortValue()));
        out.println("UDP port   : " + 
                    getPort(Connection.UDP,
                            Connection.UDP.defaultPortValue()));
        if(XWRole.isWorker()) {
            out.println("HTPP worker port : " + 
                        getPort(Connection.HTTPWORKER,
                                Connection.HTTPWORKER.defaultPortValue()));
        }
        out.println("HTPP  port : " + 
                    getPort(Connection.HTTP,
                            Connection.HTTP.defaultPortValue()));
        out.println("HTPPS port : " + 
                    getPort(Connection.HTTPS,
                            Connection.HTTPS.defaultPortValue()));
        out.println("Sun RPC interposition port : " + 
                    getPort(Connection.SUNRPC,
                            Connection.SUNRPC.defaultPortValue()));
    }
}

