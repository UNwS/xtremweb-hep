/**
 * Project : XTremWeb
 * File    : TracerConfig.java
 *
 * Date   : March 2002
 * By     : Oleg Lodygensky
 * e-mail : lodygens /at\ .in2p3.fr
 */

package xtremweb.common;

public class TracerConfig
{
  public static final int LENGTH = 36;

  public short cpuNum;
  public short cpuSpeed;
  public int  memTotal;
  public int  swapTotal;
  public int  boottime;
  public byte kernel[];
  public int time;

}
