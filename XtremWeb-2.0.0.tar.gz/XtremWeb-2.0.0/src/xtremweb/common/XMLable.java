package xtremweb.common;


import java.util.Date;

import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.Serializable;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Created: Sept 15th, 2005<br />
 * This class implements XML un/marschalling
 *
 * @author Oleg Lodygensky
 * @since RPCXW-v5
 */

public abstract class XMLable extends Logger implements Serializable {

    /**
     * This contains the standard XML header (<?xml version='1.0' encoding='UTF-8'?>)
     */
    public static final String XMLHEADER = "<?xml version='1.0' encoding='UTF-8'?>";
    public static final String ROOTTAG = "xwhep";
    public static String rootTagOpen(String v) {
	return rootTag(false, v);
    }
    public static String rootTagClose() {
	return rootTag(true, null);
    }
    public static String rootTag(boolean close, String v) {
	if(close == false)
	    return "<" + ROOTTAG + " version='" + v + "'>";
	return "</" + ROOTTAG + ">";
    }

    /**
     * This is the XML tag name
     */
    protected String XMLTAG;

    /**
     * This tells whether to dump null value
     */
    protected boolean DUMPNULLS = false;

    /**
     * This is used in XML representation to describe null attributes
     */
    protected static final String NULLVALUE = new String("NULL");

    /**
     * This stores the attributes names
     */
    protected String[] columns;

    /**
     * This is the index of the first element
     * @see #columns
     */
    protected static final int FIRST_ATTRIBUTE = 0;
    /**
     * This is the index of the last element
     * @see #columns
     */
    protected int LAST_ATTRIBUTE;
    /**
     * This is the number of element
     * @see #columns
     */
    protected int MAX_ATTRIBUTE;

    /**
     * This default constructor does nothing
     */
    protected XMLable() {
        level = LoggerLevel.INFO;
    }
    /**
     * This constructor sets XMLTAG, LAST_ATTRIBUTE and MAX_ATTRIBUTE
     * @param tag is this object XML tag
     * @param last is this object LAST_ATTRIBUTE
     * @see XMLTAG
     * @see LAST_ATTRIBUTE
     * @see MAX_ATTRIBUTE
     */
    protected XMLable(String tag, int last) {
        this();
        XMLTAG = tag;
        LAST_ATTRIBUTE = last;
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;;
        columns = new String[MAX_ATTRIBUTE];
    }

    /**
     * This retreives this object String representation
     * @return this object String representation
     */
    public abstract String toString();

    /**
     * This returns columns
     * @see #columns
     */
    public String[] columns(){
        return columns;
    }

    /**
     * This retreives this object XML tag
     * @return  this object XML tag
     */
    public String xmlTag() {
        return XMLTAG;
    }

    /**
     * This retreives this object XML representation
     * @return this object XML representation
     */
    public abstract String toXml();
    /**
     * This retreives this object XML representation
     * @return this object XML representation
     */
    public abstract void toXml(DataOutputStream o) throws IOException;
    /**
     * This returns a string representation of this object,
     * in the form column='value',column='value',... in csv is false
     * or in the form 'value','value',... if csv is true
     * @param cvs tells whether CSV format is expected
     */
    public abstract String toString(boolean csv);
    /**
     * This reads this object definition from an XML stream
     * @param input is the input stream to get XML definition
     */
    public void fromXml(DataInputStream input) throws IOException {
        try {
            String dtd = null;
            SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
            DescriptionHandler handler = new DescriptionHandler(dtd);
            parser.parse(input, handler);
        }
        catch(ParserConfigurationException e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }
        catch(SAXException e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }
    }
    /**
     * This abstract method aims to retreive attributes from XML attributes
     * @param attrs contains attributes XML representation
     */
    public abstract void fromXml(Attributes attrs) throws IOException;

    /**
     * This method is called to decode XML elements<br />
     * This method is abstract and must be overriden
     * @see DescriptionHandler#startElement(String, String, String, Attributes)
     */
    public abstract void xmlElementStart(String uri, String tag, String qname, 
                                         Attributes attrs) throws IOException;
    /**
     * This does nothing.
     * @see xtremweb.common.XMLable.DescriptionHandler#endElement(String, String, String)
     */
    public void xmlElementStop(String uri, String tag, String qname)
        throws IOException {
        debug("     xmlElementStop()  qname=\"" + qname + "\"");
    }




    /*********************************************************************
     **
     ** This class extends the XML DefaultHandler
     **
     *********************************************************************/
    private class DescriptionHandler extends DefaultHandler {
        private String attribute = null;
        private String dtd;

        DescriptionHandler(String dtd) {
            this.dtd = dtd;
        }

        public void startDocument() {
            //debug("Document started...");
        }

        public void endDocument() {
            //debug("Document ended...");
        }

        /**
         * This method aims to decode XML elements
         */
        public void startElement(String uri, String tag, String qname, 
                                 Attributes attrs)
            throws SAXException {
            try {
                xmlElementStart(uri, tag, qname, attrs);
            }
            catch(IOException e) {
                throw new SAXException(e.toString());
            }
        }

        public void endElement(String uri, String tag, String qname)
            throws SAXException {

            try {
                xmlElementStop(uri, tag, qname);
            }
            catch(IOException e) {
                throw new SAXException(e.toString());
            }
        }

        public void characters(char[] ch, int start, int length)
            throws SAXException {

            String value = new String(ch, start, length);
            //debug(" *** Characters: " + value + ", start: " + start + ", length: " + length);
        }

    }

}
