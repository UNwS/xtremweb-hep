package xtremweb.common;

import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Date;
import java.io.PrintStream;
import java.text.DateFormat;


/**
 * LogStream.java
 * A logging utility
 *
 * Created: Mon Apr  2 16:00:42 2001
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version %I% %G%
 */

public class LogStream {

    private Hashtable modules= new Hashtable(5);
    private PrintStream pStream;
    private static boolean notimeStamp = ( System.getProperty("DebugNoTimeStamp") != null);

    public LogStream( PrintStream ps ){
        pStream = ps;
    }

    /**
     * set the boolean flag for a list of modules separated with a " "
     */
    public  void logStreamSetModuleFlag( String module, boolean
                                         flag) {
        for (StringTokenizer st = new StringTokenizer(module, " "); 
             st.hasMoreTokens();
             modules.put(st.nextToken(), new Boolean(flag)))
            {}
    }

    /** 
     * get the boolean debug flag for a module
     */
    public  boolean logStreamGetModuleFlag(String module) {
        Boolean ret = (Boolean) modules.get( module );
        if ( ret==null )
            return false;
        else 
            return ret.booleanValue();
    }

    /**
     * Print according to the module the message
     */
    public  void logStreamWrite( String module, String msg ) {
        if (logStreamGetModuleFlag(module) ) 
            if (notimeStamp)
                pStream.println(  module + ": " + msg);
            else {
                Date date = new Date();
                date.getTime();
                pStream.println( DateFormat.getInstance().format(date) + "\t" + module + ": " + msg);
            }
    }

}
