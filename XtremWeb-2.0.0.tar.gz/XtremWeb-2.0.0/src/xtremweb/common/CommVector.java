package xtremweb.common;

import java.util.Vector;
import java.util.Hashtable;

/**
 * CommVector.java
 * 
 * 
 *
 * Created: Thu Nov  2 17:33:55 2000
 *
 * @author Gilles Fedak
 * @version %I% %G%
 */

public class CommVector implements java.io.Serializable {

    /** 
     * This array contains the number of XtremWeb server adresses.
     * This is used for replication; this list is provided
     * to workers at connections time.
     * This parameter exists since XtremWeb, but is used only since RPC-V.
     * @since r1v2-rc1 (RPC-V)
     */
    public int nbServers;

    /** 
     * This array contains a set of XtremWeb server adresses.
     * This is used for replication; this list is provided
     * to workers at connections time.
     * This parameter exists since XtremWeb, but is used only since RPC-V.
     * @since r1v2-rc1 (RPC-V)
     */
    private String [] xwServers;    /** Names of the XtremWeb Server to contact*/

    private String [] commLayers;   /** Communication Layer (RMI) */
    private int       alivePeriod;  /** Time between Alive */ 
    private UID       workerUID;    /** Worker uid in server */

    /** 
     * This is the default constructor.
     */
    public CommVector() {
        nbServers = 0;
    }

    /** 
     * This constructor fill fields from the provided parameter
     * typically read from config file in server side
     * This is used for replication; this list is provided
     * to workers at connections time.
     * @param servers is a vector of XtremWeb server names
     * @since r1v2-rc1 (RPC-V)
     */
    public CommVector(Vector servers) {

        Object[] obj = (Object [])servers.toArray();

        nbServers = servers.size ();
        xwServers = new String [obj.length];
        for (int i = 0; i < obj.length; i++) {
            xwServers [i] = (String)obj [i];
        }
    }


    /** 
     * This constructor fill fields from the provided hashtable
     * typically returned from XMLRPC hostRegister() in worker side
     * This is used for replication; this list is provided
     * to workers at connections time.
     * @since v1r2-rc1 (RPC-V)
     */
    public CommVector(Hashtable result) {

        nbServers = ((Integer)result.get ("nbServers")).intValue (); 
        xwServers = new String [nbServers]; 
        commLayers = new String [nbServers];

        for( int i = 0; i < nbServers; i++) {
            xwServers[i] = (String)((Vector)result.get("xwServer")).elementAt(i);
            commLayers[i] = (String)((Vector)result.get("commLayer")).elementAt(i);
        }
        alivePeriod = ((Integer)result.get("alivePeriod")).intValue(); 
    }


    /** 
     * @since r1v2-rc1 (RPC-V)
     */
    public String toString () {
        String ret = new String ("nbServers = " + nbServers + "\n");

        if (xwServers != null) {
            for (int i = 0; i < nbServers; i++)
                if (xwServers [i] != null)
                    ret = ret.concat ("server" + i + " " + xwServers [i] + "\n");
                else
                    ret = ret.concat ("server["+i+"] is null\n");
        }
        else
            ret = ret.concat ("no server\n");

        if (commLayers != null) {
            for (int i = 0; i < nbServers; i++)
                if (commLayers [i] != null)
                    ret = ret.concat ("layer" + i + " " + commLayers [i] + "\n");
                else
                    ret = ret.concat ("layer["+i+"] is null\n");
        }
        else
            ret = ret.concat ("no layer\n");

        ret = ret.concat ("alivePeriod " +  alivePeriod + "\n");
        ret = ret.concat ("workerUID " +  workerUID + "\n");

        return ret;
    }


    public String[] getServers () {
        return xwServers;
    }

    public String[] getCommLayers () {
        return commLayers;
    }

    public int getAlivePeriod () {
        return alivePeriod;
    }

    public UID getWorkerUID () {
        return workerUID;
    }

    public void setServers (String[] s) {
        xwServers = s;
    }

    public void setCommLayers (String[] cl) {
        commLayers = cl;
    }

    public void setAlivePeriod (int to) {
        alivePeriod = to;
    }

    public void setWorkerUID (UID uid) {
        workerUID = uid;
    }

} // CommVector
