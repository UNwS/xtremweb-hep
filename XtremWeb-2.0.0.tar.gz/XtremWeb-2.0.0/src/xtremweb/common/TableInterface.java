package xtremweb.common;

import java.util.Vector;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.EOFException;
import java.security.AccessControlException;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * TableInterface.java
 *
 * Created: June 26th, 2003
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @since v1r2-rc3(RPC-V)
 */

/**
 * This abstract class describes the XtremWeb object root; 
 * every object in XtremWeb has a derived interface (WorkInterface, UserInterface etc)<br />
 * This defines objects as stored in database on server side.<br />
 * This is also used to transfert objects through the network.
 */
public abstract class TableInterface extends XMLable {

    /**
     * This is used in SQL statements
     * @see xtremweb.common.util#QUOTE
     */
    public static final String QUOTE= util.QUOTE;

    /**
     * This is the ISDELETED flag name
     */
    public static final String DELETEDFLAG = "isdeleted";

    /**
     * This is the table name
     */
    protected String name;
    /**
     * This is the primary key index in arrays columns and values<br />
     * Since RPCXW, this KEYINDEX is not the index of the  primary key as
     * defined in DB, but the index of the UID. Since RPCXW, UID is always
     * the first element in arrays columns and values.
     * @see XMLable#columns
     * @see #values
     */
    public final int KEYINDEX = 0;
    /**
     * This stores values<br />
     * The first element is used as the primary key
     */
    protected Object[] values;
    /**
     * This default constructor sets all attributes to null
     */
    public TableInterface() {
        super();
        columns = null;
        values  = null;
        name    = null;
        XMLTAG = null;
    }
    /**
     * This constructor sets the table name as provided
     * @param tableName is this table name
     * @see #TableInterface()
     */
    public TableInterface(String tableName) {
        this();
        name = tableName;
        if(name != null)
            XMLTAG = name;
    }
    /**
     * This sets the primary index
     * @param tableName is this table name
     * @param index is the primary index name
     * @see #TableInterface(String)
     * @see #setPrimaryIndex(Object)
     */
    public TableInterface(String tableName, Object index) {
        this();
        name = tableName;
    }
    /**
     * This writes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    public String toXml() {

        try {
            String ret = new String("<" + XMLTAG + " ");
            for(int i = FIRST_ATTRIBUTE; i < MAX_ATTRIBUTE; i++) {
                if(values[i] != null) {
                    ret += columns[i].toLowerCase() + "=\"";
                    if(values[i] instanceof java.util.Date)
                        ret += util.getSQLDateTime((java.util.Date)values[i]);
                    else
                        ret += values[i];
                    ret += "\" ";
                }
                else {
                    if(DUMPNULLS) {
                        ret += columns[i].toLowerCase() + "=\"" + NULLVALUE + "\" ";
                    }
                }
            }
            ret += " />";
            return ret;
        }
        catch(Exception e) {
        }
        return null;
    }
    /**
     * This writes this object XML representation to output stream
     * @param o is the output stream to write to
     */
    public void toXml(DataOutputStream o) throws IOException {

        String ret = new String("<" + XMLTAG + " ");
        for(int i = FIRST_ATTRIBUTE; i < MAX_ATTRIBUTE; i++) {
            if(values[i] != null) {
                ret += columns[i].toLowerCase() + "=\"";
                if(values[i] instanceof java.util.Date)
                    ret += util.getSQLDateTime((java.util.Date)values[i]);
                else
                    ret += values[i];
                ret += "\" ";
            }
            else {
                if(DUMPNULLS) {
                    ret += columns[i].toLowerCase() + "=\"" + NULLVALUE + "\" ";
                }
            }
        }
        ret += " />";

        o.writeUTF(ret);
    }
    /**
     * This writes this object to a String an HTML table
     * @return a String containing this object definition as HTML
     */
    public String toHtml() {

        try {
            String ret = new String("<table>");
            for(int i = FIRST_ATTRIBUTE; i < MAX_ATTRIBUTE; i++) {
                if(values[i] != null) {
                    ret += "<tr><td class='param''>" + columns[i].toLowerCase()
                        + "</td><td class='value'>";
                    if(values[i] instanceof java.util.Date)
                        ret += util.getSQLDateTime((java.util.Date)values[i]);
                    else
                        ret += values[i];
                    ret += "</td></tr>";
                }
            }
            ret += "</table>";
            return ret;
        }
        catch(Exception e) {
        }
        return null;
    }
    /**
     * This reterives attributes from XML representation<br />
     * @param attrs contains attributes XML representation
     * @throws IOException on XML error
     * @see #toXml()
     * @see #setValue(String, Object)
     */
    public void fromXml(Attributes attrs) throws IOException {

        if(attrs == null) {
            error("TableInterface#fromXml attrs is null");
            throw new IOException("attrs is null");
        }

        for(int a = 0; attrs != null && a < attrs.getLength(); a++) {
            String attribute = attrs.getQName(a);
            String value = attrs.getValue(a);

            debug("     attribute #" + a + 
                  ": name=\"" + attribute + "\"" +
                  ", value=\"" + value + "\"");

            if(value.compareToIgnoreCase(NULLVALUE) == 0) {
                value = null;
            }

            try {
                setValue(attribute, value);
            }
            catch(IllegalArgumentException e) {
                throw new IOException(getClass().getCanonicalName() + " : '" +
                                      attribute + "' is not a valid attribute");
            }
        }
    }
    /**
     * This is called by XML parser to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler#startElement(String, String, String, Attributes)
     */
    public void xmlElementStart(String uri, String tag, String qname, 
                                Attributes attrs)
        throws IOException {

        debug("     xmlElementStart() qname=\"" + qname + "\"");

        if(qname.compareToIgnoreCase(XMLTAG) == 0)
            fromXml(attrs);
        else
            throw new IOException("invalid qname : " + qname); 
    }
    /**
     * This calls toString(false)
     * @see #toString(boolean)
     */
    public String toString() {
        return toString(false);
    }
    /**
     * This returns a string representation of this object,
     * in the form column='value',column='value',... in csv is false
     * or in the form 'value','value',... if csv is true
     * @param cvs tells whether CSV format is expected
     */
    public String toString(boolean csv) {

        // use ' and not \" to be hsqldb compliant...
        try {
            String ret = new String();
            for(int i = FIRST_ATTRIBUTE; i < MAX_ATTRIBUTE; i++) {

                if(i != FIRST_ATTRIBUTE)
                    ret += ",";

                if(values[i] != null) {
                    if(values[i].getClass() == XWAccessRights.class)
                        if(csv)
                            ret += " " + values[i];
                        else
                            ret += " " + columns[i] + "=" + values[i];
                    else if(values[i].getClass() != java.util.Date.class)
                        if(csv)
                            ret += " " + QUOTE + values[i] + QUOTE;
                        else
                            ret += " " + columns[i] + "=" + QUOTE + values[i] + QUOTE;
                    else {
                        java.util.Date date =(java.util.Date)values[i];
                        if(csv)
                            ret += " " + QUOTE + util.getSQLDateTime(date) + QUOTE;
                        else
                            ret += " " + columns[i] + "=" + QUOTE + util.getSQLDateTime(date) + QUOTE;
                    }
                }
                else
                    if(!csv)
                        ret += " " + columns[i] + "=" + NULLVALUE;
                    else
                        ret += NULLVALUE;
            }
            return ret;
        }
        catch(Exception e) {
        }
        return null;
    }

    /**
     * This returns a vector representation of this object<br />
     * This is usefull for client GUI
     * @return a Vector representation, or an empty Vector on error
     * @see xtremweb.client.gui.TableModel#getRows()
     */
    public Vector toVector() {

        Vector ret = new Vector(MAX_ATTRIBUTE);

        try {

            for(int i = FIRST_ATTRIBUTE; i < MAX_ATTRIBUTE; i++) {
                if(values[i] != null)
                    ret.add(values[i]);
                else
                    ret.add(new String(""));
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return ret;
    }
    /**
     * This abstract method retreives this object UID
     * @return the UID of this object
     * @exception IOException is thrown if UID is not set
     */
    public abstract UID getUID() throws IOException;
    /**
     * This abstract method retreives the DELETED flag
     */
    public abstract boolean isDeleted();
    /**
     * This abstract method retreives the DELETED flag
     */
    public abstract boolean setDeleted(boolean d);
    /**
     * This returns a string representation of this columns object,
     * in the form column,column,... so that it can be used in SQL query
     */
    public String getColumns() {

        try {
            String ret = new String();
            for(int i = FIRST_ATTRIBUTE; i < MAX_ATTRIBUTE; i++) {
                if(i != FIRST_ATTRIBUTE)
                    ret += ",";
                ret += columns[i];
            }
            return ret;
        }
        catch(Exception e) {
        }
        return null;
    }
    /**
     * This returns values
     * @see #values
     */
    public Object[] values(){
        return values;
    }
    /**
     * This returns a string representation of this columns value object,
     * in the form value,value,... so that it can be used in SQL query
     */
    public String getValues() {

        // use ' and not \" to be hsqldb compliant...
        try {
            String ret = new String();
            for(int i = FIRST_ATTRIBUTE; i < MAX_ATTRIBUTE; i++) {

                if(i != FIRST_ATTRIBUTE)
                    ret += ",";

                if(values[i] != null) {
                    if(values[i].getClass() == XWAccessRights.class)
                        ret += values[i].toString();
                    else if(values[i].getClass() != java.util.Date.class)
                        ret += QUOTE + values[i] + QUOTE;
                    else {
                        java.util.Date date =(java.util.Date)values[i];
                        ret += QUOTE + util.getSQLDateTime(date) + QUOTE;
                    }
                }
                else
                    ret += "NULL";
            }
            return ret;
        }
        catch(Exception e) {
        }
        return null;
    }
    /**
     * This creates the needed SQL query string to select work
     * @exception IOException is thrown if primary key value is not set
     * @return a String containing the needed SQL query conditions
     */
    public String criterias() throws IOException {

        if(values[KEYINDEX] != null)
            return new String(columns[KEYINDEX] + "=" + QUOTE + values[KEYINDEX] + QUOTE);

        throw new IOException("primary key not set ???");

    }
    /**
     * @return true if value has changed, false otherwise
     */
    public abstract boolean setUID(UID v);
   /**
     * This sets parameter; this is called from fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see #fromXml(Attributes)
     */
    protected abstract boolean setValue(String attribute, Object v) 
        throws IllegalArgumentException;
    /**
     * This sets parameter
     * @param index is the index of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     */
    protected boolean setValue(int index, Object v) {

        if((index > LAST_ATTRIBUTE) ||(index < KEYINDEX)) {
            System.err.println("\n\n\nWe got a huuuge problem, folks");
            System.err.println("TableInterface#setValue() : invalid index " + index +
                               " ("+ FIRST_ATTRIBUTE + ", " + 
                               LAST_ATTRIBUTE + ")");
            System.exit(1);
        }

        boolean change = false;

        try {
            if(values[index] == null)
                change = (v != null);
            else
                if(v == null)
                    change = true;
                else
                    change = (values[index].equals(v) != true);

            if(change)
                values[index] = v;
        }
        catch(Exception e) {
            System.err.println("\n\n\nWe got a huuuge problem, folks");
            System.err.println("TableInterface#setValue() " + e);
            System.exit(1);
        }
        return change;
    }
    /**
     * This retreives a parameter
     * @param index is the attribute index to set 
     * @return the expected value
     */
    public Object getValue(int index){

        if((index > LAST_ATTRIBUTE) ||(index < FIRST_ATTRIBUTE)) {
            System.err.println("\n\n\nWe got a huuuge problem, folks");
            System.err.println("TableInterface#getValue() : invalid index " + index +
                               " ("+ FIRST_ATTRIBUTE + ", " + 
                               LAST_ATTRIBUTE + ")");
            System.exit(1);
        }
        try {
            return values[index];
        }
        catch(Exception e) {
            System.err.println("\n\n\nWe got a huuuge problem, folks");
            System.err.println("TableInterface#getValue() " + e);
            System.exit(1);
        }
        return null;
    }
    /**
     * This tests user access rights
     * @param owner is the UID of the owner
     * @param user is the UID of the user to check right for
     * @param rights is the rights to test
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean checkUserRights(UID owner, UID user, XWAccessRights rights)
        throws AccessControlException, IOException {

//         System.out.println("TableInterface#checkUserRights(" + 
//                            owner + "," + user + "," + rights + ")");

        if((user == null) || (owner == null)) {
//            System.out.println("TableInterface#checkUserRights() user or owner is null");
            return false;
        }
        if(owner.equals(user)) {
//             System.out.println("TableInterface#checkUserRights() : owner equals user " + 
//                                getAccessRights() + " & " + rights +
//                                " & " + XWAccessRights.USERALL + " = " +
//                                ((getAccessRights().value() & rights.value() &
//                                  XWAccessRights.USERALL.value()) != 0));
            return ((getAccessRights().value() &
                     rights.value() & 
                     XWAccessRights.USERALL.value()) != 0);
        }
//         System.out.println("TableInterface#checkUserRights() user and owner differ : returns false");
        return false;
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @param rights is the rights to test
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean checkGroupRights(UID ownerGroup,
                                    UID userGroup, 
                                    XWAccessRights rights)
        throws AccessControlException, IOException {

//         System.out.println("TableInterface#checkGroupRights(" + 
//                            ownerGroup + "," + userGroup + "," + rights + ")");

        if(ownerGroup != null) {
            if((userGroup == null) || (ownerGroup.equals(userGroup) == false)) {
//                 System.out.println("TableInterface#checkGroupRights() : returns false"); 
                return false;
            }
        }
//         System.out.println("TableInterface#checkGroupRights() : " + 
//                            getAccessRights() + " & " + rights +
//                            " & " + XWAccessRights.GROUPALL + " = " +
//                            ((getAccessRights().value() & rights.value() &
//                              XWAccessRights.GROUPALL.value()) != 0));
        return ((getAccessRights().value() &
                 rights.value() & 
                 XWAccessRights.GROUPALL.value()) != 0);
    }
    /**
     * This tests others access rights
     * @param rights is the rights to test
     * @return true if others have access rights
     */
    public boolean checkOthersRights(XWAccessRights rights)
        throws AccessControlException, IOException {
//         System.out.println("TableInterface#checkOtherRights(" + rights + ")");

//         System.out.println("TableInterface#checkOtherRights() : " + 
//                            getAccessRights() + " & " + rights +
//                            " & " + XWAccessRights.OTHERALL + " = " +
//                            ((getAccessRights().value() & rights.value() &
//                              XWAccessRights.OTHERALL.value()) != 0));

        return ((getAccessRights().value() & 
                 rights.value() & 
                 XWAccessRights.OTHERALL.value()) != 0);
    }
    /**
     * This should retreive this access rights; this should be overriden
     * @return always XWAccessRights.NONE
     */
    public XWAccessRights getAccessRights() {
        return XWAccessRights.NONE;
    }
    /**
     * This should test access rights ; this should be overriden
     * @param user is the UId of the user who try to access
     * @param ownerGroup is the UID of the owner group
     * @param userGroup is the UID of the group of the user who try to access
     * @return always false
     */
    public final boolean checkAccessRights(UID user, UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkUserAccessRights(user) || 
            checkGroupAccessRights(ownerGroup, userGroup) ||
            checkOtherAccessRights();
    }
    /**
     * This should test access rights ; this should be overriden
     * @param user is the UID of the user who try to access
     * @return always false
     */
    public boolean checkUserAccessRights(UID user)
        throws AccessControlException, IOException {
        return false;
    }
    /**
     * This should test access rights ; this should be overriden
     * @param group is the group of the user who try to access
     * @return always false
     */
    public boolean checkGroupAccessRights(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return false;
    }
    /**
     * This should test access rights ; this should be overriden
     * @return always false
     */
    public boolean checkOtherAccessRights()
        throws AccessControlException, IOException {
        return false;
    }

    /**
     * This should test access rights ; this should be overriden
     * @param user is the user who try to read
     * @param group is the group of the user who try to read
     * @return always false
     */
    public final boolean canRead(UID user, UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return userCanRead(user) || 
            groupCanRead(ownerGroup, userGroup) ||
            otherCanRead();
    }
    /**
     * This should test access rights ; this should be overriden
     * @param user is the user who try to read
     * @param group is the group of the user who try to read
     * @return always false
     */
    public boolean userCanRead(UID user)
        throws AccessControlException, IOException {
        return false;
    }
    /**
     * This should test access rights ; this should be overriden
     * @param user is the user who try to read
     * @param group is the group of the user who try to read
     * @return always false
     */
    public boolean groupCanRead(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return false;
    }
    /**
     * This should test access rights ; this should be overriden
     * @return always false
     */
    public boolean otherCanRead()
        throws AccessControlException, IOException {
        return false;
    }

    /**
     * This should test access rights ; this should be overriden
     * @param user is the user who try to write
     * @param group is the group of the user who try to write
     * @return always false
     */
    public final boolean canWrite(UID user, UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return userCanWrite(user) || 
            groupCanWrite(ownerGroup, userGroup) ||
            otherCanWrite();
    }
    /**
     * This should test access rights ; this should be overriden
     * @param user is the user who try to write
     * @param group is the group of the user who try to write
     * @return always false
     */
    public boolean userCanWrite(UID user)
        throws AccessControlException, IOException {
        return false;
    }
    /**
     * This should test access rights ; this should be overriden
     * @param user is the user who try to write
     * @param group is the group of the user who try to write
     * @return always false
     */
    public boolean groupCanWrite(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return false;
    }
    /**
     * This should test access rights ; this should be overriden
     * @return always false
     */
    public boolean otherCanWrite()
        throws AccessControlException, IOException {
        return false;
    }
    /**
     * This should test access rights ; this should be overriden
     * @param user is the user who try to exec
     * @param group is the group of the user who try to exec
     * @return always false
     */
    public final boolean canExec(UID user, UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return userCanExec(user) || 
            groupCanExec(ownerGroup, userGroup) ||
            otherCanExec();
    }
    /**
     * This should test access rights ; this should be overriden
     * @param user is the user who try to exec
     * @param group is the group of the user who try to exec
     * @return always false
     */
    public boolean userCanExec(UID user)
        throws AccessControlException, IOException {
        return false;
    }
    /**
     * This should test access rights ; this should be overriden
     * @param user is the user who try to exec
     * @param group is the group of the user who try to exec
     * @return always false
     */
    public boolean groupCanExec(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return false;
    }
    /**
     * This should test access rights ; this should be overriden
     * @return always false
     */
    public boolean otherCanExec()
        throws AccessControlException, IOException {
        return false;
    }

    /**
     * This constructs a new XMLRPCCommand object
     * @param io is stream handler to read XML representation from
     */
    public static TableInterface newInterface(StreamIO io) 
        throws IOException {

        return newInterface(io.readXmlString());
    }
    /**
     * This constructs a new XMLRPCCommand object.
     * This first checks the opening tag and then instanciate the right object
     * accordingly to the opening tag.
     * @param xmlString is a String containing a full XML representation
     */
    public static TableInterface newInterface(String xmlString)
        throws IOException {

        if((xmlString == null) || (xmlString.length() < 1))
            throw new IOException("xmlString is null");

        int xmlHeaderIdx = 0;

        //System.out.println("TableInterface#newInterface " + xmlString);

        if(xmlString.startsWith(XMLable.XMLHEADER) == true)
            xmlHeaderIdx = XMLable.XMLHEADER.length();

        //System.out.println("TableInterface#newInterface xmlHeaderIdx " + xmlHeaderIdx);

        TableInterface ret = null;

        int spcIdx = xmlString.indexOf(' ', xmlHeaderIdx);
        //System.out.println("TableInterface#newInterface spcIdx " + spcIdx);
        int closeIdx = xmlString.indexOf('>', xmlHeaderIdx);
        //System.out.println("TableInterface#newInterface closeIdx " + closeIdx);
        int openIdx = xmlString.indexOf('<', xmlHeaderIdx);
        //System.out.println("TableInterface#newInterface openIdx " + openIdx);
        String xmltag = xmlString.substring(openIdx + 1, Math.min(spcIdx, closeIdx));
        //System.out.println("TableInterface#newInterface xmlTag " + xmltag);
        XWTag tag = XWTag.valueOf(xmltag.toUpperCase());
        //System.out.println("TableInterface#newInterface tag " + tag);

        DataInputStream inputStream = new DataInputStream(new ByteArrayInputStream(xmlString.getBytes()));

        switch(tag) {
        case APP :
            ret = new AppInterface(inputStream);
            break;
        case DATA :
            ret = new DataInterface(inputStream);
            break;
        case GROUP :
            ret = new GroupInterface(inputStream);
            break;
        case HOST :
            ret = new HostInterface(inputStream);
            break;
        case JOB :
            ret = new JobInterface(inputStream);
            break;
        case SESSION :
            ret = new SessionInterface(inputStream);
            break;
        case TASK :
            ret = new TaskInterface(inputStream);
            break;
        case TRACE :
            ret = new TraceInterface(inputStream);
            break;
        case USERGROUP :
            ret = new UserGroupInterface(inputStream);
            break;
        case USER :
            ret = new UserInterface(inputStream);
            break;
        case WORK :
            ret = new WorkInterface(inputStream);
            break;
        default :
            throw new IOException("unknown tag : " + tag);
        }

        return ret;
    }
    /**
     * This constructs a new XMLRPCCommand object.
     * This first checks the opening tag and then instanciate the right object
     * accordingly to the opening tag.
     * @param xmlString is a String containing a full XML representation
     */
    public static TableInterface newInterface(String uri, String xmltag, String qname, 
                                              Attributes attrs)
        throws IOException {

        TableInterface ret = null;
        XWTag tag = XWTag.valueOf(qname.toUpperCase());

        switch(tag) {
        case APP :
            ret = new AppInterface(attrs);
            break;
        case DATA :
            ret = new DataInterface(attrs);
            break;
        case GROUP :
            ret = new GroupInterface(attrs);
            break;
        case HOST :
            ret = new HostInterface(attrs);
            break;
        case JOB :
            ret = new JobInterface(attrs);
            break;
        case SESSION :
            ret = new SessionInterface(attrs);
            break;
        case TASK :
            ret = new TaskInterface(attrs);
            break;
        case TRACE :
            ret = new TraceInterface(attrs);
            break;
        case USERGROUP :
            ret = new UserGroupInterface(attrs);
            break;
        case USER :
            ret = new UserInterface(attrs);
            break;
        case WORK :
            ret = new WorkInterface(attrs);
            break;
        default :
            throw new IOException("unknown tag : " + tag);
        }

        return ret;
    }

    /**
     * This is for testing only.<br />
     * This creates a XMLRPCCommand from given XML String representation 
     * of any XMLRPCCommand descendant<br />
     * argv[0] must contain an XML representation.<br />
     * The object is finally dumped
     */
    public static void main(String[] argv) {
        try {
            TableInterface itf = TableInterface.newInterface(argv[0]);
            if(itf.getUID() == null)
                itf.setUID(UID.myUid);
            System.out.println(itf.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
