/**
 * Date : March 13th, 2007<br />
 * @author Oleg Lodygensky (lodygens a t lal.in2p3.fr)
 *
 * This defines properties than can be read from config files.
 * @since 2.0.0
 */

package xtremweb.common;


public enum XWPropertyDefs {

    //
    // All : config file name
    // Property name : "xtremweb.config"
    // Property type : string
    // Default value : null
    //
    CONFIGFILE,
	//
	// All : config file name
	// Property name : "logger.level"
	// Property type : string
	// Default value : WARN
	//
	LOGGERLEVEL,
	//
	// Worker : the worker uid, if any
	// Property name : "uid"
	// Property type : string
	// Default value : null
	//
	UID,
	//
	// All : system user directory
	// Property name : "user.home"
	// Property type : string
	// Default value : null
	//
	USERHOME,
	//
	// All : launcher URL where to find XtremWeb binary
	// Property name : "launcher.url"
	// Property type : string
	// Default value : null
	//
	LAUNCHERURL,
	//
	// All : this defines this process role
	// Property name : "xtremweb.role"
	// Property type : string
	// Default value : null
	//
	ROLE,
	//
	// Worker : several workers on a single host ?
	// Property name : "xtremweb.alone"
	// Property type : boolean
	// Default value : true
	// @see #INSTANCES
	//
	ALONE,
	//
	// Worker & Client : login
	// Property name : "login"
	// Property type : string
	// Default value : null
	//
	LOGIN,
	//
	// Worker & Client : password
	// Property name : "password"
	// Property type : string
	// Default value : null
	//
	PASSWORD,
	//
	// Project : this is the project the worker wants to help
	// In practice, this is a user group
	// Property name : "project"
	// Property type : string
	// Default value : null
	//
	PROJECT,
	//
	// All : temp directory
	// Property name : "path.tmpdir"
	// Property type : string
	// Default value : java.io.tmp
	//
	TMPDIR,
	//
	// All : system temp directory
	// Property name : "java.io.tmpdir"
	// Property type : string
	// Default value : java.io.tmp
	//
	JAVATMPDIR,
	//
	// Worker : how many worker instance per host (default is 1)
	// Property name : "multipleInstances"
	// Property type : boolean
	// Default value : false
	// @see #ALONE
	//
	INSTANCES,
	//
	// All : socket timeout
	// Property name : "sotimeout"
	// Property type : long integer
	// Default value : 800 ms
	// This is in milliseconds
	// @since RPCXW
	// @see #OPTIMIZENET
	//
	//
	SOTIMEOUT,
	//
	// All : delay between actions
	// Worker : delay between two work   request
	// Client : delay between two result request
	// Server : delay between two database polling
	// Property name : "timeout"
	// Property type : integer
	// Default value : 15000
	// This is in milliseconds
	//
	TIMEOUT,
	//
	// Worker : how long to wait when there is no job to compute ?
	// If the worker receive no job within this delay, it shuts down
	// This is especially helpfull when deploying workers on a cluster;
	// this ensures we don't lock CPU for nothing.
	// Property name : "noopTimeout"
	// Property type : integer
	// Default value : -1 
	//
	NOOPTIMEOUT,
	//
	// All : optimize file transfert ?
	// If set to true we don't waste time to zip small files
	// Property name : "optimizeZip"
	// Property type : boolean
	// Default value : true
	//
	OPTIMIZEZIP,
	//
	// All : optimize network ?
	// Property name : "optimizeNetwork"
	// Property type : boolean
	// Default value : true
	// @see #SOTIMEOUT
	//
	OPTIMIZENET,
	//
	// All : optimize disk ?
	// Property name : "optimizeDisk"
	// Property type : boolean
	// Default value : true
	//
	OPTIMIZEDISK,
	//#
	// All : connection mode
	// Property name : "connectionLess"
	// Property type : boolean
	// Default value : true
	//
	CONNECTIONLESS,
	//
	// Worker : how many jobs to compute before shutting down
	// Property name : "computing.jobs"
	// Property type : integer
	//
	COMPUTINGJOBS,
	//
	// All : home directory
	// Property name : "HomeDir"
	// Property type : string
	//
	HOMEDIR,
	//
	// Dispatcher : database vendor
	// Property name : "XWdbVendor"
	// Property type : string
	// @see #DB_FIRST
	//
	DBVENDOR,
	//
	// Dispatcher : database name
	// Property name : "XWdbName"
	// Property type : string
	//
	DBNAME,
	//
	// Dispatcher : database server
	// Property name : "XWdbHost"
	// Property type : string
	//
	DBHOST,
	//
	// Dispatcher : database user
	// Property name : "XWdbUser"
	// Property type : string
	//
	DBUSER,
	//
	// Dispatcher : database password
	// Property name : "XWdbPass"
	// Property type : string
	//
	DBPASS,
	//
	// All : class to milestone
	// Property name : "mileStones"
	// Property type : string
	// @see xtremweb.common#MileStone
	//
	MILESTONES,
	//
	// Dispatcher : comma separated list of services to manage
	// Property name : "xtremweb.services"
	// Property type : string
	//
	SERVICES,
	//
	// Dispatcher : scheduler class name (not used yet)
	// Property name : "scheduler.Name"
	// Property type : string
	//
	SCHEDULERNAME,
	//
	// All : comma separated list of known dispatchers (used for replication)
	// Property name : "dispatcher.servers"
	// Property type : string
	//
	DISPATCHERS,
	//
	// All : comma separated list of known data servers (used for replication)
	// Property name : "data.servers"
	// Property type : string
	//
	DATASERVERS,
	//
	// All : comma separated list of trusted adresses allowed to connect
	// Property name : "setTrusted"
	// Property type : string
	//
	TRUSTED,
	//
	// Dispatcher : alive period.
	// This is automatically forwarded to workers
	// Property name : "alive.period"
	// Property type : long integer
	//
	ALIVE,
	//
	// Dispatcher : alive timeout.
	// This is automatically calculated
	// Property name : "alive.timeout"
	// Property type : long integer
	//
	ALIVETIMEOUT,
	//
	// All : SSL key directory
	// Property name : "XWkeyStore"
	// Property type : string
	//
	KEYSTORE,
	//
	// All : SSL pass phrase
	// Property name : "XWpassPhrase"
	// Property type : string
	//
	PASSPHRASE,
	//
	// All : cache directory
	// Property name : "xtremweb.cache"
	// Property type : string
	//
	CACHEDIR,
	//
	// All : default communication layer
	// Property name : "commLayer"
	// Property type : string
	// default       : HTTPClient
	//
	COMMLAYER,
	//
	// All : comma separated list of colon separated tuples of scheme/handler
	// Property name : "commHandlers"
	// Property type : string
	// Example       : xw:xtremweb.communications.TCPClient,http:org.apache.commons.httpclient.HttpClient
	//
	COMMHANDLERS,
	//
	// Worker : use java runtime or src/exec/Executor ?
	// Property name : "javaRuntime"
	// Property type : boolean
	// Default value : false
	//
	JAVARUNTIME,
	//
	// Worker : accept binary ?
	// Property name : "acceptBin"
	// Property type : boolean
	// DEFAULT value : true
	//
	ACCEPTBIN,
	//
	// Worker : use sandbox ?
	// Property name : "sandbox.enable"
	// Property type : boolean
	// Default value : false
	//
	SANDBOX,
	//
	// Worker : use embedded sandbox ?
	// Property name : "sandbox.embedded"
	// Property type : boolean
	// Default value : false
	//
	SANDBOXEMBEDDED,
	//
	// Worker : sandbox path
	// Property name : "sandbox.location"
	// Property type : string
	//
	SANDBOXPATH,
	//
	// Worker : sandbox name
	// Property name : "sandbox.name"
	// Property type : string
	//
	SANDBOXNAME,
	//
	// Worker : sandbox arguments
	// Property name : "sandbox.args"
	// Property type : string
	//
	SANDBOXARGS,
	//
	// Worker : collect host traces ?
	// Property name : "tracer.enable"
	// Property type : boolean
	// Default value : false
	//
	TRACES,
	//
	// Worker : activator call name
	// Property name : "activator.class"
	// Property type : string
	// @see xtremweb.worker#Activator
	//
	ACTIVATOR,
	//
	// Worker : activator polling delay in minutes
	// Property name : "activator.poll.delay"
	// Property type : integer
	// @see xtremweb.worker#Activator
	//
	ACTIVATORDELAY,
	//
	// Worker : activation date
	// Property name : "activator.date"
	// Property type : string
	// @see xtremweb.worker#DateActivator
	//
	ACTIVATIONDATE,
	//
	// Worker : activation date
	// Property name : "activator.date"
	// Property type : string
	// @see xtremweb.worker#DateActivator
	//
	TCPACTIVATORFEEDBACK,
	//
	// Worker : display sys tray icon ? (win32 only)
	// Property name : "tracer.enable"
	// Property type : boolean
	// Property values : "true" | "false"
	//
	SYSTRAY,
	//
	// Worker : how many simultaneous jobs ?
	// Property name : "workpool.size"
	// Property type : integer
	//
	POOLSIZE,
	//
	// Worker : cpuLoad used with CpuActivator
	// Property name : "cpuLoad"
	// Property type : int
	// @see xtremweb.worker#CpuActivator
	//
	CPULOAD,
	//
	// All : system user login
	// Property name : "user.name"
	// Property type : string
	//
	USERNAME,
	//
	// All: use nio
	// Property name : "java.nio"
	// Property type : boolean
	// Default : true
	//
	NIO,
	//
	// Worker, server : start http server
	// Property name : "server.http"
	// Property type : boolean
	// Default : true
	//
	SERVERHTTP,
	//
	// Worker, server : incoming communications ACL
	// Property name : "server.comm.acl"
	// Property type : reg exp
	// Default : "localhost"
	//
	SERVERCOMMACL,
	//
	// Worker, server : incoming communications for server status ACL
	// Property name : "server.stat.acl"
	// Property type : reg exp
	// Default : "localhost"
	//
	SERVERSTATACL;


    /**
     * This array defines property names for config file.<br />
     * This is indexed by defined constants above.
     */
    private static final String[] labels = {
        "xtremweb.config",
        "logger.level",
        "uid",
        "user.home",
        "launcher.url",
        "xtremweb.role",
        "xtremweb.alone",
        "login",
        "password",
        "project",
        "path.tmpdir",
        "java.io.tmpdir",
        "multipleInstances",
        "sotimeout",
        "timeout",
        "noopTimeout",
        "optimizeZip",
        "optimizeNetwork",
        "optimizeDisk",
        "connectionLess",
        "computing.jobs",
        "HomeDir",
        "XWdbVendor",
        "XWdbName",
        "XWdbHost",
        "XWdbUser",
        "XWdbPass",
        "mileStones",
        "xtremweb.services",
        "scheduler.Name",
        "dispatcher.servers",
        "data.servers",
        "setTrusted",
        "alive.period",
        "alive.timeout",
        "XWkeyStore",
        "XWpassPhrase",
        "xtremweb.cache",
        "commLayer",
        "commHandlers",
        "javaRuntime",
        "acceptBin",
        "sandbox.enable",
        "sandbox.embedded",
        "sandbox.location",
        "sandbox.name",
        "sandbox.args",
        "tracer.enable",
        "activator.class",
        "activator.poll.delay",
        "activator.date",
        "activator.tcp.feedback",
        "notify.enable",
        "workpool.size",
        "cpuLoad",
        "user.name",
        "java.nio",
        "server.http",
        "server.comm.acl",
        "server.stat.acl"
    };


    /**
     * This array defines property default values<br />
     * This is indexed by defined constants above.
     */
    private static final String[] defaults = {
        null, // XWCONFIG
        "WARN", // LOGGERLEVEL
        null, // UID
        null, // USERHOME
        null, // LAUNCHERURL
        null, // ROLE
        "true", // ALONE
        null, // LOGIN
        null, // PASSWORD
        null, // PROJECT
        System.getProperty(JAVATMPDIR.toString()), // TMPDIR
        System.getProperty(JAVATMPDIR.toString()), // JAVATMPDIR
        "false", // INSTANCES
        "800", // SOTIMEOUT
        "15000", // TIMEOUT
        "-1", // NOOPTIMEOUT
        "true", // OPTIMIZEZIP
        "true", // OPTIMIZENET
        "true", // OPTIMIZEDISK
        "true", // CONNECTIONLESS
        "-1", // COMPUTINGJOBS
        System.getProperty("user.home"), // HOMEDIR
        XWDBs.DEFAULT.toString(), // DBVENDOR
        null, // DBNAME
        null, // DBHOST
        null, // DBUSER
        null, // DBPASS
        null, // MILESTONE
        null, // SERVICES
        null, // SCHEDULERNAME
        null, // DISPATCHERS
        null, // DATASERVERS
        null,// TRUSTED
        "300", // ALIVE : 5 mn = 300 sec
        "900", // ALIVETIMEOUT : 3 * ALIVE
        null, // KEYSTORE
        null, // PASSPHRASE
        System.getProperty(JAVATMPDIR.toString()), // CACHEDIR
        "xtremweb.communications.TCPClient", // COMMLAYER
        null, // COMMHANDLERS
        "false", // JAVARUNTIME
        "true", // ACCEPTBIN
        "false", // SANDBOX
        "false", // SANDBOXEMBEDDED
        null, // SANDBOXPATH
        null, // SANDBOXNAME
        null, // SANDBOXARGS
        "false", // TRACES
        "xtremweb.worker.AlwaysActive", // ACTIVATOR
        "1", // ACTIVATORDELAY
        null, // ACTIVATIONDATE
        "false", // TCPACTIVATORFEEDBACK
        "false", // SYSTRAY
        "1", // POOLSIZE
        "30", // CPULOAD
        null, // USERNAME
        "true", // NIO
        "true", // SERVERHTTP
        "localhost", // SERVERCOMMACL
        "localhost" // SERVERSTATACL
    };
    /** 
     * This converts this enum to a String.
     * @return a string containing boolean value
     */
    public String toString() {
        return labels[this.ordinal()];
    }
    /** 
     * This retreives enum from a String.
     * @param s is the enum to retreive
     * @return the retreived enum
     */
    public static XWPropertyDefs fromString (String s)
	throws ArrayIndexOutOfBoundsException {

        for (XWPropertyDefs p : XWPropertyDefs.values())
            if (s.compareToIgnoreCase(labels[p.ordinal()]) == 0)
                return p;

        throw new ArrayIndexOutOfBoundsException ("unknown property : " + s);
    }
    /** 
     * This converts database vendor to a String.
     * @param s is the value to convert
     * @return a string containing boolean value
     */
    public String value() {
        return defaults[this.ordinal()];
    }


    /**
     * This dumps enums to stdout
     */
    public static void main(String[] argv) {
        for (XWPropertyDefs p : XWPropertyDefs.values())
            System.out.println(p.toString() + " : " + p.value());
    }
}
