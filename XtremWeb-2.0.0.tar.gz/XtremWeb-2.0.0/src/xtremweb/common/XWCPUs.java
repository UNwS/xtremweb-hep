package xtremweb.common;

import xtremweb.common.CommandLineParser;

import java.io.IOException;

/**
 * XWCPUs.java<br />
 *
 * This defines XtremWeb compatible CPUs<br />
 *
 * Created: 29 janvier 2007
 * @since 1.9.0
 *
 * @author <a href="mailto: lodygens  *a**t* lal.in2p3.fr">Oleg Lodygensky</a>
 * @version %I% %G%
 */

public enum XWCPUs {

    NONE,
    IX86,
    PPC,
    SPARC,
    ALPHA,
    AMD64;

    public static final XWCPUs LAST = AMD64;
    public static final int SIZE = LAST.ordinal() + 1;

    public static XWCPUs fromInt(int v) throws IllegalArgumentException {
        for (XWCPUs i : XWCPUs.values()) {
            if(i.ordinal() == v)
                return i;
        }
        throw new IllegalArgumentException("unvalid XWCPUs value " + v);
    }
    /** 
     * Get Hardware name
     * If this architecture is not supported by XtremWeb, this forces the program to immediatly stop
     * @see #getArchName(String)
     */
    public static String getCpuName() {
        try {
            return getCpuName(System.getProperty("os.arch"));
        }
        catch(Exception e) {
            util.fatal(e.toString());
        }
        return null;
    }


    /** 
     * This forces architecture name to predefined values to avoid confusion
     * @param archName the architecture name
     * @exception ClassNotFound exception is thrown if archName is not supported by XtremWeb
     */
    public static String getCpuName(String archName) 
	throws IllegalArgumentException {

        if((archName.compareToIgnoreCase("i86")   == 0) ||
           (archName.compareToIgnoreCase("x86")   == 0) ||
           (archName.compareToIgnoreCase("ix86")  == 0) ||
           (archName.compareToIgnoreCase("i386")  == 0) ||
           (archName.compareToIgnoreCase("x386")  == 0) ||
           (archName.compareToIgnoreCase("ix386") == 0) ||
           (archName.compareToIgnoreCase("i486")  == 0) ||
           (archName.compareToIgnoreCase("x486")  == 0) ||
           (archName.compareToIgnoreCase("ix486") == 0) ||
           (archName.compareToIgnoreCase("i586")  == 0) ||
           (archName.compareToIgnoreCase("x586")  == 0) ||
           (archName.compareToIgnoreCase("ix586") == 0) ||
           (archName.compareToIgnoreCase("i686")  == 0) ||
           (archName.compareToIgnoreCase("x686")  == 0) ||
           (archName.compareToIgnoreCase("ix686") == 0)) {
            return IX86.toString();
        }

        return valueOf(archName.toUpperCase()).toString();
    }

    /** 
     * Get Hardware type
     * If this architecture is not supported by XtremWeb, this forces the program to immediatly stop
     * @see #getArchitecture(String)
     */
    public static XWCPUs getCpu() {
        try {
            return getCpu(System.getProperty("os.arch"));
        }
        catch(Exception e) {
            util.fatal(e.toString());
        }
        return null;
    }

    /** 
     * This forces architecture name to predefined values to avoid confusion
     * @param archName the architecture name
     * @exception ClassNotFound exception is thrown if archName is not supported by XtremWeb
     * @return archtecture type
     * @see #archictures
     */
    public static XWCPUs getCpu(String archName) 
	throws IllegalArgumentException {
        return valueOf(getCpuName(archName));
    }


    /**
     * This array stores enum as string 
     */
    public static String[] labels = null;
    /**
     * This retreives this enum string representation
     * @return a array containing this enum string representation
     */
    public static String[] getLabels() {
        if(labels != null)
            return labels;

        labels = new String[SIZE];
        for (XWCPUs c : XWCPUs.values())
            labels[c.ordinal()] = c.toString();
        return labels;
    }

    public static void main(String[] argv) {
        for (XWCPUs i : XWCPUs.values())
            System.out.println(i.toString() + " = " + i.ordinal() +
                               " valueOf() = " + i.valueOf(i.toString()));
    }

}
