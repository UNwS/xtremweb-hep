package xtremweb.common;

import java.io.*;
import java.sql.*;
import java.util.StringTokenizer;

import org.xml.sax.Attributes;

/**
 * UserGroupInterface.java
 *
 * Created: Feb 19th, 2002
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @since v1r3-rc7
 * @version %I%, %G%
 */

/**
 * This class describes a row of the works SQL table.
 */
public class UserGroupInterface
    extends xtremweb.common.TableInterface {

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "usergroup";

    /**
     * This enumerates this interface columns
     */
    public enum Columns {
        /**
         *
         */
        UID,
        /**
         * This is the column index of the flag to tell whether this
         * has been deleted
         * @since 2.0.0
         */
        ISDELETED,
        /**
         * This defines if this user group can be a "project".
         * Any user group can be a "project" except worker user group and administrator user group.
         */
        PROJECT,
        /**
         * This is the column index of the user group label
         */
        LABEL;


        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns c : Columns.values()) {
                if(c.ordinal() == v)
                    return c;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[LABEL.ordinal() + 1];
            for (Columns c : Columns.values())
                labels[c.ordinal()] = c.toString();
            return labels;
        }
    }

    /**
     * This is the default constructor
     */
    public UserGroupInterface () {

        super (THISTAG);

        LAST_ATTRIBUTE = Columns.LABEL.ordinal();
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values  = new Object [MAX_ATTRIBUTE];
        setDeleted(false);
    }
    /**
     * This constructor reads its definition from an SQL request result
     * @param rs is an SQL request result
     * @exception IOException
     */
    public UserGroupInterface (ResultSet rs) throws IOException {

        this ();

        try {

            setValue(Columns.UID, new UID(rs.getString(Columns.UID.toString())));
            setValue(Columns.LABEL, rs.getString(Columns.LABEL.toString()));
            try {
                setDeleted(new Boolean(rs.getString(Columns.ISDELETED.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
            setProject(new Boolean(rs.getString(Columns.PROJECT.toString())));
        }
        catch (Exception e) {
            throw new IOException (e.toString ());
        }
    }
    /**
     * This calls this(StreamIO.stream(input));
     * @param input is a String containing an XML representation
     */
    public UserGroupInterface(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public UserGroupInterface(DataInputStream input) throws IOException{
        this();
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public UserGroupInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This is the default constructor
     */
    public UserGroupInterface(UID uid) {
        this();
        setUID(uid);
    }
    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This retreives the UID
     * @return UID
     * @exception IOException is thrown is attribute is not set
     */
    public UID getUID () throws IOException{
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("UserInterface#getUID() : attribute not set");
        }
    }
    /**
     * This retreives is this can be a "project"
     * @return UID
     * @exception IOException is thrown is attribute is not set
     */
    public boolean isProject() {
        try {
            return ((Boolean)getValue(Columns.PROJECT)).booleanValue();
        }
        catch(Exception e) {
            setProject(true);
            return true;
        }
    }
    /**
     * This retreives this group label, if any
     */
    public String getLabel () {
        return (String)getValue(Columns.LABEL);
    } 
    /**
     * This gets an attribute<br />
     * This attr is forced to false if not set
     * @return this attribute
     * @since 2.0.0
     */
    public boolean isDeleted() {
        try {
            Boolean ret = (Boolean)getValue(Columns.ISDELETED);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setDeleted(false);
            return false;
        }
    }
    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) {
        return setValue(Columns.valueOf(attribute.toUpperCase()), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the column to set 
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     */
    public boolean setValue(Columns column, Object val) {
        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), null);

        String v = val.toString();
        switch(column) {
        case UID :
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case LABEL :
            // sql query safety : removing spaces and quotes
            value = v.replaceAll("[\\n\\s\'\"]+", "_");
            break;
        case PROJECT :
        case ISDELETED :
            value = new Boolean(v);
            break;
        }
        return super.setValue(column.ordinal(), value);
    }
    /**
     * This sets uid
     * @return true if value has changed
     */
    public boolean setUID (UID v) {
        return setValue(Columns.UID, v);
    }
    /**
     * This sets the label
     * @return true if value has changed
     */
    public boolean setLabel (String v) {
        return setValue(Columns.LABEL, v);
    }
    /**
     * @return true if value has changed, false otherwise
     * @since XWHEP 1.0.0.
     */
    public boolean setDeleted(boolean v) {
        return setValue(Columns.ISDELETED, new Boolean(v));
    }
    /**
     * @return true if value has changed, false otherwise
     * @since XWHEP 1.0.0
     */
    public boolean setProject(boolean v) {
        return setValue(Columns.PROJECT, new Boolean(v));
    }
    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            UserGroupInterface usergroup = new UserGroupInterface();
            usergroup.setUID(UID.myUid);
            usergroup.DUMPNULLS = true;
            System.out.println(usergroup.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
