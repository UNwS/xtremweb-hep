package xtremweb.common;

import java.io.IOException;
import java.io.FileInputStream;
import java.io.DataInputStream;
import java.util.Date;
import java.sql.ResultSet;
import java.util.StringTokenizer;
import java.security.AccessControlException;

import org.xml.sax.Attributes;

/**
 * DataInterface.java
 *
 * Created: 19 juillet 2006
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

public class DataInterface
    extends xtremweb.common.TableInterface
    implements java.io.Serializable {

    /**
     * This enumerates this interface columns
     */
    public enum Columns {

        /**
         * This is the column index of the UNIQUE ID.<br />
         * It <b>must</b> be the first attribute since we use it as primary key.
         * @see TableInterface
         */
        UID,
        /**
         * This is the column index of the owner UID
         * if any<br />
         */
        OWNERUID,
        /**
         * This is the column index of this data access rights
         * if any<br />
         */
        ACCESSRIGHTS,
        /**
         * This is the column index of the name if any.<br />
         * This should considered as an alias.
         */
        NAME,
        /**
         * This is the column index of the links
         * (how many uses this data).<br />
         */
        LINKS,
        /**
         * This is the column index of the creation date
         */
        INSERTIONDATE,
        /**
         * This is the column index of the last acces date
         */
        ACCESSDATE,
        /**
         * This is the column index of the status
         * @see xtremweb.common.XWStatus
         */
        STATUS,
        /**
         * This is the column index of the data type
         * @see xtremweb.common#DataType
         */
        TYPE,
        /**
         * This is the column index of the CPU (needed for executables)
         */
        CPU,
        /**
         * This is the column index of the OS
         */
        OS,
        /**
         * This is the column index of the size (in bytes)
         */
        SIZE,
        /**
         * This is the column index of the MD5
         */
        MD5,
        /**
         * This is the column index of the URI
         */
        URI,
        /**
         * This is the column index of the flag to tell whether this is 
         * sent to client
         */
        SENDTOCLIENT,
        /**
         * This is the column index of the flag to tell whether this
         * has been deleted
         * @since 2.0.0
         */
        ISDELETED,
        /**
         * This is the column index of the flag to tell whether this is
         * a server local work or a replicated workd
         */
        REPLICATED;

        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns c : Columns.values()) {
                if(c.ordinal() == v)
                    return c;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[REPLICATED.ordinal() + 1];
            for (Columns c : Columns.values())
                labels[c.ordinal()] = c.toString();
            return labels;
        }
    }


    /**
     * This is the XML tag
     */
    public static final String THISTAG = "data";


    /**
     * This is the default constructor
     */
    public DataInterface() {

        super(THISTAG);

        LAST_ATTRIBUTE = Columns.REPLICATED.ordinal();
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values  = new Object[MAX_ATTRIBUTE];
        setAccessRights(XWAccessRights.DEFAULT);
        setReplicated(false);
        setDeleted(false);
        setSendToClient(false);
        setAccessRights(XWAccessRights.DEFAULT);
    }
    /**
     * This constructs a new object providing its primary key value
     * @param uid is this new object UID
     */
    public DataInterface(UID uid) throws IOException {
        this();
        setUID(uid);
    }
    /**
     * This constructor reads its definition from an SQL request result
     * @param rs is an SQL request result
     * @exception IOException
     */
    public DataInterface(ResultSet rs) throws IOException {

        this();

        try {
            setUID(new UID(rs.getString(Columns.UID.toString())));
            setOwner(new UID(rs.getString(Columns.OWNERUID.toString())));


            try {
                setURI(new URI(rs.getString(Columns.URI.toString())));
            }
            catch(Exception e) {
                // stdin is optionnal
            }
            try {
                setName(rs.getString(Columns.NAME.toString()));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setLinks(new Integer(rs.getInt(Columns.LINKS.toString()))); 
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setAccessRights(new XWAccessRights(rs.getInt(Columns.ACCESSRIGHTS.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setStatus(XWStatus.valueOf(rs.getString(Columns.STATUS.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setSize(new Long(rs.getLong(Columns.SIZE.toString()))); 
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setType(DataType.valueOf(rs.getString(Columns.TYPE.toString()))); 
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setOs(XWOSes.valueOf(rs.getString(Columns.OS.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setCpu(XWCPUs.valueOf(rs.getString(Columns.CPU.toString()))); 
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setMD5(rs.getString(Columns.MD5.toString()));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setReplicated(new Boolean(rs.getString(Columns.REPLICATED.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setSendToClient(new Boolean(rs.getString(Columns.SENDTOCLIENT.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setDeleted(new Boolean(rs.getString(Columns.ISDELETED.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setAccessDate(util.getSQLDateTime(rs.getString(Columns.ACCESSDATE.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
            try {
                setInsertionDate(util.getSQLDateTime(rs.getString(Columns.INSERTIONDATE.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }
    /**
     * This calls this(StreamIO.stream(input))
     * @param input is a String containing an XML representation
     */
    public DataInterface(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws SAXException on XML error
     */
    public DataInterface(DataInputStream input) throws IOException{
        this();
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public DataInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This retreives the UID, if already set
     * @return this attribute
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getUID() throws IOException {
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("DataInterface#getUID() : attribute not set");
        }
    }
    /**
     * This retreives the owner UID
     * @return this attribute
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getOwner() throws IOException {
        try {
            return (UID)getValue(Columns.OWNERUID);
        }
        catch(NullPointerException e) {
            throw new IOException("DataInterface#getOwner() : attribute not set");
        }
    }
    /**
     * This retreives the URI
     * @return this attribute, or null if not set
     */
    public URI getURI() {
        return (URI)getValue(Columns.URI);
    }
    /**
     * This retreives the access date
     * @return this attribute
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public java.util.Date getAccessDate() throws IOException {
        try {
            return (java.util.Date)getValue(Columns.ACCESSDATE);
        }
        catch(NullPointerException e) {
            throw new IOException("DataInterface#getOwner() : attribute not set");
        }
    }
    /**
     * This retreives the creation date
     * @return this attribute
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public java.util.Date getInsertionDate() throws IOException {
        try {
            return (java.util.Date)getValue(Columns.INSERTIONDATE);
        }
        catch(NullPointerException e) {
            throw new IOException("DataInterface#getOwner() : attribute not set");
        }
    }
    /**
     * This retreives the number of links to this data
     * @return this attribute
     */
    public int getLinks() {
        try {
            return ((Integer)getValue(Columns.LINKS)).intValue();
        }
        catch(Exception e) {
        }
        setLinks(0);
        return ((Integer)getValue(Columns.LINKS)).intValue();
    }
    /**
     * This retreives this data access rights
     * @return this attribute
     */
    public XWAccessRights getAccessRights() {
        try {
            return (XWAccessRights)getValue(Columns.ACCESSRIGHTS);
        }
        catch(Exception e) {
        }
        setAccessRights(XWAccessRights.DEFAULT);
        return XWAccessRights.DEFAULT;
    }
    /**
     * This retreives this data size in bytes
     * @return this attribute
     */
    public Long getSize() {
        try {
            return ((Long)getValue(Columns.SIZE)).longValue();
        }
        catch(Exception e) {
        }
        setSize(0);
        return 0L;
    }
    /**
     * This retreives this data type
     * @return this attribute
     */
    public DataType getType() {
        try {
            return (DataType)getValue(Columns.TYPE);
        }
        catch(Exception e) {
        }
        setType(DataType.NONE);
        return DataType.NONE;
    }
    /**
     * This retreives this data CPU type
     * @return this attribute or -1 if not set
     */
    public XWCPUs getCpu() {
        try {
            return (XWCPUs)getValue(Columns.CPU);
        }
        catch(Exception e) {
        }
        return null;
    }
    /**
     * This retreives this data OS type
     * @return this attribute or -1 if not set
     */
    public XWOSes getOs() {
        try {
            return (XWOSes)getValue(Columns.OS);
        }
        catch(Exception e) {
        }
        return null;
    }
    /**
     * This retreives the name
     * @return this attribute or null if not set
     */
    public String getName() {
        try {
            return (String)getValue(Columns.NAME);
        }
        catch(Exception e) {
        }
        return null;
    }
    /**
     * This retreives the MD5
     * @return this attribute or null if not set
     */
    public String getMD5() {
        try {
            return (String)getValue(Columns.MD5);
        }
        catch(Exception e) {
        }
        return null;
    }
    /**
     * This retreives whether this data is replicated<br />
     * This attr is forced to true, if not set
     * @return this attribute
     */
    public boolean isReplicated() {
        try {
            Boolean ret = (Boolean)getValue(Columns.REPLICATED);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setReplicated(true);
            return true;
        }
    }
    /**
     * This gets an attribute<br />
     * This attr is forced to false if not set
     * @return this attribute
     */
    public boolean isSendToClient() {
        try {
            Boolean ret = (Boolean)getValue(Columns.SENDTOCLIENT);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setSendToClient(false);
            return false;
        }
    }
    /**
     * This gets an attribute<br />
     * This attr is forced to false if not set
     * @return this attribute
     * @since 2.0.0
     */
    public boolean isDeleted() {
        try {
            Boolean ret = (Boolean)getValue(Columns.ISDELETED);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setDeleted(false);
            return false;
        }
    }
    /**
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v) {
        return setValue(Columns.ISDELETED, new Boolean(v));
    }
    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) {
        return setValue(Columns.valueOf(attribute.toUpperCase()), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the Columns to set
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#setValue(int, Object)
     */
    public boolean setValue(Columns column, Object val) {
        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), null);

        String v = val.toString();

        switch(column) {
        case NAME :
        case MD5 :
            value = v;
            break;
        case UID :
        case OWNERUID :
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case URI:
            try {
                value = new URI(v);
            }
            catch(Exception e) {
            }
            break;
        case OS :
            value = XWOSes.valueOf(v);
            break;
        case CPU :
            value = XWCPUs.valueOf(v);
            break;
        case ACCESSRIGHTS :
            try {
                value = new XWAccessRights(v);
            }
            catch(Exception e) {
            }
            break;
        case LINKS :
            value = new Integer(Integer.parseInt(v));
            break;
        case SIZE :
            value = new Long(Long.parseLong(v));
            break;
        case STATUS :
            value = XWStatus.valueOf(v);
            break;
        case TYPE :
            value = DataType.valueOf(v); 
            break;
        case REPLICATED :
        case SENDTOCLIENT :
        case ISDELETED :
            value = new Boolean(v);
            break;
        case ACCESSDATE:
        case INSERTIONDATE:
            if(val instanceof java.util.Date)
                value = val;
            else
                value = util.getSQLDateTime(v);
            break;
        }
        return super.setValue(column.ordinal(), value);
    }
    /**
     * This sets the UID
     * @return true if UID has changed, false otherwise
     */
    public boolean setUID(UID v) {
        return setValue(Columns.UID, v);
    }
    /**
     * This sets the owner
     * @return true if value has changed, false otherwise
     */
    public boolean setOwner(UID v) {
        return setValue(Columns.OWNERUID, v);
    }
    /**
     * This set the URI where to get the stdin
     * @return true if value has changed, false otherwise
     */
    public boolean setURI(URI v) {
        return setValue(Columns.URI, v);
    }
    /**
     * This sets the name
     * @return true is value has changed
     */
    public boolean setName(String v) {
        return setValue(Columns.NAME, v);
    }
    /**
     * This sets the MD5
     * @return true is value has changed
     */
    public boolean setMD5(String v) {
        return setValue(Columns.MD5, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setSendToClient(boolean v) {
        return setValue(Columns.SENDTOCLIENT, new Boolean(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setReplicated(boolean v) {
        return setValue(Columns.REPLICATED, new Boolean(v));
    }
    /**
     * This sets this data type
     * @return true is value has changed
     */
    public boolean setType(DataType v) {
        return setValue(Columns.TYPE, v);
    }
    /**
     * This sets this data OS
     * @return true is value has changed
     */
    public boolean setOs(XWOSes v) {
        return setValue(Columns.OS, v);
    }
    /**
     * This sets this data CPU
     * @return true is value has changed
     */
    public boolean setCpu(XWCPUs v) {
        return setValue(Columns.CPU, v);
    }
    /**
     * This sets this data size
     * @param v is the data size in bytes
     * @return true is value has changed
     */
    public boolean setSize(long v) {
        return setValue(Columns.SIZE, new Long(v));
    }
    /**
     * This retreives this status
     * @exception IOException is thrown if attribute is not set
     * @return this attribute
     */
    public XWStatus getStatus() {
        try {
            return (XWStatus)getValue(Columns.STATUS);
        }
        catch(NullPointerException e) {
            return null;
        }
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setStatus(XWStatus v) {
        return setValue(Columns.STATUS, v);
    }
    /**
     * This sets the number of links to this data
     * @return true is value has changed
     */
    public boolean setLinks(int v) {
        return setValue(Columns.LINKS, new Integer(v));
    }
    /**
     * This sets the access rights
     * @return true is value has changed
     */
    public boolean setAccessRights(XWAccessRights v) {
        return setValue(Columns.ACCESSRIGHTS, v);
    }
    /**
     * This increments the number of links to this data
     * @return the new number of links
     */
    public int incLinks() {
        setLinks(getLinks() + 1);
        return getLinks();
    }
    /**
     * This decrements the number of links to this data
     * @return the new number of links
     */
    public int decLinks() {
        setLinks(getLinks() - 1);
        return getLinks();
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setAccessDate(Date v) {
        return setValue(Columns.ACCESSDATE, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setInsertionDate(Date v) {
        return setValue(Columns.INSERTIONDATE, v);
    }

    /**
     * This tests user access rights
     * @param user is the UID of the user who try to access
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean checkUserAccessRights(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getOwner(), user, XWAccessRights.USERALL);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean checkGroupAccessRights(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPALL);
    }
    /**
     * This tests access rights
     * @return true if others have access rights
     */
    public boolean checkOtherAccessRights()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERALL);
    }
    /**
     * This tests if user can read
     * @param user is the UID of the user who try to read
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanRead(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getOwner(), user, XWAccessRights.USERREAD);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanRead(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPREAD);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanRead()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERREAD);
    }
    /**
     * This tests if user can write
     * @param user is the UID of the user who try to write
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanWrite(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getOwner(), user, XWAccessRights.USERWRITE);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to write
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanWrite(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPWRITE);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanWrite()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERWRITE);
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            DataInterface data = new DataInterface();
            data.setUID(UID.myUid);
            data.DUMPNULLS = true;
            System.out.println(data.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
