package xtremweb.common;

/**
 * XWReturnCode.java
 *
 * Created: Mar 8th, 2007
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This defines XtremWeb return codes
 */

public enum XWReturnCode {

    /**
     * This defines the success return code
     */
    SUCCESS,
    /**
     * This defines the fatal return code
     */
    FATAL,
    /**
     * This defines the error return code
     */
    ERROR,
    /**
     * This defines the warning return code
     */
    WARNING,
    /**
     * This defines the restart return code
     */
    RESTART,
    /**
     * This defines the connection error return code
     * This means that the XtremWeb server is not reacheable
     */
    CONNECTION,
    /**
     * This defines the parsing error return code
     * This means there's an error on command line option
     */
    PARSING,
    /**
     * This defines the disk error return code
     * This means there's a disk error
     */
    DISK;
            
	/**
	 * This retreives an Columns from its integer value
	 * @param v is the integer value of the Columns
	 * @return an Columns
	 */
	public static XWReturnCode fromInt(int v) throws IndexOutOfBoundsException {
	    for (XWReturnCode c : XWReturnCode.values()) {
            if(c.ordinal() == v)
                return c;
	    }
	    throw new IndexOutOfBoundsException("unvalid XWReturnCode value " + v);
	}

}
