
package xtremweb.common;

import xtremweb.communications.IdRpc;

import java.text.ParseException;

/**
 * Created: Decembre 2006<br />
 *
 * This enumerates available command line options.
 * This is used by CommandLineParser<br />
 * <br />
 *
 * Available options :
 * <ul>
 * <li> --xwnone : to do nothing
 * <li> --xwhelp : to get this help
 * <li> --xwmacro <macro file name> : to provide a macro file (an xml file)
 * <li> --xwverbose : to see details
 * <li> --xwnoverbose : to hide details
 * <li> --xwformat [xml | csv | html] : to specify output format
 * <li> --xwlabel <label> : to provide a job label
 * <li> --xwenv [directory | file name | zip file name] : to provide a job environment file
 * <li> --xwconfig <config file name> : to provide a config file
 * <li> --xwdownload : to download data (this works with --xwgetdata and --xwgetwork to retreive result)
 * <li> --xwupdateworkers [uids list] [on | off] : to enable/disable workers
 * <li> --xwnoextract : to not expand zip result file
 * <li> --xwrmzip : to delete zip result file
 * <li> --xwerase : to remove result from server
 * <li> --xwoverride : to override existing file on local disk
 * <li> --xwgui : to display client GUI
 * </ul>
 *
 * @see #CommandLineParser
 * @author <a href="mailto:lodygens a lal.in2p3.fr">Oleg Lodygensky</a>
 * @version %I% %G%
 * @since 1.9.0
 */

public enum CommandLineOptions {

    NONE,
    HELP,
    MACRO,
    VERBOSE,
    NOVERBOSE,
    FORMAT,
    LABEL,
    ENV,
    CONFIG,
    DOWNLOAD,
    UPDATEWORKERS,
    NOEXTRACT,
    RMZIP,
    ERASE,
    OVERRIDE,
    GUI;

    public static final CommandLineOptions LAST = GUI;
    public static final int SIZE = LAST.ordinal() + 1;

    public static final String[] helpTexts = {
        " : to do nothing",
        " : to get this help",
        " <macro file name> : to provide a macro file (an xml file)",
        " : to see details",
        " : to hide details",
        " [xml | csv | html] : to specify output format",
        " <label> : to provide a job label",
        " [directory | file name | zip file name] : to provide a job environment file",
        " <config file name> : to provide a config file",
        " to download datas (this works with --xwgetdata and --xwgetwork to retreive results)",
        " [uids list] [on | off] : to enable/disable workers",
        " to not expand zip result file",
        " to delete zip result file",
        " to remove result from server",
        " to override existing file on local disk",
        " : to display client GUI"
    };

    public String help() {
        return helpTexts[this.ordinal()];
    }

    public static String help(CommandLineOptions i) {
        return helpTexts[i.ordinal()];
    }

    public String usage() {
        return CommandLineParser.PREFIX + this.toString().toLowerCase() + help();
    }

    public static void main(String[] argv) {
	
        for (CommandLineOptions i : CommandLineOptions.values())
            System.out.println(i.toString() + " = " + i.ordinal() +
                               " valueOf() = " + i.valueOf(i.toString()) + 
                               " help = " + help(i));
    }
}
