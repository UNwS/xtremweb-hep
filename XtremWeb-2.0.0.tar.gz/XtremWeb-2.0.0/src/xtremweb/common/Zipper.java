package xtremweb.common;

import java.io.IOException;
import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipException;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;


/**
 * Zipper.java
 * This class zip/unzip files
 *
 * If the same object is used to unzip and then zip, it may be configured
 * so that only new or modified files are zipped.
 * (used by the worker to improve bandwidth usage)
 *
 * Created: 5 octobre 2002
 *
 * @author Oleg Lodygensky
 */

public class Zipper extends Logger {
    static final int BUFFER = 2048;

    protected static final String NAME = "ZIPPER";
    /**
     * This sets the logger level.
     * This also sets the logger levels checkboxes menu item.
     */
    public void setLoggerLevel(LoggerLevel l) {
        level = l;
    }
    /**
     * This is the ZIP archive file name used to create/read archive
     */
    private String fileName  = null;
    /**
     * This contains files list.
     * This is filled as archive is unzipped.
     * This is used to exclude uncessary files from compression.
     * The idea is to be able to unzip, do some work and then only zip
     * modified and new files.
     */
    private Map filesList = null;
    /**
     * This contains directory name to zip.<BR>
     * It is removed from zip entry names because we want to be able to extract them everywhere.
     */
    private String scratch;
    /**
     * This tells whether or not to use <CODE>filesList</CODE> <BR>
     * This is set to true by default, to force zip creation. Set it to
     * false to zip differences only.
     */
    private boolean creation;


    private byte[] buffer = new byte[1024];


    /**
     * This is the default constructor.
     * @param l is the log level
     */
    public Zipper(LoggerLevel l) {
        creation = true;
        setLoggerLevel(l);
    }

    /**
     * This is a constructor.
     * @param fn is the filename to be used
     * @param l is the output level
     */
    public Zipper(String fn, LoggerLevel l) {
        this(l);
        fileName = fn;
    }


    public void setFileName(String fn) {
        if(fn == null)
            return;

        fileName = fn;

        if((fileName.startsWith(File.separator) == false)  &&
           (fileName.startsWith(".") == false) &&
           (fileName.charAt(1) != ':')) { // win32 specific

            fileName = "." + File.separator + fileName;
        }
        debug("seFileName " + fileName);
    }


    public String getFileName() {
        return fileName;
    }

    /**
     * This sets the file list
     * @see #filesList
     */
    public void resetFilesList() {
        filesList = new HashMap();
    }
    /**
     * This sets the file list
     * @see #filesList
     */
    public void setFilesList(Map fl) {
        filesList = fl;
    }
    /**
     * This sets the file list from the provided file
     * If file is a directory the full content is put into filesLis
     * @see #filesList
     */
    public void setFilesList(File root) {

        if(!root.exists())
            return;

        if(!root.isDirectory()) {
            filesList.put(root.getName(), new Long(root.lastModified()));
            return;
        }

        String[] list = root.list();

        for(int i = 0; i < list.length; i++) {
            File file = new File(root, list [i]);
            if(file.isDirectory())
                setFilesList(file);
            else {
                filesList.put(file.getName(), new Long(file.lastModified()));
            }
        }
    }


    public Map getFilesList() {
        return filesList;
    }


    public void setCreation(boolean r) {
        creation = r;
    }


    public boolean getCreation() {
        return creation;
    }


    /**
     * This tests whether file needs to be compressed in zip file
     * @param file is the file name to be included
     */
    private boolean generate(String dir, String file) {
        if(creation)
            return true;
        if(filesList == null)
            return true;
        if(!filesList.containsKey(file))
            return true;
        return(((Long) filesList.get(file)).longValue() < 
               (new File(dir + File.separator + file)).lastModified());
    }


    /**
     * This unzip file which file name has been provided.
     * 27 avril 2006 : this uses ZipFile; some troubles have been reported 
     * which are (hopefully) solved with unzipNew()
     * @param outDir is the directory to explode zip file to
     *
     * Since RPCXW : this may represent a non zipped file (see zip ())
     *               if there was a single 'little' file to zip
     * @return true if correctly unzipped, false otherwise
     * @see #zip(String[])
     * @exception IOException is thrown on I/O error
     * @exception NullPointerException is thrown if this fileName is not set
     */
    public boolean unzip(String outDir)
        throws IOException {

        if(fileName == null)
            throw new IOException("file name not set");

        filesList = new HashMap();

        File outputDir = new File(outDir);
        util.checkDir(outputDir);

        ZipFile zipFile = null;
        Enumeration entries = null;
        try {
            debug("Unzipping : " + fileName + " to " + outDir);
            File file = new File(fileName);
            if(file.exists() == false)
                error(fileName + " does not exist");
            zipFile = new ZipFile(file);
            entries = zipFile.entries();
        }
        catch(ZipException z) {
            if(debug())
                z.printStackTrace();
            debug("not a zip file ? trying unzipNew");
            return unzipNew(outDir);
        }

        while(entries.hasMoreElements()) {

            Thread.yield();

            ZipEntry entry =(ZipEntry) entries.nextElement();

            InputStream in = zipFile.getInputStream(entry);
            // amazing : I had such a case...
            // becase a file name contained a french accentuation
            // :(
            if(in == null) {
                warn("Unzipping " + fileName + " : " + 
                            entry.getName() + " is not unzipped ...");
                continue;
            }

            File f = new File(outDir, entry.getName());
            util.checkDir(f.getParent());
            if(entry.isDirectory())
                continue;

            FileOutputStream out = new FileOutputStream(f);

            int len;
            while((len = in.read(buffer)) >= 0) {
                out.write(buffer, 0, len);
            }
            in.close();
            out.close();
            
            filesList.put(entry.getName(), new Long(f.lastModified()));
            debug("Extracted file: " + entry.getName());
        }

        zipFile.close();

        return true;

    } // unzip()


    /**
     * This unzip file which file name has been provided.<br />
     * 27 avril 2006 : this uses ZipInputStream since some troubles have
     * been reported with unzip().
     * @param outDir is the directory to explode zip file to
     *
     * Since RPCXW : this may represent a non zipped file (see zip ())
     *               if there was a single 'little' file to zip
     * @return true if correctly unzipped, false otherwise
     * @see #zip(String[])
     * @exception IOException is thrown on I/O error
     * @exception NullPointerException is thrown if this fileName is not set
     */
    public boolean unzipNew(String outDir)
        throws IOException {

        if(fileName == null)
            throw new IOException("file name not set");

        File outputDir = new File(outDir);
        util.checkDir(outputDir);

        filesList = new HashMap();

        BufferedOutputStream dest = null;
        FileInputStream fis = null;
        ZipInputStream zis = null;
        ZipEntry entry;

        try {
            fis = new FileInputStream(fileName);
            zis = new ZipInputStream(new BufferedInputStream(fis));
        }
        catch(Exception z) {
            if(debug())
                z.printStackTrace();
            debug("definitly not a zip file " + z.toString());
            return false;
        }


        while((entry = zis.getNextEntry()) != null) {

            int count;
            byte data[] = new byte[BUFFER];

            FileOutputStream fos = null;
            try {
                File f = new File(outDir, entry.getName());
                util.checkDir(f.getParent());
                if(entry.isDirectory())
                    continue;
                fos = new FileOutputStream(f);
            }
            catch(Exception e) {
                warn("Unzipping " + fileName + " : " + 
                     entry.getName() + " is not unzipped ...");
                continue;
            }

            dest = new BufferedOutputStream(fos, BUFFER);
            while ((count = zis.read(data, 0, BUFFER)) != -1) {
                dest.write(data, 0, count);
            }
            dest.flush();
            dest.close();
            debug("Extracted file: " + entry.getName());
        }

        zis.close();

        return true;

    } // unzipNew()

    /**
     * This zips files/directories provided as arguments without any optimization
     * @see #zip(String[], boolean)
     */
    public boolean zip(String[] inputs)
        throws IOException {
        return zip(inputs, false);
    }

    /**
     * This zip files/directories provided as arguments.
     * Accordingly to filesList, some files may not be zipped if they have
     * previously been extracted from this zip file and not modified.
     *
     * If optimize is true we may not zip at all if inputs has only one file
     * and if this file size is less than util.LONGFILESIZE, since zipping
     * would then only be waste of CPU time. In such a case this.getFileName() returns
     * the name of the unic file.
     *
     * @param inputs is the directories/files list to compress
     * @param optimize tells to optimize zipping; if false this always zips
     *                 accordingly to filesList
     * @return true if something has been zipped, false otherwise
     * @since RPCXW
     * @see #filesList
     */
    public boolean zip(String[] inputs, boolean optimize)
        throws IOException {


        if((optimize) &&(inputs.length == 1)) {
            //            System.out.println("Zipper     inputs[0] = " + inputs[0]);
            File inputFile = new File(inputs [0]);
            if(inputFile.isDirectory() == false) {
                if(inputFile.length() < util.LONGFILESIZE) {
                    fileName = inputs[0];
                    debug("not necessary to zip 00 = " + fileName);
                    return false;
                }
            }
            else {
                String [] files = inputFile.list();
                switch(files.length) {
                case 0:
                    //fileName = fileName.substring(fileName.lastIndexOf(File.separator) + 1); 
                    fileName = null;
                    debug("not necessary to zip 01 = null");
                    return false;

                case 1:
                    File f2 = new File(inputFile, files [0]);
                    if((f2.isDirectory() == false) &&(f2.length() < util.LONGFILESIZE)) {
                        // RPCXW we want the parent of the scratch dir

                        // 7 avril 2008
                        //fileName = inputFile.getName() + File.separator + files[0];
                        fileName = inputFile.getAbsolutePath() + File.separator + files[0];

                        debug("not necessary to zip 02 = " + fileName);
                        return false;
                    }
                    break;
                }
            }
        }

        boolean atleastone = false;

        try {
            ZipOutputStream zipFile = new ZipOutputStream(new
                                                          FileOutputStream(new File(fileName)));

            for(int i = 0; i < inputs.length; i++) {
                debug("*** " + inputs[i]);
                scratch = inputs[i];
                atleastone = zip(zipFile, inputs[i]);
            }

            zipFile.close();
        }
        catch(ZipException ze) {
            if(atleastone)
                throw ze;
            fileName = null;
            return false;
        }
        return true;

    } // zip()


    /**
     * This zip file/directory provided as argument.
     * This is recursivly called.<BR>
     * Zipping is done using <CODE>filesList</CODE> to test whether
     * input has to be compressed or not.
     * @param zipfile is the file to add entry to
     * @param input is the current entry to add to zip file
     * @return true if something has been zipped, false otherwise
     */
    private boolean zip(ZipOutputStream zipfile, String input) 
        throws IOException {

        File inputFile = new File(input);
        String[] tmpFiles = null;
        int loop;
        boolean atleastone = false;

        if(inputFile.isDirectory() == false) {
            tmpFiles = new String[1];
            tmpFiles[0] = input;
        }
        else {
            tmpFiles = inputFile.list();
        }

        if(tmpFiles == null) {
            debug("Zipping " + input + " nothing to do");
            return false;
        }

        debug("Zipping " + input + " " + tmpFiles.length + " entries");

        if(tmpFiles.length == 0) {
            int nLen = scratch.length();
            String withoutScratch = input.substring(nLen);
            String entryName = null;

            if(withoutScratch.length() == 0)
                entryName = input;
            else
                entryName = withoutScratch + "/" + input;

            zipfile.putNextEntry(new ZipEntry(entryName + "/"));
            zipfile.closeEntry();
            return false;
        }

        for(loop = 0; loop < tmpFiles.length; loop++) {

            if(fileName.compareTo(input + "/" + tmpFiles [loop]) == 0)
                continue;

            if(generate(input, tmpFiles [loop])) {

                int nLen = scratch.length();
                String withoutScratch = input.substring(nLen);
                String entryName = null;

                if(withoutScratch.length() == 0)
                    entryName = tmpFiles [loop];
                else
                    entryName = withoutScratch + "/" + tmpFiles [loop];

                File fileIn;

                if(inputFile.isDirectory()) {
                    fileIn = new File(input + "/" + tmpFiles [loop]);
                    debug("0000 Zipping : " + entryName + 
                                 "(" + input + "/" + tmpFiles [loop] + ", " + fileIn.length() + ")");
                }
                else {
                    fileIn = new File(tmpFiles [loop]);
                    debug("0001 Zipping : " + entryName + 
                                 "(" + tmpFiles [loop] + ", " + fileIn.length() + ")");
                }

                if(fileIn.isDirectory() == false) {

                    zipfile.putNextEntry(new ZipEntry(entryName));
                    FileInputStream dataIn = new FileInputStream(fileIn);

                    int len;

                    while((len = dataIn.read(buffer)) >= 0)
                        zipfile.write(buffer, 0, len);

                    dataIn.close();

                } // if(isDirectory == false)
                else {
                    zip(zipfile, input + "/" + tmpFiles[loop]);
                    zipfile.putNextEntry(new ZipEntry(entryName + "/"));
                }

                zipfile.closeEntry();

                atleastone = true;

            } // if(generate())
            else {
                debug("Zipping is skipping : " + input + "/" + tmpFiles[loop]);
            }

        } // for()

        return atleastone;

    } // zip(ZipOutputStream, String)

    /**
     * This tests whether the provided argument is a zip file
     */
    public static boolean test(String fileName) 
        throws IOException {

        File testDir = new File(System.getProperty("java.io.tmpdir"),
                                "XWHEP.Zipper.Test." + new Date().getTime());
        util.checkDir(testDir);
        Zipper zipper = new Zipper(LoggerLevel.DEBUG);
        zipper.setCreation(false);
        zipper.setFileName(fileName);
        boolean ret = zipper.unzip(testDir.getAbsolutePath());
        util.deleteDir(testDir);
        return ret;
    }
    /**
     * This main method is for test purposes only
     */
    public static void main(String[] argv) {
        try {
            Zipper.test(argv[0]);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}

