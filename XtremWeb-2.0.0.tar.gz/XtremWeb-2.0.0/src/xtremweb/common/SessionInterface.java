package xtremweb.common;

import java.io.IOException;
import java.io.DataInputStream;
import java.sql.ResultSet;
import java.util.StringTokenizer;
import java.security.AccessControlException;

import org.xml.sax.Attributes;


/**
 * SessionInterface.java
 *
 * Created: Feb 19th, 2002
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This class describes a row of the works SQL table.
 */
public class SessionInterface
    extends xtremweb.common.TableInterface {

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "session";

    /**
     * This enumerates this interface columns
     */
    public enum Columns {

        /**
         * These are the attributes row number.
         * It <b>must</b> be the first attribute since we use it as primary key.
         * @see TableInterface
         */
        UID,
        /**
         * This is the column index of the session name
         */
        NAME,
        /**
         * This is the column index of the flag to tell whether this
         * has been deleted
         * @since 2.0.0
         */
        ISDELETED,
        /**
         * This is the column index of the UID of the associated client.
         */
        CLIENTUID;

        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns c : Columns.values()) {
                if(c.ordinal() == v)
                    return c;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[CLIENTUID.ordinal() + 1];
            for (Columns c : Columns.values())
                labels[c.ordinal()] = c.toString();
            return labels;
        }
    }


    /**
     * This is the default constructor
     */
    public SessionInterface() {

        super(THISTAG);

        LAST_ATTRIBUTE = Columns.CLIENTUID.ordinal();
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values  = new Object[MAX_ATTRIBUTE];
        setDeleted(false);
    }
    /**
     * This constructor reads its definition from an SQL request result
     * @param rs is an SQL request result
     * @exception IOException
     */
    public SessionInterface(ResultSet rs) throws IOException {

        this();

        try {
            setUID(new UID(rs.getString(Columns.UID.toString()))); 
            setName(rs.getString(Columns.NAME.toString()));
            setClient(new UID(rs.getString(Columns.CLIENTUID.toString())));
            try {
                setDeleted(new Boolean(rs.getString(Columns.ISDELETED.toString())));
            }
            catch (Exception e) {
                // this is optionnal
            }
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }
    /**
     * This calls this(StreamIO.stream(input));
     * @param input is a String containing an XML representation
     */
    public SessionInterface(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public SessionInterface(DataInputStream input) 
        throws IOException{
        this();
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public SessionInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This retreives the UID
     * @return UID
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getUID() throws IOException{
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("SessionInterface#getUID() : attribute not set");
        }
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getName() {
        return(String)getValue(Columns.NAME);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getClient() throws IOException{
        try {
            return (UID)getValue(Columns.CLIENTUID);
        }
        catch(NullPointerException e) {
            throw new IOException("SessionInterface#getClient() : attribute not set");
        }
    }
    /**
     * This gets an attribute<br />
     * This attr is forced to false if not set
     * @return this attribute
     * @since 2.0.0
     */
    public boolean isDeleted() {
        try {
            Boolean ret = (Boolean)getValue(Columns.ISDELETED);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setDeleted(false);
            return false;
        }
    }
    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) {
        return setValue(Columns.valueOf(attribute.toUpperCase()), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the column to set 
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     */
    public boolean setValue(Columns column, Object val) {
        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), null);

        String v = val.toString();

        switch(column) {
        case UID :
        case CLIENTUID :
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case NAME :
            // sql query safety : removing spaces and quotes
            value = v.replaceAll("[\\n\\s\'\"]+", "_");
            break;
        case ISDELETED :
            value = new Boolean(v);
            break;
        }
        return super.setValue(column.ordinal(), value);
    }
    /**
     * This sets the UID
     * @return true if UID has changed, false otherwise
     */
    public boolean setUID(UID v) {
        return setValue(Columns.UID, v);
    }
    /**
     * This sets the name
     * @return true if name has changed, false otherwise
     */
    public boolean setName(String v) {
        return setValue(Columns.NAME, v);
    }
    /**
     * This sets the client
     * @return true if client has changed, false otherwise
     */
    public boolean setClient(UID v) {
        return setValue(Columns.CLIENTUID, v);
    }
    /**
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v) {
        return setValue(Columns.ISDELETED, new Boolean(v));
    }

    /**
     * This tests user access rights
     * @param user is the UID of the user who try to access
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean checkUserAccessRights(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getClient(), user, XWAccessRights.USERALL);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean checkGroupAccessRights(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPALL);
    }
    /**
     * This tests access rights
     * @return true if others have access rights
     */
    public boolean checkOtherAccessRights()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERALL);
    }
    /**
     * This tests if user can read
     * @param user is the UID of the user who try to read
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanRead(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getClient(), user, XWAccessRights.USERREAD);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanRead(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPREAD);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanRead()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERREAD);
    }
    /**
     * This tests if user can write
     * @param user is the UID of the user who try to write
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanWrite(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getClient(), user, XWAccessRights.USERWRITE);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to write
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanWrite(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPWRITE);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanWrite()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERWRITE);
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            SessionInterface session = new SessionInterface();
            session.setUID(UID.myUid);
            session.DUMPNULLS = true;
            System.out.println(session.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
