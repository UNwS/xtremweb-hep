package xtremweb.common;

import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.Vector;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLRPCtuple.java
 *
 * Created: Nov 16th, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class (un)marshall tuple(key, value)
 */
public class XMLtuple extends XMLable {

    public static final String THISTAG = "XMLTUPLE";

    /**
     * This stores the key, if any
     */
    protected XMLKey key;
    /**
     * This stores the value
     */
    protected XMLValue value;


    /**
     * This default constructor sets key and value to null
     */
    public XMLtuple() {
        super(THISTAG, -1);

        key = null;
        value = null;
    }

    /**
     * This constructor sets key and value
     */
    public XMLtuple(XMLKey k, XMLValue v) {
        this();
        key = k;
        value = v;
    }
    /**
     * This constructor sets key and value from Objects
     * @param k is the tuple key; a new XMLKey is created from this param
     * @param v is the tuple value.
     *        If v is an Hashtable, a new XMLHashtable is created as value.
     *        If v is a  Vector,    a new XMLVector    is created as value
     *        Otherwise, a new XMLValue is created as value.
     *        
     */
    public XMLtuple(Object k, Object v) {
        //				this(new XMLKey(k), new XMLValue(v));
        this();
        key = new XMLKey(k);
        if(v instanceof Hashtable)
            value = new XMLHashtable((Hashtable)v);
        else if(v instanceof Vector)
            value = new XMLVector((Vector)v);
        else
            value = new XMLValue(v);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLtuple(DataInputStream input) throws IOException{
        //				this(new XMLKey(), new XMLValue());
        this();
        fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     */
    public XMLtuple(Attributes attrs) throws IOException{
        this();
        fromXml(attrs);
    }
    /**
     * This does nothing since this has no attribute
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {
    }
    /**
     * This serializes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    public String toXml() {

        String ret = "<" + XMLTAG + ">";

        if (key != null)
            ret += key.toXml();
        if (value != null)
            ret += value.toXml();

        ret += "</" + XMLTAG + ">";

        return ret;
    }
    /**
     * This writes this object XML representation to output stream
     * @param o is the output stream to write to
     */
    public void toXml(DataOutputStream o) throws IOException {

        String ret = "<" + XMLTAG + ">";
        o.writeUTF(ret);

        if (key != null)
            key.toXml(o);
        if (value != null)
            value.toXml(o);

        ret = "</" + XMLTAG + ">";
        o.writeUTF(ret);
    }
    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public void xmlElementStart(String uri, String tag, String qname, 
                                Attributes attrs)
        throws IOException {

        try {
            if(qname.compareToIgnoreCase(XMLTAG) == 0) {
                fromXml(attrs);
                return;
            }
            else {
                if((qname.compareToIgnoreCase(XMLKey.THISTAG) == 0) && 
                   (key == null)) {

                    debug("new " + qname);
                    key = new XMLKey(attrs);
                    return;
                }
            }

            if(value == null) {
                debug("new " + qname);
                if(qname.compareToIgnoreCase(XMLValue.THISTAG) == 0)
                    value = new XMLValue(attrs);
                else if(qname.compareToIgnoreCase(XMLHashtable.THISTAG) == 0)
                    value = new XMLHashtable(attrs);
                else if(qname.compareToIgnoreCase(XMLVector.THISTAG) == 0)
                    value = new XMLVector(attrs);
            }
            else {
                debug("value.xmlElementStart(" + qname + ")");
                value.xmlElementStart(uri, tag, qname, attrs);
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            throw new IOException(e.toString());
        }
    }
    /**
     * @see xtremweb.common.XMLObject#xmlElementStop(String, String, String)
     */
    public void xmlElementStop(String uri, String tag, String qname)
        throws IOException {

        debug("xmlElementStop (" + qname + ")");

        if(qname.compareToIgnoreCase(XMLKey.THISTAG) == 0)
            key.xmlElementStop(uri, tag, qname);
        else
            value.xmlElementStop(uri, tag, qname);
    }

    /**
     * this returns XML string replesentation
     */
    public String toString() {
        return toXml();
    }
    /**
     * This calls toString()
     * @param csv is never used
     * @see TableInterface#toString(boolean)
     */
    public String toString(boolean csv) {
        return toString();
    }

    /**
     * This retreives this tuple key
     * @return this tuple key XML representation
     */
    public XMLKey getXMLKey() {
        return key;
    }
    /**
     * This retreives this tuple value
     * @return this tuple value XML representation
     */
    public XMLValue getXMLValue() {
        return value;
    }
    /**
     * This retreives this tuple key
     * @return this tuple key
     */
    public Object getKey() {
        return key.getValue();
    }
    /**
     * This retreives this tuple value
     * @return this tuple value
     */
    public Object getValue() {
        return value.getValue();
    }
    /**
     * This sets this tuple key
     * @param k is the new key
     */
    public void setKey(Object k) {
        key = new XMLKey(k);
    }
    /**
     * This sets this tuple value
     * @param v is the new value
     */
    public void setValue(Object v) {
        value = new XMLValue(v);
    }
    /**
     * This sets this tuple key
     * @param k is the new key
     */
    public void setKey(XMLKey k) {
        key = k;
    }
    /**
     * This sets this tuple value
     * @param v is the new value
     */
    public void setValue(XMLValue v) {
        value = v;
    }

    /**
     * This is for testing only.<br />
     * If argv[0] is empty this creates a dummy XML representation<br />
     * Otherwise, argv[0] may content an XML file name containing 
     * an XML representation to read. <br />
     * <br />
     * The dummy or read representation is finally dumped
     */
    public static void main(String[] argv) {
        try {
            XMLtuple tuple = new XMLtuple(new Integer(1), new String("un"));

            if(argv.length == 1)
                tuple = new XMLtuple(new DataInputStream(new FileInputStream(argv[0])));

            System.out.println(tuple.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
