package xtremweb.common;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import org.xml.sax.Attributes;



/**
 * XMLRPCVector.java
 *
 * Created: Nov 28th, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class (un)marshall vector.
 * This contents values.
 *
 * This may content :
 * <ul>
 *  <li> any object that a constructor like object(String)
 *       (e.g Integer objects have Integer(String) constructor)
 *  <li> hashtables
 *  <li> vectors
 * </ul>
 */
public class XMLVector extends XMLValue {

    public static final String THISTAG = "XMLVector";

    /**
     * This is the size columns index
     * @see xtremweb.common.XMLable#columns
     */
    private final int SIZE = 0;
    /**
     * This is this vector size
     */
    private int size;
    /**
     * This count nested elements since this vector may content hashtables
     * and vectors as elements.
     * This is incremented on each new hashtable or vector, and decremented on each
     * vector or hashtable endings.<br />
     *
     * This is needed since SAX API reads input sequentially
     */
    private int nested = 0;
    /**
     * This is the values index
     * @see #values
     */
    private int currentIndex;
    /**
     * This stores vector values, if any
     */
    protected XMLValue[] values;


    /**
     * @param v is the vector to (un)marshal
     */
    public XMLVector(Vector v) {
        super(THISTAG, 0);
        if(v == null)
            return;

        empty = false;

        LAST_ATTRIBUTE = SIZE;
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = new String[MAX_ATTRIBUTE];
        columns[SIZE]    = "SIZE";

        size = v.size();
        currentIndex = 0;

        values = new XMLValue[size];

        Enumeration myenum = v.elements();
        int i = 0;
        for(; myenum.hasMoreElements(); ) {

            Object obj = myenum.nextElement(); 						

            if(obj == null)
                continue;

            if(obj instanceof Hashtable)
                values[i++] = new XMLHashtable((Hashtable)obj);
            else if(obj instanceof Vector)
                values[i++] = new XMLVector((Vector)obj);
            else
                values[i++] = new XMLValue(obj);
        }
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLVector(DataInputStream input) throws IOException{
        this(new Vector());
        empty = false;
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from an input string
     * @param input is the input string 
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLVector(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLVector(Attributes attrs) throws IOException{
        this(new Vector());
        empty = false;
        fromXml(attrs);
    }
    /**
     * This serializes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    public String toXml() {

        String ret = "<" + XMLTAG + " " + columns[SIZE] + "=\"" + size + "\" >";

        for(int i = 0; i < size; i++) {
            ret += values[i].toXml();
        }
        ret += "</" + XMLTAG + ">";

        return ret;
    }
    /**
     * This writes this object XML representation to output stream
     * @param o is the output stream to write to
     */
    public void toXml(DataOutputStream o) throws IOException {

        String ret = "<" + XMLTAG + " " + columns[SIZE] + "=\"" + size + "\" >";
        o.writeUTF(ret);

        for(int i = 0; i < size; i++) {
            values[i].toXml(o);
        }

        ret = "</" + XMLTAG + ">";
        o.writeUTF(ret);
    }
    /**
     * This 
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

        if(attrs == null) {
            throw new IOException("attrs is null");
        }

        size = 0;

        for(int a = 0; a < attrs.getLength(); a++) {
            String attribute = attrs.getQName(a);
            String value = attrs.getValue(a);
            if(attribute.compareToIgnoreCase(columns[SIZE]) == 0)
                size = new Integer(value).intValue();
        }
        if (size > 0)
            values = new XMLValue[size];
        currentIndex = 0;
    }

    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public void xmlElementStart(String uri, String tag, String qname, 
                                Attributes attrs)
        throws IOException {

        try {
            debug("xmlElementStart (" + qname + ") " +
                  "size = " + size + "  currentIndex = " + currentIndex + "  nested = " + nested);

            if((size == 0) && (qname.compareToIgnoreCase(XMLTAG) == 0)) {	
                debug("" + qname + ".fromXml(attrs)");
                fromXml(attrs);
            }
            else {

                if(size <= 0)
                    throw new IOException("size <= 0 ?!?!");

                if((qname.compareToIgnoreCase(XMLVector.THISTAG)    == 0) ||
                   (qname.compareToIgnoreCase(XMLHashtable.THISTAG) == 0)) {

                    nested++;
                }

                if(values[currentIndex] == null) {
                    debug("values[" + currentIndex + "]  = new XMValue(" + qname + ")");
                    if(qname.compareToIgnoreCase(XMLHashtable.THISTAG) == 0)
                        values[currentIndex] = new XMLHashtable(attrs);
                    else if(qname.compareToIgnoreCase(XMLVector.THISTAG) == 0)
                        values[currentIndex] = new XMLVector(attrs);
                    else if(qname.compareToIgnoreCase(XMLValue.THISTAG) == 0)
                        values[currentIndex] = new XMLValue(attrs);
                }
                else {
                    debug("values[" + currentIndex + "].xmlElementStart(" + qname + ")");
                    values[currentIndex].xmlElementStart(uri, tag, qname, attrs);
                }
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            throw new IOException(e.toString());
        }
    }
    /**
     * This increment currentIndex on "</XML>" closing tag.
     * @see #currentIndex
     * @see xtremweb.common.XMLObject#xmlElementStop(String, String, String)
     */
    public void xmlElementStop(String uri, String tag, String qname)
        throws IOException {

        if(currentIndex < size)
            values[currentIndex].xmlElementStop(uri, tag, qname);

        if((qname.compareToIgnoreCase(XMLHashtable.THISTAG) == 0) ||
           (qname.compareToIgnoreCase(XMLVector.THISTAG)    == 0)) {

            nested--;
        }

        if((qname.compareToIgnoreCase(XMLValue.THISTAG)     == 0) ||
           (qname.compareToIgnoreCase(XMLHashtable.THISTAG) == 0) ||
           (qname.compareToIgnoreCase(XMLVector.THISTAG)    == 0)) {

            if(nested <= 0)
                currentIndex++;
        }

        debug("xmlElementStop (" + qname + ") " +
              "size = " + size + "  currentIndex = " + currentIndex + "  nested = " + nested);
    }

    /**
     * This retreives this object String representation
     * @return this object XML String representation
     */
    public String toString() {
        return toXml();
    }

    /**
     * This retreives this content
     * @return an vector
     */
    public Object getValue() {
        return (Object)getVector();
    }

    /**
     * This retreives this content
     * @return an vector
     */
    public Vector getVector () {

        Vector ret = new Vector(size);

        for(int i = 0; i < size; i++) {

            Object v = values[i].getValue();

            ret.add(v);
        }

        return ret;
    }

    /**
     * This is for testing only.<br />
     * If argv[0] is empty this creates a dummy XML representation<br />
     * Otherwise, argv[0] may content an XML file name containing 
     * an XML representation to read. <br />
     * <br />
     * The dummy or read representation is finally dumped
     */
    public static void main(String[] argv) {
        try {
            Vector v = new Vector();
            Vector v2 = new Vector();
            v.add(new String("un"));
            v.add(new Integer(2));
            v.add(UID.NULLUID);
            v2.add(new String("dix"));
            v2.add(new String("cent"));
            v.add(v2);
            Hashtable h = new Hashtable();
            h.put(new Integer(1), new String("un"));
            h.put(new String("deux"), new Integer(2));
            v.add(h);
            XMLVector xmlv = new XMLVector(v);

            if(argv.length == 1)
                xmlv = new XMLVector(new DataInputStream(new FileInputStream(argv[0])));

            System.out.println(xmlv.toXml());

            if(!xmlv.debug())
                return;

            Vector ret = xmlv.getVector();
            System.out.println(ret);
            Enumeration myenum = ret.elements();
            for(; myenum.hasMoreElements(); ) {

                Object k = myenum.nextElement(); 						

                if(k == null)
                    continue;

                System.out.println("[" + k + "] " + k.getClass());
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
