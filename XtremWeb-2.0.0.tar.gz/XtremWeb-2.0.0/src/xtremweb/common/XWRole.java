package xtremweb.common;

/**
 * XWRole.java
 *
 * Created: Mar 8th, 2007
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This class describes xtremweb roles
 */

public enum XWRole {

    /** This defines unknown role */
    UNKNOWN,
    /** This defines worker role */
    WORKER,
    /** This defines client role */
    CLIENT,
    /** This defines dispatcher (aka server) role */
    SERVER;

	/**
	 * This retreives enum from integer value
	 * @param v is the integer value of the enum
	 * @return an XWRole
	 */
	public static XWRole fromInt(int v) throws IndexOutOfBoundsException {
	    for (XWRole c : XWRole.values()) {
            if(c.ordinal() == v)
                return c;
	    }
	    throw new IndexOutOfBoundsException("unvalid XWRole value " + v);
	}

	/**
	 * This retreives enum from string value
	 * @param v is the String value of the enum
	 * @return an XWRole
	 */
	public static XWRole fromString(String v) throws IndexOutOfBoundsException {
        if(v == null)
            throw new IndexOutOfBoundsException("unvalid XWRole : null value");

	    for (XWRole c : XWRole.values()) {
            if(c.toString().compareToIgnoreCase(v) == 0)
                return c;
	    }
	    throw new IndexOutOfBoundsException("unvalid XWRole value " + v);
	}

    /** 
     * This defines the current role.
     * This is initialized to UNKNOWN
     */
    public static XWRole myRole = UNKNOWN;

    /**
     * This setS the current role to worker
     */
    public static void setRole(XWRole r) {
        if(myRole != UNKNOWN)
            System.out.println("setRole : role redefined ?! (was " + myRole + ")");
        myRole = r;
    }
    /**
     * This setS the current role to worker
     */
    public static void setWorker() {
        if(myRole != UNKNOWN)
            System.out.println("setWorker : role redefined ?! (was " + myRole + ")");
        myRole = WORKER;
    }
    /**
     * This sets the current role to dispatcher
     */
    public static void setDispatcher() {
        if(myRole != UNKNOWN)
            System.out.println("setDispatcher : role redefined ?! (was " + myRole + ")");
        myRole = SERVER;
    }
    /**
     * This sets the current role to client
     */
    public static void setClient() {
        if(myRole != UNKNOWN)
            System.out.println("setClient : role redefined ?! (was " + myRole + ")");
        myRole = CLIENT;
    }
    /**
     * This tests whether role is worker
     */
    public static boolean isWorker() {
        return(myRole == WORKER);
    }
    /**
     * This tests whether role is dispatcher
     */
    public static boolean isDispatcher() {
        return(myRole == SERVER);
    }
    /**
     * This tests whether role is client
     */
    public static boolean isClient() {
        return(myRole == CLIENT);
    }


    /**
     * This array defines roles class names
     */
    private static final String[] classNames = {
        "unknown",
        "xtremweb.worker.Worker",
        "xtremweb.client.Client",
        "xtremweb.dispatcher.Dispatcher"
    };

    /** 
     * This converts this enum to a String.
     * @return a string containing boolean value
     */
    public String className() {
        return classNames[this.ordinal()];
    }
}
