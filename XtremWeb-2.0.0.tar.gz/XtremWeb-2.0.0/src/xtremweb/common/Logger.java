
package xtremweb.common;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;

/** 
 * Logger.java
 *
 * Created : 15 avril 2008
 *
 * @author Oleg Lodygensky
 */

public class Logger implements Loggerable {

    protected LoggerLevel level;
    private   String className = null;

    public LoggerLevel getLoggerLevel() {
        return level;
    }

    public void setLoggerLevel(LoggerLevel l) {
        level = l;
    }

    public Logger() {
        level = LoggerLevel.INFO;
    }
    public Logger(LoggerLevel l) {
        level = l;
    }

    /**
     * This helps to format date : the format is "yyyy-MM-dd HH:mm:ss"
     */
    public  final SimpleDateFormat logDateFormat = new SimpleDateFormat("[dd/MMM/yyyy:HH:mm:ss Z]", Locale.US);
    
    /**
     * This logs out a message
     */
    public void printLog(String msg) {
        if(className == null)
            className = this.getClass().getName();
        System.out.println (logDateFormat.format(new Date()) +
                            " [" +  className + "] " + 
                            level + " : " + msg);
    }

    /**
     * This tells whether debug level is set to DEBUG
     * @return true if debug level is set to DEBUG
     */
    public  boolean debug() {
        return (level.ordinal() <= LoggerLevel.DEBUG.ordinal());
    }
    /**
     * This logs out a DEBUG message
     */
    public  void debug(String msg) {
        if (debug())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to INFO
     * @return true if debug level is set to INFO
     */
    public  boolean info() {
        return (level.ordinal() <= LoggerLevel.INFO.ordinal());
    }
    /**
     * This logs out an INFO message
     */
    public  void info(String msg) {
        if (info())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to WARN
     * @return true if debug level is set to WARN
     */
    public  boolean warn() {
        return (level.ordinal() <= LoggerLevel.WARN.ordinal());
    }
    /**
     * This logs out a WARN message
     */
    public  void warn (String msg) {
        if (warn())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to ERROR
     * @return true if debug level is set to ERROR
     */
    public  boolean error() {
        return (level.ordinal() <= LoggerLevel.ERROR.ordinal());
    }
    /**
     * This logs out an ERROR message
     */
    public  void error(String msg) {
        if(error())
            printLog(msg);
    }
}
