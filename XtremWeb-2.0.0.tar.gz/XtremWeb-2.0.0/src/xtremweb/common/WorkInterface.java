package xtremweb.common;


import java.io.IOException;
import java.io.DataInputStream;
import java.util.Date;
import java.util.StringTokenizer;
import java.sql.ResultSet;
import java.text.ParseException;
import java.security.AccessControlException;

import org.xml.sax.Attributes;

/**
 * WorkInterface.java
 *
 * Created: Feb 19th, 2002
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This describes an XtremWeb work. <br />
 * This describes a row of the works SQL table on server side.<br />
 * This aims to transfert work through the network too.
 */
public class WorkInterface extends TableInterface {

    /**
     * This enumerates this interface columns
     */
    public enum Columns {

        /**
         * This is the column index of the unique identifier
         */
        UID,
        /**
         * This is the column index of the session UID, if any
         */
        SESSIONUID,
        /**
         * This is the column index of the group UID, if any
         */
        GROUPUID,
        /**
         * This is the column index of the worker we want to run this work
         * @since RPCXW
         */
        EXPECTEDHOSTUID,
        /**
         * This is the column index of this work access rights
         * if any<br />
         */
        ACCESSRIGHTS,
        /**
         * This is the column index of the flag which says whether the job
         * is a service
         * @since RPCXW
         */
        ISSERVICE,
        /**
         * This is the column index of the deleted flag
         * @since 2.0.0
         */
        ISDELETED,
        /**
         * This is the column index of the label, if any
         */
        LABEL,
        /**
         * This is column index of the the application UID
         */
        APPUID,
        /**
         * This is the column index of the user UID
         */
        USERUID,
        /**
         * This is the column index of the status
         */
        STATUS,
        /**
         * This is the column index of the application return code
         */
        RETURNCODE,
        /**
         * This is the column index of either the server name as found from any DNS, 
         * or the server IP address
         */
        SERVER,
        /**
         * This is the column index of the command line, if any
         */
        CMDLINE,
        /**
         * This is the column index of the stdin data URI, if any
         * If not set, this is replaced by AppInterface#STDIN
         * @see AppInterface#STDIN
         */
        STDINURI,
        /**
         * This is the column index of the environment data URI, if any
         * If not set, this is replaced by AppInterface#DIRIN
         * @see AppInterface#DIRIN
         */
        DIRINURI,
        /**
         * This is the column index of the result data URI, if any
         */
        RESULTURI,
        /**
         * This is the column index of the arrival date
         */
        ARRIVALDATE,
        /**
         * This is the column index of the completed date
         */
        COMPLETEDDATE,
        /**
         * This is the column index of the error message, if any
         */
        ERROR_MSG,
        /**
         * This is the column index of the flag to tell whether this is 
         * sent to client
         */
        SENDTOCLIENT,
        /**
         * This is the column index of the flag to tell whether this is
         * a server local work or a replicated workd
         */
        LOCAL,
        /**
         * This is the column index of the active flag
         */
        ACTIVE,
        /**
         * This is the column index of the replicated flag
         */
        REPLICATED,
        /**
         * This is the column index of the max retry 
         */
        MAXRETRY,
        /**
         * This is the column index of the minimum memory needed to run job
         * for this application<br />
         * <h3>This is not used yet</h3>
         */
        MINMEMORY,
        /**
         * This is the column index of the minimum CPU spped needed to run job
         * for this application<br />
         * <h3>This is not used yet</h3>
         */
        MINCPUSPEED;


        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns c : Columns.values()) {
                if(c.ordinal() == v)
                    return c;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[MINCPUSPEED.ordinal() + 1];
            for (Columns column : Columns.values())
                labels[column.ordinal()] = column.toString();
            return labels;
        }
    }


    /**
     * This is the XML tag
     */
    public static final String THISTAG = "work";

    /**
     * This is the default constructor
     */
    public WorkInterface() {

        super(THISTAG);

        LAST_ATTRIBUTE = Columns.MINCPUSPEED.ordinal();
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values = new Object[MAX_ATTRIBUTE];
        setService(false);
        setReplicated(false);
        setSendToClient(false);
        setDeleted(false);
        setAccessRights(XWAccessRights.DEFAULT);
    }

    /**
     * This  is a copy constructor
     * @param src is the WorkInterface to clone
     */
    public WorkInterface(WorkInterface src) throws IOException{

        this();
        setUID(src.getUID());
        setSession(src.getSession());
        setGroup(src.getGroup());
        setExpectedHost(src.getExpectedHost());
        setApplication(src.getApplication());
        setLabel(src.getLabel());
        setUser(src.getUser());
        setStatus(src.getStatus());
        setReturnCode(src.getReturnCode());
        setMaxRetry(src.getMaxRetry());
        setMinCpuSpeed(src.getMinCpuSpeed());
        setMinMemory(src.getMinMemory());
        setServer(src.getServer());
        setCmdLine(src.getCmdLine());
        setStdin(src.getStdin());
        setDirin(src.getDirin());
        setResult(src.getResult());
        setArrivalDate(src.getArrivalDate());
        setCompletedDate(src.getCompletedDate());
        setErrorMsg(src.getErrorMsg());
        setSendToClient(src.isSendToClient());
        setLocal(src.isLocal());
        setActive(src.isActive());
        setService(src.isService());
        setDeleted(src.isDeleted());
        setAccessRights(src.getAccessRights());
        setReplicated(src.isReplicated());
    }

    /**
     * This constructor reads its definition from an SQL request result
     * @param rs is an SQL request result
     * @exception IOException
     */
    public WorkInterface(ResultSet rs) throws IOException {

        this();

        try {
            setUID(new UID(rs.getString(Columns.UID.toString())));
        }
        catch(Exception e) {
            throw new IOException("Work has no UID");
        }
        try {
            setApplication(new UID(rs.getString(Columns.APPUID.toString())));
        }
        catch(Exception e) {
            throw new IOException("Work " + getUID() + " has no application");
        }
        try {
            setUser(new UID(rs.getString(Columns.USERUID.toString())));
        }
        catch(Exception e) {
            throw new IOException("Work " + getUID() + " has no user");
        }
        try {
            setStatus(XWStatus.valueOf(rs.getString(Columns.STATUS.toString())));
        }
        catch (Exception e) {
            throw new IOException("Work " + getUID() + " has no status");
        }
        try {
            setMinMemory(new Integer(rs.getInt(Columns.MINMEMORY.toString())));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setMinCpuSpeed(new Integer(rs.getInt(Columns.MINCPUSPEED.toString())));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setMaxRetry(new Integer(rs.getInt(Columns.MAXRETRY.toString())));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setReturnCode(new Integer(rs.getInt(Columns.RETURNCODE.toString())));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setAccessRights(new XWAccessRights(rs.getInt(Columns.ACCESSRIGHTS.toString()))); 
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setSession(new UID(rs.getString(Columns.SESSIONUID.toString())));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setGroup(new UID(rs.getString(Columns.GROUPUID.toString())));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setExpectedHost(new UID(rs.getString(Columns.EXPECTEDHOSTUID.toString())));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setStdin(new URI(rs.getString(Columns.STDINURI.toString())));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setDirin(new URI(rs.getString(Columns.DIRINURI.toString())));
        }
        catch(Exception e) {
            // thisis optionnal
        }
        try {
            setResult(new URI(rs.getString(Columns.RESULTURI.toString())));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setLabel(rs.getString(Columns.LABEL.toString()));
        }
        catch(Exception e) {
            // thos is optionnal
        }
        try {
            setCmdLine(rs.getString(Columns.CMDLINE.toString()));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setErrorMsg(rs.getString(Columns.ERROR_MSG.toString()));
        }
        catch(Exception e) {
            // this is optionnal
        }
        try {
            setSendToClient(new Boolean(rs.getString(Columns.SENDTOCLIENT.toString())));
        }
        catch (Exception e) {
            // this is optionnal
        }
        try {
            setLocal(new Boolean(rs.getString(Columns.LOCAL.toString())));
        }
        catch (Exception e) {
            // this is optionnal
        }
        try {
            setActive(new Boolean(rs.getString(Columns.ACTIVE.toString())));
        }
        catch (Exception e) {
            // this is optionnal
        }
        try {
            setReplicated(new Boolean(rs.getString(Columns.REPLICATED.toString())));
        }
        catch (Exception e) {
            // this is optionnal
        }
        try {
            setService(new Boolean(rs.getString(Columns.ISSERVICE.toString())));
        }
        catch (Exception e) {
            // this is optionnal
        }
        try {
            setDeleted(new Boolean(rs.getString(Columns.ISDELETED.toString())));
        }
        catch (Exception e) {
            // this is optionnal
        }
        try {
            setArrivalDate(util.getSQLDateTime(rs.getString(Columns.ARRIVALDATE.toString())));
        }
        catch (Exception e) {
            // this is optionnal
        }
        try {
            setCompletedDate(util.getSQLDateTime(rs.getString(Columns.COMPLETEDDATE.toString())));
        }
        catch (Exception e) {
            // this is optionnal
        }
    } // WorkInterface (ResultSet)

    /**
     * This calls this(StreamIO.stream(input));
     * @param input is a String containing an XML representation
     */
    public WorkInterface(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from input stream providing 
     * XML representation
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public WorkInterface(DataInputStream input) throws IOException{
        this();
        super.fromXml(input);
    }

    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public WorkInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public UID getSession()  {
        try {
            return (UID)getValue(Columns.SESSIONUID);
        }
        catch(NullPointerException e) {
            return null;
        }
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public UID getGroup() {
        try {
            return (UID)getValue(Columns.GROUPUID);
        }
        catch(NullPointerException e) {
            return null;
        }
    }

    /**
     * This retreives the UID
     * @return this attribute
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getUID() throws IOException {
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("WorkInterface#getUID() :  attribute not set");
        }
    }

    /**
     * This retreives this object access rights
     * @return this attribute
     */
    public XWAccessRights getAccessRights() {
        try {
            return (XWAccessRights)getValue(Columns.ACCESSRIGHTS);
        }
        catch(Exception e) {
        }
        setAccessRights(XWAccessRights.DEFAULT);
        return XWAccessRights.DEFAULT;
    }
    /**
     * This gets the expected host UID
     * @return this attribute, or null if not set
     * @since RPCXW
     */
    public UID getExpectedHost()  {
        try {
            return (UID)getValue(Columns.EXPECTEDHOSTUID);
        }
        catch(NullPointerException e) {
            return null;
        }
    }
    /**
     * This retreives the service flag<br />
     * If not set, this attr is forced to false
     * @return true if the work should execute a service, false otherwise
     * @since RPCXW
     */
    public boolean isService() {
        try {
            return ((Boolean)getValue(Columns.ISSERVICE)).booleanValue();
        }
        catch(NullPointerException e) {
            setService(false);
            return false;
        }
    }
    /**
     * This retreives the deleted flag.
     * If not set, this attr is forced to false
     * @return true if deleted, false otherwise
     * @since 2.0.0
     */
    public boolean isDeleted() {
        try {
            return ((Boolean)getValue(Columns.ISDELETED)).booleanValue();
        }
        catch(NullPointerException e) {
            setDeleted(false);
            return false;
        }
    }
    /**
     * This gets this work application UID
     * @return this work application UID
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getApplication() throws IOException{
        try {
            return (UID)getValue(Columns.APPUID);
        }
        catch(NullPointerException e) {
            throw new IOException("WorkInterface#getApplication() : attribute not set");
        }
    }

    /**
     * This gets the job name as defined by user at submission time. <br>
     * Label is optionnal
     * @return this attribute, or null if not set
     */
    public String getLabel() {
        return (String)getValue(Columns.LABEL);
    }

    /**
     * This gets user UID
     * @return this attribute, or null if not set
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getUser() throws IOException {
        try {
            return (UID)getValue(Columns.USERUID);
        }
        catch(NullPointerException e) {
            throw new IOException("WorkInterface#getUser() : attributenot set");
        }
    }

    /**
     * This gets an attribute
     * @exception IOException is thrown if attribute is not set
     * @return this attribute
     */
    public XWStatus getStatus()  {
        try {
            return (XWStatus)getValue(Columns.STATUS);
        }
        catch(NullPointerException e) {
            return null;
        }
    }

    /**
     * This gets an attribute
     * @return job return code, 0 on error
     */
    public int getReturnCode() {
        try {
            Integer ret = (Integer)getValue(Columns.RETURNCODE);
            return ret.intValue();
        }
        catch(NullPointerException e) {
            return 0;
        }
    }

    /**
     * This retreives an attributes;
     * if attr is not set it is forced to 0
     * @return attribute value or 0 if not set
     */		public int getMaxRetry() {
         Integer ret = (Integer)getValue(Columns.MAXRETRY);
         if(ret != null)
             return ret.intValue();
         setMaxRetry(0);
         return 0;
     }

    /**
     * This retreives an attribute;
     * if not set it is forced to 0
     * @return the attribute or 0 if not set
     */
    public int getMinMemory() {
        Integer ret =(Integer)getValue(Columns.MINMEMORY);
        if(ret != null)
            return ret.intValue();
        setMinMemory(0);
        return 0;
    }
    /**
     * This retreives an attribute;
     * if not set it is forced to 0
     * @return the attribute or 0 if not set
     */
    public int getMinCpuSpeed() {
        Integer ret =(Integer)getValue(Columns.MINCPUSPEED);
        if(ret != null)
            return ret.intValue();
        setMinCpuSpeed(0);
        return 0;
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getServer() {
        return (String)getValue(Columns.SERVER);
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getCmdLine() {
        return (String)getValue(Columns.CMDLINE);
    }

    /**
     * This retreives the URI where to get stdin
     * @return this attribute, or null if not set
     */
    public URI getStdin() {
        return (URI)getValue(Columns.STDINURI);
    }

    /**
     * This retreives the URI where to get dirin
     * @return this attribute, or null if not set
     */
    public URI getDirin() {
        return (URI)getValue(Columns.DIRINURI);
    }

    /**
     * This retreives the URI where to get result
     * @return this attribute, or null if not set
     */
    public URI getResult() {
        return (URI)getValue(Columns.RESULTURI);
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getArrivalDate() {
        return (Date)getValue(Columns.ARRIVALDATE);
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getCompletedDate() {
        return (Date)getValue(Columns.COMPLETEDDATE);
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getErrorMsg() {
        return (String)getValue(Columns.ERROR_MSG);
    }

    /**
     * This gets an attribute<br />
     * This attr is forced to false if not set
     * @return this attribute
     */
    public boolean isSendToClient() {
        try {
            Boolean ret = (Boolean)getValue(Columns.SENDTOCLIENT);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setSendToClient(false);
            return false;
        }
    }

    /**
     * This retreives whether this work is local<br />
     * This attr is forced to true, if not set
     * @return this attribute
     */
    public boolean isLocal() {
        try {
            Boolean ret = (Boolean)getValue(Columns.LOCAL);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setLocal(true);
            return true;
        }
    }

    /**
     * This gets an attribute<br />
     * This attr is forced to true, if not set
     * @return this attribute
     */
    public boolean isActive() {
        try {
            Boolean ret = (Boolean)getValue(Columns.ACTIVE);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setActive(true);
            return true;
        }
    }

    /**
     * This retreives whether this job is a replica<br />
     * This attr is forced to false, if not set
     * @return this attribute
     */
    public boolean isReplicated() {
        try {
            Boolean ret = (Boolean)getValue(Columns.REPLICATED);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setReplicated(false);
            return false;
        }
    }

    /*
      public boolean setValue(int column, Object val) {
      return setValue(Columns.fromInt(column), val);
      }
    */
    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) {
        return setValue(Columns.valueOf(attribute.toUpperCase()), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the column to set 
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     */
    public boolean setValue(Columns column, Object val) {
        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), null);

        String v = val.toString();

        switch(column) {
        case SESSIONUID:
        case GROUPUID:
        case UID:
        case APPUID:
        case EXPECTEDHOSTUID:
        case USERUID:
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case STDINURI:
        case DIRINURI:
        case RESULTURI:
            try {
                value = new URI(v);
            }
            catch(Exception e) {
            }
            break;
        case MINMEMORY :
        case MINCPUSPEED :
        case MAXRETRY:
        case RETURNCODE:
            value = new Integer(Integer.parseInt(v));
            break;
        case ACCESSRIGHTS :
            try {
                value = new XWAccessRights(v);
            }
            catch(Exception e) {
            }
            break;
        case CMDLINE:
            // sql query safety : removing  quotes but keeping spaces
            value = v.replaceAll("[\\n\'\"]+", "_");
            break;

        case LABEL:
        case SERVER:
        case ERROR_MSG:
            // sql query safety : removing spaces and quotes
            value = v.replaceAll("[\\n\\s\'\"]+", "_");
            break;

        case STATUS:
            value = XWStatus.valueOf(v);
            break;
						
        case ARRIVALDATE:
        case COMPLETEDDATE:
            if(val instanceof java.util.Date)
                value = val;
            else
                value = util.getSQLDateTime(v);
            break;
						
        case SENDTOCLIENT:
        case LOCAL:
        case ACTIVE:
        case REPLICATED:
        case ISSERVICE:
        case ISDELETED:
            value = new Boolean(v);
            break;
        }
        return super.setValue(column.ordinal(), value);
    }
    /**
     * This sets the job session session is optionnal
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setSession(UID v) {
        return setValue(Columns.SESSIONUID, v);
    }

    /**
     * This sets the job group group is optionnal
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setGroup(UID v) {
        return setValue(Columns.GROUPUID, v);
    }

    /**
     * This sets the job UID UID is mandatory
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setUID(UID v) {
        return setValue(Columns.UID, v);
    }
    /**
     * This sets the access rights
     * @return true is value has changed
     */
    public boolean setAccessRights(XWAccessRights v) {
        return setValue(Columns.ACCESSRIGHTS, v);
    }
    /**
     * This sets the expected worker UID
     * @param v is the new expected worker UID
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     * @since RPCXW
     */
    public boolean setExpectedHost(UID v) {
        if(v != null)
            return setValue(Columns.EXPECTEDHOSTUID, v.toString());
        else
            return setValue(Columns.EXPECTEDHOSTUID, null);
    }
    /**
     * This sets this work application
     * @param v is  the application UID
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setApplication(UID v) {
        return setValue(Columns.APPUID, v);
    }

    /**
     * This sets the job name as defined by user at submission time. <br>
     * Label is optionnal
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setLabel(String v) {
        return setValue(Columns.LABEL, v);
    }

    /**
     * This sets the user UID. <br>
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setUser(UID v) {
        return setValue(Columns.USERUID, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setStatus(XWStatus v) 
        throws ArrayIndexOutOfBoundsException {
        return setValue(Columns.STATUS, v);
    }

    /**
       /**
       * @return true if value has changed, false otherwise
       */
    public boolean setReturnCode(int v) {
        return setValue(Columns.RETURNCODE, new Integer(v));
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setMaxRetry(int v) {
        return setValue(Columns.MAXRETRY, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setMinMemory(int v) {
        return setValue(Columns.MINMEMORY, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setMinCpuSpeed(int v) {
        return setValue(Columns.MINCPUSPEED, new Integer(v));
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setServer(String v) {
        return setValue(Columns.SERVER, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setCmdLine(String v) {
        return setValue(Columns.CMDLINE, v);
    }

    /**
     * This set the URI where to get the stdin
     * @return true if value has changed, false otherwise
     */
    public boolean setStdin(URI v) {
        return setValue(Columns.STDINURI, v);
    }

    /**
     * This set the URI where to get the dirin
     * @return true if value has changed, false otherwise
     */
    public boolean setDirin(URI v) {
        return setValue(Columns.DIRINURI, v);
    }

    /**
     * This set the URI where to get the result
     * @return true if value has changed, false otherwise
     */
    public boolean setResult(URI v) {
        return setValue(Columns.RESULTURI, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setArrivalDate(Date v) {
        return setValue(Columns.ARRIVALDATE, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setCompletedDate(Date v) {
        return setValue(Columns.COMPLETEDDATE, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setErrorMsg(String v) {
        return setValue(Columns.ERROR_MSG, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setSendToClient(boolean v) {
        return setValue(Columns.SENDTOCLIENT, new Boolean(v));
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setLocal(boolean v) {
        return setValue(Columns.LOCAL, new Boolean(v));
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setActive(boolean v) {
        return setValue(Columns.ACTIVE, new Boolean(v));
    }
    /**
     * This set the service flag; this flag is true if this works runs a service (and not an application)
     * @return true if value has changed, false otherwise
     * @since RPCXW
     */
    public boolean setService(boolean v) {
        return setValue(Columns.ISSERVICE, new Boolean(v));
    }
    /**
     * This set the deleted flag
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v) {
        return setValue(Columns.ISDELETED, new Boolean(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setReplicated(boolean v) {
        return setValue(Columns.REPLICATED, new Boolean(v));
    }
    /**
     * This tests user access rights
     * @param user is the UID of the user who try to access
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean checkUserAccessRights(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getUser(), user, XWAccessRights.USERALL);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean checkGroupAccessRights(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPALL);
    }
    /**
     * This tests access rights
     * @return true if others have access rights
     */
    public boolean checkOtherAccessRights()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERALL);
    }
    /**
     * This tests if user can read
     * @param user is the UID of the user who try to read
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanRead(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getUser(), user, XWAccessRights.USERREAD);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanRead(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPREAD);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanRead()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERREAD);
    }
    /**
     * This tests if user can write
     * @param user is the UID of the user who try to write
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanWrite(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getUser(), user, XWAccessRights.USERWRITE);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to write
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanWrite(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPWRITE);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanWrite()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERWRITE);
    }

    /**
     * This tests if user can exec
     * @param user is the UID of the user who try to exec
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanExec(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getUser(), user, XWAccessRights.USEREXEC);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to exec
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanExec(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPEXEC);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanExec()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHEREXEC);
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            WorkInterface work = new WorkInterface();
            work.setUID(UID.myUid);
            work.DUMPNULLS = true;
            System.out.println(work.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
