package xtremweb.common;


/**
 * DataType.java
 *
 * Created: 19 juillet 2006
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @since 1.8.0
 * @version %I%, %G%
 */

/**
 * This class describes static variables that define user right levels
 */

public enum DataType {

    NONE,
    BINARY,
    TEXT,
    ZIP,
    UDPPACKET,
    STREAM;

    public static final DataType LAST = STREAM;
    public static final int SIZE = LAST.ordinal() + 1;

    /**
     * This is the default work result data name.
     * Default result data name : ResultsOf_<workUID>
     */
    public static final String RESULTHEADER = "ResultsOf_";

    /**
     * This array stores enum as string 
     */
    public static String[] labels = null;
    /**
     * This array stores associated file extension
     */
    public static String[] extensions = {
        "",     // NONE
        ".bin", // BINARY
        ".txt", // TEXT
        ".zip", // ZIP
        "",     // UDPPACKET
        ""      // STREAM
    };
    /**
     * This retreives this enum string representation
     * @return a array containing this enum string representation
     */
    public static String[] getLabels() {
        if(labels != null)
            return labels;

        labels = new String[SIZE];
        for (DataType c : DataType.values())
            labels[c.ordinal()] = c.toString();
        return labels;
    }
    /**
     * This retreives this enum string representation
     * @return a array containing this enum string representation
     */
    public String getFileExtension() {
        return extensions[this.ordinal()];
    }
    /**
     * This retreives an DataType from its integer value
     * @param v is the integer value of the DataType
     * @return a DataType
     */
    public static DataType fromInt(int v) throws IndexOutOfBoundsException {
        for (DataType i : DataType.values()) {
            if(i.ordinal() == v)
                return i;
        }
        throw new IndexOutOfBoundsException("unvalid DataType value " + v);
    }

}
