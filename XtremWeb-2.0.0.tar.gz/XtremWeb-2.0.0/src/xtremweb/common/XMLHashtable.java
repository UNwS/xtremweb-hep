package xtremweb.common;

import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import org.xml.sax.Attributes;



/**
 * XMLRPCHashtable.java
 *
 * Created: Nov 16th, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class (un)marshall hashtable
 * This contents tuples (key, value)
 *
 * This may content :
 * <ul>
 *  <li> any object that a constructor like object(String)
 *       (e.g Integer objects have Integer(String) constructor)
 *  <li> hashtables
 *  <li> vectors
 * </ul>
 */
public class XMLHashtable extends XMLValue {

    public static final String THISTAG = "XMLHashtable";

    /**
     * This is the size columns index
     * @see xtremweb.common.XMLable#columns
     */
    private final int SIZE = 0;
    /**
     * This is this hashtable size
     */
    private int size;
    /**
     * This count nested elements since this hashtable may content hashtables
     * and vectors as elements.
     * This is incremented on each new hashtable or vector, and decremented on each
     * vector or hashtable endings.<br />
     *
     * This is needed since SAX API reads input sequentially
     */
    private int nested = 0;
    /**
     * This is the tuples index
     * @see #tuples
     */
    private int currentIndex;
    /**
     * This stores hashtable values, if any
     */
    protected XMLtuple[] tuples;


    /**
     * @param h is the hashtable to (un)marshal
     */
    public XMLHashtable(Hashtable h) {
        super(THISTAG, 0);
        if(h == null)
            return;

        empty = false;

        LAST_ATTRIBUTE = SIZE;
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = new String[MAX_ATTRIBUTE];
        columns[SIZE]    = "SIZE";

        size = h.size();
        currentIndex = 0;

        tuples = new XMLtuple[size];

        Enumeration myenum = h.keys();
        int i = 0;
        for(; myenum.hasMoreElements(); ) {

            Object k = myenum.nextElement(); 						

            if(k == null)
                continue;

            tuples[i++] = new XMLtuple(k, h.get(k));
        }
    }
    /**
     * This constructs a new object from XML attributes 
     * received from an input string
     * @param input is the input string 
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLHashtable(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLHashtable(DataInputStream input) throws IOException{
        this(new Hashtable());
        empty = false;
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLHashtable(Attributes attrs) throws IOException{
        this(new Hashtable());
        empty = false;
        fromXml(attrs);
    }

    private String spaces() {
        String ret = new String();
        for(int i = 0; i <= nested + 1; i++)
            ret += " ";
        return ret;
    }

    /**
     * This serializes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    public String toXml() {

        String ret = "<" + XMLTAG + " " + columns[SIZE] + "=\"" + size + "\" >";

        for(int i = 0; i < size; i++) {
            ret += tuples[i].toXml();
        }
        ret += "</" + XMLTAG + ">";

        return ret;
    }
    /**
     * This writes this object XML representation to output stream
     * @param o is the output stream to write to
     */
    public void toXml(DataOutputStream o) throws IOException {

        String ret = "<" + XMLTAG + " " + columns[SIZE] + "=\"" + size + "\" >";
        o.writeUTF(ret);

        for(int i = 0; i < size; i++) {
            tuples[i].toXml(o);
        }
        ret = "</" + XMLTAG + ">";
        o.writeUTF(ret);
    }
    /**
     * This 
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

        if(attrs == null) {
            throw new IOException("attrs is null");
        }

        size = 0;

        for(int a = 0; a < attrs.getLength(); a++) {
            String attribute = attrs.getQName(a);
            String value = attrs.getValue(a);
            if(attribute.compareToIgnoreCase(columns[SIZE]) == 0)
                size = new Integer(value).intValue();
        }
        if (size > 0)
            tuples = new XMLtuple[size];
        currentIndex = 0;
    }

    /**
     * This is called to decode XML elements.
     * This increments nested on each "<XMLHashtable>" or "<XMLVector>"
     * @see #nested
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public void xmlElementStart(String uri, String tag, String qname, 
                                Attributes attrs)
        throws IOException {

        debug("xmlElementStart (" + qname + ") " +
              "size = " + size + "  currentIndex = " + currentIndex + "  nested = " + nested);

        if((size == 0) && (qname.compareToIgnoreCase(XMLTAG) == 0)) {	
            debug("" + qname + ".fromXml(attrs)");
            fromXml(attrs);
        }
        else {

            if(size <= 0)
                throw new IOException("size <= 0 ?!?!");

            if((qname.compareToIgnoreCase(XMLHashtable.THISTAG) == 0) ||
               (qname.compareToIgnoreCase(XMLVector.THISTAG)    == 0)) {

                nested++;
            }

            if(tuples[currentIndex] == null) {
                debug("tuples[" + currentIndex + "]  = new XMLtuple(" + qname + ")");
                tuples[currentIndex] = new XMLtuple(attrs);
            }

            //
            // XMLtuple manages XMLKey and XMLValue
            //
            debug("tuples[" + currentIndex + "].xmlElementStart(" + qname + ")");
            tuples[currentIndex].xmlElementStart(uri, tag, qname, attrs);
        }
    }

    /**
     * This decrements nested on each "</XMLHashtable>" or "</XMLVector>".<br />
     * This increment currentIndex is nested is 0;
     * otherwise this calls tuples[currentIndex].xmlElementStop()
     * @see #nested
     * @see #currentIndex
     * @see xtremweb.common.XMLObject#xmlElementStop(String, String, String)
     */
    public void xmlElementStop(String uri, String tag, String qname)
        throws IOException {

        if(currentIndex < size)
            tuples[currentIndex].xmlElementStop(uri, tag, qname);

        if((qname.compareToIgnoreCase(XMLHashtable.THISTAG) == 0) ||
           (qname.compareToIgnoreCase(XMLVector.THISTAG)    == 0)) {

            nested--;
        }

        if(qname.compareToIgnoreCase(XMLtuple.THISTAG) == 0) {
            if(nested <= 0)
                currentIndex++;
        }

        debug("xmlElementStop (" + qname + ") " +
              "size = " + size + "  currentIndex = " + currentIndex + "  nested = " + nested);
    }

    /**
     * This retreives this object String representation
     * @return this object XML String representation
     */
    public String toString() {
        return toXml();
    }

    /**
     * This retreives this content
     * @return an hashtable
     */
    public Object getValue() {
        return (Object)getHashtable();
    }

    /**
     * This retreives this content
     * @return an hashtable
     */
    public Hashtable getHashtable () {

        Hashtable ret = new Hashtable(size);

        for(int i = 0; i < size; i++) {

            Object k = tuples[i].getKey();
            Object v = tuples[i].getValue();

            ret.put(k,v);
        }

        return ret;
    }

    /**
     * This is for testing only.<br />
     * If argv[0] is empty this creates a dummy XML representation<br />
     * Otherwise, argv[0] may content an XML file name containing 
     * an XML representation to read. <br />
     * <br />
     * The dummy or read representation is finally dumped
     */
    public static void main(String[] argv) {
        try {
            Vector v = new Vector();
            v.add(new String("a string in vector"));
            v.add(new Integer(100));
            v.add(new Boolean("true"));
            Hashtable h = new Hashtable();
            Hashtable h2 = new Hashtable();
            h.put(new Integer(1), new String("un"));
            h.put(new String("deux"), new Integer(2));
            h.put(new String("a vector"), v);
            h.put(new String("a null UID"), UID.NULLUID);
            h.put(new String("a false boolean"), new Boolean("false"));
            h2.put(new Integer(10), new String("dix"));
            h2.put(new String("dix"), new Integer(10));
            h2.put(new String("a vector"), v);
            h.put(new String("an hashtable"), h2);
            XMLHashtable xmlh = new XMLHashtable(h);

            if(argv.length == 1)
                xmlh = new XMLHashtable(new DataInputStream(new FileInputStream(argv[0])));

            System.out.println(xmlh.toXml());

            if(!xmlh.debug())
                return;

            Hashtable ret = xmlh.getHashtable();
            System.out.println(ret);
            Enumeration myenum = ret.keys();
            for(; myenum.hasMoreElements(); ) {

                Object k = myenum.nextElement(); 						

                if(k == null)
                    continue;

                System.out.println("(" + k.toString() + "," +  ret.get(k) + ") " + ret.get(k).getClass());
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
