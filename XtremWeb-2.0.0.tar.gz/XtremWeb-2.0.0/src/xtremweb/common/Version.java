package xtremweb.common;

//
//  Version.java
//
// Assumes that all the version have the same number of digits

import java.io.Serializable;
import java.util.StringTokenizer;

public class Version implements Serializable {
    private String version;
    private String build;
    private String branch;

    private int[] intVersion;

    public String full() {
        return version + "-" + branch;
    }
    public String rev() {
        return version;
    }
    public String branch() {
        return branch;
    }
    public String build() {
        return build;
    }

    public int[] intVersion () {
				return intVersion;
    }

    public boolean lesserThan(Version v) {
				int iv[] = v.intVersion();
				for (int i=0; i<intVersion.length; i++ ) {
						if (intVersion[i] < iv[i] ) return true;
						if (intVersion[i] > iv[i] ) return false;
				} // end of for ()
				return false;
    }

    public boolean greaterThan(Version v) {
				int iv[] = v.intVersion();
				for (int i=0; i<intVersion.length; i++ ) {
						if (intVersion[i] < iv[i] ) return false;
						if (intVersion[i] > iv[i] ) return true;
				} // end of for ()
				return false;
    }

    private Version() {
    }

    public Version(String ver, String bran, String b) {
        version = ver;
        branch = bran;
        build = b;

				//fill the version
				StringTokenizer sk = new StringTokenizer(ver, ".");
				intVersion=new int[sk.countTokens() ];
				for ( int x=0;sk.hasMoreTokens(); x++) {
						intVersion[x]=Integer.parseInt(sk.nextToken());
				}

    }

    public String toString() {
				//				return branch +"-"+version+"-"+build;
				return branch +"-"+version;
    }

}
