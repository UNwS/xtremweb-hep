package xtremweb.common;


import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.Box;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Contains the <tt>JDialog</tt> instance that shows "about" information
 * for the application.
 */

public class AboutWindow {	

    private static final Component HORIZONTAL_SEPARATOR = 
        Box.createRigidArea(new Dimension(6,0));

    /**
     * Constant handle to the <tt>JDialog</tt> that contains about 
     * information.
     */
    private final JDialog DIALOG = new JDialog();

    /**
     * Constant handle to the main <tt>BoxPanel</tt> instance.
     */
    private final BoxPanel MAIN_PANEL = new BoxPanel(BoxPanel.Y_AXIS);

    /**
     * Constant handle to the <tt>ImageIcon</tt> to use for the about 
     * window.
     */
    private final ImageIcon ICON = new ImageIcon();
    //      GUIMediator.getImageResource("searching.gif");

    /**
     * Constant dimension for the dialog.
     */
    private final Dimension DIALOG_DIMENSION = new Dimension(240, 110);


    /**
     * Constructs the elements of the about window.
     */
    public AboutWindow() {
        DIALOG.setModal(true);
        DIALOG.setResizable(false);
        DIALOG.setTitle("About XWHEP");

        // set the main panel's border
        Border border = BorderFactory.createEmptyBorder(12,6,6,6);

        BoxPanel topPanel = new BoxPanel(BoxPanel.X_AXIS);
        topPanel.add(new JLabel(ICON));
        topPanel.add(HORIZONTAL_SEPARATOR);
        topPanel.add(HORIZONTAL_SEPARATOR);
        topPanel.add(HORIZONTAL_SEPARATOR);
        String version = CommonVersion.getCurrent().full();
        String labelStart = new String ("XWHEP");		    
        String labelEnd = new String ("Copyright (c) LAL - http://www.lal.in2p3.fr");
        String labelAddress = new String ("http://www.lal.in2p3.fr");
        String fullLabel = labelStart + " " + version + "\n" + labelAddress +
            "\n" + labelEnd;				
        MultiLineLabel label = new MultiLineLabel(fullLabel);
        label.setFont(new Font("Sans Serif", Font.PLAIN, 11));
        label.setForeground(Color.black);

        BoxPanel labelPanel = new BoxPanel(BoxPanel.Y_AXIS);
        labelPanel.add(Box.createVerticalGlue());
        labelPanel.add(label);

        Dimension labelDim = new Dimension(160, 60);
        labelPanel.setPreferredSize(labelDim);
        labelPanel.setMaximumSize(labelDim);

        topPanel.add(labelPanel);

        MAIN_PANEL.setBorder(border);
        MAIN_PANEL.setPreferredSize(DIALOG_DIMENSION);
        DIALOG.setSize(DIALOG_DIMENSION);
		
        ActionListener closeDialogListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    DIALOG.setVisible(false);
                }
            };

        String[] buttonKeys = {
            "Close"
        };

        String[] buttonTips = {
            "Close dialog box"
        };

        ActionListener[] listeners = {
            closeDialogListener
        };

        ButtonRow buttons = 
            new ButtonRow(buttonKeys, buttonTips, listeners);

        MAIN_PANEL.add(topPanel);
        MAIN_PANEL.add(buttons);
        DIALOG.getContentPane().add(MAIN_PANEL);
        DIALOG.pack();
    }

    /**
     * Displays the "About" dialog window to the user.
     */
    public void showDialog() {
        Dimension screenSize = 
            Toolkit.getDefaultToolkit().getScreenSize();
        int appWidth = 
            Math.min(screenSize.width, DIALOG_DIMENSION.width);
			
        // compare against a little bit less than the screen size,
        // as the screen size includes the taskbar
        int appHeight = 
            Math.min(screenSize.height-40, DIALOG_DIMENSION.height);
        DIALOG.setLocation((screenSize.width - appWidth)/2,
                           (screenSize.height - appHeight)/2);

        DIALOG.setVisible(true);
    }
}
