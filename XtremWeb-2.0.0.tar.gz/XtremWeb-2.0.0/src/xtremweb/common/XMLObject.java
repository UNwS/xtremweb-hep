package xtremweb.common;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Vector;
import java.lang.reflect.Constructor;

import org.xml.sax.Attributes;


/**
 * XMLObject.java
 *
 * Created: March 22nd, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class (un)marshal java.lang.Object to/from XML
 * Objects must be single ones; nor a Vector, neither Hashtable etc.
 */
public abstract class XMLObject extends XMLable {

    protected final String XMLTYPE  = "type";
    protected final String XMLVALUE = "value";

    /**
     * This stores this object value
     */
    protected Class type;
    protected Object value;

    /**
     * This defines an empty object by default
     * (i.e. an XML object like "<XMLObject ... />")
     * If false	this object is not empty
     * (i.e. an XML object like "<XMLObject> ... </XMLObject >")
     */
    protected boolean empty;

    /**
     */
    public XMLObject() {
        super("XMLOBJECT", 1);

        empty = true;
        value = null;
    }
    /**
     * This calls XMLable(String, int)
     * @see XMLable(String, int)
     */
    public XMLObject(String tag, int last) {
        super(tag, last);
        empty = true;
    }
    /**
     */
    public XMLObject(Object v) {
        super("XMLOBJECT", 1);

        value = v;
        empty = true;

        type = v.getClass();
        value = v;
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLObject(DataInputStream input) throws IOException{
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     */
    public XMLObject(Attributes attrs) throws IOException{
        this();
        fromXml(attrs);
    }
    /**
     * This serializes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    public String toXml() {

        String ret = new String ("<" + XMLTAG + " ");
        if(empty)
            ret += XMLTYPE + "=\"" + type.getName() + "\" " + XMLVALUE + "=\"" + value.toString() + "\" />";
        else
            ret += XMLTYPE + "=\"" + type.getName() + "\">" + ((XMLObject)value).toXml() + "</" + XMLTAG + ">";

        return ret;
    }
    /**
     * This writes this object XML representation to output stream
     * @param o is the output stream to write to
     */
    public void toXml(DataOutputStream o) throws IOException {

        String ret = new String ("<" + XMLTAG + " ");
        if(empty)
            ret += XMLTYPE + "=\"" + type.getName() + "\" " + XMLVALUE + "=\"" + value.toString() + "\" />";
        else {
            ret += XMLTYPE + "=\"" + type.getName() + "\">";
            o.writeUTF(ret);
            ((XMLObject)value).toXml(o);
            ret = "</" + XMLTAG + ">";
        }

        o.writeUTF(ret);
    }
    /**
     * This always throws an exception since XMLObject has no attributes
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

        try {
            for(int a = 0; a < attrs.getLength(); a++) {
                String attribute = attrs.getQName(a);
                String v = attrs.getValue(a);

                if(attribute.compareToIgnoreCase(XMLTYPE) == 0) {
                    //
                    // let store the class name
                    //
                    type = Class.forName(v);
                    //										debug("attribute #" + a + " - type = " + type);
                }
                else if(attribute.compareToIgnoreCase(XMLVALUE) == 0) {
                    //
                    // let reconstruct the object with the right class
                    // we try to find : Constructor(String)
                    // a constructor with a single String as parameter
                    //
                    Constructor[] constructors = type.getConstructors();
                    Object[] args = new Object[1];
                    args[0] = v;
                    for(int c = 0; c < constructors.length; c++) {
                        try {
                            value = constructors[c].newInstance(args);
                            break;
                        }
                        catch(Exception e) {
                            if(debug())
                                e.printStackTrace();
                            value = null;
                        }
                    }

                    if(value == null) {
                        //
                        // we did not find any constructor 
                        // with a single String as parameter
                        //
                        warn("constructor not found : " + type + "(String)");
                    }
                    //debug("attribute #" + a + " - type = " + type + " ; value = " + value);
                }
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }
    }

    /**
     * This does nothing since this object has no atributes
     * @see xtremweb.common.XMLable.DescriptionHandler#startElement(String, String, String, Atributes)
     */
    public void xmlElementStart(String uri, String tag, String qname, 
                                Attributes attrs)
        throws IOException {

        if(qname.compareToIgnoreCase(XMLTAG) == 0)
            fromXml(attrs);
    }

    public Object getValue() {
        return value;
    }

    public String toString() {
        return columns[0].toString() + " " + columns[1].toString();
    }
}
