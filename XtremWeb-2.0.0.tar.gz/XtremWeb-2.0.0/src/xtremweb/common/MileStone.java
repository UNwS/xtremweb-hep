package xtremweb.common;

import java.util.Vector;
import java.util.Iterator;

/**
 * This class aims to store time stamps
 */
public class MileStone {

    protected long lastTime,firstTime;


    protected class Stamp {
        public String classeName;
        public String message;
        public long time;
        public UID uid;
        public Stamp(String c, String m, long t, UID u) {
            classeName = c;
            message = m;
            time    = t;
            uid     = u;
        }
        public Stamp(String c, String m, long t) {
            this(c, m, t, null);
        }

        public String toString(long first, long last) {
            return MileStone.toString(classeName, message, 
                                      uid, time, first, last);
        }
    }

    public static String toString(String c, String m,
                                  UID u, long t, long first, long last) {
        long delta = (last  == -1 ? 0 : t - last);
        long total = (first == -1 ? 0 : t - first);

        // 				return new String(c + ";" + m + ";" +
        // 													(u == null ? "" : u.toString()) + ";" +
        // 													+ t + ";" + delta + ";" + total);
        return new String(c + ";" + m + ";" + t +
                          (u == null ? "" : ";" + u.toString()));
    }

    /**
     * This contains time snaps
     */
    protected Vector stamps;
    /**
     * This contains class names we want to get statistics for
     */
    protected static Vector classes;
    /**
     * This contains the instance class name
     */
    protected String className;
    /**
     * This tells whether we get statistics for className
     * This is true if classes
     */
    protected boolean print;

    /**
     * This constructs a new instance
     * @param cn is the class name for this instance
     */
    public MileStone(String cn) throws NullPointerException{

        className = cn;

        if((classes == null) || (className == null))
            throw new NullPointerException();

        Iterator li = classes.iterator();
        while(li.hasNext()) {
            String c = (String)li.next();
            print = (className.indexOf(c) != -1);
            if(print)
                break;
        }
        stamps = new Vector();
    }

    /**
     * This constructs a new instance and sets classes attribute<br />
     * If classes is already set, this does nothing
     * @param v is a Vector of String containing class names to feed classes
     * @see #classes
     */
    public MileStone(Vector v) {

        if(classes != null)
            return;

        classes = v;
        print = false;
        className = null;
    }

    /**
     * This retreives stamp flag
     * @return true if time slicing, false otherwise
     */
    public boolean print() {
        return print;
    }

    /**
     * This cancels last snap shot
     */
    public void cancel() {
        int size = stamps.size();
        if(size > 0)
            stamps.removeElementAt(size - 1);
    }

    /**
     * This takes a snap shot
     * @param msg is the string to print
     */
    public void stamp(String msg) {
        stamp(msg, null);
    }

    /**
     * This takes a snap shot
     * @param msg is the string to print
     */
    public void stamp(String msg, UID uid) {
        if(print == false)
            return;
        stamps.add(new Stamp(className ,msg,
                             System.currentTimeMillis(),
                             uid));
    }

    /**
     * This prints out all snap shots<br />
     * This clears stamps
     */
    public void dump() {
        dump((UID)null);
    }

    /**
     * This prints out all snap shots appending uid<br />
     * This clears stamps
     * @param uid to append to each message
     */
    public void dump(UID uid) {

        lastTime = -1;

        // 				Iterator li = stamps.iterator();
        // 				while(li.hasNext()) {
        // 						Stamp s = (Stamp)li.next();						
        // 						System.out.println(s.toString(firstTime, lastTime));
        // 						lastTime = s.time;
        // 				}
        while(stamps.size() > 0) {
            try {
                Stamp s = (Stamp)stamps.remove(0);						
                System.out.println(s.toString(firstTime, lastTime));
                lastTime = s.time;
            }
            catch(Exception e) {
            }
        }
        stamps.clear();
    }

    /**
     * This clears all stamps
     */
    public void clear() {
        stamps.clear();
        firstTime = lastTime = System.currentTimeMillis();
    }

    /**
     * This prints out a mile stone, if class name matches classes
     * @param msg is the string to print
     * @see #className
     * @see #classes
     */
    public void println(String msg) {
        println(msg, null);
    }

    /**
     * This prints out a mile stone, if class name matches classes
     * @param msg is the string to print
     * @param uid is appended at the end of the message
     * @see #className
     * @see #classes
     */
    public void println(String msg, UID uid) {
        if(print == false)
            return;
        long t = System.currentTimeMillis();
        System.out.println(toString(className ,msg, uid,
                                    t, firstTime, lastTime));
        lastTime = t;
    }
}
