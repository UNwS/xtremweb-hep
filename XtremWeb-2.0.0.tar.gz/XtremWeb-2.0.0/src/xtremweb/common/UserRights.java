package xtremweb.common;

import java.io.*;
import java.sql.*;
import java.util.StringTokenizer;


/**
 * UserRights.java
 *
 * Created: Nov 3rd, 2003
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This class describes static variables that define user right levels
 */

public enum UserRights {

    // normal rights

    NONE,
    LISTJOB,
    INSERTJOB,
    GETJOB,
    DELETEJOB,

    LISTDATA,
    INSERTDATA,
    GETDATA,
    DELETEDATA,

    LISTGROUP,
    INSERTGROUP,
    GETGROUP,
    DELETEGROUP,

    LISTSESSION,
    INSERTSESSION,
    GETSESSION,
    DELETESESSION,

    LISTHOST,
    GETHOST,

    LISTUSER,
    GETUSER,

    LISTUSERGROUP,
    GETUSERGROUP,

    LISTAPP,
    GETAPP,

    STANDARD_USER,

    // This is a special case, allowing user rights delegation to workers
    // e.g. workers must be able to update works and change works status (among others)

    UPDATEWORK,

    WORKER_USER,

    // advanced rights

    INSERTHOST,
    DELETEHOST,

    INSERTAPP,
    DELETEAPP,

    ADVANCED_USER,

    // privileged rights

    INSERTUSER,
    DELETEUSER,

    INSERTUSERGROUP,
    DELETEUSERGROUP,

    SUPER_USER;



    public static final UserRights LAST = SUPER_USER;
    public static final int SIZE = LAST.ordinal() + 1;

    /**
     * This tests whether this is higher than the provided parameter
     * @param c is the value to compare
     * @return true if this is higher than the parameter, false otherwise 
     */
    public boolean higherThan(UserRights c) {
        System.out.println(this.ordinal() + ".higherThan(" + c.ordinal() + ") = " +
                           (this.ordinal() > c.ordinal()));
        return this.ordinal() > c.ordinal();
    }
    /**
     * This tests whether this is higher or equal than the provided parameter
     * @param c is the value to compare
     * @return true if this is higher or equal than the parameter, false otherwise 
     */
    public boolean higherOrEquals(UserRights c) {
        return this.ordinal() >= c.ordinal();
    }
    /**
     * This tests whether this is lower than the provided parameter
     * @param c is the value to compare
     * @return true if this is lower than the parameter, false otherwise 
     */
    public boolean lowerThan(UserRights c) {
        return this.ordinal() < c.ordinal();
    }
    /**
     * This tests whether this is lower or equal than the provided parameter
     * @param c is the value to compare
     * @return true if this is lower or equal than the parameter, false otherwise 
     */
    public boolean lowerOrEquals(UserRights c) {
        return this.ordinal() <= c.ordinal();
    }
    /**
     * This tests whether this equals the provided parameter
     * @param c is the value to compare
     * @return true if this equals the parameter, false otherwise 
     */
    public boolean equals(UserRights c) {
        return this.ordinal() == c.ordinal();
    }

    /**
     * This retreives an Columns from its integer value
     * @param v is the integer value of the Columns
     * @return an Columns
     */
    public static UserRights fromInt(int v) throws IndexOutOfBoundsException {
        for (UserRights c : UserRights.values()) {
            if(c.ordinal() == v)
                return c;
        }
        throw new IndexOutOfBoundsException("unvalid status " + v);
    }

    /**
     * This array stores enum as string 
     */
    public static String[] labels = null;
    /**
     * This retreives this enum string representation
     * @return a array containing this enum string representation
     */
    public static String[] getLabels() {
        if(labels != null)
            return labels;

        labels = new String[SIZE];
        for (UserRights c : UserRights.values())
            labels[c.ordinal()] = c.toString();
        return labels;
    }

    public static void main(String[] argv) {
        for (UserRights r : UserRights.values())
            System.out.println(r.toString() + " = " + r.ordinal());
    }

}
