/**
 * Project : XTremWeb
 * File    : TracesConfig.java
 *
 * Date   : March 2002
 * By     : Oleg Lodygensky
 * e-mail : lodygens /at\ .in2p3.fr
 */

package xtremweb.common;

public class TracesConfig
{
  public String hostName;
  public String timeZone;
  public String ipAddr;
  public String hwAddr;
  public String version;
  public int    resultDelay;
  public int    sendResultDelay;
}
