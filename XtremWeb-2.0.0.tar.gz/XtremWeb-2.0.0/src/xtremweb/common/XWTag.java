package xtremweb.common;

import java.io.IOException;


public enum XWTag {

    APP,
    DATA,
    GROUP,
    HOST,
    JOB,
    SESSION,
    TASK,
    TRACE,
    USERGROUP,
    USER,
    WORK;

    public static final XWTag LAST = WORK;
    public static final int SIZE = LAST.ordinal() + 1;

    /**
     * This retreives an XWTag from its integer value
     * @param v is the integer value of the XWTag
     * @return an XWTag
     */
    public static XWTag fromInt(int v) throws IndexOutOfBoundsException {
	for (XWTag i : XWTag.values()) {
	    if(i.ordinal() == v)
		return i;
	}
	throw new IndexOutOfBoundsException("unvalid XWTag value " + v);
    }

    public static void main(String[] argv) {
	for (XWTag i : XWTag.values())
	    System.out.println(i.toString() + " = " + i.ordinal() +
			       " valueOf() = " + i.valueOf(i.toString()));
    }

}
