package xtremweb.common;
import java.io.*;
/**
 * XWMAPanel.java
 *
 * Purpose : 
 * Created : Nov 30 2001
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

public class WorkerParameters implements java.io.Serializable
{
  public int sendResultDelay;
  public int resultDelay;

  public WorkerParameters() {
  }

}
