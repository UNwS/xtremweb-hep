/**
 * Project : XTremWeb
 * File    : TracerZipFile.java
 *
 * Initial revision : July 2001
 * By               : Anna Lawer
 *
 * New revision : January 2002
 * By           : Oleg Lodygensky
 * e-mail       : lodygens /at\ .in2p3.fr
 */

package xtremweb.common;


import java.io.*;
import java.util.zip.*;
import java.util.zip.ZipOutputStream.*;
import java.util.*;
import java.util.zip.ZipFile.*;



public class TracerZipFile {

		private ZipOutputStream outfile = null;
		private ZipFile infile = null;


		/**
		 * This is the constructor to create read only file.
		 */
		public TracerZipFile (String filename) {
				try {
						infile = new ZipFile (filename);
				}
				catch (Exception e) {
						System.err.println(e.toString ());
				}
		}


		/**
		 * This is the constructor to create write only file.
		 * It inserts header (ie configuration) in zip file.
		 *
		 * @param filename is the name of the file to create.
		 * @param host contains the host definition.
		 * @param resultDelay contains the trace period.
		 * @param sendResultDelay contains the send trace period.
		 */
		public TracerZipFile (String filename,
													HostInterface host,
													int resultDelay,
													int sendResultDelay) {

				try {
						outfile = new ZipOutputStream(new FileOutputStream(filename));

						ZipEntry zipEntry;

						String lineFeed = new String ("\n\r");

						zipEntry = new ZipEntry ("Configuration");
						outfile.putNextEntry (zipEntry);

						outfile.write (host.getName ().getBytes ());
						outfile.write (lineFeed.getBytes ());

						outfile.write (host.getTimeZone ().getBytes ());
						outfile.write (lineFeed.getBytes ());

						outfile.write (host.getIPAddr ().getBytes ());
						outfile.write (lineFeed.getBytes ());

						outfile.write (host.getHWAddr ().getBytes ());
						outfile.write (lineFeed.getBytes ());

						String version = host.getVersion();
						outfile.write (version.getBytes ());
						outfile.write (lineFeed.getBytes ());

						outfile.write (String.valueOf (resultDelay).getBytes ());
						outfile.write (lineFeed.getBytes ());

						outfile.write (String.valueOf (sendResultDelay).getBytes ());
						outfile.write (lineFeed.getBytes ());

						outfile.closeEntry();
				}
				catch (Exception e) {
						System.err.println (e.toString());
				}

		} // TracerZipFile ()


		public void close () {
				try {
						if (outfile != null)
								outfile.close();
						if (infile != null)
								infile.close();
				}
				catch(Exception e) {
				}
		} // close ()


		/**
		 * This is the constructor to create write only file.
		 * It inserts header (ie configuration) in zip file.
		 *
		 * @param entryName is the name of the entry to create.
		 * @param fileName is the name of the data file.
		 */
		public void addEntry(String entryName, String fileName)
				throws Exception {
				try {

						File file = new File(fileName);
						FileInputStream dataIn = new FileInputStream (file);
						ZipEntry zipEntry;

						zipEntry = new ZipEntry (entryName);
						outfile.putNextEntry (zipEntry);

						while(dataIn.available() != 0) {
								outfile.write(dataIn.read());
						}

						dataIn.close();
						outfile.closeEntry();
				}
				catch(Exception e) {
						e.printStackTrace();
						throw e;
				}

		} //  addEntry()


		private  byte[] readEntry(String entryName)
				throws IOException {

				ZipEntry ze = infile.getEntry (entryName);
				InputStream istr = infile.getInputStream(ze);
				BufferedInputStream bis =
						new BufferedInputStream(istr);
				int sz = (int)ze.getSize();
				final int N = 1024;
				byte buf[] = new byte[sz];

				if (bis.read(buf, 0, Math.min(N, sz)) == -1)
						return null;

				bis.close();

				return buf;
		}


		private TracesConfig readTracesConfig ()
				throws Exception {

				TracesConfig ret = new TracesConfig ();

				try {
						byte buf[] =  readEntry ("Configuration");
						String strBuf = new String (buf);
						String lineFeed = new String ("\n\r");
						int indexStart = 0;
						int indexEnd = 0;

						indexEnd = strBuf.indexOf (lineFeed);
						if (indexEnd == -1)
								return null;
						ret.hostName = new String (strBuf.substring (indexStart, indexEnd));

						indexStart = indexEnd + lineFeed.length ();
						indexEnd = strBuf.indexOf (lineFeed, indexStart);
						if (indexEnd == -1)
								return null;
						ret.timeZone = new String (strBuf.substring (indexStart, indexEnd));

						indexStart = indexEnd + lineFeed.length ();
						indexEnd = strBuf.indexOf (lineFeed, indexStart);
						if (indexEnd == -1)
								return null;
						ret.ipAddr = new String (strBuf.substring (indexStart, indexEnd));

						indexStart = indexEnd + lineFeed.length ();
						indexEnd = strBuf.indexOf (lineFeed, indexStart);
						if (indexEnd == -1)
								return null;
						ret.hwAddr = new String (strBuf.substring (indexStart, indexEnd));

						indexStart = indexEnd + lineFeed.length ();
						indexEnd = strBuf.indexOf (lineFeed, indexStart);
						if (indexEnd == -1)
								return null;
						ret.version = new String (strBuf.substring (indexStart, indexEnd));

						indexStart = indexEnd + lineFeed.length ();
						indexEnd = strBuf.indexOf (lineFeed, indexStart);
						if (indexEnd == -1)
								return null;
						ret.resultDelay = new Integer(new String (strBuf.substring (indexStart, indexEnd))).intValue ();

						indexStart = indexEnd + lineFeed.length ();
						indexEnd = strBuf.indexOf (lineFeed, indexStart);
						if (indexEnd == -1)
								return null;
						ret.sendResultDelay = new Integer (new String (strBuf.substring (indexStart, indexEnd))).intValue ();
				}
				catch (Exception e) {
						throw e;
				}

				return ret;
		}


		private  short[] readMasks ()
				throws Exception {

				try {
						byte buf[] = readEntry ("mask");
						short[] mask = new short [buf.length / 2];

						//
						// buf [i+1] is the mask LSB
						// buf [i] is the mask MSB
						//

						int maskIndex = 0;
						for (int i = 0; i < buf.length; i+=2) {

								mask[maskIndex] |= byteToShort (buf, i);
								maskIndex++;
						}

						return mask;

				}
				catch (Exception e) {
						throw e;
				}
		}

   
		private  int byteToInt (byte[] buf, int offset)
				throws Exception {

				try {
						int ret  = (int)(0xff000000 & buf [offset] << 24);
						ret |= (int)(0x00ff0000 & buf [offset + 1] << 16);
						ret |= (int)(0x0000ff00 & buf [offset + 2] << 8);
						ret |= (int)(0x000000ff & buf [offset + 3]);

						return ret;
				}
				catch (Exception e) {
						throw e;
				}
		}


		private  short byteToShort (byte[] buf, int offset)
				throws Exception {

				try {
						short ret = 0;
						ret |= (short)(buf [offset] << 8);
						ret |= (short)(0x00ff & buf [offset + 1]);

						return ret;
				}
				catch (Exception e) {
						throw e;
				}
		}


		private  TracerState[] readStates(short[]masks)
				throws Exception {
				int i = 0;

				try {
						byte buf[] = readEntry ("state");
						TracerState[] states = new TracerState [masks.length];

						int bufIdx = 0;

						for (i = 0; i < masks.length; i++) {

								states[i] = new TracerState ();

								if ((masks [i] & 0x01) == 0x01) {
										states [i].cpuUser = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x02) == 0x02) {
										states [i].cpuNice = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x04) == 0x04) {
										states [i].cpuSystem = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x08) == 0x08) {
										states [i].cpuIdle = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x10) == 0x10) {
										states [i].cpuAidle = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x20) == 0x20) {
										states [i].loadOne = byteToShort (buf, bufIdx);
										bufIdx += 2;
								}

								if ((masks [i] & 0x40) == 0x40) {
										states [i].loadFive = byteToShort (buf, bufIdx);
										bufIdx += 2;
								}

								if ((masks [i] & 0x80) == 0x80) {
										states [i].loadFifteen = byteToShort (buf, bufIdx);
										bufIdx += 2;
								}

								if ((masks [i] & 0x0100) == 0x0100) {
										states [i].procRun = byteToShort (buf, bufIdx);
										bufIdx += 2;
								}

								if ((masks [i] & 0x0200) == 0x0200) {
										states [i].procTotal = byteToShort (buf, bufIdx);
										bufIdx += 2;
								}

								if ((masks [i] & 0x0400) == 0x0400) {
										states [i].memFree = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x0800) == 0x0800) {
										states [i].memShared = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x1000) == 0x1000) {
										states [i].memBuffers = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x2000) == 0x2000) {
										states [i].memCached = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x4000) == 0x4000) {
										states [i].swapFree = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}

								if ((masks [i] & 0x8000) == 0x8000) {
										states [i].time = byteToInt (buf, bufIdx);
										bufIdx += 4;
								}
						}

						return states;

				}
				catch (Exception e) {
						throw e;
				}
		}

   
		private  TracerConfig[] readConfigs()
				throws Exception {

				int i = 0;

				try {
						byte buf[] = readEntry ("config");
						TracerConfig[] configs = new TracerConfig [buf.length / TracerConfig.LENGTH];

						int bufIdx = 0;

						for (i = 0; i < configs.length; i++) {

								configs[i] = new TracerConfig ();

								configs [i].cpuNum = byteToShort (buf, bufIdx);
								bufIdx += 2;

								configs [i].cpuSpeed = byteToShort (buf, bufIdx);
								bufIdx += 2;

								configs [i].memTotal = byteToInt (buf, bufIdx);
								bufIdx += 4;

								configs [i].swapTotal = byteToInt (buf, bufIdx);
								bufIdx += 4;

								configs [i].boottime = byteToInt (buf, bufIdx);
								bufIdx += 4;

								configs [i].kernel = new byte [16];
								for (int loop = 0; loop < 16; loop++) {
										configs [i].kernel[loop] = buf [bufIdx];
										bufIdx++;
								}

								configs [i].time = byteToInt (buf, bufIdx);
						}

						return configs;
				}
				catch (Exception e) {
						throw e;
				}
		}


		public Traces read ()
				throws Exception {
				Traces ret = new Traces ();
				int nb;

				try {
						ret.t_config = readTracesConfig ();
						ret.masks = readMasks();
						ret.states = readStates(ret.masks);
						ret.configs = readConfigs ();

						return ret;
				}
				catch (Exception e) {
						throw e;
				}
		}

} //  class TracerZipFile

