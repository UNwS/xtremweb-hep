package xtremweb.common;


import java.util.Date;
import java.sql.ResultSet;
import java.util.StringTokenizer;
import java.io.IOException;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.security.AccessControlException;

import org.xml.sax.Attributes;



/**
 * HostsInterface.java
 *
 * Created: Feb 19th, 2002
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

/**
 * This class describes a row of the hosts SQL table.
 */
public class HostInterface
    extends xtremweb.common.TableInterface {

    /**
     * This enumerates this interface columns
     */
    public enum Columns {

        /**
         * This is the column index of the UID
         * It <b>must</b> be the first attribute since we use it as primary key.
         * @see TableInterface
         */
        UID,
        /**
         * This is the column index of the host name
         */
        NAME,
        /**
         * This is the column index of the connections amount
         */
        NBCONNECTIONS,
        /**
         * This is the column index of the IP address as provided by worker itself
         * This may be a NATed IP address
         * @since 2.0.0
         */
        NATEDIPADDR,
        /**
         * This sets the IP address obtained at connexion time.
         * This is set by server at connexion time
         * This may be different from NATed IP
         */
        IPADDR,
        /**
         * This is the column index of the MAC address
         */
        HWADDR,
        /**
         * This is the column index of the time zone
         */
        TIMEZONE,
        /**
         * This is the column index of the average ping to server
         * @since 2.0.0
         */
        AVGPING,
        /**
         * This is the column index of the ping amount to server
         * @since 2.0.0
         */
        NBPING,
        /**
         * This is the column index of the upload bandwidth usage (in Mb/s)
         * @since 2.0.0
         */
        UPLOADBANDWIDTH,
        /**
         * This is the column index of the download bandwidth usage (in Mb/s)
         * @since 2.0.0
         */
        DOWNLOADBANDWIDTH,
        /**
         * This is the column index of the OS name
         */
        OS,
        /**
         * This is the column index of the cpu type
         */
        CPUTYPE,
        /**
         * This is the column index of the cpu amount
         */
        CPUNB,
        /**
         * This is the column index of the cpu model
         */
        CPUMODEL,
        /**
         * This is the column index of the cpu model
         */
        CPUSPEED,
        /**
         * This is the column index of the cpu speed
         */
        TOTALMEM,
        /**
         * This is the column index of the total memory
         */
        TOTALSWAP,
        /**
         * This is the column index uf the owner UID
         */
        OWNERUID,
        /**
         * This is the column index uf the project.
         * This defines the project this worker wants to participate.
         * This is a usergroup name.
         * This overide owner's usergroup, if any.
         */
        PROJECT,
        /**
         * This is the column index of the last alive date
         */
        LASTALIVE,
        /**
         * This is the column index of the active flag<br />
         * Any erroneus worker is set inactive
         */
        ACTIVE,
        /**
         * This is the column index of the flag to tell whether this
         * has been deleted
         * @since 2.0.0
         */
        ISDELETED,
        /**
         * This is the column index of the host availability flag accordingly to 
         * worker local policy<br />
         * This is refreshed on <code>alive</code> signal
         */
        AVAILABLE,
        /**
         * This is the column index of the host timeout
         */
        TIMEOUT,
        /**
         * This is the column index of the trace flag which says to collect 
         * traces or not
         */
        TRACES,
        /**
         * This is the column index of the average execution time
         */
        AVGEXECTIME,
        /**
         * This is the column index of the time shift
         */
        TIMESHIFT,
        /**
         * This attribute tells whether worker accept application binary
         * If false worker accepts only services
         */
        ACCEPTBIN,
        /**
         * This is the worker software version
         */
        VERSION,
        /**
         * This is the column index of the compued jobs amount
         */
        NBJOBS;

        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns column : Columns.values()) {
                if(column.ordinal() == v)
                    return column;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[NBJOBS.ordinal() + 1];
            for (Columns column : Columns.values())
                labels[column.ordinal()] = column.toString();
            return labels;
        }
    }


    /**
     * This is the XML tag
     */
    public static final String THISTAG = "host";

    /**
     * This is the default constructor
     */
    public HostInterface() {

        super(THISTAG);

        LAST_ATTRIBUTE = Columns.NBJOBS.ordinal();
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values  = new Object[MAX_ATTRIBUTE];
        setDeleted(false);
        setAcceptBin(true);
        setActive(true);
        setAvailable(true);
        setTracing(false);
    }
    /**
     * This constructor reads its definition from an SQL request result
     * @param rs is an SQL request result
     * @exception IOException
     */
    public HostInterface(ResultSet rs) throws IOException {

        this();

        try {

            setNbConnections(new Integer(rs.getInt(Columns.NBCONNECTIONS.toString())));
            setNbPing(new Integer(rs.getInt(Columns.NBPING.toString())));
            setAvgPing(new Integer(rs.getInt(Columns.AVGPING.toString())));
            setCpuNb(new Integer(rs.getInt(Columns.CPUNB.toString())));
            setCpuSpeed(new Long(rs.getInt(Columns.CPUSPEED.toString())));
            setTotalMem(new Long(rs.getInt(Columns.TOTALMEM.toString())));
            setTotalSwap(new Long(rs.getInt(Columns.TOTALSWAP.toString())));
            setAvgExecTime(new Integer(rs.getInt(Columns.AVGEXECTIME.toString()))); 
            setTimeShift(new Integer(rs.getInt(Columns.TIMESHIFT.toString()))); 
            setNbJobs(new Integer(rs.getInt(Columns.NBJOBS.toString()))); 
            setTimeOut(new Integer(rs.getInt(Columns.TIMEOUT.toString()))); 

            setName(rs.getString(Columns.NAME.toString()));
            setIPAddr(rs.getString(Columns.IPADDR.toString()));
            setNatedIPAddr(rs.getString(Columns.NATEDIPADDR.toString()));
            setHWAddr(rs.getString(Columns.HWADDR.toString()));
            setTimeZone(rs.getString(Columns.TIMEZONE.toString()));
            setOs(XWOSes.valueOf(rs.getString(Columns.OS.toString())));
            setCpu(XWCPUs.valueOf(rs.getString(Columns.CPUTYPE.toString())));
            setCpuModel(rs.getString(Columns.CPUMODEL.toString()));
            setVersion(rs.getString(Columns.VERSION.toString()));
            try {
                setOwner(new UID(rs.getString(Columns.OWNERUID.toString())));
            }
            catch(Exception e) {
            }
            try {
                setProject(rs.getString(Columns.PROJECT.toString()));
            }
            catch(Exception e) {
            }
            try {
                setUploadBandwidth(new Float(rs.getFloat(Columns.UPLOADBANDWIDTH.toString()))); 
            }
            catch (Exception e) {
                setUploadBandwidth(0);
            }
            try {
                setDownloadBandwidth(new Float(rs.getFloat(Columns.DOWNLOADBANDWIDTH.toString()))); 
            }
            catch (Exception e) {
                setDownloadBandwidth(0);
            }
            try {
                setDeleted(new Boolean(rs.getString(Columns.ISDELETED.toString())));
            }
            catch (Exception e) {
                setDeleted(new Boolean(false));
            }
            setUID(new UID(rs.getString(Columns.UID.toString())));

            setAcceptBin(new Boolean(rs.getString(Columns.ACCEPTBIN.toString())));
            setActive(new Boolean(rs.getString(Columns.ACTIVE.toString())));
            setAvailable(new Boolean(rs.getString(Columns.AVAILABLE.toString())));
            setTracing(new Boolean(rs.getString(Columns.TRACES.toString())));

            try {
                setLastAlive(util.getSQLDateTime(rs.getString(Columns.LASTALIVE.toString())));
            }
            catch(Exception e) {
            }
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }
    /**
     * This constructs a new object from XML attributes
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public HostInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This calls this(StreamIO.stream(input));
     * @param input is a String containing an XML representation
     */
    public HostInterface(String input) throws IOException {
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public HostInterface(DataInputStream input) throws IOException{
        this();
        super.fromXml(input);
    }
    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getLastAlive() {
        return(Date)getValue(Columns.LASTALIVE);
    }
    /**
     * This retreives the upload bandwidth usage
     * @return this attribute
     * @since 2.0.0
     */
    public float getUploadBandwidth() {
        try {
            return ((Float)getValue(Columns.UPLOADBANDWIDTH)).floatValue();
        }
        catch(Exception e) {
        }
        setUploadBandwidth(0);
        return 0;
    }
    /**
     * This retreives the download bandwidth usage
     * @return this attribute
     * @since 2.0.0
     */
    public float getDownloadBandwidth() {
        try {
            return ((Float)getValue(Columns.DOWNLOADBANDWIDTH)).floatValue();
        }
        catch(Exception e) {
        }
        setDownloadBandwidth(0);
        return 0;
    }
    /**
     * This tests whether this host is selectable for computing<br />
     * A host is inactivated if it has sent a job as ERROR.<br />
     * This can also be(un)activated on client request<br />
     * If this attr is not set it is forced to true
     * @return true if this is attribute is set, false otherwise
     */
    public boolean isActive() {
        try {
            boolean ret =((Boolean)getValue(Columns.ACTIVE)).booleanValue();
            return ret;
        }
        catch(NullPointerException e) {
            setActive(true);
            return true;
        }
    }
    /**
     * This gets an attribute<br />
     * This attr is forced to false if not set
     * @return this attribute
     * @since 2.0.0
     */
    public boolean isDeleted() {
        try {
            Boolean ret = (Boolean)getValue(Columns.ISDELETED);
            return ret.booleanValue();
        }
        catch(NullPointerException e) {
            setDeleted(false);
            return false;
        }
    }
    /**
     * This tests whether this host accept binary application
     * @return true if this is attribute is set, false otherwise
     */
    public boolean acceptBin() {
        try {
            boolean ret =((Boolean)getValue(Columns.ACCEPTBIN)).booleanValue();
            return ret;
        }
        catch(NullPointerException e) {
            setAcceptBin(true);
            return true;
        }
    }
    /**
     * This retreives this host local policy<br />
     * This is set on alive signal<br />
     * If this attr is not set it is forced to false
     * @exception NullPointerException is thrown if attribute is not set
     * @return true if this is attribute is set, false otherwise
     */
    public boolean isAvailable() {
        try {
            boolean ret =((Boolean)getValue(Columns.AVAILABLE)).booleanValue();
            return ret;
        }
        catch(NullPointerException e) {
            setAvailable(false);
            return false;
        }
    }
    /**
     * This tests whether this host collect traces<br />
     * If this attr is not set it is forced to false
     * @exception NullPointerException is thrown if attribute is not set
     * @return true if this is attribute is set, false otherwise
     */
    public boolean isTracing() {
        try {
            boolean ret =((Boolean)getValue(Columns.TRACES)).booleanValue();
            return ret;
        }
        catch(NullPointerException e) {
            setTracing(false);
            return false;
        }
    }

    /**
     * This retreives the amount of computed jobs<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     */
    public int getNbJobs() {
        Integer ret =(Integer)getValue(Columns.NBJOBS);
        if(ret != null)
            return ret.intValue();
        setNbJobs(0);
        return 0;
    }
    /**
     * This retreives the timeout<br />
     * If this attr is not set it is forced to XWConfigurator.DEFTIMEOUT;
     * @return the timeout
     * @see xtremweb.common.XWConfigurator#timeout
     */
    public int getTimeOut() {
        Integer ret =(Integer)getValue(Columns.TIMEOUT);
        if(ret != null)
            return ret.intValue();
        setTimeOut(Integer.parseInt(XWPropertyDefs.TIMEOUT.value()));
        return Integer.parseInt(XWPropertyDefs.TIMEOUT.value());
    }
    /**
     * This tells whether the worker tries to pool as fast as possible
     * @return true is timeout is null, false otherwise
     */
    public boolean isRealTime() {
        return (getTimeOut() == 0);
    }
    /**
     * This retreives an attribute<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     */
    public int getTimeShift() {
        Integer ret =(Integer)getValue(Columns.TIMESHIFT);
        if(ret != null)
            return ret.intValue();
        setTimeShift(0);
        return 0;
    }
    /**
     * This get the average execution time<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     */
    public int getAvgExecTime() {
        Integer ret =(Integer)getValue(Columns.AVGEXECTIME);
        if(ret != null)
            return ret.intValue();
        setAvgExecTime(0);
        return 0;
    }
    /**
     * This retreives the UID
     * @return UID
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getUID() throws IOException{
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("HostInterface#getUID() : attribute not set");
        }
    }
    /**
     * This gets an attribute<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     */
    public int getNbConnections() {
        Integer ret =(Integer)getValue(Columns.NBCONNECTIONS);
        if(ret != null)
            return ret.intValue();
        setNbConnections(0);
        return 0;
    }
    /**
     * This gets an attribute<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     * @since 2.0.0
     */
    public int getNbPing() {
        Integer ret =(Integer)getValue(Columns.NBPING);
        if(ret != null)
            return ret.intValue();
        setNbPing(0);
        return 0;
    }
    /**
     * This gets an attribute<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     * @since 2.0.0
     */
    public int getAvgPing() {
        Integer ret = (Integer)getValue(Columns.AVGPING);
        if(ret != null)
            return ret.intValue();
        setAvgPing(0);
        return 0;
    }
    /**
     * This gets an attribute<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     */
    public int getCpuNb() {
        Integer ret =(Integer)getValue(Columns.CPUNB);
        if(ret != null)
            return ret.intValue();
        setCpuNb(0);
        return 0;
    }
    /**
     * This gets an attribute<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     */
    public long getCpuSpeed() {
        Long ret =(Long)getValue(Columns.CPUSPEED);
        if(ret != null)
            return ret.longValue();
        setCpuSpeed(0L);
        return 0L;
    }
    /**
     * This gets an attribute<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     */
    public long getTotalMem() {
        Long ret = (Long)getValue(Columns.TOTALMEM);
        if(ret != null)
            return ret.longValue();
        setTotalMem(0L);
        return 0L;
    }
    /**
     * This gets an attribute<br />
     * If this attr is not set it is forced to 0
     * @return this attribute or 0 if not set
     */
    public long getTotalSwap() {
        Long ret = (Long)getValue(Columns.TOTALSWAP);
        if(ret != null)
            return ret.longValue();
        setTotalSwap(0L);
        return 0L;
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getName() {
        return(String)getValue(Columns.NAME);
    }
    /**
     * This retreives the IP address as provided by worker itself.
     * This may be a NATed IP
     * @return this attribute, or null if not set
     * @since 2.0.0
     */
    public String getNatedIPAddr() {
        return(String)getValue(Columns.NATEDIPADDR);
    }
    /**
     * This retreives the IP address obtained at connexion time.
     * This is set by server at connexion time.
     * This may be different from NATed IP.
     * @return the expected parameter 
     * @since 2.0.0
     */
    public String getIPAddr() {
        return(String)getValue(Columns.IPADDR);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getHWAddr() {
        return(String)getValue(Columns.HWADDR);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getTimeZone() {
        return(String)getValue(Columns.TIMEZONE);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public XWOSes getOs() {
        return(XWOSes)getValue(Columns.OS);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public XWCPUs getCpu() {
        return(XWCPUs)getValue(Columns.CPUTYPE);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getCpuModel() {
        return(String)getValue(Columns.CPUMODEL);
    }
    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getVersion() {
        return(String)getValue(Columns.VERSION);
    }
    /**
     * This retreives this host owner
     * @return this attribute, or null if not set
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getOwner() throws IOException{
        try {
            return (UID)getValue(Columns.OWNERUID);
        }
        catch(NullPointerException e) {
            throw new IOException("HostInterface#getOwner() : attribute not set");
        }
    }
    /**
     * This retreives this host project, if any
     * @return this attribute, or null if not set
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public String getProject() {
        return (String)getValue(Columns.PROJECT);
    }
    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) {
        return setValue(Columns.valueOf(attribute.toUpperCase()), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the column to set 
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     */
    public boolean setValue(Columns column, Object val) {
        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), null);

        String v = val.toString();
				
        switch(column) {
        case PROJECT :
            value = v;
            break;
        case UID :
        case OWNERUID :
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case CPUSPEED :
        case TOTALMEM :
        case TOTALSWAP :
            value = new Long(Integer.parseInt(v));
            break;
        case NBCONNECTIONS :
        case NBPING :
        case AVGPING :
        case CPUNB :
        case TIMESHIFT :
        case NBJOBS :
        case TIMEOUT :
        case AVGEXECTIME :
            value = new Integer(Integer.parseInt(v));
            break;
        case OS :
            value = XWOSes.valueOf(v);
            break;
        case CPUTYPE :
            value = XWCPUs.valueOf(v);
            break;
        case UPLOADBANDWIDTH :
        case DOWNLOADBANDWIDTH :
            value = new Float(Float.parseFloat(v));
            break;
        case NAME :
        case IPADDR :
        case NATEDIPADDR :
        case HWADDR :
        case TIMEZONE :
        case CPUMODEL :
        case VERSION :
            // sql query safety : removing spaces and quotes
            value = v.replaceAll("[\\n\\s\'\"]+", "_");
            break;
        case LASTALIVE :
            if(val instanceof java.util.Date)
                value = val;
            else
                value = util.getSQLDateTime(v);
            break;
        case ACCEPTBIN :
        case ACTIVE :
        case AVAILABLE :
        case TRACES :
        case ISDELETED :
            value = new Boolean(v);
            break;
        }
        return super.setValue(column.ordinal(), value);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setNbConnections(int v) {
        return setValue(Columns.NBCONNECTIONS, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setNbPing(int v) {
        return setValue(Columns.NBPING, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setAvgPing(int v) {
        return setValue(Columns.AVGPING, new Integer(v));
    }
    /**
     * This increments NbPing and recalculates avg ping
     * @param v is the last ping
     * @since 2.0.0
     */
    public void incAvgPing(int v) {

        int nbpings = getNbPing();
        int avg = getAvgPing();

        if(v < 0)
            return;
        if(avg < 0)
            avg = 0;
        if(nbpings < 0)
            nbpings = 0;

        float total = (avg * nbpings) + v;

        setAvgPing((int)(total / (nbpings + 1)));

        setNbPing(nbpings + 1);
    }
    /**
     * This sets this data upload bandwidth usage (in Mb/s)
     * @return true is value has changed
     * @since 2.0.0
     */
    public boolean setUploadBandwidth(float v) {
        return setValue(Columns.UPLOADBANDWIDTH, new Float(v));
    }
    /**
     * This sets this data download bandwidth usage (in Mb/s)
     * @return true is value has changed
     * @since 2.0.0
     */
    public boolean setDownloadBandwidth(float v) {
        return setValue(Columns.DOWNLOADBANDWIDTH, new Float(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setNbJobs(int v) {
        return setValue(Columns.NBJOBS, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setTimeOut(int v) {
        return setValue(Columns.TIMEOUT, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setTimeShift(int v) {
        return setValue(Columns.TIMESHIFT, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setAvgExecTime(int v) {
        return setValue(Columns.AVGEXECTIME, new Integer(v));
    }
    /**
     * This increments NbJobs and recalculates avg exec time
     * @param v is the last execution time
     */
    public void incAvgExecTime(int v) {
        int nbJobs = getNbJobs();
        int avg = getAvgExecTime();

        if(v < 0)
            v = 0;
        if(avg < 0)
            avg = 0;
        if(nbJobs < 0)
            nbJobs = 0;

        long total = (avg * nbJobs) + v;
        setAvgExecTime((int)(total / (nbJobs + 1)));
        setNbJobs(nbJobs + 1);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setUID(UID v) {
        return setValue(Columns.UID, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setCpuNb(int v) {
        return setValue(Columns.CPUNB, new Integer(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setCpuSpeed(long v) {
        return setValue(Columns.CPUSPEED, new Long(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setTotalMem(long v) {
        return setValue(Columns.TOTALMEM, new Long(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setTotalSwap(long v) {
        return setValue(Columns.TOTALSWAP, new Long(v));
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setName(String v) {
        return setValue(Columns.NAME, v);
    }
    /**
     * This retreives the IP address as provided by worker itself.
     * This may be a NATed IP
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setNatedIPAddr(String v) {
        return setValue(Columns.NATEDIPADDR, v);
    }
    /**
     * This retreives the IP address obtained at connexion time.
     * This is set by server at connexion time.
     * This may be different from NATed IP.
     * @return the expected parameter 
     * @since 2.0.0
     */
    public boolean setIPAddr(String v) {
        return setValue(Columns.IPADDR, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setHWAddr(String v) {
        return setValue(Columns.HWADDR, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setTimeZone(String v) {
        return setValue(Columns.TIMEZONE, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setOs(XWOSes v) {
        return setValue(Columns.OS, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setCpu(XWCPUs v) {
        return setValue(Columns.CPUTYPE, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setCpuModel(String v) {
        return setValue(Columns.CPUMODEL, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setVersion(String v) {
        return setValue(Columns.VERSION, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setOwner(UID v) {
        return setValue(Columns.OWNERUID, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setProject(String v) {
        return setValue(Columns.PROJECT, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setLastAlive(Date v) {
        return setValue(Columns.LASTALIVE, v);
    }
    /**
     * @return always true
     * @deprecated this is not pertinent; use setLastAlive() instead
     * @see #setLastAlive(Date)
     */
    public boolean setAlive(boolean v) {
        return true;
        //				return setValue(ALIVE, new Boolean(v));
    }
    /**
     * This sets this host as(in)active; i.e. an active host
     * is selectable for jobs.
     * A host is inactivated if it has sent a job as ERROR.
     * This can also be(in)activated on client request.
     * @return true if this is attribute value has changed
     */
    public boolean setActive(boolean v) {
        return setValue(Columns.ACTIVE, new Boolean(v));
    }
    /**
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v) {
        return setValue(Columns.ISDELETED, new Boolean(v));
    }
    /**
     * This sets this host as able to accept binary application
     * @return true if this is attribute value has changed
     */
    public boolean setAcceptBin(boolean v) {
        return setValue(Columns.ACCEPTBIN, new Boolean(v));
    }
    /**
     * This sets this host as(un)available accordingly to its local policy
     * This is set on alive signal.
     * @return true if this is attribute value has changed
     */
    public boolean setAvailable(boolean v) {
        return setValue(Columns.AVAILABLE, new Boolean(v));
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setTracing(boolean v) {
        return setValue(Columns.TRACES, new Boolean(v));
    }

    /**
     * This tests user access rights
     * @param user is the UID of the user who try to access
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean checkUserAccessRights(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getOwner(), user, XWAccessRights.USERALL);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean checkGroupAccessRights(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPALL);
    }
    /**
     * This tests access rights
     * @return true if others have access rights
     */
    public boolean checkOtherAccessRights()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERALL);
    }
    /**
     * This tests if user can read
     * @param user is the UID of the user who try to read
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanRead(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getOwner(), user, XWAccessRights.USERREAD);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to access
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanRead(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPREAD);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanRead()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERREAD);
    }
    /**
     * This tests if user can write
     * @param user is the UID of the user who try to write
     * @return true if the user is this owner and acces rights are defined
     */
    public boolean userCanWrite(UID user)
        throws AccessControlException, IOException {
        return checkUserRights(getOwner(), user, XWAccessRights.USERWRITE);
    }
    /**
     * This tests user group access rights
     * @param ownerGroup is the owner group UID
     * @param userGroup is the group UID of the user who try to write
     * @return true if the user belongs to this owner group and group has access rights
     */
    public boolean groupCanWrite(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return checkGroupRights(ownerGroup, userGroup, XWAccessRights.GROUPWRITE);
    }
    /**
     * This tests other access rights
     * @return true if others have access rights
     */
    public boolean otherCanWrite()
        throws AccessControlException, IOException {
        return checkOthersRights(XWAccessRights.OTHERWRITE);
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            HostInterface host = new HostInterface();
            host.setUID(UID.myUid);
            host.DUMPNULLS = true;
            System.out.println(host.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
