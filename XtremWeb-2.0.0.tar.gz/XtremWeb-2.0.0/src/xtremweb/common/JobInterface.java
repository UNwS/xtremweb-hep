package xtremweb.common;

import java.io.IOException;
import java.io.DataInputStream;
import java.util.Date;
import java.util.StringTokenizer;

import org.xml.sax.Attributes;


/**
 * This describes a job by collecting informations 
 * from works, tasks, users, apps and hosts.<br />
 * This is used to display informations in a more friendly way than
 * xtremweb.common.WorkInterface only.
 * This mainly translates UID to names and labels (i.e. users UID to users name etc.).<br />
 *
 * This gathers informations from apps, works, tasks, users.<br />
 *
 * This derives from xtremweb.common.TableInterface to uniform code so that it
 * can be used where a TableInterface is expected but this does not transit 
 * through the network.<br />
 * This is only used on client side.<br />
 * <br />
 * This can be understood as the following SQL command:<br />
 *    SELECT works.uid,users.name,apps.name,works.label,works.status,
 *           works.resultstatus,works.cmdline,works.arrivaldate,
 *           works.completeddate,works.resultdate,works.returncode,works.error_msg,
 *           hosts.name
 *    FROM   users,apps,tasks,hosts
 *    WHERE      works.uid = tasks.uid AND works.user = users.uid 
 *           AND works.app = apps.uid  AND tasks.host = hosts.uid;<br />
 * <br />
 * Created: 23 avril 2006<br />
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */
public class JobInterface extends TableInterface {

    /**
     * This is the XML tag
     */
    public static final String THISTAG = "job";

    /**
     * This enumerates this interface columns
     */
    public enum Columns {

        /**
         * This is the column index of the unique identifier
         * @see xtremweb.common.UID
         */
        UID,
        /**
         * This is the column index of the user login
         */
        USERLOGIN,
        /**
         * This is column index of the the application name
         */
        APPNAME,
        /**
         * This is the column index of this work access rights
         * if any<br />
         */
        ACCESSRIGHTS,
        /**
         * This is the column index of the label, if any
         */
        LABEL,
        /**
         * This is the column index of the status
         * @see xtremweb.common.JobStatus
         */
        STATUS,
        /**
         * This is the column index of the result status
         * @see xtremweb.common.XWStatus
         */
        RESULTURI,
        /**
         * This is the column index of the result status
         * @see xtremweb.common.XWStatus
         */
        RESULTSTATUS,
        /**
         * This is the column index of the command line, if any
         */
        CMDLINE,
        /**
         * This is the column index of the arrival date
         */
        ARRIVALDATE,
        /**
         * This is the column index of the completed date
         */
        COMPLETEDDATE,
        /**
         * This is the column index of the result date
         */
        RESULTDATE,
        /**
         * This is the column index of the application return code
         */
        RETURNCODE,
        /**
         * This is the column index of the error message, if any
         */
        ERROR_MSG,
        /**
         * This is the column index of the worker, if any
         */
        HOSTNAME;

        /**
         * This retreives an Columns from its integer value
         * @param v is the integer value of the Columns
         * @return an Columns
         */
        public static Columns fromInt(int v) throws IndexOutOfBoundsException {
            for (Columns c : Columns.values()) {
                if(c.ordinal() == v)
                    return c;
            }
            throw new IndexOutOfBoundsException("unvalid Columns value " + v);
        }

        /**
         * This array stores enum asstring 
         */
        public static String[] labels = null;
        /**
         * This retreives this enum string representation
         * @return a array containing this enum string representation
         */
        public static String[] getLabels() {
            if(labels != null)
                return labels;

            labels = new String[HOSTNAME.ordinal() + 1];
            for (Columns column : Columns.values()) {
                labels[column.ordinal()] = column.toString();
            }
            return labels;
        }
    }

    /**
     * This is the default constructor
     */
    public JobInterface() {

        super(THISTAG);

        LAST_ATTRIBUTE = Columns.HOSTNAME.ordinal();
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        columns = Columns.getLabels();
        values = new Object[MAX_ATTRIBUTE];
        setAccessRights(XWAccessRights.DEFAULT);
    }

    /**
     * This constructs a new object providing its primary key value
     * @param v is this new object primary key value
     */
//     public JobInterface(int v) {

//         this();
//         setValue(Columns.UID, new Integer(v));
//     }

    /**
     * This construcs a new job
     * @param work is the WorkInterface of the job
     * @param app  is the AppInterface of the job, 
     *             or null is application is not defined (app has been removed from server)
     * @param user is the UserInterface of the job
     *             or null is user is not defined (user has been removed from server)
     * @param host is the HostInterface of the job
     *             or null is host is not defined (host has been removed from server)
     */
    public JobInterface(WorkInterface work, 
                        AppInterface  app,
                        UserInterface user,
                        HostInterface host) throws IOException{

        this();

        if(work != null) {
            setUID(work.getUID());
            setLabel(work.getLabel());
            setStatus(work.getStatus());
            setReturnCode(work.getReturnCode());
            setResult(work.getResult());
            setCmdLine(work.getCmdLine());
            setArrivalDate(work.getArrivalDate());
            setCompletedDate(work.getCompletedDate());
            setErrorMsg(work.getErrorMsg());
            setAccessRights(work.getAccessRights());
        }
        if(app != null)
            setApplicationName(app.getName());
        if(host != null)
            setHostName(host.getName());
        if(user != null)
            setLogin(user.getLogin());
    }
    /**
     * This calls this(StreamIO.stream(input));
     * @param input is a String containing an XML representation
     */
    public JobInterface(String input) throws IOException{
        this(StreamIO.stream(input));
    }
    /**
     * This constructs a new object from input stream providing 
     * XML representation
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public JobInterface(DataInputStream input) throws IOException{
        this();
        super.fromXml(input);
    }

    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param attrs contains attributes XML representation
     * @see TableInterface#fromXml(Attributes)
     * @throws IOException on XML error
     */
    public JobInterface(Attributes attrs) throws IOException{
        this();
        super.fromXml(attrs);
    }
    /**
     * This serializes this object representation to a String
     */
    public String toString() {

        String query = "";

        // use ' and not \" to be hsqldb compliant...
        for (Columns column : Columns.values()) {

            Object value = getValue(column);

            if (column != Columns.UID)
                query += ",";

            if (value == null) {
                query += " " + column + "=" + NULLVALUE;
                continue;
            }

            switch(column) {
            case STATUS:
            case RESULTSTATUS:
                try {
                    query += " " + column + "='" + (XWStatus)value + "'";
                } catch (Exception e) {
                }
                break;

            default:
                if (value.getClass() != java.util.Date.class)
                    query += " " + column + "='" + value + "'";
                else {
                    java.util.Date date = (java.util.Date)value;
                    query += " " + column + "='"
                        + util.getSQLDateTime(date) + "'";
                }
                break;
            }
        }

        return query;
    }
    /**
     * This retreives a parameter
     * @param c is the column of the parameter to retreive
     * @return the expected value
     */
    public Object getValue(Columns c){
        return super.getValue(c.ordinal());
    }
    /**
     * This retreives the UID
     * @return this attribute
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public UID getUID() throws IOException {
        try {
            return (UID)getValue(Columns.UID);
        }
        catch(NullPointerException e) {
            throw new IOException("JobInterface#getUID() :  attribute not set");
        }
    }

    /**
     * This gets the expected host name
     * @return this attribute, or null if not set
     * @since RPCXW
     */
    public String getHostName()  {
        try {
            return (String)getValue(Columns.HOSTNAME);
        }
        catch(NullPointerException e) {
            return null;
        }
    }
    /**
     * This retreives this object access rights
     * @return this attribute
     */
    public XWAccessRights getAccessRights() {
        try {
            return (XWAccessRights)getValue(Columns.ACCESSRIGHTS);
        }
        catch(Exception e) {
        }
        setAccessRights(XWAccessRights.DEFAULT);
        return XWAccessRights.DEFAULT;
    }
    /**
     * This gets this work application UID
     * @return this work application UID
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public String getApplicationName() throws IOException{
        try {
            return (String)getValue(Columns.APPNAME);
        }
        catch(NullPointerException e) {
            throw new IOException("JobInterface#getApplicationName() : attribute not set");
        }
    }

    /**
     * This gets the job name as defined by user at submission time. <br>
     * Label is optionnal
     * @return this attribute, or null if not set
     */
    public String getLabel() {
        return (String)getValue(Columns.LABEL);
    }

    /**
     * This gets user UID
     * @return this attribute, or null if not set
     * @exception IOException is thrown is attribute is nor set, neither well formed
     */
    public String getLogin() throws IOException {
        try {
            return (String)getValue(Columns.USERLOGIN);
        }
        catch(NullPointerException e) {
            throw new IOException("JobInterface#getLogin() : attributenot set");
        }
    }

    /**
     * This gets an attribute
     * @exception IOException is thrown if attribute is not set
     * @return this attribute
     */
    public XWStatus getStatus() throws IOException {
        try {
            return (XWStatus)getValue(Columns.STATUS);
        }
        catch(NullPointerException e) {
            throw new IOException("status not set");
        }
    }

    /**
     * This retreives the URI where to get result
     * @return this attribute, or null if not set
     */
    public URI getResult() {
        return (URI)getValue(Columns.RESULTURI);
    }

    /**
     * This gets an attribute
     * @return result status, MobileResultStatus.UNAVAILABLE if not set
     */
    public XWStatus getResultStatus() {
        try {
            Integer ret = (Integer)getValue(Columns.RESULTSTATUS);
            return XWStatus.fromInt(ret.intValue());
        }
        catch(NullPointerException e) {
            return XWStatus.UNAVAILABLE;
        }
    }

    /**
     * This checks whether result available<br />
     * @return true if result available, false on error (status not available)
     * @since RPCXW
     */
    public boolean resultAvailable() {
        try {
            return (getResultStatus() == XWStatus.AVAILABLE);
        }
        catch(Exception e) {
            return false;
        }
    }

    /**
     * This gets an attribute
     * @return job return code, 0 on error
     */
    public int getReturnCode() {
        try {
            Integer ret = (Integer)getValue(Columns.RETURNCODE);
            return ret.intValue();
        }
        catch(NullPointerException e) {
            return 0;
        }
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getCmdLine() {
        return (String)getValue(Columns.CMDLINE);
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getArrivalDate() {
        return (Date)getValue(Columns.ARRIVALDATE);
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getCompletedDate() {
        return (Date)getValue(Columns.COMPLETEDDATE);
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public Date getResultDate() {
        return (Date)getValue(Columns.RESULTDATE);
    }

    /**
     * This gets an attribute
     * @return this attribute, or null if not set
     */
    public String getErrorMsg() {
        return (String)getValue(Columns.ERROR_MSG);
    }
    /**
     * This does nothing
     * @return always false
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return false;
    }
    /**
     * This does nothing
     * @return always false
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v) {
        return false;
    }
    /**
     * This sets parameter; this is called from TableInterface#fromXml(Attributes)
     * @param attribute is the name of the attribute to set 
     * @param v is the new attribute value 
     * @return true if value has changed, false otherwise
     * @see TableInterface#fromXml(Attributes)
     */
    protected boolean setValue(String attribute, Object v) {
        return setValue(Columns.valueOf(attribute), v);
    }
    /**
     * This sets parameter with the right object type; this
     * reads the value string representation and instanciates the
     * value with the right object type.
     * @param column is the column to set 
     * @param val is a String representation of the new attribute value 
     * @return true if value has changed, false otherwise
     */
    public boolean setValue(Columns column, Object val) {

        Object value = null;

        if(val == null)
            return super.setValue(column.ordinal(), null);

        String v = val.toString();

        switch(column) {
        case UID:
            try {
                value = new UID(v);
            }
            catch(Exception e) {
                util.fatal(e.toString());
            }
            break;
        case RETURNCODE:
            value = new Integer(Integer.parseInt(v));
            break;
        case APPNAME:
        case HOSTNAME:
        case USERLOGIN:
        case CMDLINE:
            // sql query safety : removing  quotes but keeping spaces
            value = v.replaceAll("[\\n\'\"]+", "_");
            break;
        case LABEL:
        case ERROR_MSG:
            // sql query safety : removing spaces and quotes
            value = v.replaceAll("[\\n\\s\'\"]+", "_");
            break;
        case STATUS:
        case RESULTSTATUS:
            value = XWStatus.valueOf(v);
            break;
        case RESULTURI:
            try {
                value = new URI(v);
            }
            catch(Exception e) {
            }
            break;
        case ARRIVALDATE:
        case COMPLETEDDATE:
        case RESULTDATE:
            if(val instanceof java.util.Date)
                value = val;
            else
                value = util.getSQLDateTime(v);
            break;
        case ACCESSRIGHTS :
            try {
                value = new XWAccessRights(v);
            }
            catch(Exception e) {
            }
            break;
        }
        return super.setValue(column.ordinal(), value);
    }
    /**
     * This sets the job UID UID is mandatory
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setUID(UID v) {
        return setValue(Columns.UID, v);
    }

    /**
     * This sets the expected worker UID
     * @param v is the new expected worker UID
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     * @since RPCXW
     */
    public boolean setHostName(String v) {
        if(v != null)
            return setValue(Columns.HOSTNAME, v);
        else
            return setValue(Columns.HOSTNAME, null);
    }
    /**
     * This sets this work application
     * @param v is  the application UID
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setApplicationName(String v) {
        return setValue(Columns.APPNAME, v);
    }
    /**
     * This sets the access rights
     * @return true is value has changed
     */
    public boolean setAccessRights(XWAccessRights v) {
        return setValue(Columns.ACCESSRIGHTS, v);
    }
    /**
     * This sets the job name as defined by user at submission time. <br>
     * Label is optionnal
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setLabel(String v) {
        return setValue(Columns.LABEL, v);
    }

    /**
     * This sets the user UID. <br>
     * @return true if job name modified (and thus this work should be updated),
     *         false otherwise
     */
    public boolean setLogin(String v) {
        return setValue(Columns.USERLOGIN, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setStatus(XWStatus v) 
        throws ArrayIndexOutOfBoundsException {
        return setValue(Columns.STATUS, v);
    }

    /**
     * This set the URI where to get the result
     * @return true if value has changed, false otherwise
     */
    public boolean setResult(URI v) {
        return setValue(Columns.RESULTURI, v);
    }
    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setResultStatus(int v)
        throws ArrayIndexOutOfBoundsException {
        return setValue(Columns.RESULTSTATUS, new Integer(v));
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setReturnCode(int v) {
        return setValue(Columns.RETURNCODE, new Integer(v));
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setCmdLine(String v) {
        return setValue(Columns.CMDLINE, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setArrivalDate(Date v) {
        return setValue(Columns.ARRIVALDATE, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setCompletedDate(Date v) {
        return setValue(Columns.COMPLETEDDATE, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setResultDate(Date v) {
        return setValue(Columns.RESULTDATE, v);
    }

    /**
     * @return true if value has changed, false otherwise
     */
    public boolean setErrorMsg(String v) {
        return setValue(Columns.ERROR_MSG, v);
    }
}
