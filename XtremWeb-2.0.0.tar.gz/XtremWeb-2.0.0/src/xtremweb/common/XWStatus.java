package xtremweb.common;


/**
 * This class helps to define some constants
 * This is used to define Works, Tasks and results status
 *
 * <br /><br />
 * Job state graph
 *
 *                       Waiting
 *                         |
 *                +----> Pending <----+
 *                |        |          |
 *                |      Running      |
 *                |        |          |
 *     +----------+--------+----------+---------+
 *     |          |                   |         |
 *    Error    Aborted               Lost   Completed
 *
 * <br /><br />
 * DATAREQUEST, AVAILABLE and UNVAILABLE don't apply to jobs but to datas only
 *
 */
public enum XWStatus {

    /**
     * This is no status
     */
    NONE,
    /**
     * This is any status
     */
    ANY,
    /**
     * This tells work has not been inserted in scheduling queue yet
     */
    WAITING,
    /**
     * This tells work has been inserted in schedulling queue and is waiting for computation
     */
    PENDING,
    /**
     * This tells this work is beeing computed
     */
    RUNNING,
    /**
     * This denotes a worker error
     */
    ERROR,
    /**
     * This denotes a completed job
     */
    COMPLETED,
    /**
     * This tells work has been canceled by activation policy
     */
    ABORTED,
    /**
     * This denotes a lost job (the worker does not send heart beat signal)
     * #see xtremweb.dispatcher.TaskSet
     */
    LOST,
    /**
     * This tells a data need to be (re)downloaded from worker.
     */
    DATAREQUEST,
    /**
     * This tells this object is available
     */
    AVAILABLE,
    /**
     * This tells this object is not available
     */
    UNAVAILABLE;

    public static final XWStatus LAST = UNAVAILABLE;
    public static final int SIZE = LAST.ordinal() + 1;

    /**
     * This retreives a status from its integer value
     * @param v is the integer value of the status
     * @return a XWStatus
     */
    public static XWStatus fromInt(int v) throws IndexOutOfBoundsException {
        for (XWStatus c : XWStatus.values()) {
            if(c.ordinal() == v)
                return c;
        }
        throw new IndexOutOfBoundsException("unvalid status " + v);
    }

    /**
     * This array stores enum as string 
     */
    public static String[] labels = null;
    /**
     * This retreives this enum string representation
     * @return a array containing this enum string representation
     */
    public static String[] getLabels() {
        if(labels != null)
            return labels;

        labels = new String[SIZE];
        for (XWStatus c : XWStatus.values())
            labels[c.ordinal()] = c.toString();
        return labels;
    }
}
