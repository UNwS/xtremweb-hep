
package xtremweb.common;

import xtremweb.communications.IdRpc;

import java.util.Enumeration;
import java.util.Vector;
import java.io.IOException;
import java.text.ParseException;


/**
 * Created: August 30th, 2005<br />
 *
 * @see #CommandLineOptions
 * @see xtremweb.communications#IdRpc
 * @author <a href="mailto:lodygens a lal.in2p3.fr">Oleg Lodygensky</a>
 * @version %I% %G%
 * @since 1.9.0
 */

public class CommandLineParser extends Logger{

    /**
     * This is the command line option prefix
     */
    public final static String PREFIX = "--xw";
    /**
     * This stores parameters
     * This depends on the command; it can be empty, contains one or more values
     * @see #command
     */
    private Object[] commandParams;
    /**
     * This stores optionnal parameters
     * This depends on the command; it can be empty, contains one or more values
     * @see #command
     */
    private Object[] optionnalParameters;

    /**
     * This stores the command provided on command line
     */
    private IdRpc command;
    /**
     * This stores the output format provided on command line
     */
    private OutputFormat format;

    /** 
     * This converts command from a String.
     * @param s is the value to convert
     * @return the command represented by the parameter
     */
    public IdRpc command(String s) throws IllegalArgumentException {
        return IdRpc.valueOf(s);
    }

    /** 
     * This converts command line option from a String.
     * @param s is the value to convert
     * @return the command line option represented by the parameter
     */
    public CommandLineOptions option(String s) throws IllegalArgumentException {
        return CommandLineOptions.valueOf(s);
    }
    public void setOption(CommandLineOptions opt, Object o) {
        optionnalParameters[opt.ordinal()] = o;
    }
    public Object getOption(CommandLineOptions opt) throws ArrayIndexOutOfBoundsException {
        return optionnalParameters[opt.ordinal()];
    }
    public Object[] getOptions() {
        return optionnalParameters;
    }
    /**
     * This tries to convert the parameter to URI or UID
     * @return an UID if param represents an UID; an URI if param represents an URI; param itself otherwise
     */
    private Object checkParam(String param) {
        try {
            // is it an UID ?
            return new UID(param);
        }
        catch(IOException e) {
            // is it an URI ?
            try {
                URI uri = new URI(param);
                if(uri.getScheme() != null) {
                    return uri;
                }
            }
            catch(IOException e2) {
            }
        }
        // any other parameter
        return param;
    }

    /** 
     */
    public static void usageHeader(String header) {
        if(header != null)
            System.out.println(header);
        System.out.println("Available options :");
    }

    /** 
     * This prints usage
     */
    public static void usage(String header) {
        usageHeader(header);
        for (CommandLineOptions c : CommandLineOptions.values())
            System.out.println(c.usage());
        for (IdRpc i : IdRpc.values())
            System.out.println(i.usage());
    }

    /** 
     * This prints usage for a given command
     * @param c is the command to print usage for
     */
    public static void usage(String header, IdRpc i) {
        usageHeader(header);
        System.out.println("\t" + i.usage());
    }

    /** 
     * This prints usage for a given command
     * @param c is the command to print usage for
     */
    public static void usage(String header, CommandLineOptions i) {
        usageHeader(header);
        System.out.println("\t" + i.usage());
    }

    /**
     * This retreive the command found on command line
     */
    public IdRpc command() {
        return command;
    }

    /**
     * This retreives the commandParams
     */
    public Object commandParams(IdRpc c) {
        return commandParams[c.ordinal()];
    }

    /**
     * This retreives the commandParams for the command found on command line
     */
    public Object commandParams() {
        return commandParams[command.ordinal()];
    }

    /**
     * <p>
     * This sets the default commandParams for the command 
     * found on command line.
     * <blockquote>
     * This is typically used to set UIDs found on command line.
     * </blockquote>
     * </p>
     * <p>
     * This does nothing if commandParams is already set 
     * <blockquote>
     * (i.e. if setAction() has been called)
     * </blockquote>
     * </p>
     * @see #setAction(int, Object)
     */
    private void setCommandParams(Vector v) {
        if(command == IdRpc.NULL)
            return;
        if(commandParams[command.ordinal()] == null)
            commandParams[command.ordinal()] = v;
    }

    /**
     * This sets action with no commandParams
     * @param c the action to perform in this instance
     * @see #setAction(int, Object)
     */
    private void setAction(IdRpc i) 
        throws ParseException,IndexOutOfBoundsException{
        setAction(i, null);
    }

    /**
     * This sets action and its commandParams
     * @see #commandParams
     * @see #command
     */
    private void setAction(IdRpc i, Object obj) 
        throws ParseException, IndexOutOfBoundsException{

        if(command != IdRpc.NULL)
            throw new ParseException("can't define two simultaneous actions", 0);

        command = i;
        commandParams[command.ordinal()] = obj;
    }

    /**
     * This retreive the help flag
     */
    public boolean help() {
        try {
            return getOption(CommandLineOptions.HELP) != null;
        }
        catch(Exception e) {
            return false;
        }
    }

    /**
     * This retreive the verbose flag ("--xwverbose")
     */
    public boolean isVerbose() {
        try {
            return getOption(CommandLineOptions.VERBOSE) != null;
        }
        catch(Exception e) {
            return false;
        }
    }

    /**
     * This retreives the output format
     */
    public boolean format() {
        try {
            return getOption(CommandLineOptions.FORMAT) != null;
        }
        catch(Exception e) {
            return false;
        }
    }
    /**
     * This tells if output format is TEXT
     */
    public boolean text() {
        try {
            return ((OutputFormat)getOption(CommandLineOptions.FORMAT) == OutputFormat.TEXT);
        }
        catch(Exception e) {
            return false;
        }
    }
    /**
     * This tells if output format is TEXT
     */
    public boolean csv() {
        try {
            return ((OutputFormat)getOption(CommandLineOptions.FORMAT) == OutputFormat.CSV);
        }
        catch(Exception e) {
            return false;
        }
    }
    /**
     * This tells if output format is XML
     */
    public boolean xml() {
        try {
            return ((OutputFormat)getOption(CommandLineOptions.FORMAT) == OutputFormat.XML);
        }
        catch(Exception e) {
            return false;
        }
    }
    /**
     * This tells if output format is HTML
     */
    public boolean html() {
        try {
            return ((OutputFormat)getOption(CommandLineOptions.FORMAT) == OutputFormat.HTML);
        }
        catch(Exception e) {
            return false;
        }
    }

    /**
     * This dumps all params if verbose flag is set ("--xwverbose")
     */
    public void verbose() {

        if(isVerbose() == false)
            return;

        try {
            System.out.println("command     = " + command);
            if(commandParams[command.ordinal()] instanceof Vector) {
                int i = 0;
                for(Enumeration e = ((Vector)commandParams[command.ordinal()]).elements();
                    e.hasMoreElements() ;){
                    System.out.println("\tparameter[" + i++ + "] = " + e.nextElement());
                }
            }
            else
                System.out.println("commandParams  = " + commandParams[command.ordinal()]);
        }
        catch(Exception e) {
        }
    }

    public static String optionText(IdRpc c) {
        return PREFIX + c.toString().toLowerCase();
    }

    public static String optionText(CommandLineOptions c) {
        return PREFIX + c.toString().toLowerCase();
    }

    /**
     * This is the default contructor
     */
    public CommandLineParser() {
        super();
        optionnalParameters = new Object[IdRpc.SIZE];
        commandParams = new Object[IdRpc.SIZE];
        command  = IdRpc.NULL;
        try {
            setOption(CommandLineOptions.FORMAT, OutputFormat.XML);
        }
        catch(Exception e) {
        }
    }
    /**
     */
    public CommandLineParser(LoggerLevel l) {
        this();
        level = l;
    }



    /**
     * This constructor parses arguments
     * @param args is an array of String ocntaining the command line arguments
     */
    public CommandLineParser(String[] args) 
        throws IllegalArgumentException, ParseException {
        this(args, LoggerLevel.INFO);
    }

    /**
     * This constructor parses arguments
     * @param args is an array of String ocntaining the command line arguments
     */
    public CommandLineParser(String[] args, LoggerLevel l)
        throws IllegalArgumentException, ParseException {

        this(l);

        if((args == null) || (args.length == 0))
            throw new IllegalArgumentException("no arg provided");

        Vector params = new Vector();
        String argument = null;

        int i = 0;

        for(i = 0; i < args.length;) {

            IdRpc arg = IdRpc.NULL;
            argument = args[i];
            if(argument.toLowerCase().startsWith(PREFIX))
                argument = argument.toUpperCase().substring(PREFIX.length());

            CommandLineOptions opt = CommandLineOptions.NONE;
            try {
                arg = command(argument);

                debug(arg + " is a command");

                setAction(arg);
            }
            catch(IllegalArgumentException notACommand) {
                try {
                    opt = option(argument);

                    if(getOption(CommandLineOptions.CONFIG) != null)
                        debug(opt + " is an option");

                    switch(opt) {
                    case MACRO :
                    case LABEL :
                        setOption(opt, args[++i]);
                        break;

                    case ENV :
                        setOption(opt, checkParam(args[++i]));
                        break;

                    case UPDATEWORKERS :
                        params.add(args[++i].toLowerCase());
                        setOption(opt, new Boolean(true));
                        setAction(IdRpc.SENDHOST);
                        break;
                    case HELP:
                    case GUI:
                    case VERBOSE :
                    case NOVERBOSE :
                    case NOEXTRACT :
                    case RMZIP :
                    case ERASE :
                    case DOWNLOAD :
                    case OVERRIDE:
                        setOption(opt, new Boolean(true));
                        break;
                    case FORMAT :
                        try {
                            setOption(opt, OutputFormat.valueOf(args[++i].toUpperCase()));
                        }
                        catch(Exception ef) {
                            setOption(CommandLineOptions.FORMAT, OutputFormat.XML);
                            i--;
                        }
                        break;
                    case CONFIG :
                        try {
                            XWConfigurator config = new XWConfigurator(args[++i], false);
                            setOption(opt, config);
                            break;
                        }
                        catch(Exception e) {
                            e.printStackTrace();
                            System.exit(1);
                        }
                    }
                }
                catch(Exception notAnOption) {
                    //
                    // this is not a an option
                    //
                    debug(argument + " is an argument");

                    params.add(checkParam(argument));
                }
            }
            i++;
        }

        try {
            if(params.size() == 0) {
                setCommandParams(null);
            }
            else {
                setCommandParams(params);
            }
        }
        catch(ArrayIndexOutOfBoundsException e) {
            throw new IllegalArgumentException("invalid argument :" + argument);
        }
    }

    public static void main(String[] argv) {
        IdRpc.main(argv);
        CommandLineOptions.main(argv);
    }
}
