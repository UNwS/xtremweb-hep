/**
 * Project : XTremWeb
 * File    : XWTracerState.java
 *
 * Date   : March 2002
 * By     : Oleg Lodygensky
 * e-mail : lodygens /at\ .in2p3.fr
 */

package xtremweb.common;

public class XWTracerState
{
  int cpuUser;
  int cpuNice;
  int cpuSystem;
  int cpuIdle;
  int cpuAidle;
  short loadOne;
  short loadFive;
  short loadFifteen;
  short procRun;
  short procTotal;
  int  memFree;
  int  memShared;
  int  memBuffers;
  int  memCached;
  int  swapFree;
  int time;
}
