package xtremweb.common;

import java.io.IOException;
import java.io.DataInputStream;
import java.util.Vector;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLKey.java
 *
 * Created: March 22nd, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class (un)marshal object to/from XML
 * This is especially used by XMLtuple as key
 * @see XMLtuple
 */
public class XMLKey extends XMLObject {

    public static final String THISTAG = "XMLKEY";

    /**
     * This default constructor contructs an empty object
     */
    public XMLKey() {
        super();
        XMLTAG = THISTAG;
    }
    /**
     */
    public XMLKey(Object v) {
        super(v);
        XMLTAG = THISTAG;
    }

    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLKey(DataInputStream input) throws Exception{
        super.fromXml(input);
    }
    /**
     * This constructs a new object from XML attributes 
     */
    public XMLKey(Attributes attrs) throws IOException{
        this();
        XMLTAG = THISTAG;
        super.fromXml(attrs);
    }
    /**
     * This calls toString()
     * @param csv is never used
     * @see TableInterface#toString(boolean)
     */
    public String toString(boolean csv) {
        return toString();
    }
}
