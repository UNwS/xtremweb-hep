package xtremweb.common;

import java.rmi.RemoteException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Date;

import xtremweb.communications.XMLRPCCommand;


/**
 * Created: Oct, 2005<br />
 *
 * This class implements a FIFO buffer<br />
 * This is used by NIOClient/NIOHanlder to create/read non blocking TCP packets
 *
 * @see xtremweb.communications.NIOClient
 * @see xtremweb.dispatcher.NIOHandler
 * @author Oleg Lodygensky
 * @version RPCXW-v7
 */

public class BytePacket extends Logger{

    /**
     * This is the buffer length
     * @see xtremweb.common.util#PACKETSIZE
     */
    protected static final int BUFFERLENGTH = util.PACKETSIZE;
    /**
     * This is the buffer to ue for I/O
     */
    protected ByteBuffer buffer;

    /**
     * This constructs the buffer
     * @param l is the logger level
     * @see #setData()
     */
    public BytePacket(LoggerLevel l) {
        byte[] b = new byte[BUFFERLENGTH];
        setData(b);
        setLoggerLevel(l);
    }
    /**
     * This sets the logger level
     * @param l is the logger level
     */
    public void setLoggerLevel(LoggerLevel l) {
        level = l;
    }

    /**
     * This must be called when receiving packet
     * @see #pack()
     */
    public void reset() {
        buffer.clear();
    }

    /**
     * This must be called before sending packet
     * @see #reset()
     */
    public void pack() {
        buffer.flip();
    }

    /**
     * This retreives this stack buffer
     */
    public ByteBuffer getBuffer() {
        return buffer;
    }
    /**
     * This retreives this stack array
     */
    public byte[] getData() {
        return buffer.array();
    }

    /**
     * This sets this stack buffer
     */
    public void setData(byte[] v) {
        buffer = ByteBuffer.wrap(v);
        buffer.order(ByteOrder.BIG_ENDIAN);
        //System.out.println("BytePacket#setData " + v.length + " " + buffer.position());
    }

    /**
     * This pushes an UserInterface and an integer to packet
     * @param user is the UserInterface to push
     * @param code is the IdRpc code to push
     */
    public void putUserInterface(UserInterface user, int code) throws RemoteException {
        putInt(code);
        putObject(user);
    }
    /**
     * This pushes an UserInterface and an integer to packet
     * @param user is the UserInterface to push
     * @param code is the IdRpc code to push
     */
    public void putXMLRPCCommand(XMLRPCCommand cmd) throws RemoteException {
        putObject(cmd);
    }
    /**
     * This pushes an UserInterface and an integer to packet
     * and an optionnal parameter
     * @param user is the UserInterface to push
     * @param code is the IdRpc code to push
     * @param obj is an optionnal object to push
     */
    public void putUserInterface(UserInterface user, int code, XMLable obj) throws RemoteException {
        putUserInterface(user, code);
        if(obj != null)
            putObject(obj);
    }
    /**
     * This pushes an UserInterface and an integer to packet
     * and an optionnal parameter
     * @param user is the UserInterface to push
     * @param code is the IdRpc code to push
     * @param uid is an optionnal object to push
     */
    public void putUserInterface(UserInterface user, int code, UID uid) throws RemoteException {
        putUserInterface(user, code);
        if(uid != null)
            putUID(uid);
    }
    /**
     * This sends the IrRpc code, the UserInterface that identifies the client
     * and an optionnal UID
     * @param code is the IdRpc code to send
     * @param str is the String to send
     * @see xtremweb.common.ByteStack#putUID(UID)
     * @see #packet
     */
    public void putUserInterface(UserInterface user, int code, String str) throws RemoteException {
        putUserInterface(user, code);
        if(str != null)
            putString(str);
    }
    /**
     * This puts a byte
     * @param v is the byte to insert
     * @exception Exception is thrown on I/O error
     */
    public void putByte(byte v) throws RemoteException {
        try {
            buffer.put(v);
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This gets a byte
     * @return the extracted byte
     * @exception Exception is thrown on I/O error
     */
    public byte getByte() throws RemoteException {
        try {
            return buffer.get();
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This puts an integer
     * @param v is the integer to insert
     * @exception Exception is thrown on I/O error
     */
    public void putInt(int v) throws RemoteException {
        try {
            buffer.putInt(v);
            //System.out.println("BytePacket#putInt(" + v + ") " + buffer.position());
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This posp an integer
     * @return the extracted integer
     * @exception Exception is thrown on I/O error
     */
    public int getInt() throws RemoteException {
        try {
            int res = buffer.getInt();
            //System.out.println("BytePacket#getInt = " + res + " " + buffer.position());
            return res;
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This puts a String
     * @param v is the String to insert
     * @exception RemoteException is thrown error (buffer overflow...)
     */
    public void putString(String v) throws RemoteException {
        try {
            putArray(v.getBytes());
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This gets a String
     * @return the extracted String
     * @exception Exception is thrown on on I/O error
     */
    public String getString() throws RemoteException {
        byte[] b = getArray();
        String str = new String();
        if(b != null)
            str = new String(b);
        //System.out.println("BytePacket#getString = " + str + " " + buffer.position());
        return str;
    }
    /**
     * This tries to put a byte array accordingly to BUFFERLENGTH.
     * If there is not enough spaces on the buffer, this throws an exception.<br />
     * This first puts the array content itself if any, then the array size
     * as an integer<br />
     * If v is null a single 0 is only inserted
     * @param barray is the array to insert
     * @exception Exception is thrown on error or if the array is too large
     */
    public void putArray(byte[] barray) throws RemoteException {
        try {
            if(barray == null) {
                putInt(0);
                return;
            }

            int length = barray.length;

            if(length >= (buffer.remaining() - util.SIZEOFLONG)) {
                error("BytePacket#putArray length = " + length + "(" +  buffer.remaining()+  ")");
                throw new RemoteException("array too large!!!");
            }

            // 						System.out.println("BytePacket#putArray length = " + length + "(" +  buffer.position()+  ")");

            putInt(length);
            buffer.put(barray);
            // 						System.out.println("BytePacket#putArray " + buffer.position());
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This gets a byte array <br />
     * This first gets the array size, then the array content itself, if any
     * @return a byte array, of null if the read array size is 0
     * @exception Exception is thrown on I/O error or if the provided file does not exist
     */
    public byte[] getArray() throws RemoteException {
        try {
            int length = getInt();

            if(length == 0)
                return null;

            byte[] ret = new byte[length];
            //System.out.println("BytePacket#getArray length = " + length);

            buffer.get(ret);

            return ret;
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
    }

    /**
     * This tries to put a Vector accordingly to BUFFERLENGTH.
     * Hence this may send a subset of the vector elements only.<br />
     * This first writes vector size following by vector datas, if any<br />
     * If v is null, this writes a single 0
     * @see #BUFFERLENGTH
     * @param v is the Vector to send
     * @exception RemoteException is thrown on I/O error
     */
    public void putVector(Vector v) throws RemoteException {


        if(v == null) {
            System.out.println("BytePacket#putVector size = " + 0);
            putInt(0);
            return;
        }

        String str = new String();
        int nbElem;
        for(nbElem = 0; nbElem < v.size(); nbElem++) {
            str = str.concat(v.elementAt(nbElem).toString());
            if(str.length() >= (buffer.remaining() - util.SIZEOFLONG)) {
                nbElem--;
                if(nbElem < 0) nbElem = 0;
                warn("BytePacket#putVector puts only " + nbElem + " (" + 
                     str.length() + ", " +  buffer.remaining()+  ")");
                break;
            }
        }

        putInt(nbElem);
        for(int i = 0; i < nbElem; i++)
            putString(v.elementAt(i).toString());


        // 				putInt(v.size());
        // 				//System.out.println("BytePacket#putVector size = " + v.size());

        // 				for(int i = 0; i < v.size(); i++)
        //  						putString(v.elementAt(i).toString());
    }

    /**
     * This gets a Vector; this first reads vector size
     * then vector datas, if any<br />
     * This tries to store received objects as UID into Vector; 
     * if received objects are not UID, they are stored as String 
     * into returned Vector
     * @return a Vector of UID, or a Vector of String, or an empty Vector
     * @exception RemoteException is thrown on I/O error
     */
    public Vector getVector() throws RemoteException {


        Vector ret = new Vector();
        int size = getInt();

        //System.out.println("BytePacket#getVector() size = " + size);

        if(size == 0)
            return ret;

        for(int i = 0; i < size; i++) {
            String str = getString();
            try {
                ret.add(new UID(str));
            }
            catch(Exception e) {
                ret.add(str);
            }
        }
        return ret;
    }

    /**
     * This puts an XML object representation as String
     * @param o is the object to insert
     * @exception Exception is thrown on I/O error 
     */
    public void putObject(XMLable o) throws RemoteException {
        //System.out.println("BytePacket#putObject() ");
        if(o == null)
            putString(new String());
        else {
            //System.out.println("put XMLable " + o.toXml().length());
            //System.out.println("put XMLable " + o.toXml());
            putString(o.toXml());
        }
    }

    /**
     * This puts an UID String representation
     * @param uid is the UID to write
     * @exception RemoteException is thrown on I/O error
     * @see #getUID()
     */
    public void putUID(UID uid) throws RemoteException {
        putString(uid.toString());
    }

    /**
     * This gets an UID String representation
     * @exception RemoteException is thrown on I/O error
     * @exception RemoteException is thrown is read String does not 
     *            represent a valid UID
     * @see #putUID(UID)
     * @return UID as read from input stream
     */
    public UID getUID() throws RemoteException, IOException {
        return new UID(getString());
    }


    /**
     * This is the standard main method<br />
     * This is for debug purposes only
     */
    public static void main(String[] args) {
        try {
            BytePacket b0 = new BytePacket(LoggerLevel.DEBUG);
            BytePacket b1 = new BytePacket(LoggerLevel.DEBUG);

            b0.putInt(12345);
            b0.putInt(54321);
            if(args.length > 0)
                b0.putString(args[0]);
            else
                b0.putString("this is a test only");

            //						if(b0.buffer.hasArray()) {
            b1.setData(b0.getData());
            System.out.println("b1.getInt    = " + b1.getInt());
            System.out.println("b1.getInt    = " + b1.getInt());
            System.out.println("b1.getString = " + b1.getString());
            // 						}
            // 						else
            // 								System.out.println("hasArray = false");
        }
        catch(Exception e) {
            System.out.println(e.toString());
        }
    }


}
