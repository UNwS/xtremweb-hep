package xtremweb.common;


/**
 * LoggerLevel.java
 *
 * Created: 15 avril 2008
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @since XWHEP-1.0.24
 * @version %I%, %G%
 */

public enum LoggerLevel {

    DEBUG,
    INFO,
    WARN,
    ERROR;

    public static LoggerLevel fromInt(int v) throws IndexOutOfBoundsException {
        for (LoggerLevel i : LoggerLevel.values()) {
            if(i.ordinal() == v)
                return i;
        }
        throw new IndexOutOfBoundsException("unvalid LoggerLevel value " + v);
    }

}
