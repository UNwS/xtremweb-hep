package xtremweb.common;


import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.lang.reflect.Method;
import java.util.Vector;
import java.util.Date;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.text.SimpleDateFormat;
import java.util.Locale;


/**
 * 
 * Some utilities
 *
 * Created: Thu Jun 29 17:47:11 2000
 *
 * @author Gilles Fedak
 * @version %I% %G%
 */

public class util {

    /**
     * This is used in SQL statements<br />
     * This is defined to single quote and not to double quote to be HSQLDB compliant<br />
     * 6 decembre 2005 : client command line cannot includes this character until further notification
     */
    public static final String QUOTE="'";

    /**
     * This defines the name of the stdout file
     */
    public static final String STDOUT = "stdout" + DataType.TEXT.getFileExtension();
    /**
     * This defines the name of the stderr file
     */
    public static final String STDERR = "stderr" + DataType.TEXT.getFileExtension();

    /**
     * This defines buffer size for communications
     */
    public static final int PACKETSIZE = 16 * 1024;
    /**
     * This defines file size limit over which file is considered as huge and transfered via TCP
     */
    public static final int LONGFILESIZE = 250 * 1024;


    public static void dumpSQLException(Loggerable obj, SQLException e) {
        obj.warn("==> SQLException: " + e);
        e.printStackTrace();
        while(e != null) {
            obj.warn("Message:   " + e.getMessage());
            obj.warn("SQLState:  " + e.getSQLState());
            obj.warn("ErrorCode: " + e.getErrorCode());
            e = e.getNextException();
        }
    }

    /**
     * This helps to format date : the format is "yyyy-MM-dd HH:mm:ss"
     */
    public static final SimpleDateFormat logDateFormat = new SimpleDateFormat("[dd/MMM/yyyy:HH:mm:ss Z]", Locale.US);

    /**
     * This helps to format date : the format is "yyyy-MM-dd HH:mm:ss"
     */
    public static final SimpleDateFormat sqlDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * This formats a date to String
     * @param d is the date to format
     * @return a String containing formatted date
     * @see #sqlDateFormat
     */
    public static String getSQLDateTime(java.util.Date d) {      

        if(d == null)
            return null;

        return sqlDateFormat.format(d);
    }

    /**
     * This retreived a date from String
     * @param d is the string containing the date
     * @return a Date as represented in provided formatted string
     * @see #sqlDateFormat
     */
    public static java.util.Date getSQLDateTime(String d) {      

        if(d == null)
            return null;

        try {
            return sqlDateFormat.parse(d);
        }
        catch(Exception e) {
            //						System.err.println("util::getSQLDateTime");
            //						e.printStackTrace();
        }
        return null;
    }

    /**
     * This retreives local host name.
     * This calls getHostName("localhost")
     * @see #getHostName(String)
     * @return local host name
     */
    public static String getLocalHostName() {
        String hostName = null; 
        try {
            hostName = java.net.InetAddress.getLocalHost().getCanonicalHostName ();
            // if not resolved, hostName is the IP address
            if(hostName.compareTo(java.net.InetAddress.getLocalHost().getHostAddress()) == 0) {
                hostName = java.net.InetAddress.getLocalHost().getHostName ();
            }
        }
        catch(IOException e) {
            fatal(e.toString());
        }

        return hostName;
    }
    /**
     *  This retreives a host name.
     *  correct  misconfiguered /etc/hosts.
     */
    public static String getHostName(String hostname) 
        throws IOException {

        String ret = "";
        try {
            ret = java.net.InetAddress.getByName(hostname).getCanonicalHostName ();
        } 
        catch(Exception e) {
            throw new IOException("Cannot find host name " + e);
        }
        
        if(ret.toLowerCase().indexOf("localhost") != -1) {
            ret = getLocalHostName();
        }

        return ret;
    }

    public static boolean SearchInArray(Object a [], Object b) {
        int i = 0 ;
        boolean found =false ;      
        boolean  complete = false ;
        if(a == null) return(false);
        while(!complete) {
            found =(b.equals(a[i]));
            i++;
            complete = (i == a.length)||found;
        }
        return(found);
    }
    
    public static void fatal(String s) {

        System.err.println("Fatal : " + s);
        System.exit(XWReturnCode.FATAL.ordinal());
    }
    
    /**
     * Restart error: cause the programm to exit and restart
     */
    public static void restart(String s) {
        System.err.println("restarting : " + s);
        System.exit(XWReturnCode.RESTART.ordinal());
    }

    public static void fileCopy(File in, File out) throws IOException {
        FileInputStream fis  = new FileInputStream(in);
        FileOutputStream fos = new FileOutputStream(out);
        try {
            byte[] buf = new byte[1024];
            int i = 0;
            while ((i = fis.read(buf)) != -1) {
                fos.write(buf, 0, i);
            }
        } 
        catch (IOException e) {
            throw e;
        }
        finally {
            if (fis != null) fis.close();
            if (fos != null) fos.close();
        }
    }

    /**
     * This creates a subdir from UID.
     * This defines up to 1000 sub directories name "0" to "999".
     * This has been introduced to solve file system limitations.
     * @param parent is the parent directory of the new sub directory to create
     * @param uid is the uid to create a new subdir for
     * @return the subdir name
     * @since 1.3
     */
    public static File createDir(String parent, UID uid) throws IOException {

        return createDir(new File(parent), uid);
    }
    /**
     * This creates a subdir from UID.
     * This defines up to 1000 sub directories name "0" to "999".
     * This has been introduced to solve file system limitations.
     * @param parent is the parent directory of the new sub directory to create
     * @param uid is the uid to create a new subdir for
     * @return the subdir name
     * @since 1.3
     */
    public static File createDir(File parent, UID uid) throws IOException {

        String dirName = new Integer(uid.hashCode() % 1000).toString();
        File dir = new File(parent, dirName);
        checkDir(dir);
        return dir;
    }
    /**
     * Ensure that a directory exists.
     * 
     * If the parameter is not a directory, the file will be deleted.
     * If the directory does not exists, <code>checkDir</code> will be called
     * on its parent before creating it.</p>
     *
     * @param dir the directory to create.
     * @exception java.io.IOException if the directory does not exist and can't be created 
     */
    public static void checkDir(File dir) throws IOException {

        if((dir.exists()) &&(dir.isDirectory())) {
            return;
        }

        if(!dir.isDirectory()) { 
            if(dir.exists()) {
                dir.delete();
            } else {
                File parent = dir.getParentFile();
                checkDir(parent);
            }
        }
        if(!dir.mkdir()) {
            throw new IOException("can't create directory : " + dir.getAbsolutePath());
        }
    }
  
    public static void checkDir(String str) throws IOException {
        checkDir(new File(str));
    }
  

    /**
     * This delete a full directory
     */
    public static void deleteDir(File dir) throws IOException {

        if(!dir.exists()) {
            return;
        }

        if(!dir.isDirectory()) {
            dir.delete();
            return;
        }

        String[] list = dir.list();

        for(int i = 0; i < list.length; i++) {
            File file = new File(dir, list [i]);
            if(file.isDirectory())
                deleteDir(file);
            else {
                file.delete();
            }
        }

        dir.delete();
    }  

    /** 
     * This calls hash(src, ",", ":")
     * @see #hash(String,String,String)
     * @since XWHEP 1.0.0
     */
    public static Hashtable<String, String> hash(String src) {
        return hash(src, ",", ":");
    }
    /** 
     * This converts a string into an hashtable of strings accordingly 
     * to separators.
     * @param src is the String to split
     * @param separator1 contains separators to split Tuples
     * @param separator2 contains separators to split keys from values
     * @return an hashtable of String
     * @since XWHEP 1.0.0
     */
    public static Hashtable<String, String> hash(String src,
                                 String separator1, 
                                 String separator2) {


        Hashtable<String, String> ret = new Hashtable<String, String>();

        if((src == null) || (separator1 == null) || (separator2 == null))
            return ret;

        Vector<String> tuples = split(src, separator1);
        if(tuples == null)
            return null;

        for(int i = 0; i < tuples.size(); i++) {

            Vector<String> tuple = split(tuples.elementAt(i), separator2);
            if((tuple != null) && (tuples.size() == 2))
                ret.put(tuple.elementAt(0), tuple.elementAt(1));
        }

        return ret;
    }

    /** 
     * This converts a string into an array of strings accordingly 
     * to a separator.
     * @param src is the String to split
     * @param separator contains all separator to split <CODE>src</CODE>
     * @return an array of String
     * @since v1r2-rc1(RPC-V)
     */
    public static  Vector<String> split(String src, String separator) {
        if((src == null) ||(separator == null))
            return null;
        Vector<String> ret = new Vector<String>();
        StringTokenizer tokenizer = new StringTokenizer(src, separator);

        for(; tokenizer.hasMoreTokens();) {

            String elem = tokenizer.nextToken();
            ret.addElement(elem.trim());
        }

        return ret;
    }

    /** 
     * This converts a string into an array of strings accordingly 
     * to a separator.
     * @param src is the String to split
     * @return an array of String
     * @since v1r2-rc1(RPC-V)
     */
    public static  Vector<String> split(String src) {
        return split(src, " \t");
    }

    /**
     * This aims to launch a browser
     * @param url is the URL to display
     */
    public static void launchBrowser(String url) {
//         String cmd = null;
//         try {
//             XWOSes os = XWOSes.getOs();
//             if (os.isWin32()) {
//                 // cmd = 'rundll32 url.dll,FileProtocolHandler http://...'
//                 cmd = "rundll32 url.dll,FileProtocolHandler " + url;
//                 Runtime.getRuntime().exec(cmd);
//             }
//             else if (os.isLinux()){

//                 try {
//                     // try netscape
//                     Runtime.getRuntime().exec(cmd);
//                 }
//                 catch(Exception x) {
//                     try {
//                         // Command failed, try firefox
//                         cmd = "firefox "  + url;
//                         Runtime.getRuntime().exec(cmd);
//                     }
//                     catch(Exception y) {
//                         // Command failed, try konqueror
//                         cmd = "konqueror "  + url;
//                         Runtime.getRuntime().exec(cmd);
//                     }
//                 }
//             }
//         }
//         catch(IOException x)
//             {
//                 // couldn't exec browser
//                 System.err.println("Could not invoke browser, command=" + cmd);
//                 System.err.println("Caught: " + x);
//             }

/////////////////////////////////////////////////////////
//  Bare Bones Browser Launch                          //
//  Version 1.5 (December 10, 2005)                    //
//  By Dem Pilafian                                    //
//  Supports: Mac OS X, GNU/Linux, Unix, Windows XP    //
//  Example Usage:                                     //
//     String url = "http://www.centerkey.com/";       //
//     BareBonesBrowserLaunch.openURL(url);            //
//  Public Domain Software -- Free to Use as You Like  //
/////////////////////////////////////////////////////////
        String osName = System.getProperty("os.name");
        try {
            if (osName.startsWith("Mac OS")) {
                Class fileMgr = Class.forName("com.apple.eio.FileManager");
                Method openURL = fileMgr.getDeclaredMethod("openURL",
                                                           new Class[] {String.class});
                openURL.invoke(null, new Object[] {url});
            }
            else if (osName.startsWith("Windows"))
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + url);
            else { //assume Unix or Linux
                String[] browsers = {
                    "firefox", "opera", "konqueror", "epiphany", "mozilla", "netscape" };
                String browser = null;
                for (int count = 0; count < browsers.length && browser == null; count++)
                    if (Runtime.getRuntime().exec(
                                                  new String[] {"which", browsers[count]}).waitFor() == 0)
                        browser = browsers[count];
                if (browser == null)
                    throw new Exception("Could not find web browser");
                else
                    Runtime.getRuntime().exec(new String[] {browser, url});
            }
        }
        catch (Exception e) {
            System.err.println("Launch browser error : " + e.getLocalizedMessage());
        }
    }


    /**
     * This defines sizeof byte in Java language, in bytes
     */
    public static final int SIZEOFBYTE = 1;
    /**
     * This defines sizeof short in Java language, in bytes
     */
    public static final int SIZEOFSHORT = 2;
    /**
     * This defines sizeof integer in Java language, in bytes
     */
    public static final int SIZEOFINTEGER = 4;
    /**
     * This defines sizeof long in Java language, in bytes
     */
    public static final int SIZEOFLONG = 8;
    /**
     * This converts an array of 4 bytes to an integer
     * @param datas is a 4 elements array
     * @param len is the number of bytes to use in datas
     */
    public static int [] bytes2integers(byte datas[], int len) {

        int    nbint = len / SIZEOFINTEGER;
        int[]  integers = new int [nbint + 1];
        byte[] bytes = new byte [SIZEOFINTEGER];

        for(int i = 0; i < nbint; i++) {

            for(int j = 0; j < SIZEOFINTEGER; j++)
                bytes [j] = datas [(SIZEOFINTEGER * i) + j];

            integers [i] = bytes2integer(bytes);
        }

        return integers;
    }


    /**
     * This converts an array of 4 bytes to an integer
     * @param bytes [] is a 4 elements array
     */
    public static int bytes2integer(byte bytes[]) {

        return((int)((bytes [0] << 24) & 0xff000000) + 
               (int)((bytes [1] << 16) & 0x00ff0000) +
               (int)((bytes [2] <<  8) & 0x0000ff00) + 
               (int)(bytes [3]        & 0x000000ff));
    }


    /**
     * This converts a long to an array of 4 bytes
     * @param data is the long to convert
     * @return a byte array with height elements
     */
    public static byte [] long2bytes(long data) {

        byte bytes[] = new byte [SIZEOFLONG];
        bytes [0] =(byte)((data & 0xff00000000000000L) >> 56);
        bytes [1] =(byte)((data & 0x00ff000000000000L) >> 48);
        bytes [2] =(byte)((data & 0x0000ff0000000000L) >> 40);
        bytes [3] =(byte)((data & 0x000000ff00000000L) >> 32);
        bytes [4] =(byte)((data & 0x00000000ff000000L) >> 24);
        bytes [5] =(byte)((data & 0x0000000000ff0000L) >> 16);
        bytes [6] =(byte)((data & 0x000000000000ff00L) >> 8);
        bytes [7] =(byte)(data & 0x00000000000000ffL);

        return bytes;
    }
    /**
     * This converts an integer to an array of 4 bytes
     * @param data is the integer to convert
     * @return a byte array with four elements
     */
    public static byte [] integer2bytes(int data) {

        byte bytes[] = new byte [SIZEOFINTEGER];

        bytes [0] =(byte)((data & 0xff000000) >> 24);
        bytes [1] =(byte)((data & 0x00ff0000) >> 16);
        bytes [2] =(byte)((data & 0x0000ff00) >> 8);
        bytes [3] =(byte)(data & 0x000000ff);

        return bytes;
    }

    /**
     * This converts a short to an array of 4 bytes
     * @param data is the short to convert
     * @return a byte array with two elements
     */
    public static byte [] short2bytes(short data) {

        byte bytes[] = new byte [SIZEOFSHORT];

        bytes [0] =(byte)((data & 0xff00) >> 8);
        bytes [1] =(byte)(data & 0x00ff);

        return bytes;
    }

    public static String intToHexString(int value) {
        return "0x" + Integer.toHexString(value);
    }

    public static void main(String[] argv) {
        try {
            UID uid = null;

            if(argv.length > 0)
                uid = new UID(argv[0]);
            else
                uid = new UID();

            System.out.println("uid " + uid + " " +  uid.hashCode() + " " + (uid.hashCode() % 1000));
            System.out.println("uid " + uid + " " + createDir("/tmp", uid));
            System.out.println();

            UID uid2 = new UID(uid.toString());

            System.out.println("uid2 " + uid2 + " " +  uid2.hashCode() + " " + (uid2.hashCode() % 1000));
            System.out.println("uid2 " + uid2 + " " + createDir("/tmp", uid2));
            System.out.println();

            UID uid3 = uid;

            System.out.println("uid3 " + uid3 + " " +  uid3.hashCode() + " " + (uid3.hashCode() % 1000));
            System.out.println("uid3 " + uid3 + " " + createDir("/tmp", uid3));
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

}
