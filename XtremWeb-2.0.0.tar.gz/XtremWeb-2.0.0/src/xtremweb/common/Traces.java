/**
 * Project : XTremWeb
 * File    : Traces.java
 *
 * Date   : March 2002
 * By     : Oleg Lodygensky
 * e-mail : lodygens /at\ .in2p3.fr
 */

package xtremweb.common;

import java.util.Vector;
import java.util.Hashtable;

public class Traces
{
    /**
     * These help to work with masks
     * e.g. if (masks[i] & CPUUSER) then states[i] contains CPUUSER data
     */
    public static final short CPUUSER     = 0x0001;
    public static final short CPUNICE     = 0x0002;
    public static final short CPUSYSTEM   = 0x0004;
    public static final short CPUIDLE     = 0x0008;
    public static final short CPUAIDLE    = 0x0010;
    public static final short LOADONE     = 0x0020;
    public static final short LOADFIVE    = 0x0040;
    public static final short LOADFIFTEEN = 0x0080;
    public static final short PROCRUN     = 0x0100;
    public static final short PROCTOTAL   = 0x0200;
    public static final short MEMFREE     = 0x0400;
    public static final short MEMSHARED   = 0x0800;
    public static final short MEMBUFFERS  = 0x1000;
    public static final short MEMCACHED   = 0x2000;
    public static final short SWAPFREE    = 0x4000;
    public static final short TIME        = (short)0x8000;

    public TracesConfig t_config;
    public short[] masks;
    public TracerConfig[] configs;
    public TracerState[] states;


    public class Data {
        public double timeStamp;
        public double value;

        public Data (double t, double v) {
            timeStamp = t;
            value = v;
        }
    }


    /**
     * This tests whether traces includes some values since they have
     * only been stored if they changed between two data acquisitions
     * e.g. if   mask[index] & CPUUSER
     *      then TracerState[index] contains a CPUUSER data
     * @param index to address mask array
     * @param dataType to test masks[index]
     * @return a boolean as test result
     */
    private boolean testMask (int index, int dataType) {

        /*
          System.out.println ("testMask (" + index + ", " +  dataType + ") "
          + (masks [index] & dataType));
        */
        return ((masks [index] & dataType) != 0);
    }


    /**
     * This counts how many traces are effectivly stored
     * @param dataType determines interesting values
     * @return a boolean as test result
     */
    private int maskLength (int dataType) {
        int ret = 0;
        for (int loop = 0; loop < masks.length; loop++) {
            if (testMask (loop, dataType))
                ret++;
        }
        return ret;
    }


    /**
     * This extracts processes informations 
     * @param total is a boolean to determine whether to collect total 
     *        or running processes
     * @return an hashtable, as as getCPU ()
     */
    private Data[] processes (boolean total)
    {
        int dataType = PROCRUN | PROCTOTAL;
        Data[] ret = new Data [maskLength (dataType)];
        double pProcs = 0;
        double procsTotal = (double)(configs [0].memTotal);
        int index = 0;

        for (int loop = 0; loop < masks.length; loop++) {
            if (testMask (loop, dataType)) {

                /*
                  System.out.print ("loop = " + loop);
                  System.out.print (" index = " + index);
                  System.out.println ("time = " + states[loop].time); 
                */
                double dTime = (double)(states [loop].time);

                // * 100 because time is in hundreds of seconde
                dTime *= 100.0;

                long prun = (long)states[loop].procRun;
                long ptotal = (long)states[loop].procTotal;

                /*
                  System.out.print ("procRun   = " + states[loop].procRun +
                  " (long)" + prun);
                  System.out.println (" procTotal   = " + states[loop].procTotal +
                  " (long)" + ptotal);
                */
                if (total)
                    pProcs = (double)ptotal;
                else {
                    if (ptotal > 0)
                        pProcs = (double)((double)prun / (double)ptotal);
                    else
                        pProcs = 0;
                }

                ret [index++] = new Data(dTime, pProcs);
            }
        }

        return ret;

    } // end of runningProcesses ()


    /**
     * This extracts running procs 
     * @return an hashtable, as as getCPU ()
     */
    public Data[] runningProcesses ()
    {
        return processes (false);
    } // end of runningProcesses ()


    /**
     * This extracts total procs 
     * @return an hashtable, as as getCPU ()
     */
    public Data[] totalProcesses ()
    {
        return processes (true);
    } // end of runningProcesses ()


    /**
     * This extracts memory informations
     * @param used is a boolean to determine whether to collect used
     *        or free memory
     * @return an hashtable, as as getCPU ()
     */
    private Data[] memory (boolean used)
    {
        int dataType = MEMFREE;
        Data[] ret = new Data [maskLength (dataType)];
        double pMem = 0;
        double memTotal = (double)(configs [0].memTotal);
        int index = 0;

        for (int loop = 0; loop < masks.length; loop++) {
            if (testMask (loop, dataType)) {

                double dTime = (double)(states [loop].time);

                // * 100 because time is in hundreds of seconde
                dTime *= 100.0;

                /*
                  System.out.println ("memFree = " + (double)states[loop].memFree +
                  "mem     = " + (double)configs [0].memTotal);
                */
                if (configs [0].memTotal > 0)
                    pMem = (double)((double)states [loop].memFree / (double)configs [0].memTotal);
                else
                    pMem = 0;

                pMem *= (double)100;
                if (used)
                    pMem = (double)100 - pMem;
                else
                    pMem = pMem;

                ret [index++] = new Data(dTime, pMem);
            }
        }

        return ret;

    } // end of memory ()


    /**
     * This extracts used memory
     * @return an hashtable, as as getCPU ()
     */
    public Data[] memoryUsed ()
    {
        return memory (true);
    }


    /**
     * This extracts free memory
     * @return an hashtable, as as getCPU ()
     */
    public Data[] memoryFree ()
    {
        return memory (false);
    }


    /**
     * This extracts swap informations
     * @param used is a boolean to determine whether to collect used
     *        or free swap
     * @return an hashtable, as as getCPU ()
     */
    private Data[] swap (boolean used)
    {
        int dataType = SWAPFREE;
        Data[] ret = new Data [maskLength (dataType)];
        double pSwap = 0;
        double swapTotal = (double)(configs [0].swapTotal);
        int index = 0;

        for (int loop = 0; loop < masks.length; loop++) {
            if (testMask (loop, dataType)) {

                double dTime = (double)(states [loop].time);

                // * 100 because time is in hundreds of seconde
                dTime *= 100.0;

                /*
                  System.out.println ("swapFree = " + (double)states[loop].swapFree +
                  "swap     = " + (double)configs [0].swapTotal);
                */
                if (configs [0].swapTotal > 0)
                    pSwap = (double)((double)states [loop].swapFree / (double)configs [0].swapTotal);
                else
                    pSwap = 0;

                pSwap *= (double)100;
                if (used)
                    pSwap = (double)100 - pSwap;
                else
                    pSwap = pSwap;

                ret [index++] = new Data(dTime, pSwap);
            }
        }

        return ret;

    } // end of swap ()


    /**
     * This extracts used swap
     * @return an hashtable, as as getCPU ()
     */
    public Data[] swapUsed ()
    {
        return swap (true);
    }


    /**
     * This extracts free swap
     * @return an hashtable, as as getCPU ()
     */
    public Data[] swapFree ()
    {
        return swap (false);
    }


    /**
     * This extracts data accordingly to param dataType
     * @param  dataType to determine which data to work on
     * @return a hastable containing time stamps as keys, and data as values
     */
    private Data[] getCPU (int dataType)
    {
        Data[] ret = new Data [maskLength (dataType)];
        int nbTraces = 0;
        double pCPU = 0;

        /*
          System.out.println ("data length = " + ret.length);
          System.out.println ("data length = " + maskLength (dataType));
        */
        int index = 0;

        for (int loop = 0; loop < masks.length; loop++) {
            if (testMask (loop, dataType)) {

                double dTime = (double)(states [loop].time);

                long totalUsedCPU = 0;

                if (testMask (loop, CPUUSER))
                    totalUsedCPU += states [loop].cpuUser;
                if (testMask (loop, CPUNICE))
                    totalUsedCPU += states [loop].cpuNice;
                if (testMask (loop, CPUSYSTEM))
                    totalUsedCPU += states [loop].cpuSystem;

                long totalCPU = (states [loop].cpuUser +
                                 states [loop].cpuNice +
                                 states [loop].cpuSystem +
                                 states [loop].cpuIdle);

                if (totalCPU > 0)
                    pCPU = (double)((double)totalUsedCPU / (double)totalCPU);
                else
                    pCPU = 0;

                pCPU *= (double)100;

                ret [index++] = new Data(dTime, pCPU);
                //	System.out.println ("ret [" + (index - 1) + "] = " + ret [index - 1].value);

            } // if (CPUUSER)
        }   // for (loop)

        return ret;

    } // end of getCPU ()


    /**
     * This extracts used CPU percentage, including all but idle
     * returns: see getCPU ()
     */
    public Data[] usedCPU ()
    {
        int dataType = CPUUSER | CPUNICE | CPUSYSTEM;
        return getCPU (dataType);
    }


    /**
     * This extracts idle CPU percentage
     * returns: see getCPU ()
     */
    public Data[] idleCPU ()
    {
        int dataType = CPUIDLE;
        return getCPU (dataType);
    }


    /**
     * This extracts nice CPU percentage
     * returns: see getCPU ()
     */
    public Data[] niceCPU ()
    {
        int dataType = CPUNICE;
        return getCPU (dataType);
    }


    /**
     * This extracts user CPU percentage
     * returns: see getCPU ()
     */
    public Data[] userCPU ()
    {
        int dataType = CPUUSER;
        return getCPU (dataType);
    }


    /**
     * This extracts system CPU percentage
     * returns: see getCPU ()
     */
    public Data[] systemCPU ()
    {
        int dataType = CPUSYSTEM;
        return getCPU (dataType);
    }

}
