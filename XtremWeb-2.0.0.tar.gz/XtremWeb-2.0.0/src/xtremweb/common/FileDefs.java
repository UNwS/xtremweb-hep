package xtremweb.common;

public class FileDefs {
		public static final String SUFFIX_ZIP    = ".zip";
		public static final String SUFFIX_IN     = "_xw_in";
		public static final String SEPARATOR_IN  = SUFFIX_IN + "_";
		public static final String SUFFIX_IN_ZIP = SUFFIX_IN + SUFFIX_ZIP;
		public static final String SUFFIX_OUT     = "_xw_out";
		public static final String SEPARATOR_OUT  = SUFFIX_OUT + "_";
		public static final String SUFFIX_OUT_ZIP = SUFFIX_OUT + SUFFIX_ZIP;
};

