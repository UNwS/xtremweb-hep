package xtremweb.rpcv;

import java.lang.Exception;

/**
 * RpcvException.java
 *
 *
 * Created: Thu Apr 24 13:24:19 2003
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */
public class RpcvException extends Exception {
    String message;
    public RpcvException() {	
    } // RpcvException constructor

    public RpcvException(String message) {	
    } // RpcvException constructor

    public String toString () {
	return message;
    }
} // RpcvException
