package xtremweb.rpcv;
import xtremweb.communications.*;

/**
 * RpcvRef.java
 *
 *
 * Created: Wed Apr 23 17:56:27 2003
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */

public class RpcvRef {

    private TCPClient comClient;
    private String service;

    public RpcvRef(TCPClient c, String s) {
	comClient = c;
	service = s;
    }
    
} // RpcvRef
