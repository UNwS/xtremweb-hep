package xtremweb.rpcv;

import xtremweb.XwIDL.*;
import xtremweb.client.*;
import xtremweb.common.*;
import xtremweb.communications.*;
import xtremweb.servreg.*;

import java.net.*;


public class RpcvClient {

    private TCPClient cc;

    public RpcvClient (TCPClient c, String dispatcher, int port )  {
				cc=c;
				try {
						cc.initComm (dispatcher);	     
				} catch(Exception ce) {
						System.out.println(ce) ;
						//	    throw new RpcvException( "No connection to server : " + ce);
				} // end of try-catch
    }

    public RpcvClient( String dispatcher, int port, String login, String password) {
				//cc = new TCPClient(login, password);
				// Jun 3rd, 2005 : pas le temps de porter Rpcv...
				cc = null;
				try {
						cc.initComm(dispatcher);	     
				} catch(Exception ce) {
						cc = null;
						//	    throw new RpcvException( "No connection to server : " + ce);
				} // end of try-catch
    }

    public RpcvRef lookup (String service)  throws RpcvException { 
				if ( cc == null) {
						throw new RpcvException( "You must have a valid client connection");
				} 
	
				return new RpcvRef(cc, service);
    }
    
    public Object invoke (String method, Object[] args) {
				return new Object();
    }

    public static void main(String[] args) {
				new ModuleLoader();
				ModuleLoader.rmiBackPort=4347;
				ModuleLoader.rmiPort=4342;
				try {
						ModuleLoader.addCallback( "servreg" );
				} catch (ModuleLoaderException e) {
						System.err.println("ModuleLoader main(): " +  e);
						System.exit( 1);
				}
				try {
						ModuleLoader.addHandler( "servreg", "RMI", 4342 );
				} catch (ModuleLoaderException e) {
						System.err.println("ModuleLoader main(): " +  e);
						System.exit( 1);
				}
				//push dispatcher as a remote servreg 
				try {
						((Callbackservreg) ModuleLoader.getModule("servreg")).sr.registerServices( "servreg", new UID(), InetAddress.getLocalHost() , 4322);
				} catch ( Exception uhe) {
						System.err.println("Cannot register dispatcher " +uhe);
				} // end of try-catch

				CommRMIservreg comm = new CommRMIservreg();
				try {
						comm.initComm( "localhost", 4342, "servreg");
						ServiceLocator sl = comm.findService( "servreg" );
						System.out.println("Found service servreg :" + sl.uid + sl.ip );
				} catch(Exception e) {
						System.err.println("Cannot find service " +e);
				} // end of try-catch
	

    }
}
