/**
 * DBConnPool.java
 * 
 * 
 * Created: Sun Jun 10 16:06:17 2001
 * 
 * @author <a href="mailto:fedak /at\ lri.fr ">Gilles Fedak </a>
 * @version
 */

package xtremweb.dispatcher;

import xtremweb.common.util;
import xtremweb.common.UID;
import xtremweb.common.Logger;
import xtremweb.common.LoggerLevel;
import xtremweb.common.MileStone;
import xtremweb.common.XWPropertyDefs;

import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;
import java.util.LinkedList;
import java.util.Collections;


public class DBConnPool extends Logger {
    /**
     * This contains the complete reference to the database location
     */
    private String dburl;

    /**
     * This is a synchronized list containing connections to database
     */
    private List connPool;

    /**
     * This is a synchronized list containing milestoning system
     * @see xtremweb.common.MileStone
     */
    private List mileStones;

    // Maximunm number of connections
    private final int MAXX_CONNECTIONS = 10;

    /**
     * This is the singleton
     */ 
    public static DBConnPool instance = null;

    /**
     * This contains this class name
     */
    private String className;

    /**
     * This is the default and only constructor
     */
    public DBConnPool(LoggerLevel l) {
        super(l);

        if(instance != null)
            return;

        //RPCXW
        if (Dispatcher.config.hsqldbmem())
            dburl = "jdbc:hsqldb:mem:" + 
                Dispatcher.config.getProperty(XWPropertyDefs.DBNAME.toString());
        else
            dburl = "jdbc:" + 
                Dispatcher.config.getProperty(XWPropertyDefs.DBVENDOR.toString()) +
                "://" + 
                Dispatcher.config.getProperty(XWPropertyDefs.DBHOST.toString()) +
                "/" +
                Dispatcher.config.getProperty(XWPropertyDefs.DBNAME.toString());

        //connPool = new LinkedList();
        connPool = Collections.synchronizedList(new LinkedList());
        mileStones = Collections.synchronizedList(new LinkedList());

        try {
            // RPCXW
            if (Dispatcher.config.hsqldb()) {
                debug("org.hsqldb.jdbcDriver");
                Class.forName("org.hsqldb.jdbcDriver");
            }
            else {
                debug("org.gjt.mm.mysql.Driver");
                Class.forName("org.gjt.mm.mysql.Driver");
            }
        } catch (java.lang.ClassNotFoundException e) {
            warn("ClassNotFoundException: " + e.getMessage());
        }

        className = getClass().getName();

        debug("dburl      = '" + dburl + "' " +
              "dbuser     = '" + 
              Dispatcher.config.getProperty(XWPropertyDefs.DBUSER.toString()) +
              "' dbpassword = '" +
              Dispatcher.config.getProperty(XWPropertyDefs.DBPASS.toString()) + "'");

        for (int i = 0; i < MAXX_CONNECTIONS; i++) {

            //						logger.debug (dburl);
            // Establish Connection to the database at URL with usename and
            // password
            Connection conn = getConnection(dburl,
                                            Dispatcher.config.getProperty(XWPropertyDefs.DBUSER.toString()),
                                            Dispatcher.config.getProperty(XWPropertyDefs.DBPASS.toString()));
            if (conn != null) {
                //                connPool.add(conn);
                pushConnection(conn);
                mileStones.add(new MileStone(className));
            }
        }

        //RPCXW
        if (Dispatcher.config.hsqldb())
            hsqldbCreateTables();

        info ("Connection to database " + dburl + " is ok, " +
              connPool.size() + " created");

        if (instance == null)
            instance = this;
    }

    /**
     * This creates a new database connector
     */
    //		private synchronized Connection getConnection(String dbname, String dbuser,
    private Connection getConnection(String dbname, String dbuser,
                                     String dbpassword) {
        Connection con = null;
        try {

            // Establish Connection to the database at URL with usename and
            // password
            con = DriverManager.getConnection(dbname, dbuser, dbpassword);

        } catch (SQLException ex) {
            dumpException(ex);
        }
        //				notifyAll();
        return con;
    }

    /**
     * This gets a connection from connPool.
     * This waits an available connection from connPool.
     */
    private synchronized Connection popConnection() {

        while (connPool.size() <= 0) {
            try {
                wait();
            } catch (InterruptedException e) {}
        }
        Connection conn = (Connection) connPool.remove(0);

        notifyAll();
        return conn;
    }

    /**
     * This stores a connection into connPool and notify all waiting thread
     */
    private synchronized void pushConnection(Connection conn) {

        connPool.add(conn);
        notifyAll();
    }

    /**
     * This creates in memory tables in case of hsqldb:mem
     */
    private void hsqldbCreateTables() {

	String memory = new String();
        if (Dispatcher.config.hsqldbmem())
	    memory = "MEMORY";
        //        Connection conn = (Connection) connPool.remove(0);
        Connection conn = popConnection();

        String apps = new String("CREATE " + memory + " TABLE apps ("
                                 + "uid char primary key,"
                                 + "ownerUID char,"
                                 + "name char,"
                                 + "isService char DEFAULT 'false',"
                                 + "accessRights int DEFAULT 1877," // 0x755
                                 + "avgExecTime int,"
                                 + "minMemory int,"
                                 + "minCPUSpeed int," 
                                 + "nbJobs int,"
				 + "defaultStdinURI char,"
				 + "baseDirinURI char,"
				 + "defaultDirinURI char,"
				 + "linux_ix86URI char,"
				 + "linux_amd64URI char,"
				 + "linux_ppcURI char,"
				 + "macosx_ix86URI char,"
				 + "macosx_ppcURI char,"
				 + "win32_ix86URI char,"
				 + "win32_amd64URI char,"
				 + "javaURI char,"
				 + "osf1_alphaURI char,"
				 + "osf1_sparcURI char,"
				 + "solaris_alphaURI char,"
				 + "solaris_sparcURI char,"
				 + "ldlinux_ix86URI char,"
				 + "ldlinux_amd64URI char,"
				 + "ldlinux_ppcURI char,"
				 + "ldmacosx_ix86URI char,"
				 + "ldmacosx_ppcURI char,"
				 + "ldwin32_ix86URI char,"
				 + "ldwin32_amd64URI char,"
				 + "ldosf1_alphaURI char,"
				 + "ldosf1_sparcURI char,"
				 + "ldsolaris_alphaURI char,"
				 + "ldsolaris_sparcURI char,"
				 + "isdeleted char DEFAULT 'false',"
                                 + "CONSTRAINT apps_uniq_name UNIQUE (name))");
        String datas = new String("CREATE " + memory + " TABLE datas ("
                                  + "uid char primary key,"
                                  + "ownerUID char,"
                                  + "uri char,"
				  + "accessRights int DEFAULT 1877," // 0x755
                                  + "name char,"
                                  + "links int,"
                                  + "accessDate datetime,"
                                  + "insertionDate datetime,"
                                  + "status char,"
                                  + "type char,"
                                  + "os char,"
                                  + "cpu char,"
                                  + "md5 char,"
                                  + "size int,"
                                  + "sendToClient char DEFAULT 'false',"
                                  + "replicated char DEFAULT 'false',"
				  + "isdeleted char DEFAULT 'false')");
        String hosts = new String("CREATE " + memory + " TABLE hosts ("
                                  + "uid char primary key,"
                                  + "nbJobs int,"
                                  + "timeOut int,"
                                  + "avgExecTime int,"
                                  + "lastAlive datetime,"
                                  + "name char,"
                                  + "nbconnections int,"
                                  + "natedipaddr char,"
                                  + "ipaddr char,"
                                  + "hwaddr char,"
                                  + "timezone char,"
                                  + "os char,"
                                  + "cputype char,"
                                  + "cpunb int,"
                                  + "cpumodel char,"
                                  + "cpuspeed int,"
                                  + "totalmem int,"
                                  + "totalswap int,"
                                  + "timeShift int,"
                                  + "avgping int,"
                                  + "nbping int,"
                                  + "uploadbandwidth int,"
                                  + "downloadbandwidth int,"
                                  + "userUID char,"
                                  + "project char,"
                                  + "active char DEFAULT 'true',"
                                  + "available char DEFAULT 'false',"
                                  + "acceptbin char DEFAULT 'true',"
                                  + "version char,"
                                  + "traces char DEFAULT 'false',"
				  + "isdeleted char DEFAULT 'false')");
        String usergroups = new String("CREATE " + memory + " TABLE usergroups ("
                                       + "uid char primary key,"
                                       + "label char,"
				       + "project char DEFAULT 'true',"
				       + "isdeleted char DEFAULT 'false',"
				       + "CONSTRAINT usergroups_uniq_label UNIQUE (label))");
        String users = new String("CREATE " + memory + " TABLE users ("
                                  + "uid char primary key,"
                                  + "usergroupUID char,"
                                  + "nbJobs int,"
                                  + "login char,"
                                  + "password char DEFAULT '',"
                                  + "email char DEFAULT '',"
                                  + "fname char,"
                                  + "lname char,"
                                  + "country char,"
                                  + "rights char DEFAULT 'NONE',"
				  + "isdeleted char DEFAULT 'false',"
                                  + "CONSTRAINT users_uniq_login UNIQUE (login))");
        String tasks = new String("CREATE " + memory + " TABLE tasks ("
                                  + "uid char primary key,"
                                  + "hostUID char,"
                                  + "trial int,"
                                  + "status char,"
                                  + "InsertionDate datetime,"
                                  + "StartDate datetime,"
                                  + "LastStartDate datetime,"
                                  + "AliveCount int,"
                                  + "LastAlive datetime,"
                                  + "removalDate datetime,"
                                  + "duration int,"
                                  + "isDeleted char DEFAULT 'false')");
        String works = new String("CREATE " + memory + " TABLE works ("
                                  + "uid char primary key,"
                                  + "expectedhostUID char,"
				  + "accessRights int DEFAULT 1877," // 0x755
                                  + "sessionUID char,"
                                  + "groupUID char,"
                                  + "label char,"
                                  + "appUID char,"
                                  + "userUID char,"
                                  + "status char,"
                                  + "maxRetry int,"
                                  + "minMemory int,"
                                  + "minCPUSpeed int," 
                                  + "returnCode int,"
                                  + "server char,"
                                  + "cmdLine char,"
                                  + "stdinURI char,"
                                  + "dirInURI char,"
                                  + "resultURI char,"
                                  + "arrivalDate datetime,"
                                  + "completedDate datetime,"
                                  + "resultDate datetime,"
                                  + "error_msg char,"
                                  + "sendToClient char DEFAULT 'false',"
                                  + "local char DEFAULT 'true',"
                                  + "active char DEFAULT 'true',"
                                  + "replicated char DEFAULT 'false',"
                                  + "isService char DEFAULT 'false',"
                                  + "isDeleted char DEFAULT 'false')");
        String sessions = new String("CREATE " + memory + " TABLE sessions ("
                                     + "uid char primary key,"
                                     + "name char ,"
                                     + "clientUID char,"
				     + "isDeleted char DEFAULT 'false')");
        String groups = new String("CREATE " + memory + " TABLE groups ("
                                   + "uid char primary key,"
                                   + "name char ,"
                                   + "sessionUID char ,"
                                   + "clientUID char,"
				   + "isDeleted char DEFAULT 'false')");
        String traces = new String("CREATE " + memory + " TABLE traces ("
                                   + "uid char primary key,"
                                   + "hostUID char DEFAULT '' ,"
                                   + "login char DEFAULT '' ,"
                                   + "arrivalDate datetime ,"
                                   + "startDate datetime,"
                                   + "endDate datetime ,"
                                   + "data char DEFAULT '',"
				   + "isDeleted char DEFAULT 'false')");
        String grants = new String("GRANT ALL PRIVILEGES ON " 
                                   + Dispatcher.config.getProperty(XWPropertyDefs.DBNAME.toString()) + ".* TO "
                                   + Dispatcher.config.getProperty(XWPropertyDefs.DBUSER.toString()) + "@" + Dispatcher.config.getProperty(XWPropertyDefs.DBHOST.toString()) 
                                   + " IDENTIFIED BY '" + Dispatcher.config.getProperty(XWPropertyDefs.DBPASS.toString())
                                   + "' WITH GRANT OPTION;");
        String insertAdmin = new String ("insert into users (uid,login,"
                                         + "password,fname,lname,email,rights) "
                                         + "values('" + new UID().toString() + "',"
                                         + "'administrator','2bd109f2817f9e4c09b3f61f78735d66',"
                                         + "'','','','SUPER_USER')");
        String insertWorker = new String ("insert into users (uid,login,"
                                          + "password,fname,lname,email,rights) "
                                          + "values('" + new UID().toString() + "',"
                                          + "'xwworker','8413f3bb48c2ec1f036d7bec675b9629',"
                                          + "'','','','WORKER_USER')");
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(apps);
            rs = stmt.executeQuery(datas);
            rs = stmt.executeQuery(hosts);
            rs = stmt.executeQuery(usergroups);
            rs = stmt.executeQuery(users);
            rs = stmt.executeQuery(tasks);
            rs = stmt.executeQuery(works);
            rs = stmt.executeQuery(sessions);
            rs = stmt.executeQuery(groups);
            rs = stmt.executeQuery(traces);
            rs = stmt.executeQuery(insertAdmin);
            rs = stmt.executeQuery(insertWorker);

        } 
	catch (SQLException ex) {
            ex.printStackTrace ();
            util.fatal("ExecuteQuery SQLExecption: " + ex.getMessage());
        }

        pushConnection(conn);
    }

    /**
     * This executes SQL query
     */
    //		public synchronized ResultSet executeQuery(String query) {
    public ResultSet executeQuery(String query) {

        debug(query);

        MileStone mileStone = null;

        //        Thread.currentThread().dumpStack();

        if(mileStones.size() > 0)
            mileStone = (MileStone)mileStones.remove(0);
        else
            mileStone = new MileStone(className);

        mileStone.clear();
        if(query.length() < 80)
            mileStone.stamp(query);
        else
            mileStone.stamp(query.substring(0, 80) + "...");

        Connection conn = null;

//         if(connPool.size() > 0)
//             conn = (Connection) connPool.remove(0);
//         else
//             conn = getConnection(dburl,
//                                  Dispatcher.config.getProperty(XWPropertyDefs.DBUSER.toString()),
//                                  Dispatcher.config.getProperty(XWPropertyDefs.DBPASS.toString()));
        conn = popConnection();

        ResultSet rs = null;

        //				mileStone.stamp("connected");

        // try 3 times then return null
        for (int i = 0; i < 3; i++) {
            Statement stmt = null;
            try {
                stmt = conn.createStatement();

                //								mileStone.stamp("got statement");

                rs = stmt.executeQuery(query);

                //								mileStone.stamp("result set");

                break;
            }
            catch(Exception ex) {
                warn("ExecuteQuery SQLExecption " + 
                     "stmt.executeQuery(" + query + ") : " +
                     ex.getMessage());
                try {
                    if(stmt.execute(query)) {
                        rs = stmt.getResultSet();
                    }
                    if(rs==null) {
                        rs=stmt.getGeneratedKeys();
                    }
                    warn("ExecuteQuery SQLExecption " + 
                         "stmt.getGeneratedKeys() OK" + 
                         ex.getMessage());
                    break;
                }
                catch(Exception ex2) {
                    error("ExecuteQuery SQLExecption: " + ex2.getMessage());
                    error("ExecuteQuery SQLExecption: " + query);
                    ex.printStackTrace ();
                }
//                 conn = getConnection(dburl,
//                                      Dispatcher.config.getProperty(XWPropertyDefs.DBUSER.toString()),
//                                      Dispatcher.config.getProperty(XWPropertyDefs.DBPASS.toString()));
            }
        }

        //        connPool.add(conn);
        pushConnection(conn);

        //				mileStone.stamp("query executed");
        mileStone.dump();
        mileStones.add(mileStone);

        return rs;
    }

    /**
     * This dumps SQL exceptions
     */
    public void dumpException(SQLException ex) {
        warn("==> SQLException: ");
        while (ex != null) {
            warn("Message:   " + ex.getMessage());
            warn("SQLState:  " + ex.getSQLState());
            warn("ErrorCode: " + ex.getErrorCode());
            warn(ex.toString());
            ex = ex.getNextException();
        }
    }

}
