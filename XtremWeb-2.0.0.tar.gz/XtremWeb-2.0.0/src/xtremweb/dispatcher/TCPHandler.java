package xtremweb.dispatcher;

import xtremweb.common.util;
import xtremweb.common.LoggerLevel;
import xtremweb.common.UID;
import xtremweb.common.StreamIO;
import xtremweb.common.BytePacket;
import xtremweb.common.XMLVector;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLable;
import xtremweb.common.XWOSes;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWPropertyDefs;

import xtremweb.communications.CommHandler;
import xtremweb.communications.XMLRPCCommand;

import java.io.IOException;
import java.io.File;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.nio.channels.DatagramChannel;
import java.net.SocketAddress;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.rmi.RemoteException;



/**
 * This handles incoming communications through TCP<br>
 * This answers request from TCPClient
 *
 * Created: August 2005
 *
 * @see xtremweb.communications.TCPClient
 * @author Oleg Lodygensky
 * @version RPCXW
 */

//public class TCPHandler extends Thread implements xtremweb.communications.CommHandler {
public class TCPHandler extends xtremweb.dispatcher.CommHandler {

    private Socket socket = null;
    protected StreamIO io;

    /**
     * This is the default constructor which only calls super("TCPHandler")
     */
    public TCPHandler(){
        super("TCPHandler");
    }
    /**
     * This is the default constructor which only calls super("TCPHandler")
     */
    public TCPHandler(XWConfigurator context){
        this("TCPHandler", context);
    }
    
    /**
     * This is the default constructor which only calls super("TCPHandler")
     */
    public TCPHandler(String n, XWConfigurator context){
        super(n, context);
    }
    
    /**
     * This constructor call the default constructor and sets the logger level
     * @param l is the logger level 
     * @see #TCPHandler(XWConfigurator)
     */
    public TCPHandler(LoggerLevel l, XWConfigurator context) throws RemoteException {
        this(context);
        setLoggerLevel(l);
    }
    
    /**
     * This constructor call the previous constructor and sets the socket
     * @param socket is the socket 
     * @param l is the logger level 
     * @see #TCPHandler(Level, XWConfigurator)
     */
    public TCPHandler(Socket socket, LoggerLevel l, XWConfigurator context) throws RemoteException {
        this(l, context);
        this.socket = socket;
    }

    /**
     * @see xtremweb.communications.CommHandler#setSocket(Socket)
     */
    public void setSocket(Socket s) throws RemoteException{
        socket = s;

        boolean net = Boolean.parseBoolean(config.getProperty(XWPropertyDefs.OPTIMIZENET.toString()));
        // mac os x don't like that :(
        if((net == true) &&
           (XWOSes.getOs().isMacosx() == false)) {
            try {
                socket.setSoLinger(false, 0);          // don't wait on close
                socket.setTcpNoDelay(true);            // don't wait to send
                socket.setTrafficClass(0x08);          // maximize throughput
                socket.setKeepAlive(false);            // don't keep alive
            }
            catch(Exception e) {
                warn(e.toString());
            }
        }
    }
    /**
     * This throws an exception since setPacket() is dedicated to UDP comms
     * @exception RemoteException is always thrown since this method is dedicated to UDP comms
     */
    public void setPacket(DatagramSocket s, DatagramPacket p) throws RemoteException{
        throw new RemoteException("TCPHandler#setPacket() TCP can't set packet");
    }
    /**
     * @see xtremweb.communications.CommHandler#setSocket(Socket)
     * @exception RemoteException is always thrown since this method is dedicated to UDP comms
     */
    public void setPacket(DatagramChannel c, SocketAddress r, BytePacket p) throws RemoteException {
        throw new RemoteException("TCPHandler#setPacket() TCP can't set packet");
    }

    protected void write(XMLable cmd) throws IOException {
        try {
            mileStone.println("<write>");
            io.writeObject(cmd);
            mileStone.println("</write error='no'>");
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("</write error='yes'>");
            throw new IOException(e.toString());
        }
    }
    /**
     * This writes a file to socket
     * @param f is the file to send
     */
    public synchronized void writeFile(File f) throws IOException {
        try {
            mileStone.println("<writeFile file='" + f + "'>");
            io.writeFile(f);
            mileStone.println("</writeFile error='no'>");
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("</writeFile error='yes'>");
            throw new IOException(e.toString());
        }
    }
    /**
     * This reads a file from socket
     * This is typically needed after a workRequest to get stdin and/or dirin files
     * @param f is the file to store received bytes
     */
    public synchronized void readFile(File f) throws IOException {
        try {
            mileStone.println("<readFile file='" + f + "'>");
            io.readFile(f);
            mileStone.println("<readFile error='no'>");
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("<readFile error='yes'>");
            throw new IOException(e.toString());
        }
    }
    /**
     * This is the main loop; this is called by java.lang.Thread#start()
     * This executes one command form communication channel and exists
     * @see CommHandler#run(XMLRPCCommand)
     */
    public void run() {

        try {
            remoteName = socket.getInetAddress().getHostName();
            remoteIP   = socket.getInetAddress().getHostAddress();
            remotePort = socket.getPort();

            boolean nio = Boolean.parseBoolean(config.getProperty(XWPropertyDefs.NIO.toString()));

            io = new StreamIO(new DataOutputStream(socket.getOutputStream()),
                              new DataInputStream(socket.getInputStream()),
                              socket.getSendBufferSize(), 
                              level,
                              nio);

            XMLRPCCommand cmd = XMLRPCCommand.newCommand(io);
            debug("command received " + cmd.toXml());
            super.run(cmd);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    } // run()

    /**
     * This cleans and closes communications
     */
    public void close(){
        //Clean up 
        try{
            mileStone.println("<close>");
            if(socket.isClosed() == false) {
                socket.close();
            }
            io.close();
        } 
        catch(IOException e) {
            if(debug())
                e.printStackTrace();
            warn("Could not close.");
        }
        mileStone.println("</close>");
    }
}
