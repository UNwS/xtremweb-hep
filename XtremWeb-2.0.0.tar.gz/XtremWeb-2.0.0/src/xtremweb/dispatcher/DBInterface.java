package xtremweb.dispatcher;

import xtremweb.common.util;
import xtremweb.common.Logger;
import xtremweb.common.LoggerLevel;
import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.MileStone;
import xtremweb.common.XWStatus;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.XWAccessRights;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserRights;
import xtremweb.common.WorkInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.SessionInterface;
import xtremweb.communications.Connection;

import java.io.IOException;
import java.io.File;
import java.net.InetAddress;
import java.rmi.RemoteException;
import java.security.InvalidKeyException;
import java.security.AccessControlException;
import java.sql.*;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Iterator;

/**
 * DBInterface.java Created: Sun Feb 25 22:06:12 2001
 * 
 * @author Gilles Fedak
 * @version %I% %G%
 */


public class DBInterface extends Logger {

    /**
     * This aims to display some time stamps
     */
    MileStone mileStone;

    /**
     * Constants that define some fixed dirnames These are not considered as
     * "hardcoded", but a part of the specification.
     */

    private int stat_counter = 0;

    //To recovers works when a server has crashed
    private boolean recoverWorks = true;

    public static DBInterface instance = null;
    public xtremweb.dispatcher.RM.Replicator replicator = null;

    /**
     * This implements connection to database
     */
    private DBConnPool dbConnPool;
    /**
     * This caches database 
     */
    public DBCache cache;


    /**
     * This is the default and only constructor
     */
    public DBInterface(LoggerLevel l) throws Exception {
        super(l);
        dbConnPool = new DBConnPool(level);
        cache = new DBCache(level);
        mileStone = new MileStone(getClass().getName());

        replicator = new xtremweb.dispatcher.RM.Replicator();

        updateAppsPool();

        /*
         * Traces : create directory if needed
         */
        String tracesDirName = getTracesPath();
        File d = new File(tracesDirName);
        if(!d.exists())
            d.mkdir();

        instance = this;

        retreiveUnfinishedTasks();
    }


    /**
     * This retreives uncompleted tasks from DB
     */
    private void retreiveUnfinishedTasks() {
        try {

            String query;
            //System.out.println("Hashtaskset#retreiveUnfinishedTasks 00");

            try {
                query = "SELECT * FROM tasks WHERE isdeleted='false' AND ((status != '" + 
                    XWStatus.COMPLETED + "' AND status != '" + 
                    XWStatus.ERROR + "' AND status != 'SAVED') ";

                if(Dispatcher.config.hsqldb() == false)
                    query += "OR ISNULL(status))"; //LIMIT "+MAX_TASK;
                else
                    query += "OR status IS NULL)";
            }
            catch(Exception e) {
                warn(e.toString());
                if(debug())
                    e.printStackTrace();
                return;
            }

            ResultSet rs = DBConnPool.instance.executeQuery(query);
	    int nbTasks = 0;

            while(rs.next()) {
                try {
                    retreiveUnfinishedTask(new Task(rs));
		    nbTasks++;
                }
                catch(Exception e) {
                    warn(e.toString());
                    if(debug())
                        e.printStackTrace();
                }
            } // end of while
            info("retreiveUnfinishedTask  retreived " + nbTasks);
            try {
		info("retreiveUnfinishedTask  tasks.size = " + cache.taskSize());
	    }
	    catch(Exception ex) {
	    }
	}
        catch(SQLException ex) {
            warn("retreiveUnfinishedTask  " + ex);
            if(debug())
                ex.printStackTrace();
        }
    }

    private void retreiveUnfinishedTask(Task theTask) {

        try {
            if(theTask.getStatus() != XWStatus.PENDING) {
                theTask.setPending();
                theTask.update();
            }
            cache.put(theTask);
        }
        catch(Exception e) {
            warn("retreiveUnfinishedTask " + e.toString());
            if(debug())
                e.printStackTrace();
        }
    }



    /**
     * This reads the apps table
     */
    public  void updateAppsPool() {

        // since RPC-V
        InetAddress myIP = null;

        try {

            UID uid;
            String appName;
            boolean isService = false;

            cache.app();
            Enumeration enums = cache.apps();

            while(enums.hasMoreElements()) {

                uid = new UID((String)enums.nextElement());
                App theApp = cache.app(uid);
                try {
                    theApp = cache.app(uid);
                    appName = theApp.getName();
                    isService = theApp.isService();
                } 
                catch(Exception e) {
                    error(e.toString());
                    if(debug())
                        e.printStackTrace();
                    continue;
                }

            } // end of while

        } catch(Exception ex) {
            ex.printStackTrace();
        }

    } // updateAppsPool()
    /**
     * This retreives new pending works from DB table works
     * @see TaskSet#refill()
     */
    public  Work getWork(String server) {

        Work work = null;

        //
        // first, try to find a work from cache
        //
        try {
            Enumeration enums = cache.works();
            while(enums.hasMoreElements()) {
                UID work_uid = new UID((String)enums.nextElement());
                work = cache.work(work_uid);
                if((work.isWaiting() ==  true) && (work.isActive() ==  true)) {
                    // Now, the work is locked by the server
                    if(((work.getServer() != null) &&
                        (work.getServer().compareTo(server) != 0)) ||
                       (work.getServer() == null)){
                        work.setServer(server);
                        work.update();
                        debug("getWork() found from cache : " + work.getUID());
                        return work;
                    }
                }
            }
        }
        catch(Exception e) {
            // error("DBInterface#getWork() : no work in cache");
        }

        //
        // no work in cache, try to find one from DB
        //
        try {

            String query = null;
            UID uid = null;

            //RPCXW
            if(Dispatcher.config.hsqldb() == false)
                query = "SELECT * FROM works WHERE "
                    + "(status='" + XWStatus.WAITING + "' "
                    + "OR ISNULL(status)) AND active='true' AND isdeleted='false' LIMIT 1000";
            else
                query = "SELECT TOP 1000 * FROM works WHERE "
                    + "(status='" + XWStatus.WAITING
                    + "' OR status IS NULL) AND active='true' AND isdeleted='false'";

            // RPCXW caching
            // We don't read using cache here since all works are not kept
            // We cache selected work at the end of next loop only

            ResultSet rs = DBConnPool.instance.executeQuery(query);
            while(rs.next()) {

                try {
                    work = new Work(rs); // RPCXW not caching
                    uid = work.getUID();
                } 
                catch(IOException e) {
                    error(e.toString());
                    if(debug())
                        e.printStackTrace();
                    if(uid != null)
                        invalidateWork(uid, e.toString());
                    continue;
                }

                // Now, the work is locked by the server
                if(((work.getServer() != null) &&
                    (work.getServer().compareTo(server) != 0)) ||
                   (work.getServer() == null)){
                        work.setServer(server);
                        work.update();
                }

                cache.put(work);
                debug("getWork() found from DB : " + work.getUID() + "(" + work.getLabel()+  ")");
                return work;
            }
        } 
        catch(Exception e) {
            warn("getWork() " + e);
            //            if(debug())
                e.printStackTrace();
        }

        return null;
    } // getWork()

    /**
     * This invalidates a work with an error message
     * This also remove correspondig task from both cache and DB
     */
    public void invalidateWork(Work w, String msg) {

        try {
            w.setError(msg);
            w.update();

            Task t = cache.task(w.getUID());
            if(t != null) {
                t.setError();
                t.update();
            }
        } 
        catch(Exception e) {
            error(e.toString());
            if(debug())
                e.printStackTrace();
        }
    }

    /**
     * This invalidates a work and put an error message
     */
    public void invalidateWork(UID uid, String msg) {
        try {
            Work w = cache.work(uid);
            if(w != null) {
                invalidateWork(w, msg);
            }
        } catch(Exception e) {
            error(e.toString());
            if(debug())
                e.printStackTrace();
        }
    }

    /**
     * This set all server works to WAITING status
     * @param serverName is the server name
     */
    public  void unlockWorks(String serverName) {
        try {
            String query = "UPDATE works SET " +
                WorkInterface.Columns.STATUS + "='"  + XWStatus.WAITING +
                "'," + WorkInterface.Columns.SERVER  + "='NULL'  WHERE " + 
                WorkInterface.Columns.SERVER + "='"  + serverName + "' and(" +
                WorkInterface.Columns.STATUS + "!='" + XWStatus.ERROR + "')";
            ResultSet rs = DBConnPool.instance.executeQuery(query);
        } catch(Exception e) {
        }

    }

    /**
     * This set work to WAITING status
     * @param uid is the work uid
     */
    public  void unlockWork(UID uid) {
        try {
            Work work = cache.work(uid);
            if(work.isWaiting() == false) {
                work.setWaiting();
                work.update();
            }
        }
        catch(Exception e) {
        }

    }

    /**
     * This adds/updates a data
     * UserRights.ADVANCED_USER privilege is needed to do so.
     * This is typically called from communication handlers
     * This verifies user privileges and call addData(DataInterface)
     * @param client identifies the client
     * @param data is the data definition
     * @return the application, null on error
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     * @see #addData(DataInterface)
     */
    public synchronized Data addData(UserInterface client,
                                     DataInterface data) 
        throws IOException, InvalidKeyException {

        User theClient = checkClient(client, UserRights.INSERTDATA);

        if(data.getOwner() == null)
            data.setOwner(theClient.getUID());

        if(data.getAccessRights() == null) 
            data.setAccessRights(XWAccessRights.DEFAULT);

        UID clientGroup = theClient.getGroup();

        // owner may be != theClient in case of updating
        User owner = cache.user(data.getOwner());
        UID ownerGroup = null;
        if(owner != null)
            ownerGroup = owner.getGroup();

        try {
            // check if data already exists in DB

            Data theData = cache.data(data.getUID());
            if(theData != null) {
                try {
                    if((theData.canWrite(theClient.getUID(), 
                                         ownerGroup,
                                         clientGroup)) ||
                        (theClient.getRights().higherOrEquals(UserRights.WORKER_USER))) {

                        theData.updateInterface(data);
                        cache.update(theData);
                    }
                }
                catch(Exception e0) {
                    notifyAll();
                    if(debug())
                        e0.printStackTrace();
                    throw new IOException(e0.toString());
                }
                notifyAll();
                return theData;
            }
        }
        catch(Exception e) {
            // data does not already exist in DB
        }

        try {
            Data newData = new Data(data);
            if(data.getStatus() == null) 
                newData.setStatus(XWStatus.UNAVAILABLE);
            data.getAccessRights(); // this set default value, if not set
            newData.setInsertionDate(new java.util.Date());
            newData.setAccessDate(new java.util.Date());
            if(newData.getURI() == null)
                newData.setURI(new URI(util.getLocalHostName(),
                                       newData.getUID()));
            newData.update();
            cache.put(newData);

            notifyAll();

            //            return newData;
            Data insertedData = cache.data(newData.getUID());
            if(insertedData == null)
                warn("insertedData is null ?!?!?!");
            return insertedData;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            notifyAll();
            throw new IOException(e.toString());
        }
    } // addData()

    /**
     * This retreives works or tasks UIDs for the specified client.
     * @param client describes the client
     * @return null on error; a Vector of UID otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  Vector getDatas(UserInterface client)
        throws IOException, InvalidKeyException {

        User theClient = checkClient(client, UserRights.LISTDATA);

        Vector datas = new Vector();

        UID clientGroup = theClient.getGroup();

        try {
            // (re)load datas
            cache.data();
            Enumeration enums = cache.datas();

            while(enums.hasMoreElements()) {

                UID uid = new UID((String)enums.nextElement());

                Data theData = cache.data(uid);

                User owner = cache.user(theData.getOwner());
                UID ownerGroup = null;
                if(owner != null)
                    ownerGroup = owner.getGroup();

                if((theData.canRead(theClient.getUID(), 
                                    ownerGroup,
                                    clientGroup)) ||
                   (theClient.getRights().higherOrEquals(UserRights.SUPER_USER))) {

                    datas.add(uid);
                }
            }

            return datas;
        }
        catch(Exception ex) {
            error("getDatas " + ex);
            if(debug())
                ex.printStackTrace();

            return null;
        }
    }

    /**
     * This retreives a data for the specified client.
     * @param client is the ClientInterface, describing the client
     * @param uid is the UID of the data to retreive
     * @return null on error; a data description otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     * @exception AccessControlException is thrown on access rights error (read only data...)
     */
    public  Data getData(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        User theClient = checkClient(client, UserRights.GETDATA);

        try {
            debug("DBInterface#getData GETDATA " + uid);
            Data theData = cache.data(uid);

            if(theData == null)
                return null;
                
            User owner = cache.user(theData.getOwner());
            UID ownerGroup = null;
            if(owner != null)
                ownerGroup = owner.getGroup();

            UID clientGroup = theClient.getGroup();

            if((theData.canRead(theClient.getUID(), 
                                ownerGroup, 
                                clientGroup)) ||
               (theClient.getRights().higherOrEquals(UserRights.SUPER_USER))) {
                return theData;
            }
            else
                return null;
        }
        catch(Exception ex) {
            if(debug())
                ex.printStackTrace();
            error("getData : unknown uid?");

            return null;
        }

    } //getData;


    // Abderrhamane debut

    //A tester!!!!
    public  boolean workCancel(UID uid) {

        try {
            Work w = cache.work(uid);

            // remove from disk
            error("workCancel not implemented yet : must check file cleaning");
            //						w.clean(HOME_DIR);

            // remove from database and cache
            cache.deleteWork(uid);
            cache.deleteTask(uid);

        } 
        catch(Exception e) {
            error("workCancel : can't delete object " + e);
        }

        return true;
    }


    /* XWMA Client */

    public String getTracesPath() {
        return new String(Dispatcher.config.getProperty(XWPropertyDefs.HOMEDIR.toString()) + "Traces");
    }

    /**
     * Retreive users from SQL table users. <br>
     * If requesting client has UserRights.SUPER_USER privileges, all users
     * UID are returned; otherwise client own UID is returned only.
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @return a vector of users UID, null on error
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  Vector getUsers(UserInterface client) 
        throws IOException, InvalidKeyException {

        Vector ret = new Vector();

        checkClient(client, UserRights.LISTUSER);

        try {
            cache.user();
            Enumeration enums = cache.users();
            while(enums.hasMoreElements()) {
                UID uid = new UID((String)enums.nextElement());
                ret.addElement(uid);
            }
        }
        catch(Exception ex) {
            ret = null;
            error("getUsers() : " + ex);
            if(debug())
                ex.printStackTrace();
        }

        return ret;

    } // getUsers()

    /**
     * This retreives an user by its login then calls getUser(client, user.getUID())
     * @see #getUser(UserInterface, UID)
     */
    public  UserInterface getUser(UserInterface client, String login) 
        throws IOException, InvalidKeyException {

        try {
            User user = cache.user("login='" + login + "'");
            return getUser(client, user.getUID());
        } 
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    } // getUser(String)

    /**
     * This retreives all user informations, except password for security
     * reason. <br>
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @param uid is the user uid to retreive from DB
     * @return an UserInterface , or null on error.
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  UserInterface getUser(UserInterface client, UID uid) 
        throws IOException, InvalidKeyException {

        User user = null;
        User theClient = checkClient(client, UserRights.GETUSER);

        try {
            user = cache.user(uid);
        } 
        catch(Exception ex) {
            user = null;
            if(debug())
                ex.printStackTrace();
            error("getUser() : " + ex);
        }

        if(user == null)
            return null;

        UserInterface ret = (UserInterface)user.getInterface();

        //        System.out.println(client.getLogin() + ".getRights = " + client.getRights() + " " +
        //                 client.getRights().lowerThan(UserRights.INSERTUSER));

        if(theClient.getRights().lowerThan(UserRights.INSERTUSER)) {
            // we don't show passwords
            ret = new UserInterface(ret);
            ret.setPassword("*****");
        }
        return ret;

    } // getUser()
    /**
     * This adds or updates a new user.
     * Any user with user rights lower than UserRights.INSERTUSER can only update its own definition
     * But even in this case, an user can never change its own user rights, nor its user group
     * (otherwise it would be too easy to gain unexpected privileged access).
     * UserRights.INSERTUSER privilege to add or to modify user definition.
     * If the user already exists in DB, it is updated.
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @param user is a UserInterface object containing new user
     *        informations.
     * @return true on success, false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public synchronized  boolean addUser(UserInterface client,
                                         UserInterface user)
        throws IOException, InvalidKeyException {

        User newUser;
        User theClient = checkClient(client, UserRights.STANDARD_USER);

        if((theClient.getLogin().compareTo(user.getLogin()) != 0) &&
           (theClient.getRights().lowerThan(UserRights.INSERTUSER)))
            throw new InvalidKeyException(theClient.getLogin() + " can't modify " + user.getLogin());

        try {
            newUser = cache.user("" + UserInterface.Columns.LOGIN + "='" + user.getLogin() + "'");

            if(newUser != null) {
                //
                // for security reasons
                // an user can't change nor its group neither its rights
                //
                UserRights savRights = newUser.getRights();
                UID savGroup = newUser.getGroup();

                newUser.updateInterface(user);
                //
                // resets values if not privileged user
                //
                if(theClient.getRights().lowerThan(UserRights.INSERTUSER)) {
                    newUser.setRights(savRights);
                    newUser.setGroup(savGroup);
                }
                cache.update(newUser);
                return true;
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            return false;
        }

        if(theClient.getRights().lowerThan(UserRights.INSERTUSER))
            throw new InvalidKeyException(theClient.getLogin() + " can't add users ");

        //
        // This is a new user
        //
        try {
            if(user.getUID() == null)
                user.setUID(new UID());
            newUser = new User(user);
            cache.put(newUser);
        }
        catch(Exception e) {
            error("addUser() : " + e);
            if(debug())
                e.printStackTrace();
        }

        return true;

    } // addUser()

    /**
     * Retreive usergroups from SQL table usergroups. <br>
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @return a vector of usergroups UID, null on error
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  Vector getUserGroups(UserInterface client)
        throws IOException, InvalidKeyException {

        checkClient(client, UserRights.LISTUSERGROUP);

        Vector ret = new Vector();

        try {
            cache.usergroup();
            Enumeration enums = cache.usergroups();
            while(enums.hasMoreElements()) {
                UID uid = new UID((String)enums.nextElement());
                ret.add(uid);
            }
        } catch(Exception ex) {
            ret = null;
            error("getUserGroups() : " + ex);
            if(debug())
                ex.printStackTrace();
        }

        return ret;

    } // getUserGroups()

    /**
     * This retreives all user group informations.
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @param uid is the user group UID to retreive info for.
     * @return a UserInterface object representing the expected user, or
     *         null on error.
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  UserGroupInterface getUserGroup(UserInterface client, UID uid)
        throws IOException, InvalidKeyException {

        checkClient(client, UserRights.GETUSERGROUP);
        UserGroup ret = null;

        try {
            ret = cache.usergroup(uid);
        } 
        catch(Exception ex) {
            ret = null;
            error("getUserGroup() : " + ex);
            if(debug())
                ex.printStackTrace();
        }

        if(ret == null)
            return null;

        return (UserGroupInterface)ret.getInterface();

    } // getUserGroup()

    /**
     * This adds a new user group. UserRights.SUPER_USER privilege is needed
     * to do so.
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @param group is an UserGroupInterface object containing new user
     *        group informations.
     * @return true on success, false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public synchronized boolean addUserGroup(UserInterface client,
                                             UserGroupInterface group)
        throws IOException, InvalidKeyException {

        UserGroup newGroup;

        checkClient(client, UserRights.INSERTUSERGROUP);

        UID uid = null;
        uid = group.getUID();
        if(uid == null) {
            throw new IOException("addUserGroup : no UID");
        }

        try {
            // check if such a user group already exists in
            // Database
            newGroup = cache.usergroup(uid);

            if(newGroup != null) {
                //newGroup.setInterface(group);
                newGroup.setUID(uid);

                try {
                    newGroup.update();
                }
                catch(Exception e) {
                    return false;
                }
                return true;
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }

        try {
            newGroup = new UserGroup(group);
            //						newGroup.update();
            cache.put(newGroup);
        } catch(Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;

    } // addUserGroup()

    /**
     * This inserts or updates a service.
     * This should not be called from communication hanlders since
     * this does not verify client identity.
     * This is to be called from the dispatcher package itself only.
     *
     * @param classname is the java class name of the service
     * @return the application representing the service
     * @exception ClassNotFoundException is throws if classname can't be instanciated
     * @exception IOException is throwson error (DB, rights, I/O...)
     */
    public App insertService(String classname) 
        throws ClassNotFoundException, IOException, InvalidKeyException {

        User admin = cache.user("" + UserInterface.Columns.LOGIN + "='administrator'");
        if(admin == null)
            new InvalidKeyException("Can't retreive 'administrator' user");

        String ifname = classname.substring(0, classname.lastIndexOf('.') + 1) + "Interface";
        Object obj = Class.forName(ifname);

        if(obj == null)
            throw new ClassNotFoundException("insertService() : service '" + ifname + "'not found");

        AppInterface app = new AppInterface(new UID());
        app.setName(classname);
        app.setService(true);

        return addApplication((UserInterface)admin.getInterface(), app);
    }

    /**
     * This adds/updates an application 
     * UserRights.SUPER_USER privilege is needed to insert a global application,
     * an application that anybody can use and any worker can execute, 
     * an application with 0X777 as access rights.
     * If the client don't have UserRights.SUPER_USER rights, the application is
     * available for that user only : application access rights is forced to 0x700 
     * which means that this user will be the only allowed to insert job, and 
     * workers belonging to this user only will be able to execute.
     * @param client identifies the client
     * @param app is an ApplicationInterface object
     * @return the application, null on error
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     * @see #addApplication(AppInterface)
     */
    public synchronized App addApplication(UserInterface client,
                                           AppInterface app)
        throws IOException, InvalidKeyException {

        User theClient = checkClient(client, UserRights.STANDARD_USER);

        if(app.getOwner() == null)
            app.setOwner(theClient.getUID());
        if(app.getAccessRights() == null)
            app.setAccessRights(XWAccessRights.DEFAULT);

        UID clientGroup = theClient.getGroup();

        User owner = cache.user(app.getOwner());
        UID ownerGroup = null;
        if(owner != null)
            ownerGroup = owner.getGroup();

        try {
            // check whether application already exists in DB

            App theApp = cache.app("" + AppInterface.Columns.NAME + "='" + app.getName() + "'");

            try {
                if(theApp != null) {
                    if((theApp.canWrite(theClient.getUID(), 
                                        ownerGroup, 
                                        clientGroup)) ||
                       (theClient.getRights().higherOrEquals(UserRights.INSERTAPP))) {

                        //
                        // A standard user can insert app for itself only
                        //
                        theApp.updateInterface(app);
                        if(theClient.getRights().lowerThan(UserRights.INSERTAPP)) {
                            XWAccessRights rights = theApp.getAccessRights();
                            rights.chmod("go-rwx");
                            theApp.setAccessRights(rights);
                        }
                        cache.update(theApp);
                    }

                    notifyAll();
                    return theApp;
                }
            }
            catch(Exception e0) {
                if(debug())
                    e0.printStackTrace();
                notifyAll();
                throw new IOException(e0.toString());
            }
        }
        catch(Exception e) {
            // application does not already exist in DB
        }

        try {
            App newApp = new App(app);

            cache.put(newApp);
            //
            // A standard user can insert app for itself only
            //
            if(theClient.getRights().lowerThan(UserRights.INSERTAPP)) {

                XWAccessRights rights = newApp.getAccessRights();
                rights.chmod("go-rwx");
                newApp.setAccessRights(rights);
                cache.update(newApp);
            }
            notifyAll();
            return newApp;
        }
        catch(Exception e) {
            notifyAll();
            throw new IOException(e.toString());
        }

    } // addApplication()

    /**
     * Retreive applications from SQL table apps accordingly to conditions.
     * @param client is the <code>ClientInterface</code> that identifies the client
     * @return a vector UID objects
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public Vector getApplications(UserInterface client)
        throws IOException, InvalidKeyException {

        User theClient = checkClient(client, UserRights.LISTAPP);

        Vector ret = new Vector();

        UID clientGroup = theClient.getGroup();

        try {
            // (re)load apps
            cache.app();
            Enumeration enums = cache.apps();

            while(enums.hasMoreElements()) {

                UID uid = new UID((String)enums.nextElement());

                App theApp = cache.app(uid);

                User owner = cache.user(theApp.getOwner());
                UID ownerGroup = null;
                if(owner != null)
                    ownerGroup = owner.getGroup();

                if((theApp.canRead(theClient.getUID(), 
                                   ownerGroup, 
                                   clientGroup)) ||
                       (theClient.getRights().higherOrEquals(UserRights.SUPER_USER))) {

                    ret.add(uid);
                }
            }

        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }

        return ret;
    }

    /**
     * This retreives an object
     * @param uid is the UID of the object to retreive
     * @return the object or null if not found
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public TableInterface get(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        TableInterface ret = null;

        ret = getJob(client, uid);
        if(ret != null)
            return ret;
        ret = getApplication(client, uid);
        if(ret != null)
            return ret;
        Data data = getData(client, uid);
        if(data != null)
            return data.getInterface();
        ret = getUser(client, uid);
        if(ret != null)
            return ret;
        ret = getUserGroup(client, uid);
        if(ret != null)
            return ret;
        ret = getTask(client, uid);
        if(ret != null)
            return ret;
        /*
        ret = getSession(client, uid);
        if(ret != null)
            return ret;
        ret = getGroup(client, uid);
        if(ret != null)
            return ret;
        */
        ret = getHost(client, uid);
        if(ret != null)
            return ret;
        return null;
    }
    /**
     * This retreives an application.
     * @param client is the <code>ClientInterface</code> that identifies the client
     * @param name is the app name
     * @since RPCXW
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public AppInterface getApplication(UserInterface client, String name)
        throws IOException, InvalidKeyException, AccessControlException {

        User theClient = checkClient(client, UserRights.GETAPP);

        try {
            App theApp = cache.app("" + AppInterface.Columns.NAME + "='" + name + "'");
            if(theApp == null)
                return null;

            User owner = cache.user(theApp.getOwner());
            UID ownerGroup = null;
            if(owner != null)
                ownerGroup = owner.getGroup();

            UID clientGroup = theClient.getGroup();

            if((theApp.canRead(theClient.getUID(), 
                               ownerGroup, 
                               clientGroup)) ||
               (theClient.getRights().higherOrEquals(UserRights.SUPER_USER))) {

                return (AppInterface)theApp.getInterface();
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            error("getApplication() : " + e.toString());
        }

        return null;
    }

    /**
     * This retreives an application.
     * @param client is the <code>ClientInterface</code> that identifies the client
     * @param uid is the app UID
     * @since v1r2-rc3(RPC-V)
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public AppInterface getApplication(UserInterface client, UID uid)
        throws IOException, InvalidKeyException {

        User theClient = checkClient(client, UserRights.GETAPP);

        try {
            App theApp = cache.app(uid);
            if(theApp == null)
                return null;
            User owner = cache.user(theApp.getOwner());
            UID ownerGroup = null;
            if(owner != null)
                ownerGroup = owner.getGroup();

            UID clientGroup = theClient.getGroup();

            if((theApp.canRead(theClient.getUID(), 
                               ownerGroup, 
                               clientGroup)) ||
               (theClient.getRights().higherOrEquals(UserRights.SUPER_USER))) {

                return (AppInterface)theApp.getInterface();
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            error("getApplication() : " + e.toString());
        }

        info(theClient.getLogin() + " found no application");
        return null;
    }
    /**
     * This removes an object from cache and DB
     * @param uid is the UID of the object to remove
     * @return true on success, false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public boolean remove(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        boolean result = false;

        try {
            Work theWork = cache.work(uid);
            if(theWork != null) {
                return deleteJob(client, uid);
            }
            Group theGroup = cache.group(uid);
            if(theGroup != null) {
                return removeGroup(client, uid);
            }
            Session theSession = cache.session(uid);
            if(theSession != null) {
                return removeSession(client, uid);
            }
            User theUser = cache.user(uid);
            if(theUser != null) {
                return removeUser(client, uid);
            }
            UserGroup theUserGroup = cache.usergroup(uid);
            if(theUserGroup != null) {
                return removeUserGroup(client, uid);
            }
 
            App theApp = cache.app(uid);

            User theClient = null;
            try {
                theClient = checkClient(client, UserRights.DELETEDATA);
            }
            catch(Exception e0) {
                e0.printStackTrace();
            }
            UID clientGroup = theClient.getGroup();

            if(theApp != null) {
                User owner = cache.user(theApp.getOwner());

                UID ownerGroup = null;
                if(owner != null)
                    ownerGroup = owner.getGroup();

                return removeApplication(theClient, theApp,
                                         ownerGroup, clientGroup);
            }

            Data theData = cache.data(uid);

            if(theData != null) {
                User owner = cache.user(theData.getOwner());

                UID ownerGroup = null;
                if(owner != null)
                    ownerGroup = owner.getGroup();

                return removeData(theClient, theData,
                                  ownerGroup, clientGroup);
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            result = false;
        }

        return result;
    }
    /**
     * This removes an application from cache and DB
     * @param uid is the UID of the application to remove
     * @return true on success, false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    private synchronized boolean removeApplication(User theClient,
                                                   App theApp,
                                                   UID ownerGroup, 
                                                   UID clientGroup)
        throws IOException, InvalidKeyException, AccessControlException {

        boolean result = false;

        try {
            if((theApp.canWrite(theClient.getUID(), 
                                ownerGroup, 
                                clientGroup)) ||
               (theClient.getRights().higherOrEquals(UserRights.SUPER_USER))) {

                cache.delete(theApp);
            }
        }
        catch(Exception e) {
            result = false;
        }
        notifyAll();
        return result;
    }
    /**
     * This removes a data from cache and DB
     * @param uid is the UID of the data to remove
     * @return true on success, false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    private synchronized boolean removeData(User theClient, 
                                            Data theData,
                                            UID ownerGroup, 
                                            UID clientGroup)
        throws IOException, InvalidKeyException, AccessControlException {

        boolean result = false;

        try {
            if((theData.canWrite(theClient.getUID(), 
                                 ownerGroup, 
                                 clientGroup)) ||
               (theClient.getRights().higherOrEquals(UserRights.SUPER_USER))) {

                theData.getPath().delete();
                cache.delete(theData);
            }
            else {
                info(theClient.getLogin() + " can't remove " + theData.getUID());
            }
        }
        catch(Exception e) {
            result = false;
        }
        notifyAll();
        return result;
    }
    /**
     * This deletes a group from DB and all its associated jobs
     * @param client describes the requesting client
     * @param uid is the UID of the group to delete
     * @return true on success; false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    private synchronized boolean removeGroup(UserInterface client,
                                             UID uid)
        throws IOException, InvalidKeyException {

        User theClient = checkClient(client, UserRights.DELETEGROUP);

        Group group = cache.group(uid);

        if((group.getClient().equals(uid) == false) &&
           (theClient.getRights().lowerThan(UserRights.SUPER_USER))) {
            info(theClient.getLogin() + " can't remove group + " + uid);
            return false;
        }

        Vector jobUIDs = getGroupJobs(uid);

        if(jobUIDs == null) {
            notifyAll();
            return false;
        }

        //delete jobs of the group
        boolean result = deleteJobs(client, jobUIDs);

        if(result == true) {
            cache.deleteGroup(uid);
        }

        notifyAll();
        return result;
    }

    /**
     * This deletes a session from DB and all its associated jobs
     * @param client describes the requesting client
     * @param uid is the UID of the session to delete
     * @return true on success; false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    private synchronized boolean removeSession(UserInterface client,
                                             UID uid)
        throws IOException, InvalidKeyException {

        User theClient = checkClient(client, UserRights.DELETESESSION);

        Session session = cache.session(uid);

        if((session.getClient().equals(uid) == false) &&
           (theClient.getRights().lowerThan(UserRights.SUPER_USER))) {
            info(theClient.getLogin() + " can't remove session + " + uid);
            return false;
        }

        Vector jobUIDs = getSessionJobs(uid);

        if(jobUIDs == null) {
            notifyAll();
            return false;
        }

        //delete jobs of the session
        boolean result = deleteJobs(client, jobUIDs);

        if(result == true) {
            cache.deleteSession(uid);
        }

        notifyAll();
        return result;
    }

    /**
     * This removes an user. The user which UID is provided is effectivly
     * removed if requesting client has UserRights.SUPER_USER privileges, or
     * provided UID is the client one. <br>
     * This also removes users's jobs(i.e. tasks and works).
     * @param client identifies the client
     * @param uid is the user UID
     * @return true on success, false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    private synchronized boolean removeUser(UserInterface client, UID uid) 
        throws IOException, InvalidKeyException {

        boolean ret = true;
        User user = null;

        user = checkClient(client, UserRights.DELETEUSER);

        try {
            // remove user's works and tasks

            cache.work("" + WorkInterface.Columns.USERUID + "='" + uid + "'");
            Enumeration enums = cache.works();
            while(enums.hasMoreElements()) {
                UID work_uid = new UID((String)enums.nextElement());
                Work work = cache.work(work_uid);
                if(work.getUser().equals(uid) ==  true)
                    cache.delete(work);
                    cache.deleteTask(work_uid);
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            ret = false;
        }

        cache.deleteUser(uid);

        notifyAll();
        return ret;

    }
    /**
     * This removes an user group. The user which UID is provided is
     * effectivly removed if requesting client has UserRights.SUPER_USER
     * privileges.
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @param uid is the user group UID to remove.
     * @return true on success, false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    private synchronized boolean removeUserGroup(UserInterface client,
                                                UID uid)
        throws IOException, InvalidKeyException {

        boolean ret = true;

        checkClient(client, UserRights.DELETEUSERGROUP);

        try {
            UserGroup group = cache.usergroup(uid);
            if(group.isProject() == false)
                return false;
            cache.deleteUserGroup(uid);
        } catch(Exception e) {
            ret = false;
            e.printStackTrace();
        }

        notifyAll();
        return ret;

    } // removeUserGroup()

    /**
     * Get all known traces.
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @param since is the date from which to retreive traces
     * @param before is the date to which to retreive traces
     * @return an vector of <CODE>TraceInterface</CODE>
     */
    public Vector getRegisteredTraces(UserInterface client,
                                      java.util.Date since, java.util.Date before) {

        System.err.println("getRegisteredTraces() not implemented");
        return null;

        /*
          Vector ret = new Vector();
          TraceInterface trace;
          ParsePosition pos = new ParsePosition(0);
          String beforeStr = util.getSQLDateTime(before);
          String sinceStr = util.getSQLDateTime(since);

          try {
          String query = "SELECT * FROM traces where arrivalDate < "
          + beforeStr
          + " and arrivalDate > "
          + sinceStr;
          ResultSet rs = DBConnPool.instance.executeQuery(query);

          while(rs.next()) {
          trace = new TraceInterface(rs);
          ret.addElement(trace);
          }
          } catch(Exception ex) {
          error("getRegisteredTraces() : " + ex);
          ex.printStackTrace();
          }

          return ret;
        */
    }

    /* Tracer */

    public void writeStatFile(HostInterface host,
                              long start, long end, byte[] file) throws IOException{

        System.err.println("writeStatFile() not implemented");
    }

    //Abder: added for clientAPI 08.13.2002
    public  boolean sessionExist(UID uid) {

        try {
            Session session = cache.session(uid);
            return session != null;
        }
        catch(Exception ex) {
            warn("sessionExists() : " + ex);
            ex.printStackTrace();
        }

        return false;

    }//end sessionExist


    //RMIClient requests
    // -----------------------------------------------------------//

    /**
     * This tests whether client has the right to connect to this server and
     * to do the expected action, accordingly to the action level.
     * @param client describes the client, including login and crypted
     *        password
     * @param actionLevel is the right level
     * @return a User object if the client provides a known
     *         (user id/password) and if that user has sufficient privilege level;
     *         null otherwise.
     * @exception InvalidKeyException is client is not known, 
     *            if password is not valid or if user has not enough rights
     */
    public User checkClient(UserInterface client, UserRights actionLevel)
        throws InvalidKeyException {

        if(client == null)
            throw new InvalidKeyException("user is null ?!?!");

        User result = null;
        try {
            if(client.getUID() != null)
                result = cache.user(client.getUID());

            if(result == null) {
                result = cache.user("" + UserInterface.Columns.LOGIN + "= '"
                                    + client.getLogin() + "' AND " +
                                    UserInterface.Columns.PASSWORD + "= '"
                                    + client.getPassword() + "'");
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new InvalidKeyException(e.toString());
        }

        if(result == null)
            throw new InvalidKeyException("unknown user");

        if((result.getPassword() == null) || (client.getPassword() == null)) {
            throw new InvalidKeyException(client.getLogin() +
                                          " : null password are not allowed");
        }
        else if((result.getPassword() != null) && (client.getPassword() != null) &&
                (result.getPassword().compareTo(client.getPassword()) != 0)) {
            throw new InvalidKeyException(client.getLogin() +
                                          " : bad password");
        }

        if((result.getRights() != null) &&
           (result.getRights().lowerThan(actionLevel) == true)) {
            throw new InvalidKeyException(client.getLogin() + 
                                          " : not enough rights");
        }

        return result;

    } // checkClient

    /**
     * This retreives sessions. <br>
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @return a Vector of UID
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public Vector getSessions(UserInterface client)
        throws IOException, InvalidKeyException {

        checkClient(client, UserRights.LISTSESSION);
        return getSessions(client.getUID());
    }

    /**
     * This retreives sessions for the given client<br />
     * This method has a private access because it
     * does not call checkClient() to try to avoid too much DB access. It
     * is typically called from whithin this current source file from
     * methods which must have already called checkClient() !<br>
     * Typically deleteGroup(), deleteSession(), disconnect() etc.
     * @param client is the client uid
     * @return a Vector of UID
     */
    private  Vector getSessions(UID client) {

        Vector sessions = new Vector();

        try {
            cache.session("" + SessionInterface.Columns.CLIENTUID + "='" + client + "'");
            Enumeration enums = cache.sessions();
            while(enums.hasMoreElements()) {
                UID uid = new UID((String)enums.nextElement());
                Session session = cache.session(uid);
                if(session.getClient().equals(client) == true)
                    sessions.add(uid);
            }

        }
        catch(Exception ex) {
            error("getSessions " +ex);
            ex.printStackTrace();
            return null;
        }

        return sessions;
    }

    /**
     * This retreives sessions.
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @return a Vector of UID
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public Vector getGroups(UserInterface client)
        throws IOException, InvalidKeyException {

        checkClient(client, UserRights.LISTGROUP);
        return getGroups(client.getUID());
    }

    /**
     * This retreives groups of the provided client.<br />
     * This method has a private access because it
     * does not call checkClient() to try to avoid too much DB access. It
     * is typically called from whithin this current source file from
     * methods which must have already called checkClient() !<br>
     * Typically deleteGroup(), deleteSession(), disconnect() etc.
     * @param client is the client uid
     * @return a Vector of UID
     */
    private  Vector getGroups(UID client) {

        Vector groups = new Vector();

        try {
            cache.group("" + GroupInterface.Columns.CLIENTUID +"='" + client + "'");
            Enumeration enums = cache.groups();
            while(enums.hasMoreElements()) {
                UID uid = new UID((String)enums.nextElement());
                Group group = cache.group(uid);
                if(group.getClient().equals(client) == true)
                    groups.add(uid);
            }

        } catch(Exception ex) {
            warn("getGroups " + ex);
            ex.printStackTrace();
            return null;
        }

        return groups;
    }

    /**
     * This retreives jobs for a given group
     * @param client describes the requesting client
     * @param uid is the group UID to retreive jobs for
     * @return a Vector of UID
     * @see #getGroupJobs(String)
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public Vector getGroupJobs(UserInterface client,
                               UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        checkClient(client, UserRights.LISTJOB);
        return getGroupJobs(uid);
    }

    /**
     * This retreives jobs for a given group This method has a private
     * access because it does not call checkClient() to try to avoid too
     * much DB access. It is typically called from whithin this current
     * source file from methods which must have already called checkClient() !
     * <br>
     * Typically deleteGroup(), deleteSession(), disconnect() etc.
     * @param groupUID is the group unique ID to retreive jobs for
     * @return a Vector of UID
     */
    private  Vector getGroupJobs(UID uid)
        throws IOException, AccessControlException {

        Vector jobs = new Vector();

        try {
            cache.work("" + WorkInterface.Columns.GROUPUID + "='" + uid + "'");
            Enumeration enums = cache.works();
            while(enums.hasMoreElements()) {
                jobs.add(new UID((String)enums.nextElement()));
            }
        }
        catch(Exception ex) {
            warn("getGroupJobs " + ex);
            ex.printStackTrace();
            jobs = null;
        }

        return jobs;
    }

    /**
     * This retreives jobs for a given session
     * @param client describes the requesting client
     * @param uid is the session UID to retreive jobs for
     * @return a Vector of UID
     * @see #getSessionJobs(UID)
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public Vector getSessionJobs(UserInterface client,
                                 UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        checkClient(client, UserRights.LISTJOB);
        return getSessionJobs(uid);
    }

    /**
     * This retreives jobs for a given group This method has a private
     * access because it does not call checkClient() to try to avoid too
     * much DB access. It is typically called from whithin this current
     * source file from methods which must have already called checkClient() !
     * <br>
     * Typically deleteGroup(), deleteSession(), disconnect() etc.
     * @param session is the session uid
     * @return a Vector of UID
     */
    private  Vector getSessionJobs(UID session)
        throws IOException, AccessControlException {

        Vector jobs = new Vector();

        try {
            cache.work("" + WorkInterface.Columns.SESSIONUID + "='" + session + "'");
            Enumeration enums = cache.works();
            while(enums.hasMoreElements()) {
                jobs.add(new UID((String)enums.nextElement()));
            }

            return jobs;

        } catch(Exception ex) {
            warn("getSessionJobs " + ex);
            ex.printStackTrace();
        }

        return null;
    }

    /**
     * This creates a new session
     * @param client describes the requesting client
     * @param itf describes the session to insert in DB
     * @return true on success; false on DB error or if session already exists in DB
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public synchronized boolean createSession(UserInterface client,
                                              SessionInterface itf)
        throws IOException, InvalidKeyException {

        checkClient(client, UserRights.INSERTSESSION);

        Session session;
        UID uid = null;

        try {
            uid = itf.getUID();
            if(uid == null) {
                notifyAll();
                return false;
            }

            session = cache.session(uid);
            notifyAll();
            // session exists, return false
            return false;

        }
        catch(Exception e) {
            warn("createSession " + uid);
        }

        boolean result = true;

        try {
            // it does not exist, create a new one
            session = new Session(itf);
            //						session.update();
        } catch(Exception ex) {
            result = false;
            warn("createSession " + ex);
            ex.printStackTrace();
        }

        notifyAll();
        return result;
    }

    /**
     * This updates a new group in DB
     * @param client describes the requesting client
     * @param itf describes the group to insert in DB
     * @return true on success; false on DB error or group already exists
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public synchronized boolean createGroup(UserInterface client,
                                            GroupInterface itf)
        throws IOException, InvalidKeyException {

        checkClient(client, UserRights.INSERTGROUP);

        Group group;

        try {
            group = cache.group(itf.getUID());

            // group exists, return false

            notifyAll();
            return false;
        }
        catch(Exception e) {
            info("createGroup creating a new group");
        }

        boolean result = true;

        try {
            // it does not exist, create a new one
            group = new Group(itf);
            //						group.update();
        } catch(Exception ex) {
            result = false;
            warn("==> Exception: createGroup " + ex);
        }

        notifyAll();
        return result;
    }

    /**
     * This delete a task from DB
     * @see #deleteJob(UserInterface, UID)
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public boolean deleteJob(UserInterface client,
                             WorkInterface job) 
        throws IOException, InvalidKeyException, AccessControlException {

        return deleteJob(client, job.getUID());
    }

    /**
     * This delete a task from DB; it call deleteJobs() with a vector
     * containing only one UID: this second parameter
     * @see #deleteJobs(UserInterface, Vector)
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public boolean deleteJob(UserInterface client, UID uid) 
        throws IOException, InvalidKeyException, AccessControlException {

        Vector uids = new Vector();
        uids.add(uid);
        return deleteJobs(client, uids);
    }


    /**
     * This deletes a set of jobs from DB. <br>
     * This method calls checkClient() and return null in case of
     * authentication failure
     * @param client describes the requesting client
     * @param jobs is a Vector containting work UIDs
     * @return true on success; false otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public synchronized boolean deleteJobs(UserInterface client, Vector jobs)
        throws IOException, InvalidKeyException, AccessControlException {

        User theClient = checkClient(client, UserRights.DELETEJOB);

        Vector tasks = new Vector();
        boolean result = true;

        if((jobs == null) ||(jobs.size() < 1)) {
            notifyAll();
            return false;
        }

        UID clientGroup = theClient.getGroup();

        Iterator li = jobs.iterator();

        try {

            while(li.hasNext()) {

                UID uid = (UID)li.next();

                mileStone.clear();
                mileStone.stamp("deleting", uid);

                if(uid == null) {
                    error("deletejobs : uid is null???");
                    continue;
                }

                try {
                    Work theWork = cache.work(uid);
                    if(theWork == null) {
                        error("deletejobs : "
                                     + uid
                                     + " not found");
                        continue;
                    }

                    User owner = cache.user(theWork.getUser());
                    UID ownerGroup = null;
                    if(owner != null)
                        ownerGroup = owner.getGroup();

                    if((theWork.canWrite(theClient.getUID(), 
                                         ownerGroup, 
                                         clientGroup) == false) &&
                       (theClient.getRights().higherOrEquals(UserRights.SUPER_USER))) {

                        info("deletejobs : "
                                    + uid
                                    + " not owner");
                        result = false;
                        continue;
                    }

                    mileStone.stamp("delete retreived", uid);

                    //Delete from MySQL tables and cache
                    cache.delete(theWork);
                    cache.deleteTask(uid);
                }
                catch(Exception ew) {
                    error("deleteJobs " + ew);
                    if(debug())
                        ew.printStackTrace();
                }

                mileStone.stamp("deleted", uid);
                mileStone.dump();
            }

        } catch(Exception e) {
            result = false;
            error("deleteJobs : " + e);
            if(debug())
                e.printStackTrace();
        }

        notifyAll();
        return result;

    } // deleteJobs;

    /**
     * This broadcasts a new job to all workers accordingly to available
     * application binaries This uses the "expectedHost" job attribute e.g. :
     * if we don't have win32 binary, we don't broadcast to win32 workers
     * @see #submit(UserInterface, WorkInterface)
     * @return a Vector of String containing new jobs UID
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  Vector broadcast(UserInterface client,
                             WorkInterface job)
        throws IOException, InvalidKeyException {

        Vector ret = new Vector();
        User user = checkClient(client, UserRights.INSERTJOB);
        App app = cache.app(job.getApplication());

        if(app == null)
            throw new IOException("broadcast() : can't find application");

        Vector workers = getRegisteredWorkers(client);
        if((workers == null) ||(workers.size() == 0))
            throw new IOException("broadcast() : can't find any worker to broadcast");

        Iterator li = workers.iterator();
        try {
            while(li.hasNext()) {
                Host worker = cache.host(new UID((String)li.next()));

                if(app.getBinary(worker.getCpu(),
                                 worker.getOs()) == null) {
                    warn(worker.getUID() +
                                " : " + 
                                app.getName() + 
                                " is not broadcasted since there is no compatible binary");
                    continue;
                }
                job.setExpectedHost(worker.getUID());
                job.setUID(new UID());
                Work work = insertWork(client, job);
                if(work != null) {
                    ret.add(work.getUID());
                    work.setWaiting();
                }
                else
                    warn("broadcast() can't submit");
            }
        } catch(Exception e) {
            error("broadcast() : " + e);

            return null;
        }

        return ret;
    }

    /**
     * This inserts a new work in DB; if job already exists, it is updated<br />
     * This sets some attributes :
     * <ul>
     * <li>arrival date&nbsp;;
     * <li>user name(from the client parameter).
     * </ul>
     * @param client describes the requesting client
     * @param job is a MobileWork describing the work to insert
     * @return the provided job uid don activation;
     *         a new jobUID if a new job has been created;
     *         null on error
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  Work insertWork(UserInterface client,
                            WorkInterface job)
        throws IOException, InvalidKeyException {

        mileStone.clear();
        mileStone.stamp("insertWork start");

        UID jobUID = job.getUID();
        XWAccessRights jobRights = XWAccessRights.DEFAULT;
        Work work = null;
        User theClient = checkClient(client, UserRights.INSERTJOB);

        User owner = null;
        UID ownerGroup = null;
        UID clientGroup = theClient.getGroup();

//         if(job.getAccessRights() == null)
//             job.setAccessRights(XWAccessRights.DEFAULT);
        if(job.getAccessRights() != null)
            jobRights = job.getAccessRights();

        UID appUID = job.getApplication();
        if(appUID == null)
            throw new IOException("insertWork() : job defines no app ?!?");

        try {
            App app = cache.app(appUID);
            if(app == null)
                throw new IOException("insertWork() : app not found");

            owner = cache.user(app.getOwner());

            if(owner != null)
                ownerGroup = owner.getGroup();

            if((app.canExec(theClient.getUID(), 
                            ownerGroup, 
                            clientGroup) == false) &&
               (theClient.getRights().higherOrEquals(UserRights.SUPER_USER))) {

                throw new IOException("insertWork() : " + 
                                      theClient.getLogin() + 
                                      " don't have rights to submit job for app " +
                                      app.getName());
            }

            job.setService(app.isService());

            //
            // we set access rights to minimal value
            // e.g. : if app is 0x700, job must be 0x700 or lower (0x600, 0x500...)
            //
            int jobRightsInt = jobRights.value() & app.getAccessRights().value();
            jobRights = new XWAccessRights(jobRightsInt);
            job.setAccessRights(jobRights);
        }
        catch(IOException e) {
            throw e;
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }

        mileStone.stamp("insertion got app");

        try {

            work = cache.work(jobUID);
            if(work != null) {
                if((work.canWrite(theClient.getUID(), 
                                  ownerGroup, 
                                  clientGroup)) ||
                   (theClient.getRights().higherOrEquals(UserRights.WORKER_USER))) {

                    work.updateInterface(job);

                    switch(job.getStatus()) {
                    case ABORTED :
                        work.setPending();
                        break;

                    case COMPLETED :
                        work.setResult(job.getResult());
                        work.setCompleted();
                    case ERROR :
                        Task theTask = cache.task(jobUID);
                        theTask.setError();
                        cache.update(theTask);
                        break;
                    }

                    cache.update(work);
                    //                    System.out.println("updated " + work.toXml());
                }
                else
                    throw new InvalidKeyException(theClient.getLogin() + " can't update " + work.getUID());
            }
            else {
                work = new Work(job);
                work.setUser(theClient.getUID());
                //                work.setServer(util.getLocalHostName());
                work.update();
                cache.put(work);
            } 
        }
        catch(InvalidKeyException ike) {
            throw ike;
        }
        catch(Exception ex) {
            error("insertWork : server error : " + ex);

            if(work != null) {
                work.setError(ex.toString());

                try {
                    work.update();
                }
                catch(Exception e) {
                    if(debug())
                        e.printStackTrace();
                    throw new IOException("can't update ???");
                }
            }
            if(debug())
                ex.printStackTrace();
            throw new IOException(ex.toString());
        }

        mileStone.stamp("insertWork done");
        mileStone.dump();
        return work;
    }

    /**
     * This retreives a job status
     * @param client describes the requesting client
     * @param uid is the UID of the job to retreive status for
     * @return -1 on error, job status otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  XWStatus jobStatus(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        User theClient = checkClient(client, UserRights.GETJOB);

        UID clientGroup = theClient.getGroup();

        try {
            Work work = cache.work(uid);

            User owner = cache.user(work.getUser());
            UID ownerGroup = null;
            if(owner != null)
                ownerGroup = owner.getGroup();

            if((work.canRead(theClient.getUID(), 
                             ownerGroup, 
                             clientGroup)) &&
               (theClient.getRights().lowerThan(UserRights.SUPER_USER))) {

                throw new AccessControlException(theClient.getLogin() + " can read " + uid);
            }

            return work.getStatus();
        }
        catch(IOException e) {
            if(debug())
                e.printStackTrace();
        }

        return null;
    }

    /**
     * This retreives works UIDs for the specified client.
     * @param client is the ClientInterface, describing the client
     * @return null on error; a Vector of UID otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  Vector getAllJobs(UserInterface client)
        throws IOException, InvalidKeyException {

        User theClient = checkClient(client, UserRights.LISTJOB);

        Vector jobs = new Vector();

        UID clientGroup = theClient.getGroup();

        try {
            //            cache.work("" + WorkInterface.Columns.USERUID + "='" + theClient.getUID() + "'");
            cache.work();
            Enumeration enums = cache.works();

            while(enums.hasMoreElements()) {
                UID uid = new UID((String)enums.nextElement());
                if(uid == null)
                    continue;
                Work work = cache.work(uid);
                if(work == null)
                    continue;

                User owner = cache.user(work.getUser());
                UID ownerGroup = null;
                if(owner != null)
                    ownerGroup = owner.getGroup();

                if((work.canRead(theClient.getUID(), 
                                 ownerGroup, 
                                 clientGroup) == false) &&
                   (theClient.getRights().lowerThan(UserRights.SUPER_USER))) {

                    info(theClient.getLogin() + " can not read " + uid);
                    continue;
                }

                jobs.add(uid);
            }

            return jobs;
        }
        catch(Exception ex) {
            error("getAllJobs " + ex);
            if(debug())
                ex.printStackTrace();
            return null;
        }

    }//getAllJobs;

    /**
     * This retreives a job for the specified client.
     * @param client is the ClientInterface, describing the client
     * @param uid is the UID of the job to retreive
     * @return null on error; a MobileWork otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  WorkInterface getJob(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        User theClient = checkClient(client, UserRights.GETJOB);

        UID clientGroup = theClient.getGroup();

        try {
            Work work = cache.work(uid);
            if(work == null)
                return null;

            User owner = cache.user(work.getUser());
            UID ownerGroup = null;
            if(owner != null)
                ownerGroup = owner.getGroup();

            if((work.canRead(theClient.getUID(), 
                             ownerGroup, 
                             clientGroup) == false) &&
               (theClient.getRights().lowerThan(UserRights.SUPER_USER))) {

                throw new AccessControlException(theClient.getLogin() + " can not read " + uid);
            }

            return (WorkInterface)work.getInterface();
        }
        catch(IOException ex) {
            error("getJob : unknown uid?");
            if(debug())
                ex.printStackTrace();
            return null;
        }

    }//getJob;

    /**
     * This retreives a task for the specified client. This specifically
     * permits to retreive job instanciation informations (e.g. start date,
     * worker...)
     * @see #getJob(UserInterface, UID)
     * @param client is the ClientInterface, describing the client
     * @param uid is the UID of the task to retreive
     * @return null on error; a TaskInterface otherwise
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  TaskInterface getTask(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        User theClient = checkClient(client, UserRights.LISTJOB);

        UID clientGroup = theClient.getGroup();

        try {
            Task theTask = cache.task(uid);
            Work theWork = cache.work(uid);

            if(theTask == null) {
                debug("can retreive task " + uid);
                return null;
            }

            if(theWork == null) {
                error("can retreive work " + uid);
                return null;
            }

            User owner = cache.user(theWork.getUser());
            UID ownerGroup = null;
            if(owner != null)
                ownerGroup = owner.getGroup();

            if((theWork.canRead(theClient.getUID(), 
                                ownerGroup, 
                                clientGroup) == false) &&
               (theClient.getRights().lowerThan(UserRights.SUPER_USER))) {
                throw new AccessControlException(theClient.getLogin() +
                                                 " can't read " + uid);
            }

            return (TaskInterface)theTask.getInterface();
        }
        catch(Exception ex) {
            error("getTask : unknown uid ?");
            if(debug())
                ex.printStackTrace();
            return null;
        }

    } // getTask;

    /**
     * This retreives all host informations, except HWADDR for security
     * reason. <br>
     * @param client is the <code>ClientInterface</code> that identifies
     *        the client
     * @param uid is the host uid to retreive.
     * @return a HostInterface object representing the expected user, or
     *         null on error.
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public  HostInterface getHost(UserInterface client,
                                  UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        mileStone.clear();
        mileStone.println("getHost start");
        User user = checkClient(client, UserRights.GETHOST);

        mileStone.println("getHost got user");

        Host host = null;
        try {
            host = cache.host(uid);
        }
        catch(Exception ex) {
            error("getHost() : " + ex);
            if(debug())
                ex.printStackTrace();
            return null;
        }

        mileStone.println("getHost done");

        if(host == null)
            return null;

        return (HostInterface)host.getInterface();

    }

    /**
     * This is called by client to disconnect from server
     * This deletes this client sessions
     * @param client defines the client
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public void disconnect(UserInterface client)
        throws IOException, InvalidKeyException, AccessControlException {

        User user = checkClient(client, UserRights.NONE);
        Vector sessions = getSessions(user.getUID());
        if(sessions != null) {

            Enumeration enums = sessions.elements();						
            while(enums.hasMoreElements()) {
                removeSession(client, (UID)enums.nextElement());
            }

        }
    }


    /**
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     * ***** All the following was perviously in Accouting.java *****
     *
     * @since RPCXW
     * @author Oleg Lodygensky
     */

    /**
     * This method is remotly called by worker at start up time. It is inserted
     * in the hashtable if not present. <BR>
     * If host is allready in the hashtable which may happen if host has
     * disconnected and is currently trying to reconnect, its datas are
     * refreshed and its code returned. <BR>
     * Host is added to SQL table if missing and SQL table is modified as
     * needed.
     * 
     * @param _user describes host user
     * @param _host describes remote host
     * @return host(found or created)
     */
    public Host hostRegister(UserInterface _user, HostInterface _host) 
        throws IOException, InvalidKeyException {

        Host host = null;
        String hostName = _host.getName();
        User user = null;

        try {
            user = cache.user("" + UserInterface.Columns.LOGIN + "='" + _user.getLogin() + "'");
            if(user != null)
                if(user.getPassword().compareTo(_user.getPassword()) != 0)
                    user = null;
        }
        catch(Exception e) {
            user = null;
        }

        if(user == null) {
            error("hostRegister user " + (_user == null ? "null" : _user.getLogin()));
            error("hostRegister host " + (_host == null ? "null" : _host.getName()));
            throw new InvalidKeyException("bad user/password from " + _user.getLogin() + "@"
                                          + _host.getName());
        }

        _host.setOwner(user.getUID());

        if(_host.getUID() == null) {
            throw new IOException("_host UID must not be null!!!");
        }


        try {
            host = cache.host(_host.getUID());
            if(host != null) {

                if(_host.getUploadBandwidth() != 0)
                    host.setUploadBandwidth(_host.getUploadBandwidth());
                if(_host.getDownloadBandwidth() != 0)
                    host.setDownloadBandwidth(_host.getDownloadBandwidth());
                if(_host.getNbPing() != 0)
                    host.setNbPing(_host.getNbPing());
                if(_host.getAvgPing() != 0)
                    host.setAvgPing(_host.getAvgPing());

                host.setIPAddr(_host.getIPAddr());
                //System.out.println("DBInterface#hostRegister " + host.toXml());

                cache.update(host);

                return host;
            }
        }
        catch(Exception e) {
            host = null;
            debug("new connection");
        }


        if(host == null)
            try {
                info(hostName + " not in DB; inserting "+ _host.getUID());

//                System.out.println("\n\n");
//                System.out.println("_host " + _host);

                host = new Host(_host);

//                System.out.println("host " + host);
//                System.out.println("\n\n");

                cache.put(host);
                return host;
            }
            catch(Exception e1) {
                if(debug())
                    e1.printStackTrace();
                error(hostName + " can't create new host : " + e1);
            }

        return null;

    } // /hostRegister()

    /**
     * Set worker attribute.
     * 
     * @param uid is the worker UID to change flag for
     * @param column defines either TRACES or ACTIVE attribute to change
     * @param flag is the value to set the attribute to
     * @return true on success; false otherwise.
     */
    protected boolean changeWorker(UID uid, HostInterface.Columns column,
                                   boolean flag) {

        boolean ret = true;

        try {
            Host host = cache.host(uid);
            if(host == null)
                return false;

            switch(column) {
            case TRACES:
                //debug(uid + " set traces to " + flag);
                host.setTracing(flag);
                break;

            case ACTIVE:
                //debug(uid + " set active to " + flag);
                host.setActive(flag);
                break;

            } // switch()

            host.update();
        } 
        catch(Exception e) {
            error(e.toString());
            if(debug())
                e.printStackTrace();
            ret = false;
        }

        return ret;
    }

    /**
     * Set workers attribute.
     * @param hosts is a hashtable which contains host UID as key and their
     *              dedicated activate flag as value.
     * @param column defines either TRACES or ACTIVE attribute to change
     * @return true on success; false otherwise.
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public boolean changeWorkers(UserInterface client, Hashtable hosts,
                                 HostInterface.Columns column)
        throws IOException, InvalidKeyException, AccessControlException {

        checkClient(client, UserRights.SUPER_USER);

        if(hosts.isEmpty())
            return false;

        try {
            Enumeration enums = hosts.keys();
            while(enums.hasMoreElements()) {
                UID uid = new UID((String)enums.nextElement());
                Boolean flag =(Boolean) hosts.get(uid);
                if(changeWorker(uid, column, flag.booleanValue()) == false)
                    return false;
            }
        } catch(Exception e) {
            error(e.toString());
            if(debug())
                e.printStackTrace();
            return false;
        }

        return true;
    }

    /**
     * Set active attibute for a given worker
     * @param uid is the host UID
     * @param flag is the active attribute value
     * @return true on success; false otherwise.
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public boolean activateWorker(UserInterface client, UID uid, boolean flag)
        throws IOException, InvalidKeyException, AccessControlException {

        checkClient(client, UserRights.SUPER_USER);
        return changeWorker(uid, HostInterface.Columns.ACTIVE, flag);
    }

    /**
     * Set active flag for a given workers list.
     * @param hosts is a hashtable which contains host uid as key and their
     *              dedicated activate flag as value.
     * @return true on success; false otherwise.
     */
    public boolean activateWorkers(UserInterface client,
                                   Hashtable hosts)
        throws IOException, InvalidKeyException, AccessControlException {
        return changeWorkers(client, hosts, HostInterface.Columns.ACTIVE);
    }

    /**
     * This activate some workers.
     * @param nbWorkers is the number of workers to activate.
     * @return the number of activated workers on success, -1 on error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public int activateWorkers(UserInterface client, int nbWorkers)
        throws InvalidKeyException, AccessControlException {

        int count = 0;

        try {

            checkClient(client, UserRights.SUPER_USER);

            Enumeration enums = cache.hosts();
            while(enums.hasMoreElements()) {
                UID uid = new UID((String)enums.nextElement());
                Host host = cache.host(uid);

                if(count < nbWorkers) {
                    host.setActive(true);
                    count++;
                } else {
                    host.setActive(false);
                }

            }
        }
        catch(Exception e) {
            return -1;
        }

        return count;
    }

    /**
       /**
       * Set trace flag for a given workers list.
       * @param hosts is a hashtable which contains host uid as key and their
       *              dedicated trace flag as value.
       * @return true on success; false otherwise.
       */
    public boolean traceWorkers(UserInterface client,
                                Hashtable hosts)
        throws IOException, InvalidKeyException, AccessControlException {
        return changeWorkers(client, hosts, HostInterface.Columns.TRACES);
    }

    /**
     * This method is remotly called by XWMA.
     * @return a vector of UID
     * @exception IOException is thrown on DB access or I/O error
     * @exception InvalidKeyException is thrown on rights error (user unknown, not enough rights...)
     */
    public Vector getRegisteredWorkers(UserInterface client)
        throws IOException, InvalidKeyException, AccessControlException {

        checkClient(client, UserRights.LISTHOST);

        Vector ret = new Vector(100, 50);

        try {

            Enumeration enums = cache.hosts();
            // 						System.out.println("getWorkers hosts.size = " + cache.hostSize());
            while(enums.hasMoreElements()) {
                ret.add(new UID((String)enums.nextElement()));
            }

        }
        catch(Exception e) {
            warn(e.toString());
            return null;
        }
        return ret;
    }

    /**
     * This retreives server the provided worker should connect to, if any. <br>
     * The new server is provided to worker through 'Alive' signal. April 4th,
     * 2003 : no policy is defined yet :(
     * 
     * @param workerUID is the worker host UID
     * @since v1r2-rc1(RPC-V)
     */
    public String getServer(UID workerUID) {
        //
        // RPC-V : not implemented yet; this is just a test :)
        // Uncomment next line to test the protocol
        //    return new String("newServer");
        return null;
    }




}// DBInterface
