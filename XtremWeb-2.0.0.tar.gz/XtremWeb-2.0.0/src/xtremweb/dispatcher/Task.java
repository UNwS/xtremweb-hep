package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.TaskInterface;
import xtremweb.common.XWStatus;

import java.io.IOException;
import java.sql.ResultSet;
import java.text.ParsePosition;
import java.util.Date;
import java.security.AccessControlException;


/**
 * This class helps to describe a task.<p>
 * Includes info on the execution status, the parameters, and accounting
 * info
 * @author V. Neri, G.F, CGR, OL
 */
public class Task extends TableRow {

    /** 
     * This is the default constructor.<br />
     * This creates a new object which is **not** written in the database;
     * save this object by explicitly calling <CODE>insert()</CODE>
     * @see TableRow#insert()
     */
    public Task() throws IOException{
        super("tasks");

        row = new TaskInterface();
        setInsertionDate(new java.util.Date());
        setPending();
        setTrial(0);
        dirty = true;
    }

    /** 
     * This constructor instanciates an object from data read from an SQL table
     * @see xtremweb.common.TaskInterface#TaskInterface(ResultSet)
     */
    public Task(ResultSet rs) throws IOException {
        this();
        fill(rs);
    }

    /**
     * This is the constructor; it inserts new task into DB
     * @param w is the work the task is created for
     */
    public Task(Work w) throws IOException{

        this();
        setUID(w.getUID());
        try {
            insert();
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }


    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new TaskInterface(rs);
        dirty = true;
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public int getDuration() {
        return((TaskInterface)row).getDuration();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public int getTrial() {
        return((TaskInterface)row).getTrial();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public XWStatus getStatus() throws IOException {
        return((TaskInterface)row).getStatus();
    }
    /** 
     * This tests task status
     * @param v the value to test; must be one of the values defined in XWStatus.java.
     * @return a boolean.
     * @see xtremweb.common.XWStatus
     */
    public boolean testStatus(XWStatus v) {
        try {
            return(getStatus() == v);
        }
        catch(Exception e) {
            return false;
        }
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public int getAliveCount() {
        return((TaskInterface)row).getAliveCount();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getUID() throws IOException{
        return((TaskInterface)row).getUID();
    }
    /**
     * This gets the host UID
     * @return this host UID 
     */
    public UID getHost() throws IOException{
        return((TaskInterface)row).getHost();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public java.util.Date getInsertionDate() {
        return((TaskInterface)row).getInsertionDate();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public java.util.Date getStartDate() {
        return((TaskInterface)row).getStartDate();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public java.util.Date getLastStartDate() {
        return((TaskInterface)row).getLastStartDate();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public java.util.Date getLastAlive() {
        return((TaskInterface)row).getLastAlive();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public java.util.Date getRemovalDate() {
        return((TaskInterface)row).getRemovalDate();
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setDuration(int v) {
        if(((TaskInterface)row).setDuration(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setTrial(int v) {
        if(((TaskInterface)row).setTrial(v))
            dirty = true;
    }
    /** 
     * This increments trial
     */
    public void incTrial() {
        setTrial(getTrial() + 1);
    }
    /**
     * This set the deleted flag
     * @return true if value has changed, false otherwise
     * @since 2.0.0
     */
    public boolean setDeleted(boolean v)  {
        if (((TaskInterface) row).setDeleted(v))
            dirty = true;
        return dirty;
    }
    /**
     * This retreives the deleted flag
     * @return true if deleted, false otherwise
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return ((TaskInterface)row).isDeleted();
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    private void setStatus(XWStatus v) {
        if(((TaskInterface)row).setStatus(v))
            dirty = true;
    }
    /** 
     * This sets the task status as running on a worker.
     */
    public void setRunning() {
        setStatus(XWStatus.RUNNING);
    }
    /** 
     * This tests whether task is running on a worker.
     * @return a boolean.
     */
    public boolean isRunning() {
        return testStatus(XWStatus.RUNNING);
    }
    /** 
     * This sets the task status as pending for a worker.
     */
    public void setPending() {
        setStatus(XWStatus.PENDING);
    }
    /** 
     * This tests whether task is pending for a worker.
     * @return a boolean.
     */
    public boolean isPending() {
        return testStatus(XWStatus.PENDING);
    }
    /** 
     * This sets the task status as lost from worker.
     */
    public void setLost() {
        setStatus(XWStatus.LOST);
    }
    /** 
     * This tests whether task is lost from worker.
     * @return a boolean.
     */
    public boolean isLost() {
        return testStatus(XWStatus.LOST);
    }
    /** 
     * This sets the task status as completed by a worker.
     */
    public void setCompleted() {
        setStatus(XWStatus.COMPLETED);
        try {
            Host theHost = DBInterface.instance.cache.host(getHost());
            int exectime =(int)(System.currentTimeMillis() - getLastStartDate().getTime());
            theHost.incAvgExecTime(exectime);
            theHost.incNbJobs();
            DBInterface.instance.cache.update(theHost);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    /** 
     * This tests whether task is completed by worker.
     * @return a boolean.
     */
    public boolean isCompleted() {
        return testStatus(XWStatus.COMPLETED);
    }
    /** 
     * This sets the task status as unable to run on worker.
     */
    public void setError() {
        setStatus(XWStatus.ERROR);
    }
    /** 
     * This tests whether task generated any error
     * @return a boolean.
     */
    public boolean isError() {
        return testStatus(XWStatus.ERROR);
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setAliveCount(int v) {
        if(((TaskInterface)row).setAliveCount(v))
            dirty = true;
    }
    /**
     * This sets parameter
     */
    public void incAliveCount() {
        ((TaskInterface)row).incAliveCount();
        dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setUID(UID v) {
        if(((TaskInterface)row).setUID(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setHost(UID v) {
        if(((TaskInterface)row).setHost(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setInsertionDate(java.util.Date v) {
        if(((TaskInterface)row).setInsertionDate(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setStartDate(java.util.Date v) {
        if(((TaskInterface)row).setStartDate(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setLastStartDate(java.util.Date v) {
        if(((TaskInterface)row).setLastStartDate(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setLastAlive(java.util.Date v) {
        if(((TaskInterface)row).setLastAlive(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setRemovalDate(java.util.Date v) {
        if(((TaskInterface)row).setRemovalDate(v))
            dirty = true;
    }
    /** 
     * This resets an aborted/lost Task.<BR>
     * This increments "trials" attribute and set status to PENDING so that
     * this taks is subject to be reschedulled
     */
    public void reset() {
        setPending();
        setHost(null);
        incTrial();
        setAliveCount(0);
    }
    /**
     * This set removal date
     */
    public void remove() {

        int duration;
        java.util.Date removaldate = new java.util.Date();
        java.util.Date laststartdate = getLastStartDate();

        setRemovalDate(removaldate);

        if(laststartdate != null) {
            duration  =(int)((removaldate.getTime() -
                              laststartdate.getTime())/1000);
            setDuration(duration);
        }
    }
    /** 
     * Assign a task to a worker
     * @param worker is the worker UID
     */
    public void setRunningBy(UID worker) throws IOException{

        java.util.Date newDate = new java.util.Date(System.currentTimeMillis());

        setHost(worker);
        setLastAlive(newDate);

        try {
            if(getStartDate() == null)
                setStartDate(newDate);
        }
        catch(Exception e) {
            setStartDate(newDate);
        }
        setLastStartDate(newDate);
        setRunning();
        try {
            Work theWork = DBInterface.instance.cache.work(getUID());
            theWork.setRunning();
            theWork.update();
            update();
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }
    /**
     * Update due to alive signal
     * Since RPC-V : we must ckeck the task is not running on another worker;
     * in such a case, the current worker we are computing the alive signal for,
     * has to be asked to stop computing.
     * @param worker is the worker UID 
     * @return true on success(since RPC-V); which covers two cases:
     *              1) the computing worker is the expected one;
     *              2) no computing worker is asigned to that task certainly because
     *                 the server has crashed and relaunched since it had provided the
     *                 task to the signalling worker
     *          false  on error(since RPC-V); the worker is not the expected one!
     *                 the signalling worker has to be asked to stop computing
     */
    public boolean setAlive(UID worker) throws IOException{

        // the task is not tagged running ...
        if((isRunning() == false) ||(getHost() == null)) {

            // we note where the task is now running
            setRunningBy(worker);
        }

        // the task is noted as beeing run by another worker
        if(worker.equals(getHost()) == false)
            return false;


        // here, we're sure the task is now tagged running by this worker

        setLastAlive(new java.util.Date(System.currentTimeMillis()));

        incAliveCount();

        // save status every 5 minutes
        long delay = 5 * 60 * 1000;

        java.util.Date laststartdate = getLastStartDate();
        if(laststartdate == null)
            util.fatal("Task.java : lastStartDate is null ???");

        long lastStart = laststartdate.getTime();
        if((System.currentTimeMillis() - lastStart) > delay) {
            try {
                update();
            }
            catch(Exception e) {
                throw new IOException(e.toString());
            }
        }
        return true;
    }
}
