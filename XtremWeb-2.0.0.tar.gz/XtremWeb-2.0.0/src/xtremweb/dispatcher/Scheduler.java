package xtremweb.dispatcher;

import xtremweb.common.Logger;
import xtremweb.common.HostInterface;
import xtremweb.common.WorkInterface;

import java.io.IOException;

/**
 * This is the abstract class that defines XtremWeb task schedulers
 * main methods set.
 */
public abstract class Scheduler extends Logger {

    /**
     * This is the method to forward a work on worker demand. 
     * @param host is the worker definition
     * @param user is the worker identity
     * @return null if no work available; a MobileWork otherwise
     */
    public abstract WorkInterface select(HostInterface host,
                                         User user)
        throws IOException;

}
