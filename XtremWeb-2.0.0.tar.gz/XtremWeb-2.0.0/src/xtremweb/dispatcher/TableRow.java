package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.Logger;
import xtremweb.common.LoggerLevel;
import xtremweb.common.TableInterface;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.io.IOException;
import java.security.AccessControlException;

/**
 * This abstract class encapsulates <CODE>TableInterface</CODE>
 * This helps to create/store new objects from/to database tables
 * This is an abstract class and must be overriden
 * 
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky </A>
 * @since v1r2-rc3 (RPC-V)
 */
public abstract class TableRow extends Logger {

    /**
     * This stores the table names
     */
    protected String tableName;

    /**
     * This defines a table row
     */
    protected TableInterface row;

    /**
     * This tells whether object has changed since last DB I/O
     */
    protected boolean dirty;

    /**
     * This is the default constructor
     */
    protected TableRow(LoggerLevel l) {
        super(l);
        dirty = false;
    }

    /**
     * This constructor sets the <CODE>tableName</CODE> to the provided value
     * @param v is the <CODE>tableName</CODE> value
     */
    protected TableRow(String v) {
        this(LoggerLevel.INFO);
        tableName = v;
    }

    /**
     * This creates a new object accordingly to the provided interface
     * @param v is the <CODE>tableName</CODE> value
     * @param itf is the <CODE>row</CODE> value
     */
    protected TableRow(String v, TableInterface itf) throws IOException {
        this(v);
        setInterface(itf);
        dirty = true;
        setLoggerLevel(LoggerLevel.INFO);
    }

    public abstract void fill(ResultSet rs) throws IOException;
    public abstract void setUID(UID uid);
    public abstract UID getUID() throws IOException;

    protected String getTableName() {
        return tableName;
    }

    /*
      protected String getPrimaryIndexName() {
      return row.primaryIndexName();
      }
    */
    /**
     * This creates SQL 'select' query header
     * @return a String containing the SQL 'select' query header
     */
    protected TableInterface getInterface() {
        return row;
    }
    /**
     * This sets the interface
     * @param itf is the new interface
     * @exception IOException if parameter is null
     */
    protected void setInterface(TableInterface itf) throws IOException{

        if(itf == null)
            throw new IOException("itf is null!");

        // 				Object sav = null;
        // 				if(row != null)
        // 						sav = row.primaryIndex();
        row = itf;
        // 				if((row != null) && (sav != null))
        // 						row.setPrimaryIndex(sav);
        dirty = true;
    }

    /**
     * This creates SQL 'insert' query header
     * @return a String containing the SQL 'insert' query header
     * @see xtremweb.common.TableInterface#getColumns()
     * @see #tableName
     */
    protected String insertQueryHeader() {
        // RPCXW
        return new String("INSERT " 
                          // 													+ (Context.hsqldb ? "" : "DELAYED")
                          +" INTO " + tableName + "(" + row.getColumns() + ") ");
    }

    /**
     * This creates SQL 'select' query header
     * @return a String containing the SQL 'select' query header
     * @see #tableName
     */
    protected String selectQueryHeader() {
        return new String("SELECT * FROM " + tableName);
    }

    /**
     * This creates SQL 'update' query header
     * @return a String containing the SQL 'select' query header
     * @see #tableName
     */
    protected String updateQueryHeader() {
        // RPCXW
        String speed = "";
        if((Dispatcher.config.realTime() == false) && (Dispatcher.config.hsqldb() == false))
            speed = "LOW_PRIORITY ";

        return new String("UPDATE " + speed + tableName);

        // 				return new String("UPDATE "
        // 													+ (Context.hsqldb ? "" : "LOW_PRIORITY ")
        // 													+ tableName);
    }

    /**
     * Since XWHEP 1.0.0, this does create a delete from table SQL query header
     * but an update table SQL query header to set isdeleted flag to true.
     * Hence the row stays in table.
     * @return a String containing the SQL query header
     */
    protected String deleteQueryHeader() {
        //        return new String("DELETE FROM " + tableName);
        return new String("UPDATE " + tableName);
    }

    /**
     * This updates this object in the database table, if needed
     */
    public synchronized void update() throws IOException {
        //		public void update() throws SQLException {

        if (dirty == false)
            return;
        try {
            String rows = row.toString();
            String criterias = row.criterias();
            if ((criterias == null) || (rows == null))
                throw new IOException("unable to get update criteria");
            String query = updateQueryHeader() + " SET " + rows + " WHERE " + criterias;

            if (DBConnPool.instance.executeQuery(query) == null)
                throw new IOException("unable to update " + tableName);

            dirty = false;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }
    }

    /**
     * This reads from DB
     * @see #selectQueryHeader()
     * @see xtremweb.common.TableInterface#criterias()
     * @exception IOException is thrown on error
     */
    public synchronized void select() throws IOException {
        //		public void select() throws IOException {
        try{
            String criterias = row.criterias();
            if (criterias == null)
                throw new IOException("unable to get select criteria");

            String query = selectQueryHeader() + " WHERE " + criterias;
            ResultSet rs = DBConnPool.instance.executeQuery(query);
            if(rs == null)
                throw new IOException("unable to select from " + tableName +
                                      "(" + query + ")");
            rs.next();
            fill(rs);
        }
        catch(Exception e) {
            e.printStackTrace();
            throw new IOException(e.toString());
        }
    }

    /**
     * This inserts this object in DB and re-reads it immediatly so that
     * we have the correct primary key (which is auto-increment)
     * @see #select()
     * @see #insertQueryHeader()
     * @see xtremweb.common.TableInterface#getValues()
     * @see #tableName
     * @exception IOException is thrown on error
     */
    public synchronized void insert() throws IOException {
        //		public void insert() throws IOException {

        String criteria = row.getValues();

        if (criteria == null)
            throw new IOException("unable to get insert criteria");

        String query = insertQueryHeader() + " VALUES (" + criteria + ")";

        if(DBConnPool.instance.executeQuery(query) == null) {
            Thread.dumpStack();
            throw new IOException("unable to insert to " + tableName +
                                  "(" + query + ")");
        }
    }

    /**
     * Since XWHEP 1.0.0, this does not delete row from table
     * but updates the row and sets isdeleted flag to true.
     * Hence the row stays in table.
     * @see #deleteQueryHeader()
     * @see xtremweb.common.TableInterface#criterias()
     * @see #tableName
     */
    public synchronized void delete() throws IOException {
        //		public void delete() throws SQLException {

        try {
            String criteria = row.criterias();
            if (criteria == null)
                throw new IOException("unable to get delete criteria");

            String query = deleteQueryHeader() + " SET " + 
                TableInterface.DELETEDFLAG + "='true' WHERE " + criteria;

            if (DBConnPool.instance.executeQuery(query) == null)
                throw new IOException("unable to delete from " + tableName);
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }
    }

    /**
     * This serializes this object
     * 
     * @return a String containing the columns
     */
    public String toString() {
        return row.toString();
    }

    /**
     * This serializes this object in XML format
     * 
     * @return a String containing the columns
     */
    public String toXml() {
        return row.toXml();
    }

    /**
     * This should test access rights ; this must be overriden
     * @param user is the user UID to test
     * @param group is the user group UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#checkAccessRights(UserInterface, UserGroupInterface)
     */
    public final boolean checkAccessRights(UID user, UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return row.checkAccessRights(user, ownerGroup, userGroup);
    }
    /**
     * This should test access rights ; this must be overriden
     * @param user is the user UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#checkUserAccessRights(UserInterface)
     */
    public boolean checkUserAccessRights(UID user)
        throws AccessControlException, IOException {
        return row.checkUserAccessRights(user);
    }
    /**
     * This should test access rights ; this must be overriden
     * @param group is the user group UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#checkGroupAccessRights(UserGroupInterface)
     */
    public boolean checkGroupAccessRights(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return row.checkGroupAccessRights(ownerGroup, userGroup);
    }
    /**
     * This should test access rights ; this must be overriden
     * @return always false
     * @see xtremweb.common.TableInterface#checkOtherAccessRights()
     */
    public boolean checkOtherAccessRights()
        throws AccessControlException, IOException {
        return row.checkOtherAccessRights();
    }

    /**
     * This should test access rights ; this must be overriden
     * @param user is the user UID to test
     * @param group is the user group UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#canRead(UserInterface, UserGroupInterface)
     */
    public final boolean canRead(UID user, UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return row.canRead(user, ownerGroup, userGroup);
    }
    /**
     * This should test access rights ; this must be overriden
     * @param user is the user UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#userCanRead(UserInterface)
     */
    public boolean userCanRead(UID user)
        throws AccessControlException, IOException {
        return row.userCanRead(user);
    }
    /**
     * This tests group acces rights
     * @param ownerGroup is this object owner group UID
     * @param userGroup is the user group UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#groupCanRead(UserGroupInterface)
     */
    public boolean groupCanRead(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return row.groupCanRead(ownerGroup, userGroup);
    }
    /**
     * This tests other read access rights
     * @return true is others can read
     * @see xtremweb.common.TableInterface#otherCanRead()
     */
    public boolean otherCanRead()
        throws AccessControlException, IOException {
        return row.otherCanRead();
    }

    /**
     * This should test access rights ; this must be overriden
     * @param user is the user UID to test
     * @param ownerGroup is this onwer group
     * @param userGroup is the user group UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#canWrite(UserInterface, UerGroupInterface)
     */
    public final boolean canWrite(UID user, UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return row.canWrite(user, ownerGroup, userGroup);
    }
    /**
     * This should test access rights ; this must be overriden
     * @param user is the user UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#userCanWrite(UserInterface)
     */
    public boolean userCanWrite(UID user)
        throws AccessControlException, IOException {
        return row.userCanWrite(user);
    }
    /**
     * This should test access rights ; this must be overriden
     * @param ownerGroup is this owner group UID
     * @param userGroup is the user group UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#groupCanWrite(UserGroupInterface)
     */
    public boolean groupCanWrite(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return row.groupCanWrite(ownerGroup, userGroup);
    }
    /**
     * This should test access rights ; this must be overriden
     * @return always false
     * @see xtremweb.common.TableInterface#otherCanWrite()
     */
    public boolean otherCanWrite()
        throws AccessControlException, IOException {
        return row.otherCanWrite();
    }
    /**
     * This should test access rights ; this must be overriden
     * @param user is the user UID to test
     * @param ownerGroup is this owner group UID
     * @param userGroup is the user group UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#canExec(UserInterface, UserGroupInterface)
     */
    public final boolean canExec(UID user, UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return row.canExec(user, ownerGroup, userGroup);
    }
    /**
     * This should test access rights ; this must be overriden
     * @param user is the user UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#userCanExec(UserInterface)
     */
    public boolean userCanExec(UID user)
        throws AccessControlException, IOException {
        return row.userCanExec(user);
    }
    /**
     * This should test access rights ; this must be overriden
     * @param ownerGroup is this owner group UID
     * @param userGroup is the user group UID to test
     * @return always false
     * @see xtremweb.common.TableInterface#groupCanExec(UserGroupInterface)
     */
    public boolean groupCanExec(UID ownerGroup, UID userGroup)
        throws AccessControlException, IOException {
        return row.groupCanExec(ownerGroup, userGroup);
    }
    /**
     * This should test access rights ; this must be overriden
     * @return always false
     * @see xtremweb.common.TableInterface#otherCanExec()
     */
    public boolean otherCanExec()
        throws AccessControlException, IOException {
        return row.otherCanExec();
    }

} // class TableRow
