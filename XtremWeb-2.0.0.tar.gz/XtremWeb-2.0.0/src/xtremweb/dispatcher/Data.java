package xtremweb.dispatcher;

import xtremweb.common.util;
import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.DataInterface;
import xtremweb.common.XWAccessRights;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.XWStatus;
import xtremweb.common.DataType;
import xtremweb.common.XWCPUs;
import xtremweb.common.XWOSes;

import java.io.IOException;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.security.AccessControlException;
import java.util.Date;

/**
 * This class extends <CODE>TableRow</CODE>
 * This class encapsulates <CODE>DataInterface</CODE>
 * This helps to access DB table datas
 * 
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky </A>
 * @since 1.8.0
 * @version %I%, %G%
 */
public class Data extends TableRow {

    /**
     * This is the default constructor It creates a new object which is **not**
     * written in the database Save this object by explicitly calling <CODE>
     * update()</CODE>
     */
    public Data() {
        super("datas");
        row = new DataInterface();
        dirty = true;
    }
    /** 
     * This creates a new object which is written in the database;
     * @since RPCXW
     */
    public Data(DataInterface itf) throws IOException{
        super ("datas", itf);
        insert();
    }
    /**
     * This constructor instanciates an object from data read from an SQL table
     * @see xtremweb.common.DataInterface#DataInterface(ResultSet)
     */
    public Data(ResultSet rs) throws IOException {
        super("datas");
        fill(rs);
    }
    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new DataInterface(rs);
        dirty = false;
    }
    /**
     * This return the data path
     * @return the data path
     */
    public String getPathName() throws IOException {
        return getPath().getAbsolutePath();
    }
    /**
     * This return the data path
     * @return the data path
     */
    public File getPath() throws IOException {
        return new File(getDirName(), getUID().toString());
    }
    /**
     * This return the data directory name
     * @return the directory name
     */
    public String getDirName() throws IOException {
        return getDir().getAbsolutePath();
    }
    /**
     * This return the data directory name
     * @return the directory name
     */
    public File getDir() throws IOException {

        return util.createDir(Dispatcher.config.getProperty(XWPropertyDefs.HOMEDIR.toString()),
                              getUID());
    }
    /**
     * This deletes this data from the database table as well as associated files
     */
    public void delete() throws IOException {

        getPath().delete();
        getDir().delete();
        super.delete();
    }
    /**
     * This updates this object from interface.
     * <ul>
     * <li> access rights
     * <li> name
     * <li> type
     * <li> cpu
     * <li> os
     * </ul>
     */
    public void updateInterface(DataInterface itf) throws IOException {
        if(itf.getAccessRights() != null)
            setAccessRights(itf.getAccessRights());
        if(itf.getName() != null)
            setName(itf.getName());
        if(itf.getType() != null)
            setType(itf.getType());
        if(itf.getCpu() != null)
            setCpu(itf.getCpu());
        if(itf.getOs() != null)
            setOs(itf.getOs());
        if(itf.getStatus() != null)
            setStatus(itf.getStatus());

        setAccessDate(new java.util.Date());
    }
    /**
     * This gets parameter
     * @return the expected parameter
     */
    public UID getUID() throws IOException{
        return ((DataInterface) row).getUID();
    }
    /**
     * This gets owner UID
     * @return the expected parameter
     */
    public UID getOwner() throws IOException{
        return ((DataInterface) row).getOwner();
    }
    /**
     * This gets the URI
     * @return the expected parameter
     */
    public URI getURI() throws IOException{
        return ((DataInterface) row).getURI();
    }
    /**
     * This gets status
     */
    public XWStatus getStatus() {
        return ((DataInterface) row).getStatus();
    }
    /** 
     * This tests status
     * @param v the value to test; must be one of the values defined in XWStatus.java.
     * @return a boolean.
     * @see xtremweb.common.XWStatus
     */
    public boolean testStatus(XWStatus v) {
        try {
            return(getStatus() == v);
        }
        catch(Exception e) {
            return false;
        }
    }
    /**
     * This gets the creation date
     * @return the expected parameter
     */
    public java.util.Date getInsertionDate() throws IOException{
        return ((DataInterface) row).getInsertionDate();
    }
    /**
     * This gets the last access date
     * @return the expected parameter
     */
    public java.util.Date getAccessDate() throws IOException{
        return ((DataInterface) row).getAccessDate();
    }
    /**
     * This gets parameter
     * @return the expected parameter
     */
    public boolean isSendToClient() {
        return ((DataInterface) row).isSendToClient();
    }
    /**
     * This gets parameter
     * @return the expected parameter
     */
    public boolean isReplicated() {
        return ((DataInterface) row).isReplicated();
    }
    /**
     * This gets the name
     * @return the expected parameter
     */
    public String getName() throws IOException{
        return ((DataInterface) row).getName();
    }
    /**
     * This gets the MD5
     * @return the expected parameter
     */
    public String getMD5() throws IOException{
        return ((DataInterface) row).getMD5();
    }
    /**
     * This gets the type
     * @see xtremweb.common#DataTYpe
     * @return the expected parameter
     */
    public DataType getType() throws IOException{
        return ((DataInterface) row).getType();
    }
    /**
     * This gets the cpu type
     * @return the expected parameter
     */
    public XWCPUs getCpu() throws IOException{
        return ((DataInterface) row).getCpu();
    }
    /**
     * This gets the os type
     * @return the expected parameter
     */
    public XWOSes getOs() throws IOException{
        return ((DataInterface) row).getOs();
    }
    /**
     * This gets the access rights
     * @return the expected parameter
     */
    public XWAccessRights getAccessRights() throws IOException{
        return ((DataInterface)row).getAccessRights();
    }
    /**
     * This gets the links count
     * @return the expected parameter
     */
    public int getLinks() throws IOException{
        return ((DataInterface) row).getLinks();
    }
    /**
     * This gets the size
     * @return the data size in bytes
     * @return the expected parameter
     */
    public long getSize() throws IOException{
        return ((DataInterface) row).getSize();
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setUID(UID v) {
        if (((DataInterface) row).setUID(v))
            dirty = true;
    }
    /**
     * This sets owner UID
     * @param v is the new parameter value
     */
    public void setOwner(UID v) {
        if (((DataInterface) row).setOwner(v))
            dirty = true;
    }
    /**
     * This sets the URI
     * @param v is the new parameter value
     */
    public void setURI(URI v) {
        if (((DataInterface) row).setURI(v))
            dirty = true;
    }
    /**
     * This sets the last access date
     * @param v is the new parameter value
     */
    public void setAccessDate(java.util.Date v) {
        if (((DataInterface) row).setAccessDate(v))
            dirty = true;
    }
    /**
     * This sets the creation date
     * @param v is the new parameter value
     */
    public void setInsertionDate(java.util.Date v) {
        if (((DataInterface) row).setInsertionDate(v))
            dirty = true;
    }
    /**
     * This sets status
     * @param v is the new parameter value
     */
    public void setStatus(XWStatus v) {
        if (((DataInterface) row).setStatus(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setSendToClient(boolean v) {
        if (((DataInterface)row).setSendToClient(v))
            dirty = true;
    }
    /**
     * This gets parameter
     * @return the expected parameter
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return ((DataInterface) row).isDeleted();
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     * @since 2.0.0
     */
    public void setDeleted(boolean v) {
        if (((DataInterface)row).setDeleted(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setReplicated(boolean v) {
        if (((DataInterface) row).setReplicated(v))
            dirty = true;
    }
    /**
     * This gets the name
     */
    public void setName(String v) throws IOException{
        if (((DataInterface) row).setName(v))
            dirty = true;
    }
    /**
     * This gets the MD5
     */
    public void setMD5(String v) throws IOException{
        if (((DataInterface) row).setMD5(v))
            dirty = true;
    }
    /**
     * This gets the type
     */
    public void setType(DataType v) throws IOException{
        if (((DataInterface) row).setType(v))
            dirty = true;
    }
    /**
     * This gets the cpu type
     */
    public void setCpu(XWCPUs v) throws IOException{
        if (((DataInterface) row).setCpu(v))
            dirty = true;
    }
    /**
     * This gets the os type
     */
    public void setOs(XWOSes v) throws IOException{
        if (((DataInterface) row).setOs(v))
            dirty = true;
    }
    /**
     * This sets the access rights
     */
    public void setAccessRights(XWAccessRights v) throws IOException{
        if (((DataInterface) row).setAccessRights(v))
            dirty = true;
    }
    /**
     * This sets the size
     * @param l is the data size in bytes
     */
    public void setSize(long l) throws IOException{
        if (((DataInterface) row).setSize(l))
            dirty = true;
    }
    /**
     * This sets the links count
     */
    public void setLinks(int l) throws IOException{
        if (((DataInterface) row).setLinks(l))
            dirty = true;
    }
    /**
     * This increments the links count
     */
    public void incLinks() throws IOException{
        ((DataInterface) row).incLinks();
        dirty = true;
    }
    /**
     * This decrements the links count
     */
    public void decLinks() throws IOException{
        ((DataInterface) row).decLinks();
        dirty = true;
    }

}
