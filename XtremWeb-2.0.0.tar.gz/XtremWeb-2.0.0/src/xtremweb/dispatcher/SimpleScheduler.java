package xtremweb.dispatcher;

import xtremweb.common.util;
import xtremweb.common.LoggerLevel;
import xtremweb.common.MileStone;
import xtremweb.common.WorkInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.UserRights;

import java.util.Hashtable;
import java.io.IOException;
import java.lang.reflect.Array;

/**
 * This is the task scheduler
 * @author Gille Fedak
 */

public class SimpleScheduler extends Scheduler {
    /**
     * This aims to display some time stamps
     */
    MileStone mileStone;

    /**
     * This contains task set
     */
    HashTaskSet tset;

    public SimpleScheduler(HashTaskSet t) {
        tset = t;
        level = tset.getLoggerLevel();
        mileStone = new MileStone(getClass().getName());
    }

    /**
     * This does nothing
     */
    protected void retreiveSavingTasks() {
    }

    /**
     * Select a binary file for a given task <br>
     * The exec file may be a binary or a java file(.jar).
     * <li>a java file may be provided to any worker;
     * <li>a binary is only provided to a worker accordingly to its OS and CPU.
     * 
     * @param appUID the application UID to retreive the binary for
     * @param host is the  worker identification
     * @return the full name of the right binairie or null on error
     * @exception an IOException is thrown on invalid application error 
     *               (if appIUD dos not refer to any application) 
     */
    protected URI selectRunnableOn(UID appUID, HostInterface host) 
        throws IOException {

        App app = null;
        debug("selectRunnableOn " + appUID + " " +
                     host.getCpu() + " " +
                     host.getOs());
        app = DBInterface.instance.cache.app(appUID);

        if(app == null)
            throw new IOException("invalid app UID");

        return app.getBinary(host.getCpu(),
                             host.getOs());
    }

    /**
     * Get the first task that is waiting
     * @param host is the worker definition
     * @param user is not used here (see MatchingScheduler)
     * @return null if no work available; a MobileWork otherwise
     * @exception IOException is thrown if there's no bianry available
     */
    public WorkInterface select(HostInterface host,
                                User user) 
        throws IOException {

        int i;
        int index;
        Task theTask;

        if(host == null)
            throw new IOException("MatchingScheduler#select() host is null");

        //				debug("SimpleScheduler#select()" + host.getUID());
				
        mileStone.clear();
        mileStone.stamp("SimpleScheduler#select() start");

        theTask = tset.getNextWaitingTask(host.acceptBin());

        if(theTask == null) {
            // 31/01
            debug("SimpleScheduler#select() can't find any task");
            return null;
        }

        Work theWork = DBInterface.instance.cache.work(theTask.getUID());
        if(theWork == null) {
            error("SimpleScheduler#select() work is null ?!?!");
            return null;
        }

        return select(host, theTask, theWork);
    }

    /**
     * Get the first task that is waiting
     * @param host is the worker definition
     * @param theTask is the found waiting task
     * @param theWork is the task associated work
     * @return null if no work available; a MobileWork otherwise
     * @exception IOException is thrown if there's no bianry available
     */
    protected synchronized WorkInterface select(HostInterface host,
                                                Task theTask,
                                                Work theWork) 
        throws IOException {

        int i;
        int index;

        if((host == null) || (theTask == null) || (theWork == null)) {
            notifyAll();
            throw new IOException("SimpleScheduler#select() param error");
        }

        mileStone.stamp("SimpleScheduler#select() task found");

        //debug("theTask = " + theTask.toString());

        URI binSelected = null;
        if((theWork.isService() == false) && (host.acceptBin())) {
            try {
                binSelected = selectRunnableOn(theWork.getApplication(), host);
            }
            catch(IOException e) {
                DBInterface.instance.invalidateWork(theWork, e.getMessage());
                throw e;
            }
        }

        mileStone.stamp("SimpleScheduler#select() selected");

        //				debug("isService = " + theTask.isService() + " binSelected = " + binSelected);

        if((binSelected == null) && (theWork.isService() == false)) {
            // 31/01
            debug("no binary available");
            notifyAll();
            throw new IOException("no binary available");
        }
        WorkInterface mw = null;

        try {
            mw = (WorkInterface)(DBInterface.instance.cache.work(theTask.getUID()).getInterface());

            theTask.setRunningBy(host.getUID());
            DBInterface.instance.cache.update(theTask);
        }
        catch(Exception e) {
            // 31/01
            debug("setRunningBy error " + e);
            notifyAll();
            throw new IOException(e.toString());
        }

        UID uid = null;

        try {
            uid = theTask.getUID();
        }
        catch(Exception e) {
            error("can't retreive task UID ???");
        }

        mileStone.dump(uid);
        mileStone.println("SimpleScheduler#select() filled", uid);

        notifyAll();
        return mw;
    }
}
