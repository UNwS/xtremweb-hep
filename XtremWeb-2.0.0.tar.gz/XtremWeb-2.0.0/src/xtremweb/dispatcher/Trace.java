package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.TraceInterface;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;


/**
 * This class extends <CODE>TableRow</CODE>
 * This class encapsulates <CODE>TraceInterface</CODE>
 * This helps to access DB table apps
 *
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky</A>
 * @since v1r2-rc3 (RPC-V)
 */
public class Trace extends TableRow {


    /** 
     * This creates a new object which is not written in the database
     * @since RPCXW
     */
    public Trace () {
        super ("traces");
    }
    /** 
     * This constructor instanciates this object from data read from an SQL table
     * @see xtremweb.common.TraceInterface#TraceInterface(ResultSet)
     */
    public Trace (ResultSet rs) throws IOException {
        super ("traces");
        fill(rs);
    }

    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new TraceInterface (rs);
        dirty = false;
    }

    /**
     * This does nothing : traces don't have UIDs
     */ 
    public void setUID(UID uid) {
        System.err.println("Trace::setUID() not implemented");
    }
    /**
     * This does nothing : traces don't have UIDs
     */ 
    public UID getUID() throws IOException{
        throw new IOException("Trace::getUID() not implemented");
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getHost() {
        return ((TraceInterface)row).getHost ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getLogin() {
        return ((TraceInterface)row).getLogin ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public Date getArrivalDate() {
        return ((TraceInterface)row).getArrivalDate ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public Date getStartDate() {
        return ((TraceInterface)row).getStartDate ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public Date getEndDate() {
        return ((TraceInterface)row).getEndDate ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public URI getFile() {
        return ((TraceInterface)row).getFile ();
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setHost (UID v) {
        if(((TraceInterface)row).setHost (v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setLogin (String v) {
        if(((TraceInterface)row).setLogin (v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setArrivalDate (Date v) {
        if(((TraceInterface)row).setArrivalDate (v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setStartDate (Date v) {
        if(((TraceInterface)row).setStartDate (v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setEndDate (Date v) {
        if(((TraceInterface)row).setEndDate (v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setFile (URI v) {
        if(((TraceInterface)row).setFile (v))
            dirty = true;
    }

} 
