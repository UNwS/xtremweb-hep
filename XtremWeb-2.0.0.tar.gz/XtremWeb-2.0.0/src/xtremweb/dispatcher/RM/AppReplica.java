package xtremweb.dispatcher.RM;

import xtremweb.common.*;
import java.io.*;
import java.util.Date;

/**
 * Authors : Samir Djilali   (djilali@lri.fr)
 *           Oleg Lodygensky (lodygens /at\ .in2p3.fr)
 * Date    : Jan 23rd, 2004
 *
 * This class describes an application replica.
 * This is used for dispatcher to dispatcher application exchanges.
 *
 * A work replica encapsulates every app informations, including binary file.
 *
 * This uses <code>AppInterface</code>.
 *
 * @see src/common/AppInterface.java
 */
public class AppReplica implements Serializable {

    /**
     * This describe the application.
     * This attribute interface is used as this object interface.
     */
    private AppInterface descriptor;

    /**
     * This is the application binary bytes
     */
    private byte [] binFile;

    /**
     * This is the application status
     */
    private XWStatus status;

    /**
     * This is the only constructor
     */
    public AppReplica () {
	descriptor = null;
    }


    /**
     * This sets this object interface
     */
    public void setInterface (AppInterface itf) {
	descriptor = itf;
    }


    public AppInterface getInterface () {
	return descriptor;
    }


    public UID getUID () throws IOException{
	return descriptor.getUID ();
    }


    /**
     * This sets the status
     */
    public void setStatus (XWStatus v) throws IOException{
	status = v;
    }

    /**
     * This sets the status
     */
    public XWStatus getStatus () throws IOException{
	return status;
    }

    /**
     * This sets the binary bytes, if any
     * @param v is the array of bytes of the file content
     */
    public void setBinFile (byte [] v) throws IOException{
	binFile = v;
	/*
	if ((binFile != null) && (binFile.length > 250000))
	    setStatus (XWStatus.LONGFILE);
	*/
    }

    /**
     * This retreives the binary bytes
     * @return an array of bytes
     */
    public byte [] getBinFile () throws IOException{
	return binFile;
    }

    /**
     * This sets the application binary
     * @see #setBinFile (byte[])
     */
    public void setBinary (String fName) throws IOException{

	if (fName == null) {
	    setBinFile (null);
	    return;
	}

	try {
	    byte [] contents;
	    File contentFile = new File (fName);
	    FileInputStream fis = new FileInputStream (contentFile);

	    contents = new byte [(int)contentFile.length ()];
	    fis.read (contents);
	    fis.close ();

	    setBinFile (contents);
	}
	catch (Exception e) {
	    e.printStackTrace ();
	}
    }

} // AppReplica
