package xtremweb.dispatcher.RM;

public class OutputException extends Exception {
    
    Exception lowlevelException;

    public OutputException() {
    super();
    }
    
    public OutputException(String s) {
    super(s);
    }

    public OutputException( Exception e ) {
    super();
    lowlevelException = e;
    }

    public OutputException( String s, Exception e ) {
    super(s);
    lowlevelException = e;
    }
    
    public Exception getLowLevelException() {
        return lowlevelException;
    }
} // OutputException
