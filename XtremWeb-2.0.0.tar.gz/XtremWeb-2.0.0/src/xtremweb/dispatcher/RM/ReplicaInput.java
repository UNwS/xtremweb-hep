package xtremweb.dispatcher.RM;

import java.rmi.*;
import xtremweb.common.util;

//receive information from Input links
public class ReplicaInput {
    
    private static RMrmiHandler rmiHandler;
    public ReplicaInput() {

    }//constructor

    public void initComm(int port) throws InputException {
	try {
	    //Create a RMI Handler on port <port>
	    rmiHandler = new RMrmiHandler();
	    String host = util.getLocalHostName();
	    System.out.println("Binding the RMI object //" + host + ":" + port + "/ReplicaManager");
	    Naming.rebind("//" + host + ":" + port + "/ReplicaManager", rmiHandler);
	} catch (Exception e) {
	    System.err.println("ReplicaInput error, cannot bind a RMrmiHandler: "+ e.getMessage() + "\n" + e);
	    throw new InputException("Cannot initialize ReplicaInput ", e);
	}    
    }//initComm
    
   

}//class ReplicaInput
