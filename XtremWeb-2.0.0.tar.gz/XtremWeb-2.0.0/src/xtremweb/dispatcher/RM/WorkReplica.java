package xtremweb.dispatcher.RM;

import xtremweb.common.*;

import java.io.*;
import java.util.Date;

/**
 * Authors : Samir Djilali   (djilali@lri.fr)
 *           Oleg Lodygensky (lodygens /at\ .in2p3.fr)
 * Date    : Jan 23rd, 2004
 *
 * This class describes a work replica.
 * This is used for dispatcher to dispatcher work exchanges.
 *
 * A work replica encapsulates every work informations, including
 * all input and output files.
 *
 * This uses <code>MobileWork</code> and <code>MobileResult</code> to
 * describe replicaed work.
 *
 * A carefull reader may notice the redondancy of WorkInterface included
 * by both MobileWork and MobileResult; he/she would not have noticed this,
 * if only he/she could know how lazy I am (Oleg) ;)
 * Enough kidding: these two classes already implement all a work replica needs,
 * so there is no reason to rewrite another implementation as soon as we take care
 * of the interface usage (see this class attributes javadocs).
 *
 *
 * @see src/common/MobileWork.java
 * @see src/common/MobileResult.java
 */
public class WorkReplica implements Serializable {

    /**
     * This describe the work and its input files.
     * This attribute interface is used as this object interface.
     * It is convenient for its input files management too.
     */
    private WorkInterface work;
    /**
     * This describe the work and its output files
     * This attribute interface is **not** used (work.descritor is used instead).
     * It is only convenient for its output files management.
     * @see work
     */
    private DataInterface result;


    /**
     * This is the only constructor
     */
    public WorkReplica () {
	work = null;
	result = null;
    }


    /**
     * This sets this object interface
     */
    public void setInterface (WorkInterface itf) throws IOException{
	work = itf;
    }


    /**
     * This gets this object interface
     */
    public WorkInterface getInterface () {
	return work;
    }
    /**
     * This retreives the standard input bytes, if any
     * @return an array of bytes, or null if not available
     */
    public URI getStdin () throws IOException{
	return work.getStdin ();
    }
    /**
     * This retreives the zip file bytes, if any
     * @return an array of bytes, or null if not available
     */
    public URI getDirin () throws IOException{
	return work.getDirin ();
    }
    public URI getResult () throws IOException{
	return work.getResult ();
    }

    public void setResult (URI uid) throws IOException{
	work.setResult (uid);
    }

} // WorkReplica
