package xtremweb.dispatcher.RM;

import xtremweb.common.util;
import java.rmi.*;
import xtremweb.dispatcher.*;
import java.util.Vector;
import java.rmi.server.UnicastRemoteObject;
import java.io.*;

public class RMrmiHandler extends UnicastRemoteObject
		implements RMIOutputInterface {


    public RMrmiHandler() throws RemoteException {
				super(4327);
    }//RMrmiHandler

    public void receiveWorks(Vector works) throws RemoteException {
				System.out.println("Receiving "+ works.size() +" works");
				double t0 = System.currentTimeMillis()* 0.001;
				Dispatcher.db.replicator.writeReplicatedWorks(works);
				double t1 = System.currentTimeMillis()* 0.001;
				try {
						ReplicaManager.in.writeChars("receive " + works.size() + " work : " + (t1-t0) +"\n");
				} catch (IOException e) {
						System.err.println("Error writing in.txt" + e);
				}
    }//receiveWorks

    public void receiveResults(Vector results) throws RemoteException {
				System.err.println("Receiving "+ results.size() +" results");
				double t0 = System.currentTimeMillis()* 0.001;
				Dispatcher.db.replicator.writeReplicatedResults(results);
				double t1 = System.currentTimeMillis()* 0.001;
				try {
						ReplicaManager.in.writeChars("receive " + results.size() + " results : " + (t1-t0) +"\n");
				} catch (IOException e) {
						System.err.println("Error writing in.txt" + e);
				}
    }//receiveResults

    public void receiveClients(Vector clients) throws RemoteException {
				double t0 = System.currentTimeMillis()* 0.001;
				Dispatcher.db.replicator.writeReplicatedClients(clients);
				double t1 = System.currentTimeMillis()* 0.001;
				try {
						ReplicaManager.in.writeChars("receive " + clients.size() + " clients : " + (t1-t0) +"\n");
				} catch (IOException e) {
						System.err.println("Error writing in.txt" + e);
				}
    }//receiveClients

    public void receiveApplications(Vector apps) throws RemoteException {
				double t0 = System.currentTimeMillis()* 0.001;
				Dispatcher.db.replicator.writeReplicatedApps(apps);
				double t1 = System.currentTimeMillis()* 0.001;
				try {
						ReplicaManager.in.writeChars("receive " + apps.size() + " apps : " + (t1-t0) +"\n");
				} catch (IOException e) {
						System.err.println("Error writing in.txt" + e);
				}
    }//receiveApplications
    
}//class RMHandler
