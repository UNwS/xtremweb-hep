package xtremweb.dispatcher.RM;

import xtremweb.common.*;
import xtremweb.dispatcher.*;

import java.io.*;
import java.net.*;
import java.rmi.RemoteException;
import java.security.InvalidKeyException;
import java.security.AccessControlException;
import java.sql.*;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Replicator.java
 * This has been written by Samir Djilalli
 * Oleg Lodygensky has extracted all from DBInterface a inserted into RM package
 *
 * @author Samir Djilalli, Oleg Lodygensky
 * @version
 */

public class Replicator extends Logger {

    //Abder ReplicaManager

    public Replicator() {
        level = LoggerLevel.INFO;
    }

    /**
     * This retreives works to replicate from this server database
     * RPCXW caching : replication does not use cache
     * @return a vector of WorkReplica objects
     */
    public  Vector readWorksToReplicate() {

	Vector works = new Vector(10, 10);
	String query = "SELECT * from works where workReplicated = 'false'";
	ResultSet rs = DBConnPool.instance.executeQuery(query);

	try {

	    while(rs.next()) {

		WorkInterface workItf = new WorkInterface(rs);
		WorkReplica replica = new WorkReplica();
		replica.setInterface(workItf);

		works.add(replica);

		/*
		 * work.setReplicated(true); if
		 *(work.getResultStatus() ==
		 * MobileWork.AVAILABLE)
		 * work.setResultReplicated(true); try {
		 * work.update(); } catch(Exception e) {
		 * e.printStackTtrace(); }
		 */
	    }
	} catch(Exception ex) {
	    ex.printStackTrace();
	    works = null;
	}

	return works;

    }//readWorksToReplicate

    /**
     * This updates database in marking provided works as either work itself
     * or result 'replicated'.
     * RPCXW caching : replication does not use cache
     * @param itf the work interface of the work to update
     * @param what is a boolean true to set work replicated itself; false to
     *        set result replicated
     */
    private  void setWorkReplication(WorkInterface itf,
				     boolean what) {

	error("Replicator::setWorkReplication() not implemented yet");
	/*
	  try {
	  Work work = DBInterface.instance.cache.work(itf.getUID());

	  if(what == true)
	  work.setReplicated(true);
	  else
	  work.setResultReplicated(true);
	  work.update();
	  } catch(Exception ex) {
	  ex.printStackTrace();
	  }
	*/

    }//setWorksReplicated

    /**
     * This updates database in marking provided works as 'replicated'
     * RPCXW caching : replication does not use cache
     * @param works is a vector of WorkInterface objects
     */
    public void setWorksReplicated(Vector works) {

	for(Enumeration e = works.elements(); e.hasMoreElements();) {

	    try {
		WorkInterface workItf =(WorkInterface) e.nextElement();
		setWorkReplication(workItf, true);
	    } catch(Exception ex) {
		ex.printStackTrace();
	    }

	}

    }//setWorksReplicated

    /**
     * This inserts replicated works
     * RPCXW caching : replication does not use cache
     * @param works is a Vector of WorkReplica objects
     */
    public  void writeReplicatedWorks(Vector works) {

	try {

	    for(Enumeration e = works.elements(); e.hasMoreElements();) {

		WorkReplica replica =(WorkReplica) e.nextElement();
		WorkInterface workItf = replica.getInterface();
		Work work;

		try {

		    work = DBInterface.instance.cache.work(workItf.getUID());
		    // RM : using src/common/*Interface
		    // should we do something if work
		    // allready exist ???
		} 
		catch(Exception ex) {

		    // work is not in the database; create a
		    // new one
		    work = new Work(workItf);
		    work.setUID(new UID());

		    info("Adding work : "
				+ work.getUID());
		    /*
		    //create corresponding directories and
		    // files
		    File workDir = new File(HOME_DIR);
		    DataOutputStream dos;

		    try {
		    if(work.getStdinName() != null) {
		    work.setStdinName();
		    dos = new DataOutputStream(new FileOutputStream(new File(workDir,
		    work.getStdinName())));
		    dos.write(replica.getStdin(),
		    0,
		    replica.getStdin().length);
		    }
		    if(work.getDirinName() != null) {
		    work.setDirinName();
		    dos = new DataOutputStream(new FileOutputStream(new File(workDir,
		    work.getDirinName())));
		    dos.write(replica.getDirin(),
		    0,
		    replica.getDirin().length);
		    }
		    if(work.getStdoutName() != null) {
		    work.setStdoutName();
		    dos = new DataOutputStream(new FileOutputStream(new File(workDir,
		    work.getStdoutName())));
		    dos.write(replica.getStdout(),
		    0,
		    replica.getStdout().length);
		    }
		    if(work.getResultName() != null) {
		    work.setResultName();
		    dos = new DataOutputStream(new FileOutputStream(new File(workDir,
		    work.getResultName())));
		    dos.write(replica.getResult(),
		    0,
		    replica.getResult().length);
		    }
		    } catch(Exception exp) {
		    exp.printStackTrace();
		    work.setStatus(XWStatus.INVALID);
		    work.setErrorMsg("IO Error"
		    + exp);
		    }
		    */
		    try {
			work.update();
		    } catch(Exception ex2) {
			ex2.printStackTrace();
		    }

		}

	    }
	} catch(Exception ex) {
	    ex.printStackTrace();
	}


    }//writeReplicatedWorks

    /**
     * This retreives results to replicate from this server database
     * RPCXW caching : replication does not use cache
     * @return a vector of MobileResult objects
     */
    public  Vector readResultsToReplicate() {

	error("Replicator::readResultsToReplicate() not implemented yet");
	return null;

	/*
	  Vector results = new Vector(10, 10);
	  String query = null;

	  try {
	  query = "SELECT * from works where resultStatus = '" + XWStatus.AVAILABLE
	  + "' AND workReplicated = 'true' AND resultReplicated = 'false'";
	  } catch(Exception e) {

	  return null;
	  }

	  ResultSet rs = DBConnPool.instance.executeQuery(query);
	  String query1;
	  ResultSet rs1;

	  try {

	  while(rs.next()) {

	  WorkInterface itf = new WorkInterface(rs);
	  MobileResult result = new MobileResult(logger.getEffectiveLevel());

	  result.setInterface(itf);
	  results.add(result);
	  }

	  } catch(Exception ex) {
	  ex.printStackTrace();
	  results = null;
	  }

	  return results;
	*/
    }//readResultsToReplicate

    /**
     * This updates database in marking provided results as 'replicated'
     * RPCXW caching : replication does not use cache
     * @param works is a vector of WorkInterface objects
     */
    public void setResultsReplicated(Vector works) {

	for(Enumeration e = works.elements(); e.hasMoreElements();) {

	    try {
		WorkInterface workItf =(WorkInterface) e.nextElement();
		setWorkReplication(workItf, false);
	    } catch(Exception ex) {
		ex.printStackTrace();
	    }

	}

    }//setWorksReplicated

    /**
     * This inserts replicated works
     * RPCXW caching : replication does not use cache
     * @param works is a Vector of WorkReplica objects
     */
    public  void writeReplicatedResults(Vector works) {

	error("Replicator::writeReplicatedResults() not implemented yet");
	/*
	  try {

	  for(Enumeration e = works.elements(); e.hasMoreElements();) {

	  WorkReplica replica =(WorkReplica) e.nextElement();
	  WorkInterface workItf = replica.getInterface();
	  Work work;

	  try {
	  work = DBInterface.instance.cache.work(workItf.getUID());
	  // RM : using src/common/*Interface
	  // should we do something if work
	  // allready exist ???
	  } catch(Exception ex) {

	  // work is not in the database; create a
	  // new one
	  work = new Work(workItf);

	  //workItf.setWid(work.getWid());
	  //work.setInterface(workItf);
	  work.setUID(new UID());

	  logger.info("Adding work : "
	  + work.getUID());

	  //create corresponding directories and
	  // files
	  File workDir = new File(HOME_DIR);
	  DataOutputStream dos;

	  try {
	  if(work.getResultName() != null) {
	  work.setResultName();
	  dos = new DataOutputStream(new FileOutputStream(new File(workDir,
	  work.getResultName())));
	  dos.write(replica.getResult(), 0,
	  replica.getResult().length);
	  }
	  work.setStatus(XWStatus.COMPLETED);
	  work.setResultStatus(XWStatus.AVAILABLE);
	  work.update();
	  } catch(Exception exp) {
	  exp.printStackTrace();
	  work.setStatus(XWStatus.INVALID);
	  work.setErrorMsg("IO Error" + exp);
	  }
	  }

	  }
	  } catch(Exception ex) {
	  ex.printStackTrace();
	  }

	*/
    }//writeReplicatedResults

    /**
     * This is not implemented yet
     */
    public  Vector readClientsToReplicate() {

	Vector clients = new Vector(10, 10);
	error("readClientsToReplicate() is not implemented yet");

	return null;
    }//readClientsToReplicate

    /**
     * This is not implemented yet
     */
    public  void writeReplicatedClients(Vector clients) {
	error("writeReplicatedClients() is not implemented yet");

    }//writeReplicatedClients

    /**
     * This retreives apps from this server
     * @return a vector of AppReplica objects
     */
    public  Vector readAppsToReplicate() {

	Vector apps = new Vector(10, 10);
	String query = "SELECT * from apps WHERE name <> 'worker' AND local = 'true' AND replicated = 'false'";
	ResultSet rs = DBConnPool.instance.executeQuery(query);

	try {
	    while(rs.next()) {
		AppInterface itf = new AppInterface(rs);
		AppReplica replica = new AppReplica();
		replica.setInterface(itf);
		apps.add(replica);

	    }//while

	} catch(Exception ex) {
	    ex.printStackTrace();
	    apps = null;
	}

	return apps;

    }//readAppsToReplicate

    /**
     * This sets application as 'replicated'
     * @param apps is a vector of AppInterface objects
     */
    public  void setAppsReplicated(Vector apps) {

	for(Enumeration e = apps.elements(); e.hasMoreElements();) {

	    try {
		AppInterface itf =(AppInterface) e.nextElement();
		App app = DBInterface.instance.cache.app(itf.getUID());
		app.update();
	    } catch(Exception ex) {
		ex.printStackTrace();
	    }
	}


    }//setAppsReplicated

    /**
     * This insert an app replica
     * @param apps is a vector of AppReplica objects
     */
    public  void writeReplicatedApps(Vector apps) {

	try {

	    for(Enumeration e = apps.elements(); e.hasMoreElements();) {

		AppReplica replica =(AppReplica) e.nextElement();
		App app;
		try {
		    app = DBInterface.instance.cache.app(replica.getUID());
		    //app already present in DB: do nothing
		} catch(Exception ex) {

		    // new app
		    //app = new App();

		    AppInterface itf = replica.getInterface();
		    app = new App(itf);
		    try {
			File outputFile = new File("toto");
			FileOutputStream fos = new FileOutputStream(outputFile);
			fos.write(replica.getBinFile());
			fos.close();
			app.update();
		    } catch(Exception ex2) {
			ex2.printStackTrace();
		    }
		}
	    }
	} catch(Exception ex) {
	    util.fatal("writeReplicatedApps() : " + ex);
	}


    }//writeReplicatedApps

    /**
     * This sets all works/results not replicated
     */
    public  void resetReplicaFields() {
	String query;
	ResultSet rs;

	//works & results
	query = "UPDATE works SET workReplicated = 'false', resultReplicated='false'";
	rs = DBConnPool.instance.executeQuery(query);

	//apps
	query = "UPDATE apps SET replicated = 'false'";
	rs = DBConnPool.instance.executeQuery(query);

    }//resetReplicaFields

}// Replicator
