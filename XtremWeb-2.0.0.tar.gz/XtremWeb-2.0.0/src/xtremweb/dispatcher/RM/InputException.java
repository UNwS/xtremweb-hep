package xtremweb.dispatcher.RM;

public class InputException extends Exception {
    
    Exception lowlevelException;

    public InputException() {
    super();
    }
    
    public InputException(String s) {
    super(s);
    }

    public InputException( Exception e ) {
    super();
    lowlevelException = e;
    }

    public InputException( String s, Exception e ) {
    super(s);
    lowlevelException = e;
    }
    
    public Exception getLowLevelException() {
        return lowlevelException;
    }
} // InputException
