package xtremweb.dispatcher.RM;

public class ServerInterface {

    public String name;
    public int port;

    public ServerInterface(String name, int port) {
	this.name = name;
	this.port = port;
    }
}//ServerInterface



