package xtremweb.dispatcher.RM;

import xtremweb.common.util;
import xtremweb.common.LoggerableThread;
import xtremweb.common.LoggerLevel;
import xtremweb.dispatcher.*;

import java.rmi.*;
import java.util.Vector;
import java.lang.Thread.*;

//send information to Output links
public class ReplicaOutput extends LoggerableThread {

    private Vector serversList;
    private ServerInterface server;
    private int currentServerIndex;
    private RMIOutputInterface rmi;
    
    public ReplicaOutput(Vector servers, LoggerLevel l) {
        super("ReplicaOutput", l);
				currentServerIndex = 0;
				serversList = servers;
				this.server = (ServerInterface) serversList.get(currentServerIndex);
    }//constructor

    public void run() {
				boolean success = false;
				double t0, t1;
       
				while (true ) {
						//contact a server on output links
						while (!success) {
								try {
										success = initComm();
										info("ReplicaOutput: CONNECTED to " + server.name + ":"+server.port);
								} catch (Exception e) {
										//try next output server
										currentServerIndex = (currentServerIndex + 1) % serversList.size();
										server = (ServerInterface) serversList.get(currentServerIndex);
										success = false;
								}
						}//while
	    
						//send data to output server
	    
						try {
								t0 = System.currentTimeMillis()* 0.001;
								sendApplications();
								t1 = System.currentTimeMillis()* 0.001;
								ReplicaManager.out.writeChars("apps :  " + (t1-t0) +"\n");

								t0 = System.currentTimeMillis()* 0.001;
								sendWorks();
								t1 = System.currentTimeMillis()* 0.001;
								ReplicaManager.out.writeChars("works : " + (t1-t0) +"\n");

								t0 = System.currentTimeMillis()* 0.001;
								sendResults();
								t1 = System.currentTimeMillis()* 0.001;
								ReplicaManager.out.writeChars("results : " + (t1-t0) +"\n");
								Thread.sleep(5000);
						} catch (Exception e) {
								//Debug.Warning("Error whene sending data ...");
								//try next server
								currentServerIndex = (currentServerIndex + 1) % serversList.size();
								server = (ServerInterface) serversList.get(currentServerIndex); 
								success = false;
						}
				}//main loop
    }

    private boolean initComm() throws OutputException {
				initializeTables();
				String rmiName = "//" + server.name + ":" + server.port + "/ReplicaManager";
				//info("Try to establish rmi connection with " + rmiName);

				try {
						Thread.sleep(2500);
						try {
								rmi = (RMIOutputInterface) Naming.lookup(rmiName);
								return true;
						} catch (SecurityException e) {
								System.setSecurityManager( new SecurityManager());
								rmi = (RMIOutputInterface) Naming.lookup(rmiName);
								return true;
						}
				} catch (Exception e) {
						//Debug.Warning("initComm, Cannot connect to Replica Manager : " + rmiName + "\n" + e);
						throw new OutputException("Cannot connect to XtremWeb ReplicaManager " + rmiName, e);
						//return false;
				}
    }//initComm
	    
    public boolean sendWorks() throws OutputException {
				Vector works;
				try {
						//fill works
						works = Dispatcher.db.replicator.readWorksToReplicate();
						info("Sending "+ works.size() +" works");
						//send works
						if (!works.isEmpty()) {
								info("\n<<<<<<<<<<<<<<<<<Sending "+ works.size() +" works>>>>>>>>>>>>>\n");
								rmi.receiveWorks(works);
								Dispatcher.db.replicator.setWorksReplicated(works);
						}
						return true;
				} catch (RemoteException e) {
						warn("sendWorks " + e);
						throw new OutputException(e);
				}
    }//sendWorks

    private boolean sendResults() throws OutputException {
				Vector results;
				try {
						//fill results
						results = Dispatcher.db.replicator.readResultsToReplicate();
						//send results
						if (!results.isEmpty()) {
								info("\n<<<<<<<<<<<<<<<<<<<<Sending "+ results.size() +" results>>>>>>>>>>>>>>>>>\n");
								rmi.receiveResults(results);
								Dispatcher.db.replicator.setResultsReplicated(results);
						}
						return true;
				} catch (RemoteException e) {
						warn("sendResults " + e);
						throw new OutputException(e);
				}
    }//sendResults

    private void sendClients() throws OutputException {
				Vector clients;
				try {
						//fill clients
						clients = Dispatcher.db.replicator.readClientsToReplicate();
						//send clients
						if (!clients.isEmpty())
								rmi.receiveClients(clients);
				} catch (RemoteException e) {
						warn("sendClients " + e);
						throw new OutputException(e);
				}
    }//sendClients

    private boolean sendApplications() throws OutputException {
				Vector apps;
				try {
						//fill apps
						//info("Reading apps to replicate");
						apps = Dispatcher.db.replicator.readAppsToReplicate();
						//info(apps.size()+" apps to replicate");
						//send apps
						//if (!apps.isEmpty()) {
						rmi.receiveApplications(apps);
						Dispatcher.db.replicator.setAppsReplicated(apps);
						//info("APPS REPLICATED SUCCESFULLY ......... ");
						//}
						return true;
				} catch (RemoteException e) {
						warn("sendApplications " + e);
						throw new OutputException(e);
				}
    }//sendApplications

    private void initializeTables() {
				info("\n>>>>>>>>>>>>>>> RM: initializeTables <<<<<<<<<<<<<<<<<<<<<<\n");
				Dispatcher.db.replicator.resetReplicaFields();
    }


}//class ReplicaOutput
