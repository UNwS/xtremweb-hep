package xtremweb.dispatcher.RM;

import xtremweb.dispatcher.Dispatcher;

import xtremweb.common.util;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.LoggerableThread;
import xtremweb.common.LoggerLevel;

import java.util.Vector;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileNotFoundException;


public class ReplicaManager extends LoggerableThread {

    private Vector serversList = new Vector(); //list of known servers
    private static ReplicaInput replicaInput;
    private static ReplicaOutput replicaOutput1, replicaOutput2;
    private static Vector server1, server2;

    public static DataOutputStream in, out;
    
    public ReplicaManager(LoggerLevel l) {
        super("ReplicaManager", l);

        try {
            in = new DataOutputStream(new FileOutputStream((Dispatcher.config.getProperty(XWPropertyDefs.HOMEDIR.toString()) + File.separator + "in.txt")));
            out = new DataOutputStream(new FileOutputStream((Dispatcher.config.getProperty(XWPropertyDefs.HOMEDIR.toString()) + File.separator + "out.txt")));
        } catch (FileNotFoundException e) {
            info("stat File not found " + e);
        }
    }//constructor
    
    public void run() {
	
        serversList = Dispatcher.config.dispatchers;
        initInputLinks();
        initOutputLinks();
    }
    
    private void initOutputLinks() {
        try {
            //choose output servers to contact
            server1 = new Vector();
            for (int i = 0; i < (serversList.size()); i++)
                server1.add((ServerInterface) serversList.get(i));
	    
            replicaOutput1 = new ReplicaOutput(server1, level);
            replicaOutput1.start();
        } catch (Exception e) {
            //changer de serveur
            warn("error : output links: " + e);
        }
    }// initOutputLinks

    private void initInputLinks() {
        try {
            replicaInput = new ReplicaInput();
            replicaInput.initComm(4322);
        } catch (InputException e) {
            warn("error : input link");
        }
    }// initInputLinks

}// ReplicaManager
