package xtremweb.dispatcher.RM;

import java.rmi.*;
import java.util.Vector;

public interface RMIOutputInterface extends Remote {

    void receiveWorks(Vector works) throws RemoteException;
    void receiveResults(Vector results) throws RemoteException;
    void receiveClients(Vector clients) throws RemoteException;
    void receiveApplications(Vector apps) throws RemoteException;

}// RMIOutputInterface
