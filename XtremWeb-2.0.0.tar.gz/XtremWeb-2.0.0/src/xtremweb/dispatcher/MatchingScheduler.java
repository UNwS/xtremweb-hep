package xtremweb.dispatcher;

import xtremweb.common.HostInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.UID;
import xtremweb.common.UserRights;

import java.io.IOException;
import java.lang.reflect.Array;

/**
 * This implements a scheduler which selects a task for the expected worker.
 * This helps to broadcast as well as to use the WorkInterface#expextedhost field.
 * This also helps to check whether the identity (user definition) under which
 * the worker is running, has the right to execute the task.
 * @see xtremweb.common.WorkInterface
 * @since RPCXW
 */

public class MatchingScheduler extends SimpleScheduler {


    /**
     * This constructor only call its parent constructor
     */
    public MatchingScheduler (HashTaskSet t) {
        super (t);
    }


    /**
     * This retreives a task to send to the worker as defined by parameter
     * @param host is the worker identifier
     * @see xtremweb.dispatcher.TaskSet#getNextWaitingTask(UID, boolean)
     */
    protected Task getNextWaitingTask(HostInterface host) {
        try {
            return tset.getNextWaitingTask (host.getUID(), host.acceptBin());
        }
        catch(IOException e) {
            return null;
        }
    }


    /**
     * This first checks if the host has a project preference.
     * In such a case, this looks for a task of this project; if no
     * task found, this return null.
     * <br />
     * If host defines no project, this gets the first waiting task.
     * This checks if the identity (user definition) under which
     * the worker is running, has the right to execute the task.
     * @param host is the requesting worker identifier
     * @param user is the identity of the worker
     * @return null if no work available; a MobileWork otherwise
     * @exception IOException is thrown if there's no bianry available
     */
    public WorkInterface select(HostInterface host,
                                User user) 
        throws IOException {

        int i;
        int index;
        Task theTask;

        if((host == null) || (user == null))
            throw new IOException("MatchingScheduler#select() param error");

        String userLogin = user.getLogin();
        UID userUID = user.getUID();
        if(DBInterface.instance.cache.user(userUID) == null)
            throw new IOException("Can't find user " + userLogin);

        //				debug("SimpleScheduler#select()" + host.getUID());

        //
        // host has a prefered project ?
        // project is finally just a user group
        //
        String projectName = host.getProject();
        UID projectUID = null;
        if((projectName != null) &&
           (projectName.length() > 0)){
            UserGroup project = DBInterface.instance.cache.usergroup("label = '"
                                                                     + projectName
                                                                     + "'");
            if(project == null) {
                error("MatchingScheduler#select() project not found "
                      + projectName);
                return null;
            }
            projectUID = project.getUID();
            if(projectUID == null) {
                error("MatchingScheduler#select() project uid is null ?!?!?! "
                             + projectName);
                return null;
            }
        }

        mileStone.clear();
        mileStone.stamp("MatchingScheduler#select start");

        theTask = tset.getNextWaitingTask(host.acceptBin());

        if(theTask == null) {
            // 31/01
            info("select() : can't find any task");
            return null;
        }

        Work theWork = DBInterface.instance.cache.work(theTask.getUID());
        if(theWork == null)
            throw new IOException("MatchingScheduler#select() work is null ?!?!");

        UID ownerUID = theWork.getUser();
        if(ownerUID == null)
            throw new IOException("Work has no owner ???");

        User owner = DBInterface.instance.cache.user(ownerUID);
        if(owner == null)
            throw new IOException("Can't find owner of work " + theWork.getUID());

        UID ownerGroupUID = owner.getGroup();
        UserGroup ownerGroup = null;
        if(ownerGroupUID != null)
            ownerGroup = DBInterface.instance.cache.usergroup(ownerGroupUID);

        if((projectUID != null) && (projectUID.equals(ownerGroupUID) == false)) {
            warn("MatchingScheduler#select() host project is " + 
                        projectName + " and not " + ownerGroup.getLabel());
            return null;
        }


        UID userGroupUID = user.getGroup();
        UserGroup userGroup = null;
        if(userGroupUID != null)
            userGroup = DBInterface.instance.cache.usergroup(userGroupUID);

        String workLabel = theWork.getLabel();
        if(workLabel == null)
            workLabel = "theWork";

        boolean userCanExecJob = theWork.userCanExec(userUID);
        boolean groupCanExecJob = theWork.groupCanExec(ownerGroupUID,
                                                       userGroupUID);
        boolean otherCanExecJob = theWork.otherCanExec();

        boolean workerUser = (user.getRights().higherOrEquals(UserRights.WORKER_USER));

        debug(workLabel + ".userCanExec(" + userLogin + ") = " +
                     userCanExecJob);
        debug(workLabel + ".groupCanExec(" + 
                     (ownerGroup != null ? ownerGroup.getLabel() : "" ) + "," +
                     (userGroup  != null ? userGroup.getLabel()  : "" ) + ") = " +
                     groupCanExecJob);
        debug(workLabel + ".otherCanExec() = " +
                     otherCanExecJob);

        //
        // Is this a private worker ?
        // Does the worker run under the identity of this job owner ?
        //
        if(userUID.equals(ownerUID)) {
            if(userCanExecJob == true) {
                info("MatchingScheduler#select() " + user.getLogin() +
                            " is a private worker and can exec work " + theWork.getUID());
                return super.select(host, theTask, theWork);
            }
            else {
                warn("MatchingScheduler#select() " + user.getLogin() +
                            " is a private worker but cannot exec work " + theWork.getUID());
                return null;
            }
        }

        //
        // Is this a group worker ?
        //
        // A group worker has 2 specificities
        // -1- a group worker runs under an identity which 
        //     is in the user group of this job owner
        // -2- a group worker has WORKER_USER user rights
        //
        if(userGroupUID.equals(ownerGroupUID)) {
            if((groupCanExecJob == true) && (workerUser == true)) {
                info("MatchingScheduler#select() " + user.getLogin() +
                            " is a group worker and can exec work " + theWork.getUID());
                return super.select(host, theTask, theWork);
            }
            else {
                warn("MatchingScheduler#select() " + user.getLogin() +
                            " is a group worker but cannot exec work " + theWork.getUID());
                return null;
            }
        }

        //
        // Finally : this is a public worker
        // A public worker must have WORKER_USER user rights
        //

        if(workerUser == false) {
            warn("MatchingScheduler#select() " + user.getLogin() +
                        " is not a public worker and cannot exec work " + theWork.getUID());
            return null;
        }

        if(otherCanExecJob == true) {
            info("MatchingScheduler#select() " + user.getLogin() +
                        " can exec work " + theWork.getUID());
            return super.select(host, theTask, theWork);
        }

        warn("MatchingScheduler#select() " + user.getLogin() +
                    " cannot exec work " + theWork.getUID());
        return null;
    }
}

