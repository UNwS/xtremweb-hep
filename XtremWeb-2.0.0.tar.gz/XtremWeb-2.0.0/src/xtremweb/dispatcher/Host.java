package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.HostInterface;
import xtremweb.common.XWCPUs;
import xtremweb.common.XWOSes;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Date;


/**
 * This class extends <CODE>TableRow</CODE>
 * This class encapsulates <CODE>HostInterface</CODE>
 * This helps to access DB table hosts
 *
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky</A>
 * @since v1r2-rc3 (RPC-V)
 */
public class Host extends TableRow {

    /** 
     * This is the default constructor.<br />
     * This creates a new host which is **not** written in the database;
     * save this host by explicitly calling <CODE>select()</CODE>
     * @see TableRow#insert()
     */
    public Host() {
        super("hosts");
        row = new HostInterface();
        dirty = true;
    }

    /** 
     * This creates a new object which is written in the database;
     * @since RPCXW
     */
    public Host(HostInterface itf) throws IOException {
        super("hosts", itf);
        insert();
    }

    /** 
     * This constructor instanciates a host from data read from an SQL table
     * @see xtremweb.common.HostInterface#HostInterface(ResultSet)
     */
    public Host(ResultSet rs) throws IOException {
        super("hosts");
        fill(rs);
    }

    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new HostInterface(rs);
        dirty = false;
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public int getAvgExecTime() {
        return((HostInterface)row).getAvgExecTime();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public int getNbJobs() {
        return((HostInterface)row).getNbJobs();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public int getTimeOut() {
        return((HostInterface)row).getTimeOut();
    }
    /**
     * This tells whether the worker tries to pool as fast as possible
     * @return true is timeout is null, false otherwise
     */
    public boolean isRealTime() {
        return((HostInterface)row).isRealTime();
    }

    public int getTimeShift() {
        return((HostInterface)row).getTimeShift();
    }
    /**
     * This gets nbconnections
     * If not set, this sets it to 0
     * @return the expected parameter 
     */
    public int getNbConnections() {
        try {
            return((HostInterface)row).getNbConnections();
        }
        catch(NullPointerException e) {
            setNbConnections(0);
            dirty = true;
        }
        return((HostInterface)row).getNbConnections();
    }
    /**
     * This gets nbping
     * If not set, this sets it to 0
     * @return the expected parameter 
     * @since 2.0.0
     */
    public int getNbPing() {
        try {
            return((HostInterface)row).getNbPing();
        }
        catch(NullPointerException e) {
            setNbPing(0);
            dirty = true;
        }
        return((HostInterface)row).getNbPing();
    }
    /**
     * This gets ping average 
     * If not set, this sets it to 0
     * @return the expected parameter 
     * @since 2.0.0
     */
    public int getAvgPing() {
        try {
            return((HostInterface)row).getAvgPing();
        }
        catch(NullPointerException e) {
            setAvgPing(0);
            dirty = true;
        }
        return((HostInterface)row).getAvgPing();
    }
    /**
     * This gets parameter
     * If not set, this sets it to 1
     * @return the expected parameter 
     */
    public int getCpuNb() {
        try {
            return((HostInterface)row).getCpuNb();
        }
        catch(NullPointerException e) {
            setCpuNb(1);
            dirty = true;
        }
        return((HostInterface)row).getCpuNb();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public long getCpuSpeed() {
        return((HostInterface)row).getCpuSpeed();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public long getTotalMem() {
        return((HostInterface)row).getTotalMem();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public long getTotalswap() {
        return((HostInterface)row).getTotalSwap();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getUID() throws IOException{
        return((HostInterface)row).getUID();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getName() {
        return((HostInterface)row).getName();
    }
    /**
     * This retreives the IP address as provided by worker itself.
     * This may be a NATed IP
     * @return the expected parameter 
     */
    public String getNatedIPAddr() {
        return((HostInterface)row).getNatedIPAddr();
    }
    /**
     * This retreives the IP address obtained at connexion time.
     * This is set by server at connexion time
     * This may be different from NATed IP
     * @return the expected parameter 
     * @since 2.0.0
     */
    public String getIPAddr() {
        return((HostInterface)row).getIPAddr();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getHWAddr() {
        return((HostInterface)row).getHWAddr();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getTimeZone() {
        return((HostInterface)row).getTimeZone();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public XWOSes getOs() {
        return ((HostInterface)row).getOs();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public XWCPUs getCpu() {
        return ((HostInterface)row).getCpu();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getProject() {
        return ((HostInterface)row).getProject();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getCpuModel() {
        return((HostInterface)row).getCpuModel();
    }

    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getOwner() throws IOException{
        return((HostInterface)row).getOwner();
    }

    /**
     * This retreives the last alive date
     * @return the last alive date
     */
    public Date getLastAlive() {
        return ((HostInterface)row).getLastAlive();
    }

    /**
     * This tests whether this host is alive(i.e. if it connects periodically)
     * @return always true
     * @deprecated this is not pertinent; use getLastAlive() instead
     * @see #getLastAlive()
     */
    public boolean isAlive() {
        return true;
    }

    /**
     * This tests whether this host is active(i.e. if it can be choosen for a job)
     * This host is inactivated if it has returned a job as ERROR.
     * This host can also be(un)activated on client request
     * @exception NullPointerException is thrown if attribute is not set
     * @return true if this is attribute is set, false otherwise
     */
    public boolean isActive() {
        return((HostInterface)row).isActive();
    }
    /**
     * This tests whether this host is available accordingly to its local policy
     * This is set on alive signal
     * @exception NullPointerException is thrown if attribute is not set
     * @return true if this is attribute is set, false otherwise
     */
    public boolean isAvailable() {
        return((HostInterface)row).isAvailable();
    }

    /**
     * This determines whether the worker is collecting trace or not
     * If traces flag is not set, this sets it to false
     * @return the expected parameter 
     */
    public boolean isTracing() {
        try{
            return((HostInterface)row).isTracing();
        }
        catch(NullPointerException e) {
            setTracing(false);
            dirty = true;
        }
        return((HostInterface)row).isTracing();
    }
    /**
     * This sets parameter
     */
    public void setNbConnections(int v) {
        if(((HostInterface)row).setNbConnections(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @since 2.0.0
     */
    public void setNbPing(int v) {
        if(((HostInterface)row).setNbPing(v))
            dirty = true;
    }
    /**
     * This increments nbconnections
     * If not set, this sets it to 0
     */
    public void incNbPing() {
        if(((HostInterface)row).setNbPing(getNbPing() + 1))
            dirty = true;
    }
    /**
     * This gets the upload bandwidth usage (in Mb/s)
     * @return the expected parameter
     * @since 2.0.0
     */
    public float getUploadBandwidth() throws IOException{
        return ((HostInterface) row).getUploadBandwidth();
    }
    /**
     * This gets the download bandwidth usage (in Mb/s)
     * @return the expected parameter
     * @since 2.0.0
     */
    public float getDownloadBandwidth() throws IOException{
        return ((HostInterface) row).getDownloadBandwidth();
    }
    /**
     * This sets the upload bandwidth usage
     * @param l is the new bandwidth usage (in  Mb/s)
     * @since 2.0.0
     */
    public void setUploadBandwidth(float l) throws IOException{
        if (((HostInterface) row).setUploadBandwidth(l))
            dirty = true;
    }
    /**
     * This calculates the upload bandwidth usage in Mb/s, providing the transfert delay
     * @param transfert is the delay needed to upload data content
     * @param size is the transfert size in bytes
     * @since 2.0.0
     */
    public void setUploadBandwidth(long transfert, long size) throws IOException{
        size /= (1024 * 1024);
        float b = (float)(size / transfert);
        if (((HostInterface) row).setUploadBandwidth(b))
            dirty = true;
    }
    /**
     * This sets the download bandwidth usage
     * @param l is the new bandwidth usage (in  Mb/s)
     * @since 2.0.0
     */
    public void setDownloadBandwidth(float l) throws IOException{
        if (((HostInterface) row).setDownloadBandwidth(l))
            dirty = true;
    }
    /**
     * This calculates the download bandwidth usage in Mb/s, providing the transfert delay
     * @param transfert is the delay needed to download data content
     * @param size is the transfert size in bytes
     * @since 2.0.0
     */
    public void setDownloadBandwidth(long transfert, long size) throws IOException{
        size /= (1024 * 1024);
        float b = (float)(size / transfert);
        if (((HostInterface) row).setDownloadBandwidth(b))
            dirty = true;
    }
    /**
     * This sets parameter
     * @since 2.0.0
     */
    public void setAvgPing(int v) {
        if(((HostInterface)row).setAvgPing(v))
            dirty = true;
    }
    /**
     * This increments NbPing and recalculates avg ping
     * @param v is the last ping
     * @since 2.0.0
     */
    public void incAvgPing(int v) {
        ((HostInterface)row).incAvgPing(v);
        dirty = true;
        try {
            update();
        }
        catch(Exception e) {
            error("host::incAvgPing() : " + e);
        }
    }
    /**
     * This increments nbconnections
     * If not set, this sets it to 0
     */
    public void incNbConnections() {
        if(((HostInterface)row).setNbConnections(getNbConnections() + 1))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setNbJobs(int v) {
        if(((HostInterface)row).setNbJobs(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setTimeOut(int v) {
        if(((HostInterface)row).setTimeOut(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setProject(String v) {
        if(((HostInterface)row).setProject(v))
            dirty = true;
    }

    public void setTimeShift(int v) {
        if(((HostInterface)row).setTimeShift(v))
            dirty = true;
    }
    /**
     * This increments the number of executed jobs
     */
    public void incNbJobs() {
        if(((HostInterface)row).setNbJobs(getNbJobs() + 1))
            dirty = true;
    }
    /**
     * This sets the average execution time
     * @param v is the new value
     */
    public void setAvgExecTime(int v) {

        if(((HostInterface)row).setAvgExecTime(v))
            dirty = true;
    }
    /**
     * This increments NbJobs and recalculates avg exec time
     * @param v is the last execution time
     */
    public void incAvgExecTime(int v) {
        ((HostInterface)row).incAvgExecTime(v);
        dirty = true;
        try {
            update();
        }
        catch(Exception e) {
            error("host::incAvgExecTime() : " + e);
        }
    }
    /**
     * This sets the cpu counter
     * @param v is the cpu counter
     */
    public void setCpuNb(int v) {
        if(((HostInterface)row).setCpuNb(v))
            dirty = true;
    }

    /**
     * This sets the cpu speed 
     * @param v is the cpus peed
     */
    public void setCpuSpeed(long v) {
        if(((HostInterface)row).setCpuSpeed(v))
            dirty = true;
    }

    /**
     * This sets the total memory
     * @param v is the total memory
     */
    public void setTotalMem(long v) {
        if(((HostInterface)row).setTotalMem(v))
            dirty = true;
    }

    /**
     * This sets the total swap
     * @param v is the total swap
     */
    public void setTotalSwap(long v) {
        if(((HostInterface)row).setTotalSwap(v))
            dirty = true;
    }

    /**
     * This sets the uid
     * @param v is the UID
     */
    public void setUID(UID v) {
        if(((HostInterface)row).setUID(v))
            dirty = true;
    }

    /**
     * This sets the host name
     * @param v is the host name
     */
    public void setName(String v) {
        if(((HostInterface)row).setName(v))
            dirty = true;
    }
    /**
     * This sets the IP address as provided by worker itself.
     * This may be a NATed IP
     * @param v is the IP address
     */
    public void setNatedIPAddr(String v) {
        if(((HostInterface)row).setNatedIPAddr(v))
            dirty = true;
    }
    /**
     * This sets the IP address obtained at connexion time.
     * This is set by server at connexion time
     * This may be different from NATed IP
     * @return the expected parameter 
     * @since 2.0.0
     */
    public void setIPAddr(String v) {
        if(((HostInterface)row).setIPAddr(v))
            dirty = true;
    }
    /**
     * This sets the MAC address
     * @param v is the MAC address
     */
    public void setHWAddr(String v) {
        if(((HostInterface)row).setHWAddr(v))
            dirty = true;
    }

    /**
     * This sets the time zone
     * @param v is the time zone
     */
    public void setTimeZone(String v) {
        if(((HostInterface)row).setTimeZone(v))
            dirty = true;
    }

    /**
     * This sets the OS name
     * @param v is the OS name
     */
    public void setOs(XWOSes v) {
        if(((HostInterface)row).setOs(v))
            dirty = true;
    }

    /**
     * This sets the cpu type
     * @param v is the cpu type
     */
    public void setCpu(XWCPUs v) {
        if(((HostInterface)row).setCpu(v))
            dirty = true;
    }

    /**
     * This sets the cpu model
     * @param v is the cpu model
     */
    public void setCpuModel(String v) {
        if(((HostInterface)row).setCpuModel(v))
            dirty = true;
    }

    /**
     * This sets the owner uid
     * @param v is the owner uid
     */
    public void setOwner(UID v) {
        if(((HostInterface)row).setOwner(v))
            dirty = true;
    }

    /**
     * This sets the last alive date
     * @param v is the last alive date
     */
    public void setLastAlive(Date v) {
        if(((HostInterface)row).setLastAlive(v))
            dirty = true;
    }

    /**
     * This does nothing
     * @deprecated this is not pertinent; use setLastAlive(Date) instead
     * @see #setLastAlive(Date)
     */
    public void setAlive(boolean v) {
    }

    /**
     * This marks this host as(in)active; i.e. an active host
     * may be choosen for computing jobs.<br />
     * A host is inactivated if it has returned a job as ERROR.<br />
     * This can also be (un)activated on client request.
     * @param v is true to mark the host as active, false otherwise
     */
    public void setActive(boolean v) {
        if(((HostInterface)row).setActive(v))
            dirty = true;
    }

    /**
     * This marks this host as (un)available accordingly to its local policy<br />
     * This is set on alive signal.
     * @param v is true to mark the host as available, false otherwise
     */
    public void setAvailable(boolean v) {
        if(((HostInterface)row).setAvailable(v))
            dirty = true;
    }

    /**
     * This sets the tracer flag
     * @param v is true to mark the host as tracing, false otherwise
     */
    public void setTracing(boolean v) {
        if(((HostInterface)row).setTracing(v))
            dirty = true;
    }

    /**
     * This gets parameter
     * @return the expected parameter
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return ((HostInterface) row).isDeleted();
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     * @since 2.0.0
     */
    public void setDeleted(boolean v) {
        if (((HostInterface)row).setDeleted(v))
            dirty = true;
    }
}
