package xtremweb.dispatcher;

import xtremweb.common.*;

import java.lang.reflect.Method;
import java.io.DataInputStream;

/**Kind of task choosen for candidates to run
 * Motivation: the scheduling policy in task set will operate
 * inside the available pool, which must be controlled.
 * The policy may be choosen from the currently available policies.
 */

public class Pool {

    /**
     * The primary policy should be given first it may superced all
     * other policy for upgrading the client for instance
     */
    private static Method primaryPolicy;

    /* To be removed */
    private static Method currentPolicy;

    /**
     * If no policy return a Work then the defaultPolicy is choosen
     */
    private static Method defaultPolicy;

     
    // Hides ugly and variable suff
    private static int FairCounter;

    Pool () {
        Class c = getClass();   
        try {
        
            /** Here we are binding 
             *  current_policy with FAIR_POLICY
             */
            Class cc = String.class;
            Class[] stringTypes = new Class[] {String.class};
            setPolicy( currentPolicy, c.getMethod("fairPolicy", 
                                                  stringTypes) );

        } catch (Exception e) {
            //FIXME ERROR msg
            util.fatal("Unable to construct Pool " + e.getMessage());
        }
    }

    public Work getWork ( String serverName) {
        try {
            Object [] params = new Object[] {serverName};
            return ((Work) currentPolicy.invoke(this, params));
        } catch (Exception e) {
            //FIXME Error MSg
            e.printStackTrace ();
            System.err.println("Pool.getWork failed " + e.getMessage());
            return (null);
        }
    }
    
    /** 
     * //FIXME
     * This sets the arbitration policy
     */
    public void setPolicy( Method source, Method target) {
        // Check that the Policy is declared
        Method [] allm = getClass().getDeclaredMethods();
        if (util.SearchInArray (allm, target)) {
            // FIXME use different order of policy
            source = target;
            currentPolicy = target;
        }
        else
            util.fatal( " Methods " + source.toString() + " or " + target.toString() + " arn't in Object Pool " );
    }


    /**
     *  The currently available policies ;
     */ 

    /**
     * A policy that distributes works according to ratios per applications 
     * @return a work choosen on a equal-chance basis
     */
    public Work fairPolicy (String server) {
        try {
            Work w;
            w = Dispatcher.db.getWork(server);
            return w;
        }
        catch(Exception e) {
            return null;
        }
    }

    /** 
     *   The Special Idle policy chooses the idletask
     *       @return an Idle-type work
     */
    public  Work idlePolicy() {
        // NO NEED TO ACCESS DATABASE
        return null;
    }  
    
    /**
     * The Special upgrade Policy choose the upgrade task 
     * @return an upgrade type work
     */
    public Work upgradePolicy() {
        // NOT IMPLEMENTED YET
        return null;
    }
}
