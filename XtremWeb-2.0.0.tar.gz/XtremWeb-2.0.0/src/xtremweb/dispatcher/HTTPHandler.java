package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.LoggerLevel;
import xtremweb.common.util;
import xtremweb.common.StreamIO;
import xtremweb.common.BytePacket;
import xtremweb.common.XMLVector;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLable;
import xtremweb.common.XWOSes;
import xtremweb.common.MD5;
import xtremweb.common.XWConfigurator;

import xtremweb.communications.IdRpc;
import xtremweb.communications.CommHandler;
import xtremweb.communications.XWPostParams;
import xtremweb.communications.XMLRPCCommand;
import xtremweb.communications.XMLRPCCommandActivateHost;
import xtremweb.communications.XMLRPCCommandBroadcastWork;
import xtremweb.communications.XMLRPCCommandDisconnect;
import xtremweb.communications.XMLRPCCommandDownloadData;
import xtremweb.communications.XMLRPCCommandGet;
import xtremweb.communications.XMLRPCCommandGetApps;
import xtremweb.communications.XMLRPCCommandGetDatas;
import xtremweb.communications.XMLRPCCommandGetGroups;
import xtremweb.communications.XMLRPCCommandGetGroupWorks;
import xtremweb.communications.XMLRPCCommandGetHosts;
import xtremweb.communications.XMLRPCCommandGetSessions;
import xtremweb.communications.XMLRPCCommandGetSessionWorks;
import xtremweb.communications.XMLRPCCommandGetTasks;
import xtremweb.communications.XMLRPCCommandGetTraces;
import xtremweb.communications.XMLRPCCommandGetUserByLogin;
import xtremweb.communications.XMLRPCCommandGetUsers;
import xtremweb.communications.XMLRPCCommandGetUserGroups;
import xtremweb.communications.XMLRPCCommandGetWorks;
import xtremweb.communications.XMLRPCCommandRemove;
import xtremweb.communications.XMLRPCCommandSendApp;
import xtremweb.communications.XMLRPCCommandSendData;
import xtremweb.communications.XMLRPCCommandSendGroup;
import xtremweb.communications.XMLRPCCommandSendHost;
import xtremweb.communications.XMLRPCCommandSendTrace;
import xtremweb.communications.XMLRPCCommandSendTask;
import xtremweb.communications.XMLRPCCommandSendUser;
import xtremweb.communications.XMLRPCCommandSendUserGroup;
import xtremweb.communications.XMLRPCCommandSendSession;
import xtremweb.communications.XMLRPCCommandSendWork;
import xtremweb.communications.XMLRPCCommandUploadData;
import xtremweb.communications.XMLRPCCommandWorkAlive;
import xtremweb.communications.XMLRPCCommandWorkAliveByUID;
import xtremweb.communications.XMLRPCCommandWorkRequest;
import xtremweb.communications.XMLRPCCommandPing;

import java.io.IOException;
import java.io.File;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.nio.channels.DatagramChannel;
import java.net.SocketAddress;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.rmi.RemoteException;
import java.util.Iterator;
import java.util.List;
import java.util.Enumeration;
import java.util.Map;
import java.security.InvalidKeyException;
import java.security.AccessControlException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mortbay.jetty.Connector;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.Response;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.bio.SocketConnector;
import org.mortbay.jetty.handler.AbstractHandler;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * This handles incoming communications through TCP<br>
 * This answers request from TCPClient
 *
 * Created: August 2005
 *
 * @see xtremweb.communications.TCPClient
 * @author Oleg Lodygensky
 * @version RPCXW
 */

public class HTTPHandler extends xtremweb.dispatcher.CommHandler {

    Request request;
    HttpServletResponse response;
    FileItem dataUpload;
    FileItemFactory diskFactory;
    ServletFileUpload servletUpload;

    IdRpc idRpc;
    UserInterface user;

    /**
     * This is the default constructor which only calls super("HTTPHandler")
     */
    public HTTPHandler(){
        super("HTTPHandler");
        user = null;
        idRpc = null;
        dataUpload = null;
        diskFactory = new DiskFileItemFactory();
        servletUpload = new ServletFileUpload(diskFactory);
        servletUpload.setSizeMax(XWPostParams.MAXUPLOADSIZE);
    }
    /**
     * This is the default constructor which only calls super("HTTPHandler")
     */
    public HTTPHandler(XWConfigurator c){
        this("HTTPHandler", c);
    }
    
    /**
     * This is the default constructor which only calls super("HTTPHandler")
     */
    public HTTPHandler(String n, XWConfigurator c){
        super(n, c);
        user = null;
        idRpc = null;
        dataUpload = null;
        diskFactory = new DiskFileItemFactory();
        servletUpload = new ServletFileUpload(diskFactory);
    }
    
    /**
     * This constructor call the default constructor and sets the logger level
     * @param l is the logger level
     * @see #HTTPHandler(XWConfigurator)
     */
    public HTTPHandler(LoggerLevel l, XWConfigurator c) throws RemoteException {
        this(c);
        setLoggerLevel(l);
    }
    
    /**
     * This constructor call the previous constructor 
     * @param socket is not used
     * @param l is the logger level 
     * @see #HTTPHandler(Level, XWConfigurator)
     */
    public HTTPHandler(Socket socket, LoggerLevel l, XWConfigurator c) throws RemoteException {
        this(l, c);
    }

    /**
     * This does nothing
     */
    public void setSocket(Socket s) throws RemoteException{
    }
    /**
     * This throws an exception since setPacket() is dedicated to UDP comms
     * @exception RemoteException is always thrown since this method is dedicated to UDP comms
     */
    public void setPacket(DatagramSocket s, DatagramPacket p) throws RemoteException{
        throw new RemoteException("HTTPHandler#setPacket() TCP can't set packet");
    }
    /**
     * @see xtremweb.communications.CommHandler#setSocket(Socket)
     * @exception RemoteException is always thrown since this method is dedicated to UDP comms
     */
    public void setPacket(DatagramChannel c, SocketAddress r, BytePacket p) throws RemoteException {
        throw new RemoteException("HTTPHandler#setPacket() TCP can't set packet");
    }

    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.jetty.Handler
     */
    public void setServer(Server server) {
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.jetty.Handler
     */
    public Server getServer() {
        return null;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return true
     */
    public boolean isFailed() {
        return true;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isRunning() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStarted() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStarting() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return true
     */
    public boolean isStopped() {
        return true;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStopping() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     */
    public void start() {
    }


    protected synchronized void write(XMLable cmd) throws IOException {
        try {
            //System.out.println("\n\n\nwrite(" + cmd.toXml() + ")\n\n\n");

            mileStone.println("<write>");
            if(response == null) {
                mileStone.println("</write error='yes'>");
                error("Can't write : this.response is not set");
                return;
            }

            debug("HTTPHandler#write(" + cmd.toXml() + ")");
            response.setContentType("text/xml;charset=UTF-8");
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().println(XMLable.XMLHEADER + cmd.toXml());
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("</write error='yes'>");
            throw new IOException(e.toString());
        }
        mileStone.println("</write error='no'>");
    }
    /**
     * This is not implemented and always throws an IOException
     */
    public synchronized void writeFile(File f) throws IOException {
//        throw new IOException("HTTPHandler#writeFile not implemented");
        try {
            mileStone.println("<writeFile file='" + f + "'>");
            //
            // 2 dec 2007 : we force nio to false
            //
            StreamIO io = new StreamIO(new DataOutputStream(response.getOutputStream()),
                                       null,
                                       level,
                                       false);
            io.writeFile(f);
            mileStone.println("</writeFile error='no'>");
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("</writeFile error='yes'>");
            throw new IOException(e.toString());
        }
    }
    /**
     * This is not implemented and always throws an IOException
     */
    public void readFile(File f) throws IOException {
        throw new IOException("HTTPHandler#readFile not implemented");
    }
    /**
     * This handles incoming connections.
     * This is inherited from org.mortbay.jetty.Handler.
     * <br />
     * This expects a POST parameter : XWPostParams.COMMAND
     * @see xtremweb.communications#XWPostParams
     */
    public synchronized void handle(String target, 
                                    HttpServletRequest _request, 
                                    HttpServletResponse _response, 
                                    int dispatch)
        throws IOException, ServletException {


        dataUpload = null;

        request = (_request instanceof Request) ?
            (Request)_request : 
            HttpConnection.getCurrentConnection().getRequest();
        response = _response instanceof Response ?
            (Response)_response :
            HttpConnection.getCurrentConnection().getResponse();

//         System.out.println("Handling " + request.getContentLength() + " " + request.getContentType());

        try {
            boolean isMultipart = ServletFileUpload.isMultipartContent(request);

//             System.out.println("Handling ismultipart    = " + isMultipart);

            String commandString = null;
            if(isMultipart == false)
                commandString = request.getParameter(XWPostParams.XWCOMMAND.toString());
            else {
                List parts = servletUpload.parseRequest(request);
                if(parts != null){
                    for(Iterator it = parts.iterator(); it.hasNext();) {
                        FileItem item = (FileItem)it.next();

                        switch(XWPostParams.valueOf(item.getFieldName().toUpperCase())) {
                        case XWCOMMAND :
                            commandString = item.getString();
                            break;
                        case XWUPLOAD :
                            dataUpload = item;
                            break;
                        }

//                         System.out.println("Handling part field name : " + 
//                                            item.getFieldName() + " = " +
//                                            item.getString());
                    }
                }
            }

//            System.out.println("Handling CMD = " + commandString);

            XMLRPCCommand cmd = XMLRPCCommand.newCommand(commandString);

//             System.out.println("Handling parameter size = " + request.getParameterMap().size());
//             System.out.println("Handling query string   = " + request.getQueryString());
//             System.out.println("Handling path info      = " + request.getPathInfo());
//             System.out.println("Handling method         = " + request.getMethod());
//             for(Enumeration e = request.getParameterNames() ; e.hasMoreElements() ;) {
//                 System.out.println("parameter " + e.nextElement());
//             }
//             for(Enumeration e = request.getHeaderNames() ; e.hasMoreElements() ;) {
//                 System.out.println("header " + e.nextElement());
//             }

//             remoteName = socket.getInetAddress().getHostName();
//             remoteIP   = socket.getInetAddress().getHostAddress();
//             remotePort = socket.getPort();
            remoteName = request.getRemoteHost();
            remoteIP   = request.getRemoteAddr();
            remotePort = request.getRemotePort();

            super.run(cmd);
            request.setHandled(true);

            return;
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This uploads a data to server<br />
     * Data must be defined on server side (i.e. sendData() must be called first)
     * @param client is the caller attributes
     * @param uid is the UID of the data to upload
     * @see #sendData(UserInterface, DataInterface)
     */
    public synchronized long uploadData(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        Data theData = null;
        long ret = 0;

        mileStone.println("<uploadData>");

        try {
            theData = DBInterface.instance.getData(client, uid);
            if(theData == null) {
                mileStone.println("</uploadData error='yes'>");
                throw new RemoteException("uploadData(" + uid +") data not found");
            }

            File dFile = theData.getPath();

            if(dataUpload == null) {
                mileStone.println("</uploadData error='yes'>");
                throw new Exception("upload is null");
            }

            dataUpload.write(dFile);
            theData.setStatus(XWStatus.AVAILABLE);
            DBInterface.instance.cache.update(theData);
            ret = dFile.length();
        }
        catch(InvalidKeyException e){
            mileStone.println("</uploadData error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(AccessControlException e){
            mileStone.println("</uploadData error='yes'>");
            throw (AccessControlException)e;
        }
        catch(Exception e) {
            try {
                theData.setStatus(XWStatus.ERROR);
                DBInterface.instance.cache.update(theData);
            }
            catch(Exception e2) {
                if(debug())
                    e2.printStackTrace();
            }

            if(debug())
                e.printStackTrace();
            mileStone.println("</uploadData error='yes'>");
            throw new RemoteException(e.toString());						
        }

        dataUpload = null;
        mileStone.println("</uploadData error='no'>");

        return ret;
    }
    /**
     * This cleans and closes communications
     */
    public void close(){

        mileStone.println("<close>");

        try {
            request.getInputStream().close();
        }
        catch(Exception e) {
        }

        try {
            response.getWriter().flush();
        }
        catch(Exception e) {
        }

        try {
            response.getWriter().close();
        }
        catch(Exception e) {
        }

        mileStone.println("</close>");
    }
}
