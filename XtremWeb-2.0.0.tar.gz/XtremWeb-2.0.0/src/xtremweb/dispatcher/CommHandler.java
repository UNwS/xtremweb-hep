package xtremweb.dispatcher;

import xtremweb.common.util;
import xtremweb.common.LoggerableThread;
import xtremweb.common.AppInterface;
import xtremweb.common.CommVector;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.XMLable;
import xtremweb.common.XMLVector;
import xtremweb.common.XMLHashtable;
import xtremweb.common.MileStone;
import xtremweb.common.UID;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.XWStatus;
import xtremweb.common.UserRights;

import xtremweb.communications.IdRpc;
import xtremweb.communications.AccessLogger;
import xtremweb.communications.XMLRPCCommand;
import xtremweb.communications.XMLRPCCommandActivateHost;
import xtremweb.communications.XMLRPCCommandBroadcastWork;
import xtremweb.communications.XMLRPCCommandDisconnect;
import xtremweb.communications.XMLRPCCommandDownloadData;
import xtremweb.communications.XMLRPCCommandGet;
import xtremweb.communications.XMLRPCCommandGetApps;
import xtremweb.communications.XMLRPCCommandGetDatas;
import xtremweb.communications.XMLRPCCommandGetGroupWorks;
import xtremweb.communications.XMLRPCCommandGetGroups;
import xtremweb.communications.XMLRPCCommandGetHosts;
import xtremweb.communications.XMLRPCCommandGetSessionWorks;
import xtremweb.communications.XMLRPCCommandGetSessions;
import xtremweb.communications.XMLRPCCommandGetTasks;
import xtremweb.communications.XMLRPCCommandGetTraces;
import xtremweb.communications.XMLRPCCommandGetUserByLogin;
import xtremweb.communications.XMLRPCCommandGetUserGroups;
import xtremweb.communications.XMLRPCCommandGetUsers;
import xtremweb.communications.XMLRPCCommandGetWorks;
import xtremweb.communications.XMLRPCCommandRemove;
import xtremweb.communications.XMLRPCCommandSendApp;
import xtremweb.communications.XMLRPCCommandSendData;
import xtremweb.communications.XMLRPCCommandSendGroup;
import xtremweb.communications.XMLRPCCommandSendHost;
import xtremweb.communications.XMLRPCCommandSendSession;
import xtremweb.communications.XMLRPCCommandSendTask;
import xtremweb.communications.XMLRPCCommandSendTrace;
import xtremweb.communications.XMLRPCCommandSendUser;
import xtremweb.communications.XMLRPCCommandSendUserGroup;
import xtremweb.communications.XMLRPCCommandSendWork;
import xtremweb.communications.XMLRPCCommandUploadData;
import xtremweb.communications.XMLRPCCommandWorkAlive;
import xtremweb.communications.XMLRPCCommandWorkAliveByUID;
import xtremweb.communications.XMLRPCCommandWorkRequest;
import xtremweb.communications.XMLRPCResult;

import xtremweb.XwIDL.*;

import java.rmi.RemoteException;
import java.io.IOException;
import java.io.EOFException;
import java.io.File;
import java.util.Date;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Iterator;
import java.security.InvalidKeyException;
import java.security.AccessControlException;
import java.net.SocketException;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import org.mortbay.jetty.Server;

/**
 * CommHandler.java This Class launches several communication handler over
 * different "media" like RMI, UDP, SSL, custom, For now uses only RMI
 * 
 * Created: Sun Jul 9 17:39:06 2000
 * 
 * @author Gilles Fedak
 * @version %I% %G%
 */

public abstract class CommHandler 
    extends LoggerableThread 
    implements xtremweb.communications.CommHandler {

    /**
     * Access logger
     */
    protected AccessLogger accessLogger;

    /**
     * This aims to display some time stamps
     */
    protected MileStone mileStone;

    /**
     * This tells whether results recovery should be tested.
     * 
     * @since v1r2-rc0 (RPC-V)
     */
    protected final boolean TESTRESULTRECOVERY = false;

    /**
     * This tells how many tests on results recovery should be made. It is only
     * used if <CODE>TESTRESULTRECOVERY</CODE> is true.
     * 
     * @since v1r2-rc0 (RPC-V)
     */
    protected final int RESULTTRY = 2;

    /**
     * This is the test results recovery counter. It is only used if <CODE>
     * TESTRESULTRECOVERY</CODE> is true.
     * 
     * @since v1r2-rc0 (RPC-V)
     */
    protected int resultTry = 0;

    protected int tracesResultDelay = 10000; // 10 sec

    protected int tracesSendResultDelay = 60; // 60 * tracesResultDelay = 10 mn

    /**
     * This is the client host name; for debug purposes only
     */
    protected String remoteName;
    /**
     * This is the client IP addr; for debug purposes only
     */
    protected String remoteIP;
    /**
     * This is the client port; for debug purposes only
     */
    protected int remotePort;
    /**
     * This has been constructed from config file
     */
    protected XWConfigurator config;

    protected CommHandler(String name) {
        super(name);
        mileStone = new MileStone(getClass().getName());
        config = Dispatcher.config;
        level = config.getLoggerLevel();
        accessLogger = new AccessLogger(config.getTmpDir(), util.getLocalHostName());
    }

    protected CommHandler(String name, XWConfigurator c) {
        this(name);
        config = c;
    }

    protected String msgWithRemoteAddresse(String msg) {
        return new String("{" + remoteName + "/" + remoteIP + "} : " + msg);
    }

    /**
     * This prefixes the debug message with the remote host name and port
     * @see #logger
     */
    public void debug(String msg) {
        super.debug(msgWithRemoteAddresse(msg));
    }
    /**
     * This prefixes the info message with the remote host name and port
     * @see #logger
     */
    public void info(String msg) {
        super.info(msgWithRemoteAddresse(msg));
    }
    /**
     * This prefixes the warning message with the remote host name and port
     * @see #logger
     */
    public void warn(String msg) {
        super.warn(msgWithRemoteAddresse(msg));
    }
    /**
     * This prefixes the error message with the remote host name and port
     * @see #logger
     */
    public void error(String msg) {
        super.error(msgWithRemoteAddresse(msg));
    }

    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.jetty.Handler
     */
    public void handle(String target,
                       HttpServletRequest request,
                       HttpServletResponse response,
                       int dispatch)
        throws IOException,
               ServletException {
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.jetty.Handler
     */
    public void setServer(Server server) {
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.jetty.Handler
     */
    public Server getServer() {
        return null;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return true
     */
    public boolean isFailed() {
        return true;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isRunning() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStarted() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStarting() {
        return false;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return true
     */
    public boolean isStopped() {
        return true;
    }
    /**
     * This does nothing and must be overidden by any HTTP handler
     * This is inherited from org.mortbay.component.LifeCycle
     * @return false
     */
    public boolean isStopping() {
        return false;
    }

    /**
     * This write an object to output channel
     */
    protected abstract void write(XMLable obj) throws IOException;
    /**
     * This writes a file to output channel
     */
    protected abstract void writeFile(File f) throws IOException;
    /**
     * This read a file from input channel
     */
    protected abstract void readFile(File f) throws IOException;

    /**
     * This is called by run() from inherited classes.
     * @param command is the command received from communication channel
     */
    protected void run(XMLRPCCommand command) {

        IdRpc idRpc = null;

        String accessPath = "";
        int accessStatus = 200;
        int accessAnswerSize= 0;
        XMLable result = null;

        try {

            idRpc = command.getIdRpc();
            accessPath = "/" + idRpc.toString();

            mileStone.println(msgWithRemoteAddresse("<new connection IDRPC='" + 
                                                    idRpc.toString() + "'>"));


            switch(idRpc) {
            case DISCONNECT:
                disconnect(command.getUser());
            case CLOSE:
                break;
            case SHUTDOWN:
                shutDown(command.getUser(), command.getHost());
                break;
            case REMOVE:
                remove(command.getUser(), ((XMLRPCCommandRemove)command).getUID());
                break;
            case GET:
                result = get(command.getUser(), ((XMLRPCCommandGet)command).getUID());
                break;
            case GETAPPS:
                result = new XMLVector(getApps(command.getUser()));
                break;
            case SENDAPP:
                sendApp(command.getUser(), (AppInterface)command.getParam());
                break;
            case GETDATAS:
                result = new XMLVector(getDatas(command.getUser()));
                break;
            case SENDDATA:
                sendData(command.getUser(), (DataInterface)command.getParam());
                break;
            case UPLOADDATA:
                uploadData(command.getUser(), ((XMLRPCCommandUploadData)command).getUID());
                break;
            case DOWNLOADDATA:
                downloadData(command.getUser(), ((XMLRPCCommandDownloadData)command).getUID());
                break;
            case GETGROUPS:
                result = new XMLVector(getGroups(command.getUser()));
                break;
            case GETGROUPWORKS:
                result = new XMLVector(getGroupWorks(command.getUser(),
                                                     ((XMLRPCCommandGetGroupWorks)command).getUID()));
                break;
            case SENDGROUP:
                sendGroup(command.getUser(), (GroupInterface)command.getParam());
                break;
            case ACTIVATEHOST:
                activateWorker(command.getUser(), 
                               ((XMLRPCCommandActivateHost)command).getUID(),
                               ((XMLRPCCommandActivateHost)command).getActivation());
                break;
            case GETHOSTS:
                result = new XMLVector(getWorkers(command.getUser()));
                break;
            case GETSESSIONS:
                result = new XMLVector(getSessions(command.getUser()));
                break;
            case SENDSESSION:
                sendSession(command.getUser(), (SessionInterface)command.getParam());
                break;
            case GETTASKS:
                result = new XMLVector(getTasks(command.getUser()));
                break;
            case SENDTASK:
                sendTask(command.getUser(), (TaskInterface)command.getParam());
                break;
            case GETTRACES:
                result = new XMLVector(getTraces(command.getUser()));
                break;
            case SENDTRACE:
                sendTrace(command.getUser(), (TraceInterface)command.getParam());
                break;
            case SENDUSER:
                sendUser(command.getUser(), (UserInterface)command.getParam());
                break;
            case GETUSERBYLOGIN:
                result = getUser(command.getUser(), ((XMLRPCCommandGetUserByLogin)command).getLogin());
                break;
            case GETUSERS:
                result = new XMLVector(getUsers(command.getUser()));
                break;
            case GETUSERGROUPS:
                result = new XMLVector(getUserGroups(command.getUser()));
                break;
            case SENDUSERGROUP:
                sendUserGroup(command.getUser(), (UserGroupInterface)command.getParam());
                break;
            case GETWORKS:
                result = new XMLVector(getWorks(command.getUser()));
                break;
            case SENDWORK:
                sendWork(command.getUser(), (WorkInterface)command.getParam());
                break;
            case BROADCASTWORK:
                broadcast(command.getUser(), (WorkInterface)command.getParam());
                break;
            case WORKREQUEST:
                result = workRequest(command.getUser(), command.getHost());
                break;
            case WORKALIVEBYUID:
                result = new XMLHashtable(workAlive(command.getUser(),
                                                    command.getHost(),
                                                    ((XMLRPCCommandWorkAliveByUID)command).getUID()));
                break;
            case WORKALIVE:
                Hashtable hash = ((XMLHashtable)command.getParam()).getHashtable();
                result = new XMLHashtable(workAlive(command.getUser(),
                                                    command.getHost(),
                                                    hash));
                break;
            case PING:
                // we do nothing here
                break;

            default :
                error("BAD Id: " + idRpc );
                accessStatus = 404;
                break;
            }

            if(result != null) {
                debug("answer " + result.toXml());
                mileStone.println(msgWithRemoteAddresse("<write result>"));
                write(result);
                mileStone.println(msgWithRemoteAddresse("</write result>"));
            }
            else
                debug("no answer");
        }
        catch(EOFException e) {
            // this is normal
        }
        catch(SocketException e) {
            // this is normal
            debug(e.toString());
        }
        catch(InvalidKeyException e) {
            // this should not occur
            error("Right access error " + e);
            accessStatus = 401;
        }
        catch(AccessControlException e) {
            // this should not occur
            error("Right access error " + e);
            accessStatus = 403;
        }
        catch(Exception e) {
            // this should not occur
            error("Cannot get io socket " + e);
	    //            if(debug())
                e.printStackTrace();
        }

        close();

        mileStone.println(msgWithRemoteAddresse("</new connection IDRPC='" + 
                                                idRpc.toString() + "'>"));
        try {
            String accessProto = null;
            if(this instanceof TCPHandler)
                accessProto = "TCP";
            if(this instanceof UDPHandler)
                accessProto = "UDP";
            if(this instanceof HTTPHandler)
                accessProto = "HTTP";

            accessLogger.println(accessPath,
                                 command.getUser() != null ? command.getUser().getLogin() : "-",
                                 accessProto,
                                 accessStatus,
                                 result != null ? result.toXml().length() : 0,
                                 remoteName, 
                                 command.getHost() != null ? command.getHost().getOs().toString() : "-");
        }
        catch(IOException e) {
        }

    } // run(XMLRPCCommand)

    /**
     * Set workers running parameters.
     * @param client is the client identifier
     * @param nbWorkers is the expected number of workers to activate.
     * @param p are the parameters to set
     * @return the number of activated workers, -1 on error
     */
    public synchronized int setWorkersParameters(UserInterface client,
                                    int nbWorkers,
                                    WorkerParameters p)
        throws RemoteException,InvalidKeyException {
	
        mileStone.println(msgWithRemoteAddresse("<setWorkersParameters>"));

        int ret = DBInterface.instance.activateWorkers(client, nbWorkers);
        tracesSendResultDelay = p.sendResultDelay;
        tracesResultDelay = p.resultDelay;

        mileStone.println(msgWithRemoteAddresse("</setWorkersParameters error='no'>"));

        return ret;
    }

    /**
     * Get workers running parameters.
     * 
     * @return workers parameters
     */
    public synchronized WorkerParameters getWorkersParameters(UserInterface client) {

        mileStone.println(msgWithRemoteAddresse("<getWorkersParameters>"));

        WorkerParameters params = new WorkerParameters();
        params.sendResultDelay = tracesSendResultDelay;
        params.resultDelay = tracesResultDelay;

        mileStone.println(msgWithRemoteAddresse("</getWorkersParameters>"));

        return params;
    }
    /**
     * Call to the scheduler to select a work
     * @return a Description of the Work the server has to complete
     */
    public synchronized WorkInterface workRequest(UserInterface _user, 
                                                  HostInterface _host)
        throws RemoteException, InvalidKeyException {

        Host host = null;
        WorkInterface work = null;

        mileStone.clear();
        mileStone.stamp("<workRequest>");

        try {
            _host.setIPAddr(remoteIP);
            host = DBInterface.instance.hostRegister(_user, _host);

            if (host.isActive()) {

                mileStone.stamp("workRequest selecting");

                User user = DBInterface.instance.checkClient(_user, UserRights.GETJOB);

                work = Dispatcher.sched.select(_host, user);

                if (work != null) {
                    UID uid = work.getUID();
                    mileStone.stamp("workRequest instanciated", uid);
                }
                else {
                    // 31/01
                    debug("worker " + host.getName() + " gets nothing");
                    // mileStone.stamp("no work available");
                }
            }
            mileStone.stamp("</workRequest error='no'>");
            mileStone.dump();

            return work;
        }
        catch(Exception e) {

            mileStone.stamp("</workRequest error='yes'>");
            mileStone.dump();

            if(debug())
                e.printStackTrace();

            // 31/01
            debug("host register error : " + e);
            if(e instanceof InvalidKeyException)
                throw (InvalidKeyException)e;
            else
                throw new RemoteException(e.getMessage());
        }

    } // workRequest ()

    /**
     * This is sent by the worker for each job it has. This is not called if the
     * worker has no job.
     * 
     * This gets current job UID from worker. This sends a boolean back to
     * worker wich tells whether to stop computing this jobs TRUE to continue
     * and FALSE to stop
     * 
     * @param jobUID is the UID od the computing job on worker side
     * @return a hashtable containing this job status so that worker continue or
     *         stop computing it
     */
    public synchronized Hashtable workAlive(UserInterface _user, 
                                            HostInterface _host, 
                                            UID jobUID)
        throws RemoteException, InvalidKeyException {

        mileStone.println("<workAlive>");

        Hashtable result = new Hashtable();
        Task theTask;
        boolean keepWorking;

        Host host = null;
        try {
            _host.setIPAddr(remoteIP);
            host = DBInterface.instance.hostRegister(_user, _host);
        }
        catch(IOException e) {
        }

        if (host == null) {
            error("workAlive : can't find host ");
            mileStone.println("</workAlive error='yes'>");
            return result;
        }

        //
        // try { host.setLastAlive (new java.util.Date
        // (System.currentTimeMillis())); host.update (); } catch (Exception e) {
        // logger.error ("can't set host last alive date ? "); }
        //

        boolean isActive = _host.isActive();

        //
        // retreiving current computing job
        //
        theTask = Dispatcher.tset.getTaskByUid(jobUID);

        if (theTask != null) {
            if (isActive == false) {
                //debug("workAlive(" + id.host.getName() + "," + jobUID + ") unlock");
                Dispatcher.db.unlockWork(jobUID);
                keepWorking = false;
                //util.info(level, getName(), "workAlive(" + id.host.getName() + "," + jobUID + ") stopping => active = false");
            }
            else {
                try {
                    keepWorking = theTask.setAlive(_host.getUID());
                } 
                catch (Exception e) {
                    error(e.toString());
                    e.printStackTrace();
                    keepWorking = false;
                }
            }
        } else {
            //
            // Task is not in the dispatcher task pool
            // Send back 'abort'
            //
            //util.info(level, getName(), "workAlive(" + id.host.getName() + "," + jobUID + ") stopping => unknwon task");
            keepWorking = false;
        }

        if (keepWorking == false)
            info("workAlive(" + _host.getName() + "," + jobUID
                 + ") stopping!");

        result.put("keepWorking", new Boolean(keepWorking));
        //				if ((taskId != -1) || (workId != -1))
        //debug("workAlive(" + id.host.getName() + "," + jobUID + ") " + (keepWorking ? "continuing" : "stopping"));
 
        mileStone.println("</workAlive error='no'>");
        return result;

    } //workAlive (String);

    /**
     * This is send by worker to tell it is still connected. Workers always try
     * to sent this signal.
     * 
     * This gets some informations from worker:
     * <ul>
     * <li>current stored job results UIDs, if any
     * </ul>
     * 
     * This sends some parameters back to worker:
     * <ul>
     * <li>traces, a boolean, to collect traces (or not);
     * <li>tracesSendResultDelay, an integer, contains traces results transfert
     * to coordinator periodicity;
     * <li>tracesResultDelay, an integer, contains traces collection
     * periodicity.
     * <li>savedTasks, a Vector, contains tasks saved by coordinator that
     * worker can delete from local disk (since v1r2-rc0/RPC-V) savedTasks also
     * contains tasks that the coordinator is not able to save for any reason.
     * <li>resultsExpected, a Vector, contains tasks the coordinator wants the
     * worker sends again results for (since v1r2-rc0/RPC-V)
     * </ul>
     * 
     * @param _user defines the calling client
     * @param _host defines the calling host
     * @param rmiParams is a Hashtable containing the worker local results, if any
     * @return a hashtable containing new worker parameters.
     */
    public synchronized Hashtable workAlive(UserInterface _user,
                                            HostInterface _host,
                                            Hashtable rmiParams) 
        throws RemoteException, InvalidKeyException{

        mileStone.println("<workAlive>");

        Hashtable result = new Hashtable();
        boolean keepWorking;

        Host host = null;
        try {
            _host.setIPAddr(remoteIP);
            host = DBInterface.instance.hostRegister(_user, _host);
        }
        catch(IOException e) {
        }

        if (host == null) {
            error("workAlive : can't find host ");
            mileStone.println("</workAlive error='yes'>");
            return result;
        }

        try {
            host.setLastAlive(new java.util.Date(System.currentTimeMillis()));
            host.setAvailable(_host.isAvailable());
            host.update();
        }
        catch (Exception e) {
            error("can't set host last alive date ? " + e);
        }

        boolean isTracing = host.isTracing();
        boolean isActive = host.isActive();

        result.put("traces", new Boolean(isTracing));
        result.put("tracesSendResultDelay", new Integer(tracesSendResultDelay));
        result.put("tracesResultDelay", new Integer(tracesResultDelay));

        //
        // retreive saved tasks -- RPC-V
        // so that the worker cleans its local copy
        //
        Vector finishedTasks = new Vector();
        Vector tasksVector = null;
        Iterator li = null;

        try {
            tasksVector = Dispatcher.tset.getSavedByHost(_host.getUID());

            if(tasksVector != null) {

                li = tasksVector.iterator();

                while (li.hasNext()) {
                    try {
                        Task aTask = (Task) li.next();
                        if (aTask == null)
                            continue;

                        info("workAlive(" + _host.getName() + ") : saved "+ aTask.getUID());

                        finishedTasks.add(aTask.getUID());
                        Work theTaskWork = DBInterface.instance.cache.work(aTask.getUID());
                        java.util.Date theDate = new java.util.Date();
			
                        aTask.setCompleted();
                        theTaskWork.setCompleted();
			
                        aTask.update();
                        theTaskWork.update();
                    } 
                    catch (Exception e) {
                        error("workAlive (" + _host.getName()
                              + "): can't update task");
                    }
                }
            }
	    
            //
            // it also retreives tasks with server side error -- RPC-V
            // so that the worker cleans its local copy
            //
            tasksVector = Dispatcher.tset.getErroneus(_host.getUID());
	    
            li = tasksVector.iterator();
	    
            while (li.hasNext()) {
                Task aTask = (Task) li.next();
                if (aTask == null)
                    continue;
		
                //debug("workAlive (" + id.host.getName() + ") : server error " + aTask.getUID());
                finishedTasks.add(aTask.getUID());
                aTask.setError();
                try {
                    aTask.update();
                } catch (Exception e) {
                    error("workAlive (" + _host.getName()
                          + ") : can't update task");
                }
            }

            //
            // It finally checks whether worker should erase some results it still
            // owns.
            // This may happen if worker has some deleted job results on its disk.
            // (i.e. if client has submitted a job which has been dispatched and
            // computed on a worker while the client finally decided to delete that
            // job)
            //
            Vector jobResults = (Vector) rmiParams.get("jobResults");
	    
            if (jobResults != null) {
		
                //debug("workAlive (" + id.host.getName() + ") : jobResults.size () = " + jobResults.size());

                li = jobResults.iterator();

                while (li.hasNext()) {

                    UID resultUID = (UID) li.next();

                    if (resultUID == null)
                        continue;

                    if ((Dispatcher.tset.getTaskByUid(resultUID) == null)
                        && (finishedTasks.contains(resultUID) == false)) {
                        // we don't know that job, remove result on worker side
                        //debug("workAlive (" + id.host.getName()+ ") : remove result " + resultUID);
                        finishedTasks.add(resultUID);
                    }
                }
            }

            //debug("workAlive (" + id.host.getName()
            //						 + ") : finishedTasks.size () = " + finishedTasks.size());
            result.put("finishedTasks", finishedTasks);

            //
            // retreive tasks which results are expected -- RPC-V
            // so that the worker re-send them
            //
            Vector resultsVector = new Vector();
            Vector resultsExpected = Dispatcher.tset.askDatasFromHost(_host.getUID());

            li = resultsExpected.iterator();

            while (li.hasNext()) {
                Task aTask = (Task) li.next();
                if (aTask == null)
                    continue;

                //debug("workAlive (" + id.host.getName()
                //						 + ") : needed result for " + aTask.getUID());

                resultsVector.add(aTask.getUID());
            }

            //debug("workAlive (" + id.host.getName()
            //						 + ") : resultsVector.size () = " + resultsVector.size());
            result.put("resultsExpected", resultsVector);

            //
            // RPC-V : new server this worker has to connect to
            //
            String newServer = DBInterface.instance.getServer(_host.getUID());

            if (newServer != null) {
                info("workAlive (" + _host.getName() + ") : new server = "
                     + newServer);
                result.put("newServer", newServer);
            }

            // 1.5.1
            debug("alivePeriod = " + config.getProperty(XWPropertyDefs.ALIVE.toString()));
            result.put("alivePeriod", 
                       new Integer(config.getProperty(XWPropertyDefs.ALIVE.toString())));

        }
        catch(IOException e) {
        }

        mileStone.println("</workAlive error='no'>");

        return result;

    } // workAlive (Hashtable);

    /* Tracer */
    public void  tactivityMonitor(HostInterface host,
                                  long   start,
                                  long   end,
                                  byte[] file) throws RemoteException {
        tactivityMonitor(host,
                         new Long(start).toString(),
                         new Long( end ).toString(),
                         file);
    }
    public synchronized void tactivityMonitor(HostInterface host,
                                              String start, String end, byte[] file) {
        try {

            try {
                //
                // because of XMLRPC, long have been stringified
                //
                // Cf worker/CommXMLRPC.java
                //
                long startValue = (new Long(start)).longValue();
                long endValue = (new Long(end)).longValue();

                Dispatcher.db.writeStatFile(host, startValue,
                                            endValue, file);
            } 
            catch (Exception e) {
                error("CommHandler::tactivityMonitor () : " + e);
            }
        } 
        catch (NullPointerException ff) {
            error("CommHandler::tactivityMonitor () : " + ff);
        }
    }

    
    /**
     * This disconnects this client from server
     * @param client defines this client attributes, such as user ID, password etc.
     */
    public synchronized void disconnect(UserInterface client)  
        throws RemoteException, InvalidKeyException {

        mileStone.println("<disconnect>");
        try {
            DBInterface.instance.disconnect(client);
        }
        catch(InvalidKeyException e){
            mileStone.println("</disconnect error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</disconnect error='yes'>");
            throw new RemoteException(e.toString());
        }
        mileStone.println("</disconnect error='no'>");
    }


    /**
     * @see xtremweb.communications.ServerAPI#shutDown(UserInterface, HostInterface)
     */
    public void shutDown(UserInterface client, HostInterface host) 
        throws RemoteException {
        throw new RemoteException("Shutdown is not implemented yet");
    }
    /**
     * This creates or updates an application on server side
     * This calls DBInterface::addApplication() to check whether client has the right to do so.
     * @see DBInterface#addApplication(UserInterface, AppInterface)
     */
    public synchronized void sendApp(UserInterface client, AppInterface mapp) 
        throws RemoteException, InvalidKeyException {

        mileStone.println("<sendApp>");

        try {
            App theApp = null;
            theApp = DBInterface.instance.addApplication(client, mapp);
        }
        catch(InvalidKeyException e) {
            mileStone.println("</sendApp error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("</sendApp error='yes'>");
            throw new RemoteException(e.toString());
        }

        DBInterface.instance.updateAppsPool();
        mileStone.println("</sendApp error='no'>");
    }

    /**
     * This retreives an application from server
     */
    public synchronized TableInterface get(UserInterface client, UID uid) 
        throws RemoteException, InvalidKeyException, AccessControlException {

        try {
            mileStone.println("<get>");
            TableInterface ret = DBInterface.instance.get(client, uid);
            mileStone.println("</get error='no'>");
            return ret;
        }
        catch(InvalidKeyException e){
            mileStone.println("</get error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(AccessControlException e){
            mileStone.println("</get error='yes'>");
            throw (AccessControlException)e;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</get error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This retreives an application from server
     */
    public synchronized AppInterface getApp(UserInterface client, String name) 
        throws IOException, InvalidKeyException, AccessControlException {
        try {
            mileStone.println("<getApp>");
            AppInterface ret = DBInterface.instance.getApplication(client, name);
            mileStone.println("</getApp error='no'>");
            return ret;
        }
        catch(InvalidKeyException e){
            mileStone.println("</getApp error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getApp error='yes'>");
            throw new RemoteException(e.toString());
        }
    }

    /**
     * This retreives all applications from server
     * @return a vector of UIDs
     */
    public synchronized Vector getApps(UserInterface client)
        throws IOException, InvalidKeyException {
        try {
            mileStone.println("<getApps>");
            Vector ret = DBInterface.instance.getApplications(client);
            mileStone.println("</getApps error='no'>");
            return ret;
        }
        catch(InvalidKeyException e){
            mileStone.println("</getApps error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getApps error='yes'>");
            throw new RemoteException(e.toString());
        }
    }

    /**
     * This removes an application from server
     * @param client defines the client
     * @param appUID is the UID of the application to remove
     */
    public synchronized void remove(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException {
        try {
            mileStone.println("<remove>");
            DBInterface.instance.remove(client, uid);
            mileStone.println("</remove error='no'>");
        }
        catch(InvalidKeyException e){
            mileStone.println("</remove error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(AccessControlException e){
            mileStone.println("</remove error='yes'>");
            throw (AccessControlException)e;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</remove error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This creates or updates data on server side
     * @param client is the caller attributes
     * @param data is the data to create
     */
    public synchronized DataInterface sendData(UserInterface client, DataInterface data)
        throws RemoteException, InvalidKeyException {

        try {
            mileStone.println("<sendData>");
            Data d = DBInterface.instance.addData(client, data);
            mileStone.println("</sendData error='no'>");
            return (DataInterface)d.getInterface();
        }
        catch(InvalidKeyException e){
            mileStone.println("</sendData error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("</sendData error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This retreives a data from server
     */
    public synchronized Vector getDatas(UserInterface client) 
        throws RemoteException, InvalidKeyException {

        try {
            mileStone.println("<getDatas>");
            Vector ret = DBInterface.instance.getDatas(client);
            mileStone.println("</getDatas error='no'>");
            return ret;
        }
        catch(InvalidKeyException e){
            mileStone.println("</getDatas error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getDatas error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This uploads a data to server<br />
     * Data must be defined on server side (i.e. sendData() must be called first)
     * @param client is the caller attributes
     * @param uid is the UID of the data to upload
     * @see #sendData(UserInterface, DataInterface)
     * @return the size of the uploaded data
     */
    public synchronized long uploadData(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException {

        long ret = 0;

        mileStone.println("<uploadData>");
        Data theData = null;
        try {
            Date date = new Date();
            theData = DBInterface.instance.getData(client, uid);
            if(theData == null) {
                mileStone.println("</uploadData error='yes'>");
                throw new RemoteException("uploadData(" + uid +") data not found");
            }

            File dFile = theData.getPath();
            readFile(dFile);
            theData.setStatus(XWStatus.AVAILABLE);
            DBInterface.instance.cache.update(theData);
            ret = dFile.length();
        }
        catch(InvalidKeyException e){
            mileStone.println("</uploadData error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(AccessControlException e){
            mileStone.println("</uploadData error='yes'>");
            throw (AccessControlException)e;
        }
        catch(Exception e) {
            try {
                theData.setStatus(XWStatus.ERROR);
                DBInterface.instance.cache.update(theData);
            }
            catch(Exception e2) {
                if(debug())
                    e2.printStackTrace();
            }

            if(debug())
                e.printStackTrace();
            mileStone.println("</uploadData error='yes'>");
            throw new RemoteException(e.toString());						
        }
        mileStone.println("</uploadData error='no'>");
        return ret;
    }
    /**
     * This downloads a data from server
     * @param client is the caller attributes
     * @param data is the UID of the data to remove
     */
    public synchronized long downloadData(UserInterface client, UID data)
        throws IOException, InvalidKeyException, AccessControlException {

        long ret = 0;

        mileStone.println("<downloadData>");
        try {
            Date date = new Date();
            Data theData = DBInterface.instance.getData(client, data);
            if(theData == null) {
                mileStone.println("</downloadData error='yes'>");
                throw new RemoteException("downloadData(" + data +") data not found");
            }
            File dFile = theData.getPath();
            writeFile(dFile);
            ret = dFile.length();
        }
        catch(InvalidKeyException e){
            mileStone.println("</downloadData error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(AccessControlException e){
            mileStone.println("</downloadData error='yes'>");
            throw (AccessControlException)e;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
                mileStone.println("</downloadData error='yes'>");
            throw new RemoteException(e.toString());						
        }
        mileStone.println("</downloadData error='no'>");
        return ret;
    }

    /**
     * This creates or updates a group on server side
     * @param client contains user id/password
     * @param group is the group to send
     */
    public synchronized void sendGroup(UserInterface client, GroupInterface group) 
        throws IOException, InvalidKeyException {

        try {
            mileStone.println("<sendGroup>");
            DBInterface.instance.createGroup(client, group);
            mileStone.println("</sendGroup error='no'>");
        }
        catch(InvalidKeyException e){
            mileStone.println("</sendGroup error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</sendGroup error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This retreives this client groups
     * @param client defines this client attributes, such as user ID, password etc.
     */
    public synchronized Vector getGroups(UserInterface client)  
        throws IOException, InvalidKeyException {

        mileStone.println("<getGroups>");

        try {
            Vector ret = DBInterface.instance.getGroups(client);
            return ret;
        }
        catch(InvalidKeyException e){
            mileStone.println("</getGroups error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getGroups error='yes'>");
            throw new RemoteException(e.toString());
        }
    }

    /**
     * This retreives all works for the given group
     * @param client defines this client attributes, such as user ID, password etc.
     * @param group is the group UID to retreive works for
     */
    public synchronized Vector getGroupWorks(UserInterface client, UID group) 
        throws IOException, InvalidKeyException, AccessControlException {

        try {
            mileStone.println("<getGroupWorks>");
            Vector ret = DBInterface.instance.getGroupJobs(client, group);
            mileStone.println("</getGroupWorks error='no'>");
            return ret;
        }
        catch(InvalidKeyException e){
            mileStone.println("</getGroupWorks error='yes'>");
            throw (InvalidKeyException)e;
        }
        catch(AccessControlException e){
            mileStone.println("</getGroupWorks error='yes'>");
            throw (AccessControlException)e;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getGroupWorks error='yes'>");
            throw new RemoteException(e.toString());
        }
    }

    /**
     * This creates or updates an session on server side
     */
    public synchronized void sendSession(UserInterface client, SessionInterface session) 
        throws RemoteException {

        try {
            mileStone.println("<sendSession>");
            DBInterface.instance.createSession(client, session);
            mileStone.println("</sendSession error='no'>");
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</sendSession error='yes'>");
            throw new RemoteException(e.toString());
        } 
   }
    /**
     * This retreives all sessions from server
     * @return a vector of UIDs
     */
    public synchronized Vector getSessions(UserInterface client) 
        throws RemoteException {

        try {
            mileStone.println("<getSessions>");
            Vector ret = DBInterface.instance.getSessions(client);
            mileStone.println("</getSessions error='no'>");
            return ret;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getSessions error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This retreives all works for the given session
     * @param client defines this client attributes, such as user ID, password etc.
     * @param session is the session UID to retreive works for
     */
    public synchronized Vector getSessionWorks(UserInterface client, UID session)
        throws RemoteException {

        try {
            mileStone.println("<getSessionWorks>");
            Vector ret = DBInterface.instance.getSessionJobs(client, session);
            mileStone.println("</getSessionWorks error='no'>");
            return ret;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getSessionWorks error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This creates or updates an task on server side
     */
    public void sendTask(UserInterface client, TaskInterface task) 
        throws RemoteException {
        throw new RemoteException("TCPHandler::senTask  TCP not implemented yet");
    }
    /**
     * This retreives all tasks from server
     * @return a vector of UIDs
     */
    public synchronized Vector getTasks(UserInterface client) throws RemoteException {
        mileStone.println("<getTasks>");
        try {
            Vector ret = DBInterface.instance.getAllJobs(client);
            mileStone.println("</getTasks error='no'>");
            return ret;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("</getTasks error='no'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This creates or updates an work on server side
     * This calls DBInterface#insertWork()
     * @see DBInterface#insertWork(UserInterface, WorkInterface)
     */
    public synchronized void sendWork(UserInterface client, WorkInterface work)
        throws RemoteException {

        try {
            mileStone.println("<sendWork>");
            DBInterface.instance.insertWork(client, work);
            mileStone.println("</sendWork error='no'>");
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</sendWork error='yes'>");
            throw new RemoteException(e.toString());
        }
    }

    /**
     * @deprecated since 1.9.0 this is deprecated ; sendWork() should be used instead
     *             stdin and dirin must be sent using sendData
     * @see #sendWork(UserInterface, WorkInterface)
     * @see #sendData(UserInterface, DataInterface)
     */
    public void submit(UserInterface client, WorkInterface job)
        throws RemoteException {
    }
    /**
     * This retreives an work from server, including all associated files
     * @param client is the caller attributes
     * @param uid is the work UID
     * @return a WorkInterface object
     */
    public WorkInterface loadWork(UserInterface client, UID uid) 
        throws RemoteException {
        throw new RemoteException("TCPHandler::loadWork() not implemented yet");
    }
    /**
     * This retreives all works from server
     * @return a vector of UIDs
     */
    public synchronized Vector getWorks(UserInterface client)
        throws RemoteException {

        mileStone.println("<getWorks>");

        try {
            Vector ret = DBInterface.instance.getAllJobs(client);
            mileStone.println("</getWorks error='no'>");
            return ret;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("</getWorks error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This broadcasts a new work to all workers
     * @param client defines this client attributes, such as user ID, password etc.
     * @param work defines the work to broadcast
     * @return a Vector of String containing submitted work UIDs
     */
    public synchronized Vector broadcast(UserInterface client, WorkInterface work)
        throws RemoteException {

        try {
            mileStone.println("<broadcast>");
            Vector ret = DBInterface.instance.broadcast(client, work);
            mileStone.println("</broadcast error='no'>");
            return ret;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("</broadcast error='yes'>");
            throw new RemoteException(e.toString());
        }
    }

    /**
     * This always throws an exception
     * @deprecated since 1.9.0 
     * @see #sendData(UserInterface, DataInterface)
     */
    public DataInterface getResult(UserInterface client, UID uid) 
        throws RemoteException {
        throw new RemoteException("GETRESULT is deprecated; please use GETDATA");
    }
    /**
     * This always throws an exception
     * @deprecated since 1.9.0 
     * @see #sendData(UserInterface, DataInterface)
     */
    public void sendResult(UserInterface client, DataInterface result)
        throws RemoteException {
        throw new RemoteException("SENDRESULT is deprecated; please use SENDDATA");
    }
    /**
     * This creates or updates an worker on server side
     */
    public void sendWorker(UserInterface client, HostInterface worker) 
        throws RemoteException {
        throw new RemoteException("TCPHandler::sendWorker TCP not implemented yet");
    }
    /**
     * This retreives all workers from server
     * @return a vector of UIDs
     */
    public synchronized Vector getWorkers(UserInterface client)
        throws RemoteException {

        try {
            mileStone.println("<getWorkers>");
            Vector ret = DBInterface.instance.getRegisteredWorkers(client);
            mileStone.println("</getWorkers error='no'>");
            return ret;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getWorkers error='yes'>");
            throw new RemoteException(e.toString());
        }
    }

    /** 
     * Set worker active flag.
     * @param client contains client parameters
     * @param uid is the worker uid
     * @param flag is the active flag
     */
    public synchronized void activateWorker(UserInterface client, UID uid, boolean flag)
        throws RemoteException {

        try {
            mileStone.println("<activateWorkers>");
            DBInterface.instance.activateWorker(client, uid, flag);
            mileStone.println("</activateWorkers error='no'>");
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</activateWorkers error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This set the expected number of workers
     * @param client contains client parameters
     * @return the number of activated workers, -1 on error
     */
    public synchronized int setWorkersNb(UserInterface client, int nb)
        throws RemoteException { 
        try {
            int ret = DBInterface.instance.activateWorkers(client, nb);
            return ret;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            throw new RemoteException(e.toString());
        }
    }
    /** 
     * This adds a new user.
     * @param client contains client parameters
     * @param user describes new user informations
     */
    public synchronized void sendUser(UserInterface client, UserInterface user)
        throws RemoteException {
        try {
            mileStone.println("<sendUser>");
            DBInterface.instance.addUser(client, user);
            mileStone.println("</sendUser error='no'>");
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</sendUser error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /** 
     * Get traces files path.
     * @return a string containing traces files path.
     */
    public synchronized String getTracesPath() 
        throws RemoteException {

        String ret = DBInterface.instance.getTracesPath();
        return ret;
    }
    /**
     * This creates or updates an usergroup on server side
     * This forces group.project to true
     */
    public synchronized void sendUserGroup(UserInterface client, 
                                           UserGroupInterface group)
        throws RemoteException {
        try {
            mileStone.println("<sendUserGroup>");
            group.setProject(true);
            DBInterface.instance.addUserGroup(client, group);
            mileStone.println("</sendUserGroup error='no'>");
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</sendUserGroup error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This retreives all usergroups from server
     * @return a vector of UIDs
     */
    public synchronized Vector getUserGroups(UserInterface client)
        throws RemoteException { 

        try {
            mileStone.println("<getUserGroups>");
            Vector ret = DBInterface.instance.getUserGroups(client);
            mileStone.println("</getUserGroups error='no'>");
            return ret;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getUserGroups error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This retreives an user from server
     */
    public synchronized UserInterface getUser(UserInterface client, String login)
        throws RemoteException {

        try {
            mileStone.println("<getUser>");
            UserInterface ret = DBInterface.instance.getUser(client, login);
            mileStone.println("</getUser error='no'>");
            return ret;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getUser error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This retreives all users from server
     * @return a vector of UIDs
     */
    public synchronized Vector getUsers(UserInterface client) 
        throws RemoteException {

        try {
            mileStone.println("<getUsers>");
            Vector ret = DBInterface.instance.getUsers(client);
            mileStone.println("</getUsers error='no'>");
            return ret;
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</getUsers error='yes'>");
            throw new RemoteException(e.toString());
        }
    }
    /** 
     * This creates a Mobile Work filled with worker software. It is
     * used to update worker as 
     * @param user defines the client
     * @param host defines the host
     * @return a filled mobileWork
     */ 
    public DataInterface getWorkerBin(UserInterface user, 
                                      HostInterface host)
        throws RemoteException {

        throw new RemoteException("getWorkerBin is not implemented");
        /*
          try {
          return Dispatcher.upgradeHelper.getWorkerBin(wid);
          }
          catch(IOException e) {
          throw new RemoteException(e.toString());
          }
        */
    }
    /**
     * This creates or updates an trace on server side
     */
    public void sendTrace(UserInterface client, TraceInterface trace) throws RemoteException {
        throw new RemoteException("TCPHandler::sendTrace TCP not implemented yet");
    }
    /**
     * This retreives all traces from server
     * @return a vector of UIDs
     */
    public Vector getTraces(UserInterface client) throws RemoteException {
        throw new RemoteException("TCPHandler::getTraces TCP not implemented yet");
    }
    /** 
     * Get all known traces.
     * @return an vector of TraceInterface
     */
    public synchronized Vector getTraces(UserInterface client, 
                                         Date since,
                                         Date before)
        throws RemoteException {

        Vector ret = Dispatcher.db.getRegisteredTraces(client, since, before);
        return ret;
   }
    /** 
     * Get the path of traces files.
     * @return a string describing path to traces files.
     */
    public String getTracesPath(UserInterface client)
        throws RemoteException {
        throw new RemoteException("TCPHandler::getTracesPath TCP not implemented yet");
    }
    /** 
     * Get trusted addresses
     * @return a string containing trused ip addresses separated by a
     * white space.
     */
    public String getTrustedAddresses(UserInterface client)
        throws RemoteException {
        return null;
    }
    /** 
     * Add a trusted address
     * @param ip new trusted IP
     */
    public void addTrustedAddress(UserInterface client, String ip)
        throws RemoteException {
    }
    /** 
     * this is not implemented
     * @param ip trusted IP to remove
     */
    public void removeTrustedAddress(UserInterface client, String ip)
        throws RemoteException {
        throw new RemoteException ("removeTrustedAddress is not implemented");
    }
    /** 
     * Set workers trace flag.
     * @param hosts is a hashtable which contains host name as key and their
     * dedicated trace flag as value.
     */
    public synchronized void traceWorkers(UserInterface client, Hashtable hosts)
        throws RemoteException {
        try {
            mileStone.println("<traceWorker>");
            DBInterface.instance.traceWorkers(client, hosts);
            mileStone.println("</traceWorker error='no'>");
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            mileStone.println("</traceWorker error='yes'>");
            throw new RemoteException(e.toString());
        }
    }

} // CommHandler

