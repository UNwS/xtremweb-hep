package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.Logger;
import xtremweb.common.LoggerLevel;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Enumeration;

/**
 * This class caches a DB table
 * This implentation is very simple and does not know how to manage
 * complex SQL query
 * This implementation uses Hashtable, using key as String
 * The default key is UID
 * @see java.util.Hashtable
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky</A>
 * @since RPCXW
 */
public class TableCache extends Logger {

    /**
     * This defines the table name
     */
    protected String tableName;
    /**
     * This defines the row class to cache
     * (i.e. xtremweb.dispatcher.App)
     */
    protected String className;
    /**
     * This defines the key name 
     * This must be a column as defined in DB
     * (i.e. uid, login...)
     * Default is uid
     */
    protected String keyName;

    /**
     * This is the table cache
     * This stores table rows using UID as keys
     * @see xtremweb.dispatcher.TableRow
     */
    protected Hashtable cache;

    /** 
     * This constructs a cache accordingly to the provided class name
     * @param tn is the table name
     * @param cn is the row class name to cache
     */
    public TableCache(String tn, String cn, LoggerLevel l) {
        tableName = tn;
        className = cn;
        keyName = "uid";
        cache = new Hashtable(250);
        level = l;
    }

    /**
     * This retreives the cache size
     */ 
    public int size() throws IOException {
        return cache.size();
    }

    /**
     * This inserts a row in DB and cache with default key
     * @param row is the row to insert
     */
    public void insert(TableRow row) throws NullPointerException, IOException {
        row.insert();
        put(row);
    }

    /**
     * This caches a row with default key
     * @param row is the row to cache
     * @see DBInterface#getWork(String)
     */
    public void put(TableRow row) throws NullPointerException {
        try{
            put(row.getUID().toString(), row);
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new NullPointerException(e.toString());
        }
    }

    /**
     * This caches a row with the provided key value
     * @param key is the hashtable key value
     * @param row is the row to cache
     * @see DBInterface#getWork(String)
     */
    public void put(String key, TableRow row) throws NullPointerException {
        //System.out.println("TableCache#put " + key);
        if(cache.containsKey(key) == false) {
            cache.put(key, row);
        }
    }

    /**
     * This retreives stored keys enumeration
     * @return an enumeration of the keys in this cache
     * @see java.util.Hashtable
     */
    public Enumeration keys() throws IOException {
        return cache.keys();
    }

    /**
     * This retreives all rows from table and caches them
     * This forces DB read
     * @return the last found row
     */
    public TableRow select() throws IOException {
        return select((String)null);
    }

    /**
     * This retreives some rows from table and caches them
     * This forces DB read
     * @param conditions is the SQL query conditions
     * @return the last found row
     */
    public TableRow select(String conditions) throws IOException {

        String query = "SELECT * from " + tableName + " WHERE ";
        if(conditions != null)
            query += conditions + " AND ";

        query += "isdeleted = 'false'";

        debug("select " + tableName + ": " + query);
        ResultSet rs = DBConnPool.instance.executeQuery(query);

        TableRow row = null;
        try {
            while(rs.next()) {

                //								try {
                row = (TableRow)Class.forName(className).newInstance();
                row.fill(rs);
                put(row);
                // 								logger.debug("TableCache#select " + tableName +
                // 														 " found " + row.getUID() + 
                // 														 " size " + size());
                // 								}
                // 								catch(Exception e) {
                // 										logger.error(e.toString());
                // 										if(logger.getEffectiveLevel() == Level.DEBUG)
                // 												e.printStackTrace();
                // 										continue;
                // 								}

            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }

        return row;
    }

    /**
     * This retreives a row from cache by its key value
     * This reads row from DB and caches it if not already loaded
     * @param value is the key value
     * @return the table row
     */
    public TableRow selectByKey(String value) throws IOException {
        // 				logger.debug("TableCache#selectByKey(" + tableName + ") : <" +
        // 										 keyName + ":" + value + ">");
        TableRow row =(TableRow)cache.get(value);
        if(row != null) {
            //logger.debug("TableCache#selectByKey(" + tableName + ") : <" +
            //						 keyName + ":" + value + "> found in cache");
            return row;
        }

        // 				try {
        row = (TableRow)select(keyName + "='" + value + "'");
        // 				}
        // 				catch(Exception e) {
        // 						e.printStackTrace();
        // 						throw new IOException(e.toString());
        // 				}

        // 				if(row != null)
        // 						put(row);

        return row;
    }

    /**
     * This retreives a row from cache by its UID
     * This reads row from DB and caches it if not already loaded
     * @param uid is the row UID
     * @return the table row
     */
    public TableRow select(UID uid) throws IOException {
        //return (TableRow)cache.get(uid.toString());
        return selectByKey(uid.toString());
    }

    /**
     * This removes a row from cache, but not from DB
     * @param uid is the UID of the row to remove
     * @return the removed row
     */
    public TableRow remove(UID uid) throws IOException {
        return remove(uid.toString());
    }

    /**
     * This removes a row from cache, but not from DB
     * @param key is the key of the row to remove
     * @return the removed row
     */
    public TableRow remove(String key) throws IOException {
        TableRow row = (TableRow)cache.remove(key);
        return row;
    }

    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public TableRow delete(UID uid) throws IOException {
        return delete(uid.toString());
    }
    /**
     * This deletes a row from both cache and DB
     * @param key is the row key
     * @return the deleted row
     */
    public TableRow delete(String key) throws IOException {
        //        logger.debug("TableCache#delete(" + tableName + ") : " + key + "(" + cache.size() + ")");
        TableRow row = remove(key);
        if(row == null)
            row = selectByKey(key);
        if(row != null) {
            //            logger.debug("TableCache#delete(" + tableName + ") : " + key + " found");
            row.delete();
            // 27/05/2006 : oups!
            row = remove(key);
        }
        //        else
        //            logger.debug("TableCache#delete(" + tableName + ") : " + key + " not found");
        //        logger.debug("TableCache#delete(" + tableName + ") : " + key + " removed from DB");
        return row;
    }

} // class TableCache
