package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.TableInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserRights;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;


/**
 * This class extends <CODE>TableRow</CODE>
 * This class encapsulates <CODE>UserInterface</CODE>
 * This helps to access DB table apps
 *
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky</A>
 * @since v1r2-rc3 (RPC-V)
 */
public class User extends TableRow {


    /** 
     * This creates a new object which is not written in DB
     * @since RPCXW
     */
    public User() {
        super ("users");
    }
    /** 
     * This creates a new object which is written in the database
     * @since RPCXW
     */
    public User (UserInterface itf) throws IOException{
        super ("users", itf);
//         // because the database defines password as char(50)
//         if(getPassword().length() > 50)
//             setPassword(getPassword().substring(0,49));
//         else
//             setPassword(getPassword());
        insert();
    }
    /** 
     * This constructor instanciates this object from data read from an SQL table
     * @see xtremweb.common.UserInterface#UserInterface(ResultSet)
     */
    public User (ResultSet rs) throws IOException {
        super ("users");
        fill(rs);
    }
    /**
     * This updates this object from interface.
     * <ul>
     * <li> user group
     * <li> first name
     * <li> last name
     * <li> email
     * <li> country
     * <li> team
     * <li> password
     * <li> rights
     * </ul>
     */
    public void updateInterface(UserInterface itf) throws IOException {
        if(itf.getGroup() != null)
            setGroup(itf.getGroup());
        if(itf.getFirstName() != null)
            setFirstName(itf.getFirstName());
        if(itf.getLastName() != null)
            setLastName(itf.getLastName());
        if(itf.getEMail() != null)
            setEMail(itf.getEMail());
        if(itf.getCountry() != null)
            setCountry(itf.getCountry());
        if(itf.getPassword() != null)
            setPassword(itf.getPassword());
        if(itf.getRights() != null)
            setRights(itf.getRights());
    }
    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new UserInterface (rs);
        dirty = false;
    }
    /**
     * This change login to "DEL@" + login + "@DEL" and set ISDELETED flag to TRUE
     * Because login is a DB constraint and one may want to insert and delete
     * and then reinsert a user with the same login.
     * And delete does not remove row from DB : it simply set ISDELETED flag to true
     */
    public synchronized void delete() throws IOException {
        try {
            setLogin("DEL@" + getUID() + "_" + getLogin() + "@DEL");

            String criteria = row.criterias();
            if (criteria == null)
                throw new IOException("unable to get delete criteria");

            String query = deleteQueryHeader() + " SET " + 
                TableInterface.DELETEDFLAG + "='true', login='" + getLogin() + "' WHERE " + criteria;

            if (DBConnPool.instance.executeQuery(query) == null)
                throw new IOException("unable to delete from " + tableName);
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UserRights getRights () {
        return ((UserInterface)row).getRights ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getUID () throws IOException{
        return ((UserInterface)row).getUID ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getGroup () throws IOException{
        return ((UserInterface)row).getGroup ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getFirstName () {
        return ((UserInterface)row).getFirstName ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getLastName () {
        return ((UserInterface)row).getLastName ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getEMail () {
        return ((UserInterface)row).getEMail ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getLogin () {
        return ((UserInterface)row).getLogin ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public int getNbJobs () {
        return ((UserInterface)row).getNbJobs ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getPassword () {
        return ((UserInterface)row).getPassword ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getCountry () {
        return ((UserInterface)row).getCountry ();
    }
    /**
     * This sets parameter
     * @param r is the new value to set the param to
     */
    public void setRights (UserRights r) {
        if (((UserInterface)row).setRights(r))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setUID (UID v) {
        if (((UserInterface)row).setUID (v))
            dirty = true;
    }
    public void setGroup (UID v) {
        if (((UserInterface)row).setGroup (v))
            dirty = true;
    }
    /**
     * This sets the first name
     * @param v is the first name
     */
    public void setFirstName (String v) {
        if(((UserInterface)row).setFirstName (v))
            dirty = true;
    }
    /**
     * This sets the last name
     * @param v is the last name
     */
    public void setLastName (String v) {
        if(((UserInterface)row).setLastName (v))
            dirty = true;
    }
    /**
     * This sets the login
     * @param v is the login
     */
    public void setLogin (String v) {
        if(((UserInterface)row).setLogin (v))
            dirty = true;        
    }
    /**
     * This sets the password
     * @param v is the password
     */
    public void setPassword (String v) {
        if(((UserInterface)row).setPassword (v))
            dirty = true;
    }
    /**
     * This sets the completed jobs counter
     * @param v is the counter
     */
    public void setNbJobs (int v) {
        if (((UserInterface)row).setNbJobs (v))
            dirty = true;
    }
    /**
     * This increments the completed jobs counter
     */
    public void incNbJobs () {
        if (((UserInterface)row).setNbJobs (getNbJobs () + 1))
            dirty = true;
    }
    /**
     * This sets the email address
     * @param v is the email address
     */
    public void setEMail (String v) {
        if(((UserInterface)row).setEMail (v))
            dirty = true;
    }
    /**
     * This sets the country
     * @param v is the country
     */
    public void setCountry (String v) {
        if(((UserInterface)row).setCountry (v))
            dirty = true;
    }
    /**
     * This gets parameter
     * @return the expected parameter
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return ((UserInterface) row).isDeleted();
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     * @since 2.0.0
     */
    public void setDeleted(boolean v) {
        if (((UserInterface)row).setDeleted(v))
            dirty = true;
    }
}
