package xtremweb.dispatcher;

import xtremweb.common.util;
import xtremweb.common.UID;
import xtremweb.common.LoggerLevel;
import xtremweb.common.StreamIO;
import xtremweb.common.BytePacket;
import xtremweb.common.XMLVector;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLable;
import xtremweb.common.XWOSes;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWPropertyDefs;

import xtremweb.communications.CommHandler;
import xtremweb.communications.XMLRPCCommand;

import java.io.IOException;
import java.io.File;
import java.io.DataOutputStream;
import java.nio.channels.DatagramChannel;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.rmi.RemoteException;


/**
 * This handles incoming communications through UDP<br>
 * This answers request from UDPClient
 *
 * Created: August 2005
 *
 * @see xtremweb.communications.UDPClient
 * @author Oleg Lodygensky
 * @version RPCXW
 */

public class UDPHandler extends xtremweb.dispatcher.CommHandler {

    /**
     * This aims to send datagram packets back to client
     */
    protected DatagramSocket serverSocket = null;
    /**
     * This is the datagram packet used for I/O
     */
    DatagramPacket serverPacket;

    boolean answerSent;

    /**
     * This manages the receiving packet byte array
     */
    //		private ByteStack packetIn;
    protected BytePacket packetIn;
    /**
     * This manages the sending packet byte array
     */
    //		private ByteStack packetOut;
    protected BytePacket packetOut;

    /**
     * This is the default constructor which only calls super("UDPHandler")
     */
    public UDPHandler(){
        super("UDPHandler");
    }
    /**
     * This is the default constructor which only calls super("UDPHandler")
     */
    public UDPHandler(XWConfigurator context){
        this("UDPHandler", context);
    }
    /**
     * This is the default constructor which only calls super("UDPHandler")
     */
    public UDPHandler(String n, XWConfigurator context){
        super(n, context);
        packetIn = new BytePacket(LoggerLevel.WARN);
        packetOut = new BytePacket(LoggerLevel.WARN);

        answerSent = false;
    }
    /**
     * This constructor call the default constructor and sets the logger level
     * @param l is the logger level 
     * @see #UDPHandler()
     */
    public UDPHandler(LoggerLevel l, XWConfigurator context) throws RemoteException {
        this(context);
        setLoggerLevel(l);
        // 				packetIn  = new ByteStack(l);
        // 				packetOut = new ByteStack(l);
        packetIn  = new BytePacket(l);
        packetOut = new BytePacket(l);
    }
    
    /**
     * This throws an exception since setSocket() is dedicated to TCP comms
     * @see xtremweb.communications.CommHandler#setSocket(Socket)
     * @exception RemoteException is always thrown since this method is dedicated to TCP comms
     */
    public void setSocket(Socket s) throws RemoteException{
        throw new RemoteException("setSocket is not implemented for UDP comms");
    }
    /**
     */
    public void setPacket(DatagramSocket s, DatagramPacket p) throws RemoteException{
        serverPacket = p;
        packetIn.setData(p.getData());
        serverSocket = s;

        boolean net = Boolean.parseBoolean(config.getProperty(XWPropertyDefs.OPTIMIZENET.toString()));
        // mac os x don't like that :(
        if((net == true) &&
           (XWOSes.getOs().isMacosx() == false))
            try {
                serverSocket.setTrafficClass(0x08);          // maximize throughput
            }
            catch(Exception e) {
                warn(e.toString());
            }

        InetSocketAddress socket = (InetSocketAddress)(serverPacket.getSocketAddress());
        remoteName = socket.getHostName();
        remoteIP = socket.getAddress().getHostAddress();
        remotePort = socket.getPort();
    }
    /**
     * @see xtremweb.communications.CommHandler#setSocket(Socket)
     * @exception RemoteException is always thrown since this method is dedicated to UDP comms
     */
    public void setPacket(DatagramChannel c, SocketAddress r, BytePacket p) throws RemoteException {
        throw new RemoteException("UDPHandler#setPacket() UDP can't set packet");
    }
    /**
     * This first packs the packet, then sends it
     * @see xtremweb.common.BytePacket#pack()
     */
    protected synchronized void send() throws RemoteException {
        if(answerSent) {
            return;
        }

        try {
            //						mileStone.stamp("send start");
            packetOut.pack();
            serverPacket.setData(packetOut.getData());
            serverSocket.send(serverPacket);
            //						mileStone.stamp("send done");

            answerSent = true;
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
    }
    /**
     * @see xtremweb.communications.CommHandler#close()
     */
    public void close() {
        info("UDPHandler#close() does nothing (this is normal)");
    }
    /**
     * This sends the object
     */
    protected void write(XMLable obj) throws IOException {
        try {
            packetOut.putObject(obj);
            send();
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }
    }
    /**
     * This writes a file to socket
     * @param f is the file to send
     */
    public void writeFile(File f) throws IOException {
        error("UDP does not implement writeFile");
        throw new IOException("UDP does not implement writeFile");
     }
    /**
     * This reads a file from socket
     * This is typically needed after a workRequest to get stdin and/or dirin files
     * @param f is the file to store received bytes
     */
    public void readFile(File f) throws IOException {
        error("UDP does not implement readFile");
        throw new IOException("UDP does not implement readFile");
    }

    /**
     * This is the main loop; this is called by java.lang.Thread#start()
     * This executes one command form communication channel and exists
     * @see CommHandler#run(XMLRPCCommand)
     */
    public void run() {

        try {
            packetOut.reset();
            answerSent = false;
            super.run(XMLRPCCommand.newCommand(packetIn.getString()));
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    } // run()
}
