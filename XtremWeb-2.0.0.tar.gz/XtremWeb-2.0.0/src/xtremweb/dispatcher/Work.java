package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.WorkInterface;
import xtremweb.common.XWStatus;
import xtremweb.common.XWAccessRights;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.security.AccessControlException;


/**
 * This class extends <CODE>TableRow</CODE>
 * This class encapsulates <CODE>WorkInterface</CODE>
 * This helps to access DB table works
 * 
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky </A>
 * @since v1r2-rc3 (RPC-V)
 */
public class Work extends TableRow {

    /**
     * This is the default constructor It creates a new object which is **not**
     * written in the database Save this object by explicitly calling <CODE>
     * update()</CODE>
     */
    public Work() {
        super("works");
        row = new WorkInterface();
        dirty = true;
        setWaiting();
        setArrivalDate(new java.util.Date());
        setActive(true);
    }

    /** 
     * This creates a new object which is written in the database;
     * @since RPCXW
     */
    public Work(WorkInterface itf) throws IOException{
        super ("works", itf);
        setWaiting();
        setArrivalDate(new java.util.Date());
        setActive(true);
        insert();
    }

    /**
     * This constructor instanciates an object from data read from an SQL table
     * @see xtremweb.common.WorkInterface#WorkInterface(ResultSet)
     */
    public Work(ResultSet rs) throws IOException {
        super("works");
        fill(rs);
    }

    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new WorkInterface(rs);
        dirty = true;
    }

    /**
     * This updates this object from interface.
     * <ul>
     * <li> session UID
     * <li> group UID
     * <li> expected host UID
     * <li> access rigths
     * <li> isservice
     * <li> isdeleted
     * <li> label
     * <li> app uid
     * <li> status
     * <li> return code
     * <li> command line
     * <li> stdin URI
     * <li> dirin URI
     * <li> result URI
     * <li> arrival date
     * <li> completeddate
     * <li> error msg
     * <li> send to lient 
     * <li> local
     * <li> active replicated
     * <li> max retry
     * <li> min memory
     * <li> min cpu speed
     * </ul>
     */
    public void updateInterface(WorkInterface itf) throws IOException {
        if(itf.getGroup() != null)
            setGroup(itf.getGroup());
        if(itf.getSession() != null)
            setSession(itf.getSession());
        if(itf.getExpectedHost() != null)
            setExpectedHost(itf.getExpectedHost());
        if(itf.getAccessRights() != null)
            setAccessRights(itf.getAccessRights());
        setService(itf.isService());
        setDeleted(itf.isDeleted());
        setSendToClient(itf.isSendToClient());
        setLocal(itf.isLocal());
        setReplicated(itf.isReplicated());
        setActive(itf.isActive());
        if(itf.getLabel() != null)
            setLabel(itf.getLabel());
        if(itf.getApplication() != null)
            setApplication(itf.getApplication());
        if(itf.getStatus() != null)
            setStatus(itf.getStatus());
        setReturnCode(itf.getReturnCode());
        if(itf.getCmdLine() != null)
            setCmdLine(itf.getCmdLine());
        if(itf.getStdin() != null)
            setStdin(itf.getStdin());
        if(itf.getDirin() != null)
            setDirin(itf.getDirin());
        if(itf.getResult() != null)
            setResult(itf.getResult());
        if(itf.getArrivalDate() != null)
            setArrivalDate(itf.getArrivalDate());
        if(itf.getCompletedDate() != null)
            setCompletedDate(itf.getCompletedDate());
        if(itf.getErrorMsg() != null)
            setErrorMsg(itf.getErrorMsg());
        setMaxRetry(itf.getMaxRetry());
        setMinMemory(itf.getMinMemory());
        setMinCpuSpeed(itf.getMinCpuSpeed());
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public UID getSession() throws IOException{
        return ((WorkInterface) row).getSession();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public UID getGroup() throws IOException{
        return ((WorkInterface) row).getGroup();
    }

    /**
     * This set the URI where to get stdin
     */
    public void setStdin(URI stdin) throws IOException{
        if (((WorkInterface) row).setStdin(stdin))
            dirty = true;
    }
    /**
     * This set the URI where to get dirin
     */
    public void setDirin(URI dirin) throws IOException{
        if (((WorkInterface) row).setDirin(dirin))
            dirty = true;
    }
    /**
     * This set the URI where to get result
     */
    public void setResult(URI result) throws IOException{
        if (((WorkInterface) row).setResult(result))
            dirty = true;
    }
    /**
     * This retreives the URI where to get the stdin
     * @return the stdin file UID
     */
    public URI getStdin() throws IOException{
        return ((WorkInterface) row).getStdin();
    }
    /**
     * This retreives the URI where to get the stdin
     * @return the dirin file UID
     */
    public URI getDirin() throws IOException{
        return ((WorkInterface) row).getDirin();
    }
    /**
     * This retreives the URI where to get the stdin
     * @return the result file UID
     */
    public URI getResult() throws IOException{
        return ((WorkInterface) row).getResult();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public UID getUID() throws IOException{
        return ((WorkInterface) row).getUID();
    }
    /**
     * This gets the access rights
     * @return the expected parameter
     */
    public XWAccessRights getAccessRights() throws IOException{
        return ((WorkInterface)row).getAccessRights();
    }
    /**
     * This gets the expected host UID
     * @return this host UID
     * @since RPCXW
     */
    public UID getExpectedHost() throws IOException{
        return ((WorkInterface) row).getExpectedHost();
    }

    /**
     * This gets this work application UID
     * @return the is work application UID
     */
    public UID getApplication() throws IOException{
        return ((WorkInterface) row).getApplication();
    }

    /**
     * This gets user UID
     * @return the expected parameter
     */
    public UID getUser() throws IOException{
        return ((WorkInterface) row).getUser();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public XWStatus getStatus() throws IOException{
        return ((WorkInterface) row).getStatus();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public int getReturnCode() {
        return ((WorkInterface) row).getReturnCode();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public int getMaxRetry() {
        return ((WorkInterface) row).getMaxRetry();
    }
    /**
     */
    public int getMinMemory() {
        return((WorkInterface)row).getMinMemory();
    }
    public int getMinCpuSpeed() {
        return((WorkInterface)row).getMinCpuSpeed();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public String getServer() {
        return ((WorkInterface) row).getServer();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public String getCmdLine() {
        return ((WorkInterface) row).getCmdLine();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public Date getArrivalDate() {
        return ((WorkInterface) row).getArrivalDate();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public Date getCompletedDate() {
        return ((WorkInterface) row).getCompletedDate();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public String getErrorMsg() {
        return ((WorkInterface) row).getErrorMsg();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public boolean isSendToClient() {
        return ((WorkInterface) row).isSendToClient();
    }

    /**
     * This gets parameter
     * @return the expected parameter
     */
    public boolean isActive() {
        return ((WorkInterface) row).isActive();
    }
    /**
     * This set the service flag; this flag is true if this works 
     * runs a service (and not an application)
     * @since RPCXW
     */
    public void setService(boolean v)  {
        if (((WorkInterface) row).setService(v))
            dirty = true;
    }
    /**
     * This set the deleted flag
     * @since 2.0.0
     */
    public void setDeleted(boolean v)  {
        if (((WorkInterface) row).setDeleted(v))
            dirty = true;
    }
    /**
     * This retreives the service flag
     * @return true is the work should execute a service, false otherwise
     * @since RPCXW
     */
    public boolean isService() {
        return ((WorkInterface) row).isService();
    }
    /**
     * This retreives the deleted flag
     * @return true if deleted, false otherwise
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return ((WorkInterface)row).isDeleted();
    }
    /**
     * This tells whether this work is waiting to be inserted in server works pool
     * @return true if this work is waiting
     * @since RPCXW
     */
    public boolean isWaiting() {
        try {
            return (getStatus() == XWStatus.WAITING);
        }
        catch(IOException e) {
            return false;
        }
    }

    public boolean isReplicated() {
        return ((WorkInterface) row).isReplicated();
    }

    public boolean isLocal() {
        return ((WorkInterface) row).isLocal();
    }
    /**
     * This sets the access rights
     */
    public void setAccessRights(XWAccessRights v) throws IOException{
        if (((WorkInterface) row).setAccessRights(v))
            dirty = true;
    }
    /**
     * This sets the expected worker UID
     * @param v is the new value to set the param to
     * @since RPCXW
     */
    public void setExpectedHost(UID v) {
        if (((WorkInterface) row).setExpectedHost(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setSession(UID v) {
        if (((WorkInterface) row).setSession(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setGroup(UID v) {
        if (((WorkInterface) row).setGroup(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setUID(UID v) {
        if (((WorkInterface) row).setUID(v))
            dirty = true;
    }

    /**
     * This sets this work application UID
     * @param v
     *            is the application UID
     */
    public void setApplication(UID v) {
        if (((WorkInterface) row).setApplication(v))
            dirty = true;
    }

    /**
     * This sets user UID
     * @param v is the new parameter value
     */
    public void setUser(UID v) {
        if (((WorkInterface) row).setUser(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    private void setStatus(XWStatus v) {
        if (((WorkInterface) row).setStatus(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setReturnCode(int v) {
        if (((WorkInterface) row).setReturnCode(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setMaxRetry(int v) {
        if (((WorkInterface) row).setMaxRetry(v))
            dirty = true;
    }
    public void setMinMemory(int v) {
        if(((WorkInterface)row).setMinMemory(v))
            dirty = true;
    }
    public void setMinCpuSpeed(int v) {
        if(((WorkInterface)row).setMinCpuSpeed(v))
            dirty = true;
    }

    /**
     * This marks this work as managed by provided server.
     * @param v is the name of the server managing this work
     * @see #setPending()
     */
    public void setServer(String v) {
        if(((WorkInterface)row).setServer(v))
            dirty = true;
        setPending();
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setCmdLine(String v) {
        if (((WorkInterface) row).setCmdLine(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setArrivalDate(Date v) {
        if (((WorkInterface)row).setArrivalDate(v))
            dirty = true;
    }


    /**
     * This marks this work as completed
     */
    public void setCompleted() {

        setStatus(XWStatus.COMPLETED);

        try {
            Date cDate = new Date();
            setCompletedDate(cDate);
            App theApp = DBInterface.instance.cache.app(getApplication());
            User theUser = DBInterface.instance.cache.user(getUser());
            int exectime = (int)(cDate.getTime() - getArrivalDate().getTime());
            theApp.incAvgExecTime(exectime);
            theUser.incNbJobs();
            DBInterface.instance.cache.update(theUser);
            DBInterface.instance.cache.update(theApp);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * This marks this work as not managed by server yet
     */
    public void setWaiting() {
        setArrivalDate(new java.util.Date());
        setStatus(XWStatus.WAITING);
        setActive(true);
        setLocal(true);
        setReplicated(false);
        setSendToClient(false);
    }

    /**
     * This tells whether this work is pending for computation
     * @return true if this work is pending
     * @since 2.0.0
     */
    public boolean isPending() {
        try {
            return (getStatus() == XWStatus.PENDING);
        }
        catch(IOException e) {
            return false;
        }
    }
    /**
     * This marks this work result as not available yet
     */
    public void setPending() {
        setStatus(XWStatus.PENDING);
        setActive(true);
        setLocal(true);
        setReplicated(false);
        setSendToClient(false);
    }

    /**
     * This marks this work as ERROR
     * @param v is the error msg, if any
     */
    public void setError(String v) {
        setStatus(XWStatus.ERROR);
        setErrorMsg(v);
    }
    /** 
     * This sets the task status as lost from worker.
     */
    public void setRunning() {
        setStatus(XWStatus.RUNNING);
    }

    /**
     * This marks this work result as not available
     */
    public void setUnavailable() {
        setStatus(XWStatus.UNAVAILABLE);
    }
    /**
     * This marks this work result as available
     * @since RPCXW
     */
    public void setAvailable() {
        setStatus(XWStatus.AVAILABLE);
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    private void setCompletedDate(Date v) {
        if (((WorkInterface) row).setCompletedDate(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setErrorMsg(String v) {
        if (((WorkInterface) row).setErrorMsg(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setSendToClient(boolean v) {
        if (((WorkInterface) row).setSendToClient(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setActive(boolean v) {
        if (((WorkInterface) row).setActive(v))
            dirty = true;
    }

    public void setReplicated(boolean v) {
        if (((WorkInterface) row).setReplicated(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setLocal(boolean v) {
        if (((WorkInterface) row).setLocal(v))
            dirty = true;
    }

    /**
     * This retreives the label
     * @return a String containing the label
     * @since RPCXW
     */
    public String getLabel() {
        return ((WorkInterface)row).getLabel();
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     */
    public void setLabel(String v) {
        if (((WorkInterface) row).setLabel(v))
            dirty = true;
    }
}
