package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.UserGroupInterface;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;


/**
 * This class extends <CODE>TableRow</CODE>
 * This class encapsulates <CODE>UserGroupInterface</CODE>
 * This helps to access DB table apps
 *
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky</A>
 * @since v1r2-rc3 (RPC-V)
 */
public class UserGroup extends TableRow {


    /** 
     * This creates a new object which is not written in DB
     * @since RPCXW
     */
    public UserGroup() {
        super ("usergroups");
    }

    /** 
     * This creates a new object which is written in DB;
     * @since RPCXW
     */
    public UserGroup(UserGroupInterface itf) throws IOException{
        super ("usergroups", itf);
        insert();
    }

    /** 
     * This constructor instanciates this object from data read from an SQL table
     * @see xtremweb.common.UserGroupInterface#UserGroupInterface(ResultSet)
     */
    public UserGroup (ResultSet rs) throws IOException {
        super ("usergroups");
        fill(rs);
    }

    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new UserGroupInterface (rs);
        dirty = false;
    }

    /**
     * This gets the UID
     * @return the UID
     */
    public UID getUID () throws IOException{
        return ((UserGroupInterface)row).getUID ();
    }
    /**
     * This gets the label
     * @return the label
     */
    public String getLabel () {
        return ((UserGroupInterface)row).getLabel ();
    }
    /**
     * This retreive the project flag
     * @return the project flag
     */
    public boolean isProject () {
        return ((UserGroupInterface)row).isProject ();
    }
    /**
     * This sets the UID
     * @param v is the new value to set the param to
     */
    public void setUID (UID v) {
        if (((UserGroupInterface)row).setUID (v))
            dirty = true;
    }
    /**
     * This sets the label
     * @param v is the new value to set the param to
     */
    public void setLabel (String v) {
        if (((UserGroupInterface)row).setLabel (v))
            dirty = true;
    }

    /**
     * This gets parameter
     * @return the expected parameter
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return ((UserGroupInterface) row).isDeleted();
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     * @since 2.0.0
     */
    public void setDeleted(boolean v) {
        if (((UserGroupInterface)row).setDeleted(v))
            dirty = true;
    }
}
