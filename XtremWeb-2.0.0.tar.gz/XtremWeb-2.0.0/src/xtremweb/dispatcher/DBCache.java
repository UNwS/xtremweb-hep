package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.Logger;
import xtremweb.common.LoggerLevel;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.io.IOException;
import java.util.*;


/**
 * This class manages database caches
 *
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky</A>
 * @since RPCXW
 */
public class DBCache extends Logger {

    /**
     * This is the apps table cache
     */
    protected TableCache apps;
    /**
     * This is the groups table cache
     */
    protected TableCache groups;
    /**
     * This is the hosts table cache
     */
    protected TableCache hosts;
    /**
     * This is the sessions table cache
     */
    protected TableCache sessions;
    /**
     * This is the tasks table cache
     */
    protected TableCache tasks;
    /**
     * This is the traces table cache
     */
    protected TableCache traces;
    /**
     * This is the users table cache
     */
    //    protected UsersCache users;
    protected TableCache users;
    /**
     * This is the usergroups table cache
     */
    protected TableCache usergroups;
    /**
     * This is the works table cache
     */
    protected TableCache works;
    /**
     * This is the datas table cache
     */
    protected TableCache datas;


    /**
     * This instanciates caches
     */
    public DBCache(LoggerLevel l) throws IOException{
        apps       = new TableCache("apps", "xtremweb.dispatcher.App", l);
        groups     = new TableCache("groups", "xtremweb.dispatcher.Group", l);
        hosts      = new TableCache("hosts", "xtremweb.dispatcher.Host", l);
        sessions   = new TableCache("sessions", "xtremweb.dispatcher.Session", l);
        tasks      = new TableCache("tasks", "xtremweb.dispatcher.Task", l);
        traces     = new TableCache("traces", "xtremweb.dispatcher.Trace", l);
        users      = new TableCache("users", "xtremweb.dispatcher.User", l);
        usergroups = new TableCache("usergroups", "xtremweb.dispatcher.UserGroup", l);
        works      = new TableCache("works", "xtremweb.dispatcher.Work", l);
        datas      = new TableCache("datas", "xtremweb.dispatcher.Data", l);

        user();
    }

    /**
     * This retreives an App
     * @param uid is the UID
     */ 
    public App app(UID uid) throws IOException {
        return (App)apps.select(uid);
    }
    /**
     * This retreives and caches all apps
     * @return the last loaded row
     */ 
    public App app() throws IOException {
        return (App)apps.select();
    }
    /**
     * This retreives and caches apps accordingly to conditions
     * @param conditions is the SQL query conditions
     * @return the last loaded row
     */ 
    public App app(String conditions) throws IOException {
        return (App)apps.select(conditions);
    }
    /**
     * This retreives enumeration of App stored UIDs
     * @return an enumeration of the App stored UIDs
     */
    public Enumeration apps() throws IOException {
        return apps.keys();
    }
    /**
     * This retreives the datas cache size
     */ 
    public int appSize() throws IOException {
        return apps.size();
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public App delete(App row) throws IOException {
        return deleteApp(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public Group delete(Group row) throws IOException {
        return deleteGroup(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public Host delete(Host row) throws IOException {
        return deleteHost(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public Session delete(Session row) throws IOException {
        return deleteSession(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public Task delete(Task row) throws IOException {
        return deleteTask(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public Trace delete(Trace row) throws IOException {
        return deleteTrace(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public User delete(User row) throws IOException {
        return deleteUser(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public UserGroup delete(UserGroup row) throws IOException {
        return deleteUserGroup(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public Work delete(Work row) throws IOException {
        return deleteWork(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param row is the row to delete
     * @return the deleted row
     */
    public Data delete(Data row) throws IOException {
        return deleteData(row.getUID());
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public App deleteApp(UID uid) throws IOException {
        return (App)apps.delete(uid);
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public Group deleteGroup(UID uid) throws IOException {
        return (Group)groups.delete(uid);
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public Host deleteHost(UID uid) throws IOException {
        return (Host)hosts.delete(uid);
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public Session deleteSession(UID uid) throws IOException {
        return (Session)sessions.delete(uid);
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public Task deleteTask(UID uid) throws IOException {
        return (Task)tasks.delete(uid);
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public Trace deleteTrace(UID uid) throws IOException {
        return (Trace)traces.delete(uid);
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the user uid
     * @return the deleted row
     */
    public User deleteUser(UID uid) throws IOException {
        return (User)users.delete(uid);
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public UserGroup deleteUserGroup(UID uid) throws IOException {
        return (UserGroup)usergroups.delete(uid);
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public Work deleteWork(UID uid) throws IOException {
        Work ret = (Work)works.delete(uid);
        return ret;
    }
    /**
     * This deletes a row from both cache and DB
     * @param uid is the row UID
     * @return the deleted row
     */
    public Data deleteData(UID uid) throws IOException {
        Data ret = (Data)datas.delete(uid);
        return ret;
    }
    /**
     * This caches an App
     * This does not write row in DB
     */ 
    public void put(App row) throws IOException {
        apps.put(row);
    }
    /**
     * This removes an App from cache
     * This does not remove row from DB
     * @param row is the row to remove
     * @return the removed row
     */
    public App remove(App row) throws IOException {
        return removeApp(row.getUID());
    }
    /**
     * This removes an App from cache
     * This does not remove row from DB
     * @param uid is the app uid
     * @return the removed row
     */
    public App removeApp(UID uid) throws IOException {
        return (App)apps.remove(uid);
    }
    /**
     * This updates an App in both cache and DB
     * @param row is the app uid
     */
    public void update(App row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }
    /**
     * This retreives and caches a Group
     * @param uid is the UID
     */ 
    public Group group(UID uid) throws IOException {
        return (Group)groups.select(uid);
    }
    /**
     * This retreives and caches all groups
     * @return the last loaded row
     */ 
    public Group group() throws IOException {
        return (Group)groups.select();
    }
    /**
     * This retreives a Group
     * @param conditions is the SQL query conditions
     * @return the last loaded row
     */ 
    public Group group(String conditions) throws IOException {
        return (Group)groups.select(conditions);
    }
    /**
     * This retreives enumeration of Group stored UIDs
     * @return an enumeration of the Group stored UIDs
     */
    public Enumeration groups() throws IOException {
        return groups.keys();
    }
    /**
     * This caches a Group
     * This does not write row in DB
     */ 
    public void put(Group row) throws IOException {
        groups.put(row);
    }
    /**
     * This removes a Group from cache
     * This does not remove row from DB
     * @param row is the row to remove
     * @return the removed row
     */
    public Group remove(Group row) throws IOException {
        return removeGroup(row.getUID());
    }
    /**
     * This removes a Group from cache
     * This does not remove row from DB
     * @param uid is the row UID
     * @return the removed row
     */
    public Group removeGroup(UID uid) throws IOException {
        return (Group)groups.remove(uid);
    }
    /**
     * This updates a Group in both cache and DB
     * @param row is the group uid
     */
    public void update(Group row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }
    /**
     * This retreives a Host
     * @param uid is the UID
     */ 
    public Host host(UID uid) throws IOException {
        return (Host)hosts.select(uid);
    }
    /**
     * This retreives and caches all hosts
     * @return the last loaded row
     */ 
    public Host host() throws IOException {
        return (Host)hosts.select();
    }
    /**
     * This retreives and caches a Host
     * @param conditions is the SQL query conditions
     * @return the last loaded row
     */ 
    public Host host(String conditions) throws IOException {
        return (Host)hosts.select(conditions);
    }
    /**
     * This retreives enumeration of Host stored UIDs
     * @return an enumeration of the Host stored UIDs
     */
    public Enumeration hosts() throws IOException {
        return hosts.keys();
    }
    /**
     * This caches a Host
     * This does not write row in DB
     */ 
    public void put(Host row) throws IOException {
        hosts.put(row);
    }
    /**
     * This removes a Host from cache
     * This does not remove row from DB
     * @param row is the row to remove
     * @return the removed row
     */
    public Host remove(Host row) throws IOException {
        return removeHost(row.getUID());
    }
    /**
     * This removes a Host from cache
     * This does not remove row from DB
     * @param uid is the row UID
     * @return the removed row
     */
    public Host removeHost(UID uid) throws IOException {
        return (Host)hosts.remove(uid);
    }
    /**
     * This updates a Host in both cache and DB
     * @param row is the host
     */
    public void update(Host row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }
    /**
     * This retreives a Session
     * @param uid is the UID
     */ 
    public Session session(UID uid) throws IOException {
        return (Session)sessions.select(uid);
    }
    /**
     * This retreives and caches all rows
     * @return the last loaded row
     */ 
    public Session session() throws IOException {
        return (Session)sessions.select();
    }
    /**
     * This retreives and caches a row
     * @param conditions is the SQL query conditions
     * @return the last loaded row
     */ 
    public Session session(String conditions) throws IOException {
        return (Session)sessions.select(conditions);
    }
    /**
     * This retreives enumeration of Session stored UIDs
     * @return an enumeration of the Session stored UIDs
     */
    public Enumeration sessions() throws IOException {
        return sessions.keys();
    }
    /**
     * This caches a Session
     * This does not write row in DB
     */ 
    public void put(Session row) throws IOException {
        sessions.put(row);
    }
    /**
     * This removes a Session from cache
     * This does not remove row from DB
     * @param row is the row to remove
     * @return the removed row
     */
    public Session remove(Session row) throws IOException {
        return removeSession(row.getUID());
    }
    /**
     * This removes a Host from cache
     * This does not remove row from DB
     * @param uid is the row UID
     * @return the removed row
     */
    public Session removeSession(UID uid) throws IOException {
        return (Session)sessions.remove(uid);
    }
    /**
     * This updates a Session in both cache and DB
     * @param row is the session
     */
    public void update(Session row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }
    /**
     * This retreives the host cache size
     */ 
    public int hostSize() throws IOException {
        return hosts.size();
    }
    /**
     * This retreives the task cache size
     */ 
    public int taskSize() throws IOException {
        return tasks.size();
    }
    /**
     * This retreives a Task
     * @param uid is the UID
     */ 
    public Task task(UID uid) throws IOException {
        return (Task)tasks.select(uid);
    }
    /**
     * This retreives and caches all rows
     * @return the last loaded row
     */ 
    public Task taask() throws IOException {
        return (Task)tasks.select();
    }
    /**
     * This retreives a Task
     * @param conditions is the SQL conditions
     * @return the last loaded row
     */ 
    public Task task(String conditions) throws IOException {
        return (Task)tasks.select(conditions);
    }
    /**
     * This retreives enumeration of Task stored UIDs
     * @return an enumeration of the Task stored UIDs
     */
    public Enumeration tasks() throws IOException {
        return tasks.keys();
    }
    /**
     * This caches a Task
     * This does not write row in DB
     */ 
    public void put(Task row) throws IOException {
        tasks.put(row);
    }
    /**
     * This removes a Task from cache
     * This does not remove row from DB
     * @param row is the row to remove
     * @return the removed row
     */
    public Task remove(Task row) throws IOException {
        return removeTask(row.getUID());
    }
    /**
     * This removes a Task from cache
     * This does not remove row from DB
     * @param uid is the task uid
     * @return the removed row
     */
    public Task removeTask(UID uid) throws IOException {
        return (Task)tasks.remove(uid);
    }
    /**
     * This updates a Task in both cache and DB
     * @param row is the task
     */
    public void update(Task row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }
    /**
     * This retreives a Trace
     * @param uid is the UID
     */ 
    public Trace trace(UID uid) throws IOException {
        return (Trace)traces.select(uid);
    }
    /**
     * This retreives and caches all rows
     * @return the last loaded row
     */ 
    public Trace trace() throws IOException {
        return (Trace)traces.select();
    }
    /**
     * This retreives a Trace
     * @param conditions is the SQL conditions
     * @return the last loaded row
     */ 
    public Trace trace(String conditions) throws IOException {
        return (Trace)traces.select(conditions);
    }
    /**
     * This retreives enumeration of Trace stored UIDs
     * @return an enumeration of the Trace stored UIDs
     */
    public Enumeration traces() throws IOException {
        return traces.keys();
    }
    /**
     * This caches a Trace
     * This does not write row in DB
     */ 
    public void put(Trace row) throws IOException {
        traces.put(row);
    }
    /**
     * This removes a Trace from cache
     * This does not remove row from DB
     * @param row is the row to remove
     * @return the removed row
     */
    public Trace remove(Trace row) throws IOException {
        return removeTrace(row.getUID());
    }
    /**
     * This removes a Trace from cache
     * This does not remove row from DB
     * @param uid is the trace uid
     * @return the removed row
     */
    public Trace removeTrace(UID uid) throws IOException {
        return (Trace)traces.remove(uid);
    }
    /**
     * This updates a Trace in both cache and DB
     * @param row is the trace
     */
    public void update(Trace row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }
    /**
     * This retreives a User
     * @param uid is the UID
     */ 
    public User user(UID uid) throws IOException {
        return (User)users.select(uid);
    }
    /**
     * This retreives a User by its login
     * @param key is the user login
     * @return the last loaded row
     */ 
    /*
    public User userByLogin(String key) throws IOException {
        return (User)users.selectByKey(key);
    }
    */
    /**
     * This retreives all Users
     * @return the last loaded row
     */ 
    public User user() throws IOException {
        return (User)users.select();
    }
    /**
     * This retreives a User
     * @param conditions is the SQL conditions
     * @return the last loaded row
     */ 
    public User user(String conditions) throws IOException {
        return (User)users.select(conditions);
    }
    /**
     * This retreives enumeration of User stored UIDs
     * @return an enumeration of the User stored UIDs
     */
    public Enumeration users() throws IOException {
        return users.keys();
    }
    /**
     * This retreives the users cache size
     */ 
    public int userSize() throws IOException {
        return users.size();
    }
    /**
     * This caches a User
     * This does not write row in DB
     */ 
    public void put(User row) throws IOException {
        users.put(row);
    }
    /**
     * This removes an User from cache
     * This does not remove row from DB
     * @param row is the row to remove
     * @return the removed row
     */
    public User remove(User row) throws IOException {
        return removeUser(row.getUID());
    }
    /**
     * This removes an App from cache
     * This does not remove row from DB
     * @param uid is the app uid
     * @return the removed row
     */
    public User removeUser(UID uid) throws IOException {
        return (User)users.remove(uid);
    }
    /**
     * This updates an User in both cache and DB
     * @param row is the user
     */
    public void update(User row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }
    /**
     * This retreives a UserGroup
     * @param uid is the UID
     */ 
    public UserGroup usergroup(UID uid) throws IOException {
        return (UserGroup)usergroups.select(uid);
    }
    /**
     * This retreives all rows
     * @return the last loaded row
     */ 
    public UserGroup usergroup() throws IOException {
        return (UserGroup)usergroups.select();
    }
    /**
     * This retreives a UserGroup
     * @param conditions is the SQL conditions
     * @return the last loaded row
     */ 
    public UserGroup usergroup(String conditions) throws IOException {
        return (UserGroup)usergroups.select(conditions);
    }
    /**
     * This retreives enumeration of UserGroup stored UIDs
     * @return an enumeration of the UserGroup stored UIDs
     */
    public Enumeration usergroups() throws IOException {
        return usergroups.keys();
    }
    /**
     * This caches a UserGroup
     * This does not write row in DB
     */ 
    public void put(UserGroup row) throws IOException {
        usergroups.put(row);
    }
    /**
     * This removes an Usergroup from cache
     * This does not remove row from DB
     * @param row is the row to remove
     * @return the removed row
     */
    public UserGroup remove(UserGroup row) throws IOException {
        return removeUserGroup(row.getUID());
    }
    /**
     * This removes an Usergroup from cache
     * This does not remove row from DB
     * @param uid is the usergroup uid
     * @return the removed row
     */
    public UserGroup removeUserGroup(UID uid) throws IOException {
        return (UserGroup)usergroups.remove(uid);
    }
    /**
     * This updates a UserGroup in both cache and DB
     * @param row is the usergroups
     */
    public void update(UserGroup row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }
    /**
     * This retreives a Work
     * @param uid is the UID
     * @return the last loaded row
     */ 
    public Work work(UID uid) throws IOException {
        return (Work)works.select(uid);
    }
    /**
     * This retreives all rows
     * @return the last loaded row
     */ 
    public Work work() throws IOException {
        return (Work)works.select();
    }
    /**
     * This retreives a row
     * @param conditions is the SQL conditions
     * @return the last loaded row
     */ 
    public Work work(String conditions) throws IOException {
        return (Work)works.select(conditions);
    }

    /**
     * This retreives enumeration of Work stored UIDs
     * @return an enumeration of the Work stored UIDs
     */
    public Enumeration works() throws IOException {
        return works.keys();
    }
    /**
     * This retreives the works cache size
     */ 
    public int workSize() throws IOException {
        return works.size();
    }
    /**
     * This caches a Work
     * This does not write row in DB
     */ 
    public void put(Work row) throws IOException {
        works.put(row);
    }
    /**
     * This removes a Work from cache
     * This does not remove row from DB
     * @param row is the Work to remove
     * @return the removed row
     */
    public Work remove(Work row) throws IOException {
        return removeWork(row.getUID());
    }
    /**
     * This removes a Work from cache
     * This does not remove row from DB
     * @param uid is the UID of the Work to remove
     * @return the removed row
     */
    public Work removeWork(UID uid) throws IOException {
        return (Work)works.remove(uid);
    }
    /**
     * This updates a Work in both cache and DB
     * @param row is the work
     */
    public void update(Work row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }

    /**
     * This retreives a Data
     * @param uid is the UID
     * @return the last loaded row
     */ 
    public Data data(UID uid) throws IOException {
        return (Data)datas.select(uid);
    }
    /**
     * This retreives all rows
     * @return the last loaded row
     */ 
    public Data data() throws IOException {
        return (Data)datas.select();
    }
    /**
     * This retreives a row
     * @param conditions is the SQL conditions
     * @return the last loaded row
     */ 
    public Data data(String conditions) throws IOException {
        return (Data)datas.select(conditions);
    }

    /**
     * This retreives enumeration of Data stored UIDs
     * @return an enumeration of the Data stored UIDs
     */
    public Enumeration datas() throws IOException {
        return datas.keys();
    }
    /**
     * This retreives the datas cache size
     */ 
    public int dataSize() throws IOException {
        return datas.size();
    }
    /**
     * This caches a Data
     * This does not write row in DB
     */ 
    public void put(Data row) throws IOException {
        datas.put(row);
    }
    /**
     * This removes a Data from cache
     * This does not remove row from DB
     * @param row is the Data to remove
     * @return the removed row
     */
    public Data remove(Data row) throws IOException {
        return removeData(row.getUID());
    }
    /**
     * This removes a Data from cache
     * This does not remove row from DB
     * @param uid is the UID of the Data to remove
     * @return the removed row
     */
    public Data removeData(UID uid) throws IOException {
        return (Data)datas.remove(uid);
    }
    /**
     * This updates a Data in both cache and DB
     * @param row is the data
     */
    public void update(Data row) throws IOException {
        remove(row);
        row.update();
        put(row);
    }

} // class DBCache
