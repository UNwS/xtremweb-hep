package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.GroupInterface;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;


/**
 * This class extends <CODE>TableRow</CODE>
 * This class encapsulates <CODE>GroupInterface</CODE>
 * This helps to access DB table apps
 *
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky</A>
 * @since v1r2-rc3 (RPC-V)
 */
public class Group extends TableRow {

   /** 
     * This is the default constructor.<br />
     * This creates a new object which is **not** written in the database;
     * save this object by explicitly calling <CODE>insert()</CODE>
     * @see TableRow#insert()
     */
    public Group() {
        super ("groups");
        row = new GroupInterface ();
        dirty = true;
    }
    /** 
     * This creates a new object which is written in the database;
     * @since RPCXW
     */
    public Group (GroupInterface itf) throws IOException{
        super ("groups", itf);
        insert();
    }
    /** 
     * This constructor instanciates this object from data read from an SQL table
     */
    public Group (ResultSet rs) throws IOException {
        super ("groups");
        fill(rs);
    }
    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new GroupInterface (rs);
        dirty = false;
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getUID () throws IOException{
        return ((GroupInterface)row).getUID ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getName () {
        return ((GroupInterface)row).getName ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getSession () throws IOException{
        return ((GroupInterface)row).getSession ();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getClient () throws IOException{
        return ((GroupInterface)row).getClient ();
    }
    /**
     * This gets parameter
     * @return the expected parameter
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return ((GroupInterface) row).isDeleted();
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setUID (UID v) {
        if (((GroupInterface)row).setUID (v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setName (String v) {
        if (((GroupInterface)row).setName (v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setClient (UID v) {
        if (((GroupInterface)row).setClient (v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setSession (UID v) {
        if (((GroupInterface)row).setSession (v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     * @since 2.0.0
     */
    public void setDeleted(boolean v) {
        if (((GroupInterface)row).setDeleted(v))
            dirty = true;
    }
}
