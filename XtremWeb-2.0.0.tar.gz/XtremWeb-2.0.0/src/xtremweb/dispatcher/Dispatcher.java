package xtremweb.dispatcher;

import xtremweb.common.Logger;
import xtremweb.common.LoggerLevel;
import xtremweb.common.XWRole;
import xtremweb.common.XWReturnCode;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.CommandLineParser;
import xtremweb.common.CommandLineOptions;
import xtremweb.common.XWConfigurator;
import xtremweb.common.util;
import xtremweb.common.CommonVersion;
import xtremweb.dispatcher.RM.*;
import xtremweb.communications.HTTPServer;
import xtremweb.communications.TCPServer;
import xtremweb.communications.UDPServer;

import java.util.Vector;
import java.util.Timer;
import java.util.Date;


/**
 * Dispatcher Implementation
 * The Dispatcher is responsible for delivering task to servers
 * @author V. Neri, G. Fedak
 */

/**
 * The <CODE>Dispatcher</CODE> is the XtremWeb Dispatcher main class.
 */

public class Dispatcher extends Logger {

    /**
     * The TaskSet and TaskManager
     */
    public static TaskSet tset ;

    // Database Interface
    public static DBInterface db;

    /** Scheduling policy */
    public static Scheduler sched ;

    /** Internal database of todo work, on disk */
    public static Pool tpool ;

    /** Timer */
    public static Timer timer;

    /* Event recording and analysing, NYI */
    // public TaskStats tstats ;


    /**
     * This stores and tests the command line parameters
     */
    private CommandLineParser args;
    /** 
     * Config as read from config file
     */
    public static XWConfigurator config;
		
    /**
     * This is the default constructor
     */
    public Dispatcher(String argv[]) {

        try {
            args = new CommandLineParser(argv);
        }
        catch(Exception e){
            util.fatal("Command line error " + e);
        }

        XWRole.setDispatcher();

        // Setting some initialisation value
        //        config = new Config();
        //        config.initConfig(argv);
        try {
            config = (XWConfigurator)args.getOption(CommandLineOptions.CONFIG);
        }
        catch(Exception e) {
            util.fatal("can retreive config file");
        }
        level = config.getLoggerLevel();
    }


    /**
     * Main function
     */
    public static void main(String args[]) {

        try {
            new Dispatcher(args).go();
        }
        catch(Exception e){
            System.err.println(e.toString());
        }
    }

    /**
     * Main function
     */
    public void go() throws Exception{

        // create a Timer running as a daemon thread
        timer = new Timer();

        // Database access
        db = new DBInterface(level);

        // Create a Pool of work to do by reading the disk
        tpool = new Pool();

        // create the upgrade manager
        /*
          logger.error("incorrect get worker bin!!!!");
          String workerDir = db.getBinDir(new UID());
          if(workerDir != null) {
          upgradeHelper = new UpgradeHelper(workerDir);
          upgradeHelper.rebuildArchiveMap();
          logger.info("upgrade enabled");
          }
          else
        */
	    warn("upgrade disabled since no worker bin found in DB :(");
        
        // Create a list of tasks ready to be computed

        tset = new HashTaskSet(tpool, level);
        // Create a Scheduler
        //        sched = new SimpleScheduler((HashTaskSet) tset);
        //				sched = Class.forName(config.schedulerName);
        //        sched.newInstance((HashTaskSet)tset);
        // RPCXW
        sched = new MatchingScheduler((HashTaskSet) tset);
        tset.start();
        try {
            while(tset.isReady() == false ) {
                Thread.sleep(1000);
                info("still waiting task set...");
            }
        }
        catch(Exception e) {
            error("exception while waiting task set...");
        }

        // Creating communications layers
        try {
            // This opens TCP communication
            TCPServer tcpServer = new TCPServer(level);
            tcpServer.initComm(config,
                               new TCPHandler(level,
                                              config));
            tcpServer.start();

            // This opens UDP communication
            UDPServer udpServer = new UDPServer(level);
            udpServer.initComm(config,
                               new UDPHandler(level,
                                              config));
            udpServer.start();

            if(config.http() == true) {
                // This opens HTTP communication
                HTTPServer httpServer = new HTTPServer(level);
                httpServer.initComm(config,
                                    new HTTPHandler(level,
                                                config));
                httpServer.start();
            }
        }
        catch(Exception e) {
            util.fatal("Dispatcher main(): " +  e);
        }

        // if it happens to appear in remove it
        // 				new ModuleLoader();
        // 				try {
        // 						ModuleLoader.addCallback( "servreg" );
        // 				} catch(ModuleLoaderException e) {
        // 						logger.warn("Dispatcher main(): " +  e);
        // 				}
        // 				try {
        // 						ModuleLoader.addHandler( "servreg", "RMI", Config.instance.getRMIRegistryPort());
        // 				} catch(ModuleLoaderException e) {
        // 						logger.warn("Dispatcher main(): " +  e);
        // 				}

        // 				try {
        // 						ModuleLoader.addCallback( "timeserv" );
        // 				} catch(ModuleLoaderException e) {
        // 						logger.warn("Dispatcher main(): " +  e);
        // 				}
        // 				try {
        // 						ModuleLoader.addHandler( "timeserv", "RMI", Config.instance.getRMIRegistryPort());
        // 				} catch(ModuleLoaderException e) {
        // 						logger.warn("Dispatcher main(): " +  e);
        // 				}
	
        // 				try {
        // 						Callbackservreg srvreg = 
        // 								(Callbackservreg)ModuleLoader.getModule("servreg");
        // 						xtremweb.servreg.ServiceRegistry sr = srvreg.sr;
        // 						InetAddress myIP= InetAddress.getLocalHost();
        // 						sr.registerServices( "mpi", sr.getUID(), myIP, Config.instance.getRMIRegistryPort());
        // 						sr.unRegisterServer(  sr.getUID());
        // 				} catch(ModuleLoaderException e) {
        // 						logger.warn("Dispatcher::main() " +  e);
        // 				} catch(UnknownHostException e) {
        // 						logger.warn("Can't guess my own ip");
        // 				}
	
        // RPCXW : insert services
        Vector services = util.split(config.getProperty(XWPropertyDefs.SERVICES.toString()));
        if(services != null) {
            for(int i = 0; i < services.size(); i++) {
                try {
                    System.out.println(services.elementAt(i).toString());
                    db.insertService(services.elementAt(i).toString());
                }
                catch(Exception e) {
                    warn("Unable to start service : " +  e);
                }
                db.updateAppsPool();
            }
        }


        // All is ok now
        System.out.println("XWHEP Dispatcher(" +
                           CommonVersion.getCurrent().full() +
                           ") started [" + new Date() + "]");
        System.out.println("DB vendor  = " + 
                           config.getProperty(XWPropertyDefs.DBVENDOR.toString()));
        System.out.println("mileStone  = " + 
                           config.getProperty(XWPropertyDefs.MILESTONES.toString()));
        System.out.println("Time out   = " + 
                           config.getProperty(XWPropertyDefs.TIMEOUT.toString()));
        System.out.println("Disk opt'd = " + 
                           config.getProperty(XWPropertyDefs.OPTIMIZEDISK.toString()));
        System.out.println("Net  opt'd = " +
                           config.getProperty(XWPropertyDefs.OPTIMIZENET.toString()));
        System.out.println("NIO        = " +
                           config.getProperty(XWPropertyDefs.NIO.toString()));
        config.dump(System.out, "XWHEP Dispatcher started ");
    }

    public static void shutdown() {
        db.unlockWorks(util.getLocalHostName());
        System.exit(XWReturnCode.SUCCESS.ordinal());
    }


    public void finalize() {
        db.unlockWorks(util.getLocalHostName());
    }


}
