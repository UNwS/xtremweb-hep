package xtremweb.dispatcher;

import xtremweb.common.UID;
import xtremweb.common.SessionInterface;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;


/**
 * This class extends <CODE>TableRow</CODE>
 * This class encapsulates <CODE>SessionInterface</CODE>
 * This helps to access DB table apps
 *
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky</A>
 * @since v1r2-rc3(RPC-V)
 */
public class Session extends TableRow {

    /** 
     * This is the default constructor.<br />
     * This creates a new object which is **not** written in the database;
     * save this object by explicitly calling <CODE>update()</CODE>
     * @see TableRow#insert()
     */
    public Session() {
        super("sessions");
        row = new SessionInterface();
        dirty = true;
    }
    /** 
     * This creates a new object which is written in the database;
     * @since RPCXW
     */
    public Session(SessionInterface itf) throws IOException {
        super("sessions", itf);
        insert();
    }
    /** 
     * This constructor instanciates this object from data read from an SQL table
     * @see xtremweb.common.SessionInterface#SessionInterface(ResultSet)
     */
    public Session(ResultSet rs) throws IOException {
        super("sessions");
        fill(rs);
    }
    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new SessionInterface(rs);
        dirty = false;
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getUID() throws IOException{
        return((SessionInterface)row).getUID();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getName() {
        return((SessionInterface)row).getName();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getClient() throws IOException{
        return((SessionInterface)row).getClient();
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setClient(UID v) {
        if(((SessionInterface)row).setClient(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setName(String v) {
        if(((SessionInterface)row).setName(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setUID(UID v) {
        if(((SessionInterface)row).setUID(v))
            dirty = true;
    }
    /**
     * This gets parameter
     * @return the expected parameter
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return ((SessionInterface) row).isDeleted();
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     * @since 2.0.0
     */
    public void setDeleted(boolean v) {
        if (((SessionInterface)row).setDeleted(v))
            dirty = true;
    }
}
