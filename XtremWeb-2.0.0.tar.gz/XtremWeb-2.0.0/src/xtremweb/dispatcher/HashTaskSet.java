package xtremweb.dispatcher;

import xtremweb.common.LoggerLevel;
import xtremweb.common.util;
import xtremweb.common.UID;
import xtremweb.common.XWStatus;
import xtremweb.common.TaskInterface;
import xtremweb.common.XWPropertyDefs;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Date;
import java.util.Enumeration;
import java.io.IOException;


/**
 * HashTaskSet.java
 *
 * Created: Wed Aug 23 14:17:05 2000
 *
 * @author Gilles Fedak
 * @version %I% %G%
 */

public class HashTaskSet extends TaskSet {

    private Pool tpool;
    private final int GRAND_MAX_TASK = 10000 ;
    public int MAX_TASK ;

    /**
     * This an iterator
     */
    private Enumeration taskEnumeration;

    public HashTaskSet(Pool p, LoggerLevel l) {
        super(l);

        tpool = p;
        //				MAX_TASK = Context.getMaxTask();
        MAX_TASK = 10000; //To make tests as long as this value is not configurable with the file

        taskEnumeration = null;
    }


    private  boolean refill_unitary() {

        Work theWork = tpool.getWork(util.getLocalHostName());
	
        if(theWork == null)
            return false;
	
        Task theTask = null;
        try {
            if(DBInterface.instance.cache.task(theWork.getUID()) == null) {
                theTask = new Task(theWork);
                DBInterface.instance.cache.put(theTask);
            }
        }
        catch(Exception e) {
            error("refill : can't update work " + e);
            e.printStackTrace();
        }

        return true;
    }


    private  void scheduleLost(UID key) {

        try {
            Task theTask = getTaskByUid(key);
	
            if(theTask.isLost()) {
                theTask.reset();
                theTask.update();
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            error("scheduleLost: can't update task");
        }
    }

    /**
     * This completes the task set if there is available place
     */
    protected void refill() {

        try {
            int size = DBInterface.instance.cache.taskSize();

            while(isReady() &&(size < MAX_TASK)) {
                if(!refill_unitary()) {
                    break;
                }
            }

            // scan the bag for lost task

            UID uid = null;
            Enumeration enumeration = DBInterface.instance.cache.tasks();
            for(; enumeration.hasMoreElements();) {
                uid = new UID((String)enumeration.nextElement());
                scheduleLost(uid);
            }
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }

    }


    /**
     * This checks whether task is lost.
     * This detects lost jobs and sets their status back to pending to give a chance of rescheduling.
     * A job is lost after 3 alive periods whithout heart beat signal from worker
     */
    private  void detectAbortedTasks_unitary(UID uid) {

        try {
            Task theTask = getTaskByUid(uid);

            if((theTask == null) ||(theTask.getLastAlive() == null))
                return;

            int delay =(int)(System.currentTimeMillis() - theTask.getLastAlive().getTime());

            //System.err.println("delay    = " + delay + "    task.lastAlive = "
            //+ theTask.getLastAlive().getTime());
            //System.err.println("maxdelay = " + Context.getAliveTimeout());

            //if(theTask.isRunning())
            //System.err.println("task running");
            //else
            //System.err.println("task not running");
            //if(delay > Context.getAliveTimeout())
            //System.err.println(delay + " > " + Context.getAliveTimeout());
            //else
            //System.err.println("delay no reached");

            int aliveTimeOut = 
                Integer.parseInt(Dispatcher.config.
                                 getProperty(XWPropertyDefs.
                                             ALIVETIMEOUT.toString()));
            aliveTimeOut *= 1000;

            if(theTask.isRunning() && (delay > aliveTimeOut)) {

                //System.err.println("task " + uid + " lost");

                //31/01
                //theTask.setLost();
                theTask.incTrial();
                theTask.setPending();
                theTask.update();


                Work work = DBInterface.instance.cache.work(uid);
                if(work != null) {
                    work.setServer(util.getLocalHostName());
                    work.update();
                }

                if(theTask.getHost() != null) {
                    Host host = DBInterface.instance.cache.host(theTask.getHost());
                    if(host != null) {
                        host.setLastAlive(new Date());
                        host.update();
                    }
                }
            }
            // 						else
            // 								System.err.println("task " + uid + " not lost");
        }
        catch(Exception e) {
            error("detecAbortedTasks_unitary : can't set tasks lost " + e);
            e.printStackTrace();
        }

    }


    /**
     * This checks all tasks to detect lost ones
     * @see #detectAbortedTasks_unitary(UID)
     */
    protected void detectAbortedTasks() {

        try {
            Enumeration enumeration = DBInterface.instance.cache.tasks();
            for(; enumeration.hasMoreElements();) {
                detectAbortedTasks_unitary(new UID((String)enumeration.nextElement()));
            }
        }
        catch(Exception e){
            error(e.toString());
            e.printStackTrace();
        }	
    }


    /**
     * Verify is the task is completed. If it is remove it and return true
     * @return true if the task was completed
     */

    private  boolean freeCompletedTasks_unitary(UID uid) {

        boolean result = false;

        try {
            Task theTask = getTaskByUid(uid);
	
            if(theTask.isCompleted() || theTask.isError()) {
	    
                theTask.remove();
                theTask.update();
                result = true;
            }
        }
        catch(Exception e ) {
            error("freeCompletedTask(),  " + e);
            e.printStackTrace();
        }

        return result;
    }

    /**
     * This removes completed task from cache
     */
    protected void freeCompletedTasks() {

        try {
            Enumeration enumeration = DBInterface.instance.cache.tasks();
            for(; enumeration.hasMoreElements();) {
                UID uid = new UID((String)enumeration.nextElement());
                if(freeCompletedTasks_unitary(uid))
                    DBInterface.instance.cache.removeTask(uid);
            }
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }

    } // freeCompletedTasks()


    /**
     * This retreives a task from cache and test whether it is waiting for a computing resource
     * @param taskUID is the task UID
     * @param acceptBin tells whether worker accepts binary; if false this looks for service tasks only
     * @return the task if it is waiting for a comuting resource; null otherwise
     */
    private Task getWaitingTask(UID taskUID, boolean acceptBin) {

        try {
            Task theTask = getTaskByUid(taskUID);
            Work theWork = getWorkByUid(taskUID);

	    info("getWaitingTask(" + taskUID + ", " + acceptBin+ ") " + theTask.getStatus() + " " + theWork.isService());
            if(theTask.isPending())
                if((acceptBin) || (theWork.isService()))
                    return theTask;

	    info("getWaitingTask(" + taskUID + ", " + acceptBin+ ") returns null");
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }

        return null;
    }


    /**
     * This retreives the first waiting task.
     * This resets taskEnumeration attribute and return its first element
     * @see #getWaitingTask(UID, boolean)
     * @see #taskEnumeration
     */
    private Task getFirstWaitingTask(boolean acceptBin) {

        try {
	    info("getFirstWaitingTask(" + acceptBin+ ")");
            taskEnumeration = DBInterface.instance.cache.tasks();
            if(taskEnumeration.hasMoreElements()) {
                return getWaitingTask(new UID((String)taskEnumeration.nextElement()),
                                      acceptBin);
            }

	    info("getFirstWaitingTask(" + acceptBin + ") returns null");
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }
        return null;
    }


    /**
     * This retreives the first waiting task.
     * This resets taskEnumeration attribute and return its first element
     * @see #getWaitingTask(UID, boolean)
     * @see #taskEnumeration
     */
    public Task getNextWaitingTask(boolean acceptBin) {

        try {
	    info("getNextWaitingTask(" + acceptBin + ")");
            if((taskEnumeration == null) || (taskEnumeration.hasMoreElements() == false))
                return getFirstWaitingTask(acceptBin);

            return getWaitingTask(new UID((String)taskEnumeration.nextElement()),
                                  acceptBin);
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }

	info("getNextWaitingTask(" + acceptBin + ") returns null");
        return null;
    }


    /**
     * This retreives a task from cache and test whether it is waiting for the provided computing resource
     * @param hostUID is the worker UID to retreive a task for
     * @param acceptBin tells whether worker accepts binary, if false this looks for services tasks only
     * @return the task if it is waiting for the provided comuting resource; null otherwise
     */
    private Task getWaitingTask(UID taskUID, UID hostUID, boolean acceptBin) {

        try {
	    info("getWaitingTask(" + taskUID + ", " + hostUID + ", " + acceptBin + ")");

            Task theTask = getTaskByUid(taskUID);
            Work theWork = getWorkByUid(taskUID);

            UID expectedHost = theWork.getExpectedHost();
            boolean expectedTest = true;

            if(expectedHost != null)
                expectedTest = expectedHost.equals(hostUID);

            if(theTask.isPending() && (expectedTest)) {
                if((acceptBin) || (theWork.isService()))
                    return theTask;
            }
	    info("getWaitingTask(" + taskUID + ", " + hostUID + ", " + acceptBin + ") returns null");
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }

        return null;
    }


    /**
     * This retreives the next waiting task for the given worker
     * @param hostUID is the worker UID to retreive a task for
     * @param acceptBin tells whether worker accepts binary, if false this looks for services tasks only
     * @return the next waiting task.
     * @since RPCXW
     */
    private Task getFirstWaitingTask(UID hostUID, boolean acceptBin) {

        try {
	    info("getFirstWaitingTask(" + hostUID + ", " + acceptBin + ")");

            taskEnumeration = DBInterface.instance.cache.tasks();
            if(taskEnumeration.hasMoreElements())
                return getWaitingTask(new UID((String)taskEnumeration.nextElement()),
                                      hostUID, acceptBin);

	    info("getFirstWaitingTask(" + hostUID + ", " + acceptBin + ") returns null");
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }

        return null;
    }


    /**
     * This retreives the next waiting task for the given worker
     * @param hostUID is the worker UID to retreive a task for
     * @param acceptBin tells whether worker accepts binary, if false this looks for services tasks only
     * @return the next waiting task.
     * @since RPCXW
     */
    public Task getNextWaitingTask(UID hostUID, boolean acceptBin) {

        try {
	    info("getNextWaitingTask(" + hostUID + ", " + acceptBin + ")");
            if((taskEnumeration == null) || (taskEnumeration.hasMoreElements() == false))
                return getFirstWaitingTask(hostUID, acceptBin);

            return getWaitingTask(new UID((String)taskEnumeration.nextElement()),
                                  hostUID, acceptBin);
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }

	info("getNextWaitingTask(" + hostUID + ", " + acceptBin + ") returns null");
        return null;
    }

    /**
     * This retreives a task from its UID
     * @param   uid is the task UID
     * @return  the found Task, or null if task is not found
     */
    protected Task getTaskByUid(UID uid) {
        try {
            return DBInterface.instance.cache.task(uid);
        }
        catch(Exception e){
            // 31/01
            debug("getTaskByUid " + e);
            return null;
        }
    }
    /**
     * This retreives a work from its UID
     * @param   uid is the task UID
     * @return  the found Task, or null if task is not found
     */
    protected Work getWorkByUid(UID uid) {
        try {
            return DBInterface.instance.cache.work(uid);
        }
        catch(Exception e){
            // 31/01
            debug("getWorkByUid " + e);
            return null;
        }
    }


    /**
     * This retreives a running task thanks to its UID
     * @param   uid is the task UID
     * @return  the found Task, or null if task is nor found neither running
     */
    public Task getRunningByID(UID uid) {

        Task task = getTaskByUid(uid);
        if(task == null)
            return null;

        try {
            if(!task.isRunning())
                task = null;
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }

        return task;
    }


    /**
     * This retreives result for the given worker
     * @see TaskSet#getHostDatas(UID, int)
     */
    protected Vector getHostDatas(UID hostUID, XWStatus dataStatus) {

        int i;
        Vector ret = new Vector();
        try {

            DBInterface.instance.cache.task("" + TaskInterface.Columns.HOSTUID + "='" + hostUID + "'");

            Enumeration enumeration = DBInterface.instance.cache.tasks();
            for(; enumeration.hasMoreElements();) {

                UID uid = new UID((String)enumeration.nextElement());
                Task theTask = getTaskByUid(uid);

                UID task_host = theTask.getHost();
                if((task_host == null) || (task_host.equals(hostUID) == false))
                    continue;

		Work theTaskWork = DBInterface.instance.cache.work(uid);
                if(theTaskWork == null)
                    continue;
		if(theTaskWork.getResult() == null)
		    continue;
		Data theWorkResult = DBInterface.instance.cache.data(theTaskWork.getResult().getUID());
                if(theWorkResult == null)
                    continue;

                if(task_host.equals(hostUID) && (theWorkResult.testStatus(dataStatus))) {
		    info("getHostDatas(" + hostUID + ", " + dataStatus  +
			 ") add = " + theTask.getUID());
                    ret.add(theTask);
                }
		else
		    info("getHostDatas(" + hostUID + ", " + dataStatus  +
			 ") bypass = " + theTask.getUID());
            }
        }
        catch(Exception e) {
            error(e.toString());
            e.printStackTrace();
        }

        return ret;
    }    

    /**
     * This retreives datas saved for the specified worker.
     */
    public Vector getSavedByHost(UID hostUID) {

	Vector ret = getHostDatas(hostUID, XWStatus.AVAILABLE);
        return ret;
    }    

    /**
     * This retreives erroneus tasks, including due to server side error
     *(can not store result file, replicat error etc.) 
     * This replaces getServerError(String host)
     * @param host is the host UID where the task has been run.
     * @return a vector of tasks.
     * @since 1.3.12
     */
    public Vector getErroneus(UID host) {

        return getHostDatas(host, XWStatus.ERROR);
    }


    /**
     * This retreives tasks which results are expected from the specified worker.
     * @see TaskSet#getSavedByHost(UID)
     */
    public Vector askDatasFromHost(UID hostUID) {

        Vector ret = getHostDatas(hostUID, XWStatus.DATAREQUEST);
        return ret;
    }    

    /**
     * This converts this object to string
     */
    public String toString() {

        try {
            String s = "";
            Enumeration enumeration = DBInterface.instance.cache.tasks();
            for(; enumeration.hasMoreElements();) {

                UID uid = new UID((String)enumeration.nextElement());
                Task theTask = getTaskByUid(uid);
                s += theTask.toString() + "\n";
            }
            return s;
        }
        catch(Exception e) {
            return null;
        }
    }

} // HashTaskSet
