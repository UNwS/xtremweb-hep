package xtremweb.dispatcher;

import xtremweb.common.AppInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.XWAccessRights;
import xtremweb.common.UserRights;
import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.XWCPUs;
import xtremweb.common.XWOSes;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.security.AccessControlException;


/**
 * This class extends <CODE>TableRow</CODE>
 * This class encapsulates <CODE>AppInterface</CODE>
 * This helps to access DB table apps
 *
 * @author <A HREF="mailto:lodygens /at\ lal.in2p3.fr">Oleg Lodygensky</A>
 * @since v1r2-rc3(RPC-V)
 */
public class App extends TableRow {


    /** 
     * This is the default constructor
     * It creates a new object which is **not** written in the database
     * Save this object by explicitly calling <CODE>insert()</CODE>
     * @see TableRow#insert()
     */
    public App() {
        super("apps");
        row = new AppInterface();
        dirty = true;
    }

    /** 
     * This creates a new object which is written in the database;
     * @since RPCXW
     */
    public App(AppInterface itf) throws IOException{
        super("apps", itf);
        insert();
    }

    /** 
     * This constructor instanciates this object from data read from an SQL table
     * @see xtremweb.common.TableInterface
     */
    public App(ResultSet rs) throws IOException {
        super("apps");
        fill(rs);
    }

    /**
     * This fills this object with datas from DB
     * @param rs is a ResultSet read from DB
     */
    public void fill(ResultSet rs) throws IOException{
        row = new AppInterface(rs);
        dirty = false;
    }
    /**
     * This change name to "DEL@" + uid + "_" + name + "@DEL" and set ISDELETED flag to TRUE
     * Because name is a DB constraint and one may want to insert and delete
     * and then reinsert an app with the same name.
     * And delete does not remove row from DB : it simply set ISDELETED flag to true
     */
    public synchronized void delete() throws IOException {

        try {
            setName("DEL@" + getUID() + "_" + getName() + "@DEL");
            String criteria = row.criterias();
            if (criteria == null)
                throw new IOException("unable to get delete criteria");

            String query = deleteQueryHeader() + " SET " + 
                TableInterface.DELETEDFLAG + "='true', name='" + getName() + "' WHERE " + criteria;

            System.out.println("App#delete : " + query);

            if (DBConnPool.instance.executeQuery(query) == null)
                throw new IOException("unable to delete from " + tableName);
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }
    }
    /**
     * This updates this object from interface.
     * <ul>
     * <li> name
     * <li> isservice flag
     * <li> access rights
     * <li> min memory
     * <li> min cpu speed
     * <li> default stdin
     * <li> default dirin
     * <li> base dirin
     * <li> libraries paths
     * <li> binaries paths
     * </ul>
     */
    public void updateInterface(AppInterface itf) throws IOException {

        if(itf.getName() != null)
            setName(itf.getName());

        setService(itf.isService());

        if(itf.getAccessRights() != null)
            setAccessRights(itf.getAccessRights());

        if(itf.getMinMemory() != 0)
            setMinMemory(itf.getMinMemory());
        if(itf.getMinCpuSpeed() != 0)
            setMinMemory(itf.getMinCpuSpeed());

        if(itf.getDefaultStdin() != null)
            setDefaultStdin(itf.getDefaultStdin());
        if(itf.getBaseDirin() != null)
            setBaseDirin(itf.getBaseDirin());
        if(itf.getDefaultDirin() != null)
            setDefaultDirin(itf.getDefaultDirin());

        if(itf.getLDLinux_ix86() != null)
            setLDLinux_ix86(itf.getLDLinux_ix86());
        if(itf.getLDLinux_ppc() != null)
            setLDLinux_ppc(itf.getLDLinux_ppc());
        if(itf.getLDLinux_amd64() != null)
            setLDLinux_amd64(itf.getLDLinux_amd64());
        if(itf.getLDMacos_ix86() != null)
            setLDMacos_ix86(itf.getLDMacos_ix86());
        if(itf.getLDMacos_ppc() != null)
            setLDMacos_ppc(itf.getLDMacos_ppc());
        if(itf.getLDWin32_amd64() != null)
            setLDWin32_amd64(itf.getLDWin32_amd64());
        if(itf.getLDWin32_ix86() != null)
            setLDWin32_ix86(itf.getLDWin32_ix86());
        if(itf.getLDOsf1_alpha() != null)
            setLDOsf1_alpha(itf.getLDOsf1_alpha());
        if(itf.getLDOsf1_sparc() != null)
            setLDOsf1_sparc(itf.getLDOsf1_sparc());
        if(itf.getLDSolaris_sparc() != null)
            setLDSolaris_sparc(itf.getLDSolaris_sparc());
        if(itf.getLDSolaris_alpha() != null)
            setLDSolaris_alpha(itf.getLDSolaris_alpha());

        if(itf.getLinux_ix86() != null)
            setLinux_ix86(itf.getLinux_ix86());
        if(itf.getLinux_ppc() != null)
            setLinux_ppc(itf.getLinux_ppc());
        if(itf.getLinux_amd64() != null)
            setLinux_amd64(itf.getLinux_amd64());
        if(itf.getMacos_ix86() != null)
            setMacos_ix86(itf.getMacos_ix86());
        if(itf.getMacos_ppc() != null)
            setMacos_ppc(itf.getMacos_ppc());
        if(itf.getWin32_amd64() != null)
            setWin32_amd64(itf.getWin32_amd64());
        if(itf.getWin32_ix86() != null)
            setWin32_ix86(itf.getWin32_ix86());
        if(itf.getOsf1_alpha() != null)
            setOsf1_alpha(itf.getOsf1_alpha());
        if(itf.getOsf1_sparc() != null)
            setOsf1_sparc(itf.getOsf1_sparc());
        if(itf.getSolaris_sparc() != null)
            setSolaris_sparc(itf.getSolaris_sparc());
        if(itf.getSolaris_alpha() != null)
            setSolaris_alpha(itf.getSolaris_alpha());

        if(itf.getJava() != null)
            setJava(itf.getJava());
    }
//     /**
//      * This checks whether user has the right to work with this application.<br>
//      * <li> if this application has no user group, every user can work with this app.
//      * <li> if this application has a user group, these group users can work with this app only.
//      * <li> any user with UserRights::SUPER_USER rights can work with this app.
//      * @see UserRights
//      * @see User
//      * @return true if user can work with this application 
//      *         false otherwise
//      */
//     public boolean checkRights(User user, UserGroup appGroup) {

//         UserRights userRights;
//         UID userGroup;

//         try {
//             userGroup = user.getGroup();
//             userRights = user.getRights();
//         }
//         catch(Exception e) {
//             e.printStackTrace();
//             return false;
//         }

//         if((userRights.ordinal() >= UserRights.SUPER_USER.ordinal()) ||
//            (appGroup == null))
//             return true;

//         if(userGroup == null)
//             return false;

//         return appGroup.equals(userGroup);
//     }


    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public int getAvgExecTime() {
        return((AppInterface)row).getAvgExecTime();
    }

    /**
     * This returns the number of executed jobs for this application
     * @return the expected parameter 
     */
    public int getNbJobs() {
        return((AppInterface)row).getNbJobs();
    }

    /**
     * This gets the owner UID, if any
     * @return the owner UID
     */
    public UID getOwner() {
        return((AppInterface)row).getOwner();
    }
    /**
     * This retreives the URI to get application binary accordingly to OS and CPU
     * @param cpu is the cpu for the expected binary
     * @param os  is the os  for the expected binary
     * @return binary URI or null
     */
    public URI getBinary(XWCPUs cpu, XWOSes os) {
        return ((AppInterface)row).getBinary(cpu, os);
    }
    /**
     * This retreives the URI to get application binary for linux ix86
     * @return an URI
     */
    public URI getLinux_ix86() {
        return ((AppInterface)row).getLinux_ix86();
    }
    /**
     * This retreives the URI to get application binary for linux amd64
     * @return an URI
     */
    public URI getLinux_amd64() {
        return ((AppInterface)row).getLinux_amd64();
    }
    /**
     * This retreives the URI to get application binary for linux ppc
     * @return an URI
     */
    public URI getLinux_ppc() {
        return ((AppInterface)row).getLinux_ppc();
    }
    /**
     * This retreives the URI to get application binary for win32 ix86
     * @return an URI
     */
    public URI getWin32_ix86() {
        return ((AppInterface)row).getWin32_ix86();
    }
    /**
     * This retreives the URI to get application binary for win32 amd64
     * @return an URI
     */
    public URI getWin32_amd64() {
        return ((AppInterface)row).getWin32_amd64();
    }
    /**
     * This retreives the URI to get application binary for mac os ix86
     * @return an URI
     */
    public URI getMacos_ix86() {
        return ((AppInterface)row).getMacos_ix86();
    }
    /**
     * This retreives the URI to get application binary for mac os ppc
     * @return an URI
     */
    public URI getMacos_ppc() {
        return ((AppInterface)row).getMacos_ppc();
    }
    /**
     * This retreives the URI to get application binary for java
     * @return an URI
     */
    public URI getJava() {
        return ((AppInterface)row).getJava();
    }
    /**
     * This retreives the URI to get application binary for solaris sparc
     * @return an URI
     */
    public URI getSolaris_sparc() {
        return ((AppInterface)row).getSolaris_sparc();
    }
    /**
     * This retreives the URI to get application binary for solaris alpha
     * @return an URI
     */
    public URI getSolaris_alpha() {
        return ((AppInterface)row).getSolaris_alpha();
    }
    /**
     * This retreives the URI to get application binary for osf1 sparc
     * @return an URI
     */
    public URI getOsf1_sparc() {
        return ((AppInterface)row).getOsf1_sparc();
    }
    /**
     * This retreives the URI to get application binary for osf1 alpha
     * @return an URI
     */
    public URI getOsf1_alpha() {
        return ((AppInterface)row).getOsf1_alpha();
    }
    /**
     * This retreives the URI to get application library accordingly to OS and CPU
     * @param cpu is the cpu for the expected binary
     * @param os  is the os  for the expected binary
     * @return binary URI or null
     */
    public URI getLibrary(XWCPUs cpu, XWOSes os) {
        return ((AppInterface)row).getLibrary(cpu, os);
    }
    /**
     * This retreives the URI to get application library for linux ix86
     * @return an URI
     */
    public URI getLDLinux_ix86() {
        return ((AppInterface)row).getLDLinux_ix86();
    }
    /**
     * This retreives the URI to get application library for linux amd64
     * @return an URI
     */
    public URI getLDLinux_amd64() {
        return ((AppInterface)row).getLDLinux_amd64();
    }
    /**
     * This retreives the URI to get application library for linux ppc
     * @return an URI
     */
    public URI getLDLinux_ppc() {
        return ((AppInterface)row).getLDLinux_ppc();
    }
    /**
     * This retreives the URI to get application library for win32 ix86
     * @return an URI
     */
    public URI getLDWin32_ix86() {
        return ((AppInterface)row).getLDWin32_ix86();
    }
    /**
     * This retreives the URI to get application library for win32 amd64
     * @return an URI
     */
    public URI getLDWin32_amd64() {
        return ((AppInterface)row).getLDWin32_amd64();
    }
    /**
     * This retreives the URI to get application library for mac os ix86
     * @return an URI
     */
    public URI getLDMacos_ix86() {
        return ((AppInterface)row).getLDMacos_ix86();
    }
    /**
     * This retreives the URI to get application library for mac os ppc
     * @return an URI
     */
    public URI getLDMacos_ppc() {
        return ((AppInterface)row).getLDMacos_ppc();
    }
    /**
     * This retreives the URI to get application library for solaris sparc
     * @return an URI
     */
    public URI getLDSolaris_sparc() {
        return ((AppInterface)row).getLDSolaris_sparc();
    }
    /**
     * This retreives the URI to get application library for solaris alpha
     * @return an URI
     */
    public URI getLDSolaris_alpha() {
        return ((AppInterface)row).getLDSolaris_alpha();
    }
    /**
     * This retreives the URI to get application library for osf1 sparc
     * @return an URI
     */
    public URI getLDOsf1_sparc() {
        return ((AppInterface)row).getLDOsf1_sparc();
    }
    /**
     * This retreives the URI to get application library for osf1 alpha
     * @return an URI
     */
    public URI getLDOsf1_alpha() {
        return ((AppInterface)row).getLDOsf1_alpha();
    }
    /**
     *
     */
    public XWAccessRights getAccessRights() {
        return((AppInterface)row).getAccessRights();
    }
    /**
     */
    public int getMinMemory() {
        return((AppInterface)row).getMinMemory();
    }
    public int getMinCpuSpeed() {
        return((AppInterface)row).getMinCpuSpeed();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public String getName() {
        return((AppInterface)row).getName();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public UID getUID() throws IOException{
        return((AppInterface)row).getUID();
    }
    /**
     * This retreives the URI to get default stdin
     * @return an URI
     */
    public URI getDefaultStdin() throws IOException{
        return ((AppInterface) row).getDefaultStdin();
    }
    /**
     * This retreives the URI to get base dirin
     * @return an URI
     */
    public URI getBaseDirin() throws IOException{
        return ((AppInterface) row).getBaseDirin();
    }
    /**
     * This retreives the URI to get default dirin
     * @return an URI
     */
    public URI getDefaultDirin() throws IOException{
        return ((AppInterface) row).getDefaultDirin();
    }
    /**
     * This gets parameter
     * @return the expected parameter 
     */
    public boolean isService() {
        return((AppInterface)row).isService();
    }
    /**
     * This gets parameter
     * @return the expected parameter
     * @since 2.0.0
     */
    public boolean isDeleted() {
        return ((AppInterface) row).isDeleted();
    }
    /**
     * This sets the user UID
     * @param client is the client UID
     */
    public void setOwner(UID  client) {
        if(((AppInterface)row).setOwner(client))
            dirty = true;
    }
    /**
     * This sets the URI to get default stdin
     */
    public void setDefaultStdin(URI v) throws IOException{
        if (((AppInterface) row).setDefaultStdin(v))
            dirty = true;
    }
    /**
     * This sets the URI to get base dirin
     */
    public void setBaseDirin(URI v) throws IOException{
        if (((AppInterface) row).setBaseDirin(v))
            dirty = true;
    }
    /**
     * This sets the URI to get default dirin
     */
    public void setDefaultDirin(URI v) throws IOException{
        if (((AppInterface) row).setDefaultDirin(v))
            dirty = true;
    }
    /**
     * This sets the URI to retreive application binary for linux ix86 
     * @return  true if value has changed, false otherwise
     */
    public void setBinary(XWCPUs cpu, XWOSes os, URI v) {
        try {
            if(((AppInterface)row).setBinary(cpu, os, v))
                dirty = true;
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * This sets the URI to retreive application binary for linux ix86
     */
    public void setJava(URI v) {
        if(((AppInterface)row).setJava(v))
            dirty = true;
    }
    /**
     * This sets the URI to retreive application binary for linux ix86
     */
    public void setLinux_ix86(URI v) {
        if(((AppInterface)row).setLinux_ix86(v))
            dirty = true;
    }
    /**
     * This sets the URI to retreive application binary for linux amd64
     */
    public void setLinux_amd64(URI v) {
        if(((AppInterface)row).setLinux_amd64(v))
            dirty = true;
    }
    /**
     * This sets the URI to retreive application binary for linux ppc
     */
    public void setLinux_ppc(URI v) {
        if(((AppInterface)row).setLinux_ppc(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application binary for win32 ix86
     * @param v is an URI
     */
    public void setWin32_ix86(URI v) {
        if(((AppInterface)row).setWin32_ix86(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application binary for win32 amd64
     * @param v is an URI
     */
    public void setWin32_amd64(URI v) {
        if(((AppInterface)row).setWin32_amd64(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application binary for mac os ix86
     * @param v is an URI
     */
    public void setMacos_ix86(URI v) {
        if(((AppInterface)row).setMacos_ix86(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application binary for mac os ppc
     * @param v is an URI
     */
    public void setMacos_ppc(URI v) {
        if(((AppInterface)row).setMacos_ppc(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application binary for solaris sparc
     * @param v is an URI
     */
    public void setSolaris_sparc(URI v) {
        if(((AppInterface)row).setSolaris_sparc(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application binary for solaris alpha
     * @param v is an URI
     */
    public void setSolaris_alpha(URI v) {
        if(((AppInterface)row).setSolaris_alpha(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application binary for osf1 sparc
     * @param v is an URI
     */
    public void setOsf1_sparc(URI v) {
        if(((AppInterface)row).setOsf1_sparc(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application binary for osf1 alpah
     * @param v is an URI
     */
    public void setOsf1_alpha(URI v) {
        if(((AppInterface)row).setOsf1_alpha(v))
            dirty = true;
    }
    /**
     * This sets the URI to retreive application library for linux ix86 
     * @return  true if value has changed, false otherwise
     */
    public void setLDLibrary(XWCPUs cpu, XWOSes os, URI v) {
        try {
            if(((AppInterface)row).setLibrary(cpu, os, v))
                dirty = true;
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * This sets the URI to retreive application library for linux ix86
     */
    public void setLDLinux_ix86(URI v) {
        if(((AppInterface)row).setLDLinux_ix86(v))
            dirty = true;
    }
    /**
     * This sets the URI to retreive application library for linux amd64
     */
    public void setLDLinux_amd64(URI v) {
        if(((AppInterface)row).setLDLinux_amd64(v))
            dirty = true;
    }
    /**
     * This sets the URI to retreive application library for linux ppc
     */
    public void setLDLinux_ppc(URI v) {
        if(((AppInterface)row).setLDLinux_ppc(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application library for win32 ix86
     * @param v is an URI
     */
    public void setLDWin32_ix86(URI v) {
        if(((AppInterface)row).setLDWin32_ix86(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application library for win32 amd64
     * @param v is an URI
     */
    public void setLDWin32_amd64(URI v) {
        if(((AppInterface)row).setLDWin32_amd64(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application library for mac os ix86
     * @param v is an URI
     */
    public void setLDMacos_ix86(URI v) {
        if(((AppInterface)row).setLDMacos_ix86(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application library for mac os ppc
     * @param v is an URI
     */
    public void setLDMacos_ppc(URI v) {
        if(((AppInterface)row).setLDMacos_ppc(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application library for solaris sparc
     * @param v is an URI
     */
    public void setLDSolaris_sparc(URI v) {
        if(((AppInterface)row).setLDSolaris_sparc(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application library for solaris alpha
     * @param v is an URI
     */
    public void setLDSolaris_alpha(URI v) {
        if(((AppInterface)row).setLDSolaris_alpha(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application library for osf1 sparc
     * @param v is an URI
     */
    public void setLDOsf1_sparc(URI v) {
        if(((AppInterface)row).setLDOsf1_sparc(v))
            dirty = true;
    }
    /**
     * This sets the URI to get application library for osf1 alpah
     * @param v is an URI
     */
    public void setLDOsf1_alpha(URI v) {
        if(((AppInterface)row).setLDOsf1_alpha(v))
            dirty = true;
    }
    /**
     * This sets this app access rights
     */
    public void setAccessRights(XWAccessRights v) {
        if(((AppInterface)row).setAccessRights(v))
            dirty = true;
    }
    public void setMinMemory(int v) {
        if(((AppInterface)row).setMinMemory(v))
            dirty = true;
    }
    public void setMinCpuSpeed(int v) {
        if(((AppInterface)row).setMinCpuSpeed(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setNbJobs(int v) {
        if(((AppInterface)row).setNbJobs(v))
            dirty = true;
    }

    /**
     * This increments the number of executed jobs for this application
     */
    public void incNbJobs() {
        ((AppInterface)row).incNbJobs();
    }

    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setAvgExecTime(int v) {
        if(((AppInterface)row).setAvgExecTime(v))
            dirty = true;
    }
    /**
     * This increments NbJobs and recalculates avg exec time
     * @param v is the last execution time
     */
    public void incAvgExecTime(int v) {
        ((AppInterface)row).incAvgExecTime(v);
        dirty = true;
        try {
            update();
        }
        catch(Exception e) {
            error("app::incAvgExecTime() : " + e);
        }
    }

    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setName(String v) {
        if(((AppInterface)row).setName(v))
            dirty = true;
    }

    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setUID(UID v) {
        if(((AppInterface)row).setUID(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new parameter value
     * @since 2.0.0
     */
    public void setDeleted(boolean v) {
        if (((AppInterface)row).setDeleted(v))
            dirty = true;
    }
    /**
     * This sets parameter
     * @param v is the new value to set the param to
     */
    public void setService(boolean v) {
        if(((AppInterface)row).setService(v))
            dirty = true;
    }
//     /**
//      * This tests user access rights
//      * @param user is the user UID to test
//      * @param rights are the acces rights to test
//      * @return true if the user is this owner and acces rights are defined
//      */
//     public boolean checkUserAccessRights(UID user, XWAccessRights rights)
//         throws AccessControlException, IOException {
//         if(getUID().equals(user))
//             return ((getAccessRights().value() & rights.value() & XWAccessRights.USERALL.value()) != 0);
//         return false;
//     }
//     /**
//      * This tests user group access rights
//      * @param group is the user group UID to test
//      * @param rights are the access rights to test
//      * @return true if the user belongs to this owner group and group has access rights
//      */
//     public boolean checkGroupAccessRights(UID userGroup, XWAccessRights rights)
//         throws AccessControlException, IOException {
//         User owner = DBInterface.instance.cache.user(getOwner());
//         UserGroup ownerGroup = DBInterface.instance.cache.usergroup(owner.getGroup());
//         if(ownerGroup.equals(userGroup))
//             return ((rights.value() & getAccessRights().value() & XWAccessRights.GROUPALL.value()) != 0);
//         return false;
//     }
//     /**
//      * This tests access rights
//      * @param rights are the access rights to test
//      * @return true if others have access rights
//      */
//     public boolean checkOtherAccessRights(XWAccessRights rights)
//         throws AccessControlException, IOException {
//         return ((getAccessRights().value() & rights.value() & XWAccessRights.OTHERALL.value()) != 0);
//     }
//     /**
//      * This tests if user can read
//      * @param user is the user UID to test
//      * @param rights is the user rights to test
//      * @return true if the user is this owner and acces rights are defined
//      */
//     public boolean userCanRead(UID user, XWAccessRights rights)
//         throws AccessControlException, IOException {
//         boolean isOwner = getOwner().equals(user);
//         if(isOwner) {
//             return ((getAccessRights().value() & rights.value() & XWAccessRights.USERREAD.value()) != 0);
//         }
//         return false;
//     }
//     /**
//      * This tests user group access rights
//      * @param group is the user group UID to test
//      * @param rights is the user rights to test
//      * @return true if the user belongs to this owner group and group has access rights
//      */
//     public boolean groupCanRead(UID userGroup, XWAccessRights rights)
//         throws AccessControlException, IOException {
//         User owner = DBInterface.instance.cache.user(getOwner());
//         UserGroup ownerGroup = DBInterface.instance.cache.usergroup(owner.getGroup());
//         if(ownerGroup.equals(userGroup))
//             return ((getAccessRights().value() & rights.value() & XWAccessRights.GROUPREAD.value()) != 0);
//         return false;
//     }
//     /**
//      * This tests other access rights
//      * @param rights is the user rights to test
//      * @return true if others have access rights
//      */
//     public boolean otherCanRead(XWAccessRights rights)
//         throws AccessControlException, IOException {

//         return ((getAccessRights().value() & rights.value() & XWAccessRights.OTHERREAD.value()) != 0);
//     }
//     /**
//      * This tests if user can write
//      * @param user is the user UID to test
//      * @param rights is the user rights to test
//      * @return true if the user is this owner and acces rights are defined
//      */
//     public boolean userCanWrite(UID user, XWAccessRights rights)
//         throws AccessControlException, IOException {
//         boolean isOwner = getOwner().equals(user);
//         if(isOwner) {
//             return ((getAccessRights().value() & rights.value() & XWAccessRights.USERWRITE.value()) != 0);
//         }
//         return false;
//     }
//     /**
//      * This tests user group access rights
//      * @param group is the user group UID to test
//      * @param rights is the user rights to test
//      * @return true if the user belongs to this owner group and group has access rights
//      */
//     public boolean groupCanWrite(UID userGroup, XWAccessRights rights)
//         throws AccessControlException, IOException {
//         User owner = DBInterface.instance.cache.user(getOwner());
//         UserGroup ownerGroup = DBInterface.instance.cache.usergroup(owner.getGroup());
//         if(ownerGroup.equals(userGroup))
//             return ((getAccessRights().value() & rights.value() & XWAccessRights.GROUPWRITE.value()) != 0);
//         return false;
//     }
//     /**
//      * This tests other access rights
//      * @param rights is the user rights to test
//      * @return true if others have access rights
//      */
//     public boolean otherCanWrite(XWAccessRights rights)
//         throws AccessControlException, IOException {

//         return ((getAccessRights().value() & rights.value() & XWAccessRights.OTHERWRITE.value()) != 0);
//     }
//     /**
//      * This tests if user can exec
//      * @param user is the user UID to test
//      * @param rights is the user rights to test
//      * @return true if the user is this owner and acces rights are defined
//      */
//     public boolean userCanExec(UID user, XWAccessRights rights)
//         throws AccessControlException, IOException {
//         boolean isOwner = getOwner().equals(user);
//         if(isOwner) {
//             return ((getAccessRights().value() & rights.value() & XWAccessRights.USEREXEC.value()) != 0);
//         }
//         return false;
//     }
//     /**
//      * This tests user group access rights
//      * @param group is the user group UID to test
//      * @param rights is the user rights to test
//      * @return true if the user belongs to this owner group and group has access rights
//      */
//     public boolean groupCanExec(UID userGroup, XWAccessRights rights)
//         throws AccessControlException, IOException {
//         User owner = DBInterface.instance.cache.user(getOwner());
//         UserGroup ownerGroup = DBInterface.instance.cache.usergroup(owner.getGroup());
//         if(ownerGroup.equals(userGroup))
//             return ((getAccessRights().value() & rights.value() & XWAccessRights.GROUPEXEC.value()) != 0);
//         return false;
//     }
//     /**
//      * This tests other access rights
//      * @param rights is the user rights to test
//      * @return true if others have access rights
//      */
//     public boolean otherCanExec(XWAccessRights rights)
//         throws AccessControlException, IOException {

//         return ((getAccessRights().value() & rights.value() & XWAccessRights.OTHEREXEC.value()) != 0);
//     }
}
