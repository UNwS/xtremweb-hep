package xtremweb.dispatcher;

import xtremweb.common.util;
import xtremweb.common.UID;
import xtremweb.common.LoggerableThread;
import xtremweb.common.LoggerLevel;
import xtremweb.common.XWStatus;
import xtremweb.common.TaskInterface;
import xtremweb.common.XWPropertyDefs;

import java.util.Vector;

/**
 * The <CODE>TaskSet</CODE> is an abstract class which defines
 * the minimum needed methods set to manage XtremWeb tasks.
 */

public abstract class TaskSet extends LoggerableThread {

    public TaskSet(LoggerLevel l) {
        super("TaskSet", l);
    }


    /**
     * This tells whether the task set is ready
     * The taskset is ready when tasks have been read from DB, ckecked
     * and up to dated to a corret status
     * @return true if tasks set is ready
     */
    public boolean isReady() {
        return ready;
    }
    /**
     * This stores the tasks set status
     * @see #isReady()
     */
    private boolean ready = false;

    /**
     * This is a pure abstract method.
     * It has to be implemented in every child classes.<BR>
     * It creates new task accordingly to new works inserted in
     * database, if any.
     */
    protected abstract void refill();
    /**
     * This is a pure abstract method.
     * This detects lost jobs and set their status back to pending to give a chance of rescheduling.
     * A job is lost after 3 alive periods whithout heart beat signal from worker
     * @see xtremweb.dispatcher.Context#getAliveTimeout()
     * @see xtremweb.common#XWStatus
     */
    protected abstract void detectAbortedTasks();
    /**
     * This is a pure abstract method.
     * It detects completed tasks and remove them.
     */
    protected abstract void freeCompletedTasks();
    /**
     * This is a pure abstract method.
     * It retreives the next waiting task.
     * @return the next waiting task.
     * @param acceptBin tells whether worker accepts binary, if false this looks for services tasks only
     */
    public abstract Task getNextWaitingTask(boolean acceptBin);
    /**
     * This is a pure abstract method.
     * It retreives the next waiting task for the given worker
     * @return the next waiting task.
     * @param hostUID is the worker UID
     * @param acceptBin tells whether worker accepts binary, if false this looks for services tasks only
     */
    public abstract Task getNextWaitingTask(UID hostUID, boolean acceptBin);
    /**
     * This is a pure abstract method.
     * It retreives a task thanks to provided arguments.
     * @param tid is task ID to retreive.
     * @param wid is work ID associated to the task.
     * @return the expected task.
     */
    //  public abstract Task getByID(int tid, int wid);
    //
    // Oct 3rd, 2003: Oleg
    // Task are no longer indentified by TID/WID
    // but by their name which contains UID created by clients
    //
    /**
     * This is a pure abstract method.
     * It retreives a task from its uid
     * @param uid is task unique ID.
     * @return the expected task.
     */
    protected abstract Task getTaskByUid(UID uid);
    /**
     * This is a pure abstract method.
     * It retreives a work from its uid
     * @param uid is task unique ID.
     * @return the expected task.
     */
    protected abstract Work getWorkByUid(UID uid);
    /**
     * This is a pure abstract method.
     * get a running task in the set corresponding to an unique Id
     * @param   uid unique Id number
     * @return  t Task or null task not found
     */
    public abstract Task getRunningByID(UID uid);
    /**
     * This is a pure abstract method.
     * It retreives a task run by the specified worker.
     * @param host is the host UID running the worker.
     * @return the expected task.
     */
    //		public abstract Task getRunningByHost(UID host);
    /**
     * This is a pure abstract method.
     * It retreives datas with specified status, for the specified worker.
     * @param host is the worker host UID
     * @param s is the status; must be one of the values defined in XWStatus.java
     * @return a vector of tasks.
     * @since v1r2-rc3(RPC-V)
     * @see xtremweb.common.XWStatus
     */
    protected abstract Vector getHostDatas(UID host, XWStatus s);
    /**
     * This is a pure abstract method.
     * It retreives a task saved for the specified worker.
     * @param host is the host UID where the task has been run.
     * @return a vector of tasks.
     * @since v1r2-rc0(RPC-V)
     */
    public abstract Vector getSavedByHost(UID host);

    /**
     * This is a pure abstract method.
     * This retreives erroneus tasks, including due to server side error
     *(can not store result file, replicat error etc.) 
     * This replaces getServerError(UID host)
     * @param host is the host UID where the task has been run.
     * @return a vector of tasks.
     * @since 1.3.12
     */
    public abstract Vector getErroneus(UID host);
    /**
     * This is a pure abstract method.
     * It retreives tasks which results are expected from the specified worker.
     * @param host is the host name where the task has been run.
     * @return a vector of tasks.
     * @since v1r2-rc0(RPC-V)
     */
    public abstract Vector askDatasFromHost(UID host);



    /**
     * This is the main method. It only has an infinite loop thats
     * refills tasks set, detects aborted tasks and free completed ones.
     */
    public void run()
    {
        //fill();
        try {
            // RPCXW
            int timeout = Integer.parseInt(Dispatcher.config.getProperty(XWPropertyDefs.TIMEOUT.toString()));


            // while(!Context.isTaskSetChanged()) {
            while(true) {

                // July 2005 : this is not necessary any more 
                // since DBInterface#addApplication() inserts new app in pool
                //Dispatcher.db.updateAppsPool();

                // Sept 2005 : removed
                refill();

                detectAbortedTasks();
                freeCompletedTasks();
                ready = true;

                // RPCXW
                sleep(timeout);
                //								sleep(1000);
            }
        }
        catch(Exception e) 
            {
                e.printStackTrace();
                error("TaskSet.java" + e +
                      "\ntrace\n"  );
            }
        //  Context.setTaskSetChanged(false);
    }
}
