package xtremweb.archdep;

/*
 * This has been extracted from limewire
 * package com.limegroup.gnutella.gui.notify;
 */

import xtremweb.common.AboutWindow;
import xtremweb.common.util;

import javax.swing.JFrame;

/**
 * This class handles user notification events on Windows.  It forwards
 * events to native c++ code that reduces application to the system tray.
 */

public class XWNotifyImpl implements XWNotify
{

    /**
     * Placeholder used in the native code.
     */
    private int _handler = 0;

    /**
     * The tooltip to use for the tray icon.
     */
    private String _tooltip;

    /**
     * Handle to the name of the image file.
     */
    private String _imageFileName;

    /**
     * Client window
     */
    private JFrame  _client = null;

    public void setClient (JFrame c)
    {
				_client = c;
    }

    public void addNotify()
    {
				String tip = "XtremWeb Worker : providing CPU facility";
				updateNotify("xw.ico", tip);
    }

    public void removeNotify()
    {
				try {
						nativeDisable();
				}
				catch(UnsatisfiedLinkError ule) {
				}
    }

    public void updateNotify(final String imageFile, 
														 final String tooltip) {

				try {           
						_tooltip = tooltip;
						_imageFileName = imageFile;   
						int imageInt = nativeLoadImage(imageFile); 
	    
						// nothing we can do if the image does not load 
						// successfully
						if(imageInt == -1) {
								System.err.println("[notify] Can't load icon : " + imageFile);
								return;
						}
	    
						nativeEnable(imageInt, _tooltip);
				}
				catch(UnsatisfiedLinkError ule) {
						System.err.println(ule);
				}
    }

    public void updateImage(final String imageFileName) {
				updateNotify(imageFileName, _tooltip);
    }

    public void updateDesc(final String desc) {
				updateNotify(_imageFileName, desc);
    }

    public void hideNotify() {
				try {
						nativeHide();
				}
				catch(UnsatisfiedLinkError ule) {
						System.err.println(ule);
				}
    }

    /**
     * This is used by the native method as a callback to 
     * show this worker owner statistics
     */
    public void statistics() {
				util.launchBrowser("http://www.xtremweb.net");
    }

    /**
     * This is used by the native method as a callback to 
     * show this worker config
     */
    public void config() {
				util.launchBrowser("http://localhost");
    }

    /**
     * This is the callback from the native code to exit the
     * application.
     */
    public void exitApplication() {
				removeNotify ();
				util.fatal ("Exit on demand");
    }

    /**
     * Shows the about window to the user.
     */
    public void showAboutWindow() {
				AboutWindow about = new AboutWindow();
				about.showDialog();
    }

    /**
     * Removes the system tray icon.
     *
     * @throws UnsatisfiedLinkError if the associated native method 
     *  could not be linked to successfully
     */
    private synchronized native void nativeDisable() 
				throws UnsatisfiedLinkError;
    
    /**
     * Enables the system tray icon, using the specified image resource
     * and tooltip.  This method can also be used to modify the existing
     * system tray icon and tooltip.
     *
     * @param image the integer identifier of the image to use
     * @param tooltip the tooltip to display over the system tray icon
     */
    private synchronized native void nativeEnable( int image, String tooltip ) 
				throws UnsatisfiedLinkError;
    
    /**
     * Frees the specified image from memory.
     *
     * @param image the integer identifier of the native image
     */
    private synchronized static native void nativeFreeImage( int image ) 
				throws UnsatisfiedLinkError;
    
    /**
     * Loads the image specified in the <tt>fileName</tt> argument
     * natively into memory.
     *
     * @param fileName the full pathname of the image file to load
     */
    private synchronized static native int nativeLoadImage( String fileName ) 
				throws UnsatisfiedLinkError;
    
    /**
     * Loads the image specified in the <tt>intResource</tt> argument
     * natively into memory.
     *
     * @param intResource the integer identifier of the image resource
     */
    private synchronized static native int nativeLoadImageFromResource( int intResource ) 
				throws UnsatisfiedLinkError;
    
    /**
     * Hides the system tray icon.
     */
    private synchronized native void nativeHide() 
				throws UnsatisfiedLinkError;
}
