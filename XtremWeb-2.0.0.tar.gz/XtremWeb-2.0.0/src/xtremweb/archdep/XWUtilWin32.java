package xtremweb.archdep;

//  XWUtilWin32.java
//  
//  Created: Tue Apr 16 2002

/**  
 *      <p>Win32 implementation of <code>XWUtil</code></p>
 *      
 *      @author Samuel h&eacute;riard
 */
public class XWUtilWin32 extends XWUtilImpl {
/*
    public void chmodpx(String s) { 
        return;
    }
    public int getNumProc() {
        return 1;
    }
*/
}
