package xtremweb.archdep;

import xtremweb.common.LoggerLevel;

/**
 * <p>This interface describes needed methods to manage process
 * </p>
 * <p>An object implementing this interface can be obtained with the <code>xwexec()</code>
 * of <code>ArchDepFactory</code>
 * </p>
 * 
 * @see xtremweb.archdep.ArchDepFactory
 */

                                                                                
public interface XWExec{

    void init();

    //Launch the execution on a separate process
    boolean exec(String[] args, String stdin, String stdout, String stderr, String workingDir);

    //Stop the curant execution
    public boolean kill();
    public boolean destroy();

    //Wait for the end of the current execution
    public int waitFor();

    //Suspend the current execution
    public boolean suspend();

    //Re-activate the current execution
    public boolean activate();
    public boolean isRunning();

}
