package xtremweb.archdep;
//java side for native functions 
//actual C code is in XWUtil.c
//some deprecated functions remain...

public interface XWUtil {
    /** This changes the current directory */
    public void cd(String s);
    /** This sets the execute bit of the specified file */
    public void chmodpx(String s);
    /**
     * This tells whether a process is running or not
     * @param pid is the process id
     * @return true is process is running false otherwise
     */  
    public boolean isRunning(int pid);
    /**
     * This determines the process id
     * @return an integer containing the process id
     */  
    public int getPid();
    /**
     * This retreives the group id of the current process
     */
    public int getGid();
    /**
     * This retreives user id of the current process
     */
    public int getUid();
    /**
     * This determines the number of installed processors
     * @return an integer containing the number of installed processors
     */  
    public int getNumProc();
    /**
     * This determines the main processor speed
     * @return the main processor speed
     */  
    public int getSpeedProc();
    /**
     * This determines the main processor model
     * @return a String containing the main processor model name
     */  
    public String getProcModel();
    /**
     * This determines the total memory size
     * @return the total memory size in kB
     */  
    public int getTotalMem();
    /**
     * This determines the total memory swap size
     * @return the total memory swap size in kB
     */  
    public int getTotalSwap();

    /**
     * This determines this host cpu load
     * @return an integer containing the percentage of cpu load for this host
     *         100 on error
     */
    public int getCpuLoad();
    /**
     * This determines this process cpu load
     * @return an integer containing the percentage of cpu load for this process
     *         0 on error
     */  
    public int getProcessLoad();
    public void raz ();
}
