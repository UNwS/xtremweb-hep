package xtremweb.archdep;

//
//  PortMapperImpl.java
//  
//  Generic implementation of PortMapper
//  all methods are native.

public class PortMapper implements PortMapperItf {
		/**
		 * This retreives the RPC TCP port
		 * @param prog is the RPC prog number
		 * @param version is the RPC prog version number
		 */
    public native int gettcpport (int prog, int version);
		/**
		 * This retreives the RPC UDP port
		 * @param prog is the RPC prog number
		 * @param version is the RPC prog version number
		 */
    public native int getudpport (int prog, int version);
		/**
		 * This retreives the group id of the current process
		 */
    public native int getGid();
		/**
		 * This retreives user id of the current process
		 */
    public native int getUid();
}
