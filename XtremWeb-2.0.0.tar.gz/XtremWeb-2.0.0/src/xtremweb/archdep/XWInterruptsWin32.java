package xtremweb.archdep;

/**  
 * <p>Win32 XWInterrupts implementation,
 *  all methods are native.</p>
 *
 *  @author Oleg Lodygensky
 */

public class XWInterruptsWin32 implements XWInterrupts {
    /**
     * This initializes IRQ counter
     * @return true on success false otherwise
     */
  public native boolean initialize ();
    /**
     * Read keyboard interrupts occurences
     */
    public native int readKey();
    /**
     * Read mouse interrupts occurences
     */
    public native int readMouse();

}

