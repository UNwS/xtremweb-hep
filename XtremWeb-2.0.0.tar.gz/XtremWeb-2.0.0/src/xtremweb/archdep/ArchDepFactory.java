package xtremweb.archdep;
//  ArchDepFactory.java
//  Created : Mon Mar 25 2002.


import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Hashtable;

import xtremweb.common.Logger;
import xtremweb.common.LoggerLevel;
import xtremweb.common.XWOSes;
import xtremweb.common.XWCPUs;
import xtremweb.common.Version;
import xtremweb.common.CommonVersion;


/**
 *  Provider of architecture dependant classes. 
 *
 *  <p><code>ArchDepFactory</code> is the key class of the package, it handles instanciation of 
 *      interface implementations, and loading of JNI libraries
 *  </p>
 * 
 *  @author Samuel H&eacute;riard
 * 
 */
 
public class ArchDepFactory extends Logger{

    /** Mapping between interface and implementations */
    protected Map ifmap;

    /** Instances of architecture dependant classes, indexed by the interface name */
    protected Map uniqueInstances;

    /** unique instance of the class */
    protected static ArchDepFactory instance = new ArchDepFactory();

    /** ArchDepFactory singleton
     * @return the unique instance of ArchdepFactory
     */
    public static ArchDepFactory getInstance() {
        return instance;
    }
    
    /** 
     * This is the default contructor
     * This creates all needed maps to retreive libraryies accordingly to the OS
     */
    protected ArchDepFactory() {

        level = LoggerLevel.INFO;

        Map map_util = new Hashtable(10);
        Map map_tracer = new Hashtable(10);
        Map map_interrupts = new Hashtable(10);
        Map map_notify = new Hashtable(10);
        Map map_exec = new Hashtable(10);
        Map map_portmap = new Hashtable(10);

        map_util.put (XWOSes.NONE, "xtremweb.archdep.XWUtilDummy");
        map_util.put (XWOSes.LINUX, "xtremweb.archdep.XWUtilLinux");
        map_util.put (XWOSes.SOLARIS, "xtremweb.archdep.XWUtilSolaris");
        map_util.put (XWOSes.WIN32, "xtremweb.archdep.XWUtilWin32");
        map_util.put (XWOSes.MACOSX, "xtremweb.archdep.XWUtilMacOSX");
        
        map_tracer.put(XWOSes.NONE, "xtremweb.archdep.XWTracerImpl");
        
        map_interrupts.put (XWOSes.LINUX, "xtremweb.archdep.XWInterruptsLinux");
        map_interrupts.put (XWOSes.WIN32, "xtremweb.archdep.XWInterruptsWin32");

        map_notify.put(XWOSes.NONE, "xtremweb.archdep.XWNotifyNative");
        map_notify.put(XWOSes.WIN32, "xtremweb.archdep.XWNotifyImpl");
        
        map_exec.put(XWOSes.NONE, "xtremweb.archdep.XWExecPureJava");
        map_exec.put(XWOSes.LINUX, "xtremweb.archdep.XWExecPureJava");

        map_portmap.put (XWOSes.NONE, "xtremweb.archdep.PortMapper");
        map_portmap.put (XWOSes.LINUX, "xtremweb.archdep.PortMapper");

        ifmap = new Hashtable(10);
        ifmap.put("xtremweb.archdep.XWUtil",map_util);
        ifmap.put("xtremweb.archdep.XWTracerNative", map_tracer);
        ifmap.put("xtremweb.archdep.XWInterrupts", map_interrupts);
        ifmap.put("xtremweb.archdep.XWNotify", map_notify);
        ifmap.put("xtremweb.archdep.XWExec", map_exec);
        ifmap.put("xtremweb.archdep.PortMapperItf", map_portmap);

        uniqueInstances = new Hashtable(10);

        // force libraries loading at startup
        String loading_message ="";
        String [] librairies = { "XWUtil", "XWInterrupts", "XwTracer", "XWNotify","XWExecJNI", "PortMapper"};
        for (int i=0; i< librairies.length; i++) {
            loading_message += librairies[i] +"\t\t" + (loadLibrary(librairies[i])?"Loaded":"Missing")+"\n";
        }
        debug("\n"+loading_message);
    }


    /**
     * This retrieves the resource name of the JNI library
     * Such names are composed as follow:
     *     <libName>.jni.<version>.<osName>-<cpuName>
     *
     * @param lib name of the library
     * @return the name of the resource containing this library. The data can later be retrieved
     *         using <code>getResource</code> or <code>getResourceAsStream</code>
     */
    //protected static String mapLibraryName(String lib, String os, Version v) {
    protected static String mapLibraryName(String lib) {

        Version v = CommonVersion.getCurrent ();
        XWOSes os = XWOSes.getOs();
        XWCPUs cpu = XWCPUs.getCpu();

        return lib + ".jni." + v.full()
            + "." + os + "-" + cpu;
    }
    
    /**
     * Loads a JNI library
     * 
     * <p>
     * <code>loadLibrary</code> uses <code>mapLibraryName</code> to find the actual name of the library, 
     * then it tries to load the library from the cache directory, or from the classloader if it's not
     * already in the cache. The architecture names of the architecture chain are tested from the most
     * specific to the most generic</p>
     *
     * @param s name of the library
     * @see #mapLibraryName(String)
     */
    protected boolean loadLibrary(String s) {
        boolean loaded = false;

        try {

            //for (int i = 0; !loaded && i < archChain.length; i++) {

            //String libname = mapLibraryName(s, archChain[i], CommonVersion.getCurrent());

            String libname = mapLibraryName(s);

            System.err.println("ArchDepFactory::loadLibrary  xtremweb.cache = " + System.getProperty("xtremweb.cache"));

            new File(System.getProperty("xtremweb.cache")).mkdirs();

            File f = new File(System.getProperty("xtremweb.cache"), 
                              libname);

            debug("copy jni "+ libname + " lib to "+f.getAbsolutePath()); 

            String libpath = System.getProperty("java.library.path");

            if(libpath == null)
                libpath = new String();

            if(libpath.indexOf(System.getProperty("xtremweb.cache")) == -1)
                libpath = libpath.concat(":.:" + System.getProperty("xtremweb.cache"));

            System.setProperty("java.library.path", libpath);

            if (f.exists())
                f.delete();

            //						if (! f.exists()) {
            // ca pue, mais il faudrait vraiment un filesystem xtremweb pour
            // faire ca clean. SHD
            String resname = "jni/" + libname;
            InputStream ls = getClass().getClassLoader().getResourceAsStream(resname);
            if ((ls != null) && (ls.available()>0)) {
                byte[] buf = new byte[1024];
                FileOutputStream lf = new FileOutputStream(f);
                for (int n = ls.read(buf); n > 0; n = ls.read(buf)) {
                    lf.write(buf, 0, n);
                }
                ls.close();
                lf.close();
            }
            else {
                debug("the jni lib " +  resname +" does not exist in the archive" );
            }
            //						}

            if (f.exists()) {
                // try to load it from the cache first and then from the classpath
                try {
                    System.load(f.getAbsolutePath());
                }
                catch (UnsatisfiedLinkError ule) {
                    System.loadLibrary(libname);
                }

                info("Loaded jni library : " + s);
                loaded = true;
            } 

            //} // end for

            if (! loaded) {
                debug("Can't find jni library : " + s);
            }

        } 
        catch (Throwable e) {
            debug(" can't load " + s + " : " + e);
        }
        return loaded;
    }

    
    /** Maps a interface to its implemantation
     * @param ifname of the interface
     * @return the class implementing this interface
     * @exception ArchDepException if the implementation does not exists or can't be loaded
     * @see #getUniqueInstance(String)
     */
    public Class getClassForInterface(String ifname)
        throws ArchDepException {

        String implclass = null;
        Map map = (Map) ifmap.get(ifname);
        ArchDepException error =
            new ArchDepException("No implementation found for interface : " +
                                 ifname);
        if (map == null)
            throw error;

        System.out.println("ifname = " + ifname);
        System.out.println("OS     = " + XWOSes.getOs());
        implclass = (String)map.get(XWOSes.getOs());

        if (implclass == null)
            implclass = (String)map.get(XWOSes.NONE);

        if (implclass == null) {
            throw error;
        }

        try {
            Class result = Class.forName(implclass);
            return result;
        } 
        catch (ClassNotFoundException e) {
            debug(e.getMessage());
            throw new ArchDepException(
                                       "Unable to load implementation for interface " +
                                       ifname + " : " + e.getMessage());
        }
    }


    /** 
     * Gets an instance of an implementation of an given interface.
     * @param ifname name of the interface
     * @return a cached instance of the implementation of <code>ifname</code>. 
     Only one such instance will be created.
    */
    public Object getUniqueInstance(String ifname) {
        Object obj = uniqueInstances.get(ifname);
        if (obj == null) {
            try {
                Class iface = Class.forName(ifname);
                obj = getClassForInterface(ifname).newInstance();
                if (!iface.isInstance(obj)) {
                    throw new ArchDepException("Invalid implementation : " + obj.getClass() 
                                               + " does not implements " + ifname);
                }
                uniqueInstances.put(ifname, obj);
            } 
            catch (Exception e) {
                debug(e.getMessage());
                obj = null;
                error("Can't get implementation for " + ifname + " : " + e.getMessage());
            }
        }
        return obj;
    }

    // Implementation accessors
    
    /**
     * Quick access to <code>XWUtil</code>
     * 
     * @return an <code>XWUtil</code> instance or <code>null</code> if the implementation 
     *          could not be loaded 
     * @see #getUniqueInstance(String)
     */
    public static XWUtil xwutil() {
        return (XWUtil)instance.getUniqueInstance("xtremweb.archdep.XWUtil");
    }

    /** Quick access to <code>XWTracerNative</code> */
    public static XWTracerNative xwtracer() {
        return (XWTracerNative)instance.getUniqueInstance("xtremweb.archdep.XWTracerNative");
    }

    /*
      public static XwCheckpointNative xwchkpt() {
      return (XwCheckpointNative)getUniqueInstance("xtremweb.archdep.XwCheckpointNative");
      }
    */
    /** Quick access to <code>XWInterrupts<code> */
    public static XWInterrupts xwinterrupts() {
        return (XWInterrupts)instance.getUniqueInstance("xtremweb.archdep.XWInterrupts");
    }
    
    /** Quick access to <code>XWNotify</code> */
    public static XWNotify xwnotify() {
        return (XWNotify)instance.getUniqueInstance("xtremweb.archdep.XWNotify");
    }

    /** Quick access to <code>XWNotify</code> */
    public static XWExec xwexec() {
        try{
            return (XWExec)instance.getClassForInterface("xtremweb.archdep.XWExec").newInstance();
        }catch(Exception e){
            return null;
        }
    }

    /** Quick access to <code>PortMapper</code> */
    public static PortMapper portMap () {
        try{
            return (PortMapper)instance.getUniqueInstance("xtremweb.archdep.PortMapperItf");
        }catch(Exception e){
            System.err.println(e.toString ());
            return null;
        }
    }
}



