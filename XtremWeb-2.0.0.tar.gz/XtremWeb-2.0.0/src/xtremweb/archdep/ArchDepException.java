package xtremweb.archdep;
/** 
 * ArchDepException.java
 * Exceptions thrown by ArchDepFactory
 *
 * Created : Mon Mar 25 2002.
 *  
 * @author Samuel Heriard 
 */


public class ArchDepException extends Exception { 
    ArchDepException(String msg) {
        super(msg);
    }
    
    ArchDepException() {
        super();
    }

}
