package xtremweb.archdep;
/**
 * Date    : Mar 25th, 2005<br />
 * Project : RPCXW / RPCXW-C<br />
 * File    : PortMapper.java<br />
 *
 * @author <a href="mailto:lodygens_a_lal.in2p3.fr">Oleg Lodygensky</a>
 * @version
 */


/**
 * <p>This interface describes needed methods to reterive some system informations
 *<ul>
 *  <li> Sun RPC tcp port
 *  <li> Sun RPC udp port
 *  <li> user id
 *  <li> group id
 *</ul>
 * </p>
 * <p>An object implementing this interface can be obtained with the <code>portmap()</code>
 * of <code>ArchDepFactory</code>
 * </p>
 * <p><code>xtremweb.services.rpc.rpc#udp(byte[])</code> uses this interface</p>
 * 
 * @see xtremweb.archdep.ArchDepFactory
 * @see xtremweb.services.rpc.rpc#udp(byte[])
 */
public interface PortMapperItf  {
		/**
		 * This retreives the RPC TCP port
		 * @param prog is the RPC prog number
		 * @param version is the RPC prog version number
		 */
    public int gettcpport (int prog, int version);
		/**
		 * This retreives the RPC UDP port
		 * @param prog is the RPC prog number
		 * @param version is the RPC prog version number
		 */
    public int getudpport (int prog, int version);
}
