package xtremweb.archdep;

/**
 * <p>This interface describes needed methods to read the number of keyboard and mouse interrupts 
 * that occured since system startup.
 * </p>
 * <p>An object implementing this interface can be obtained with the <code>xwinterrupts()</code>
 * of <code>ArchDepFactory</code>
 * </p>
 * <p><code>xtremweb.worker.MouseKbdActivator</code> uses this intereface</p>
 * 
 * @see xtremweb.archdep.ArchDepFactory
 * @see xtremweb.worker.MouseKbdActivator
 */

public interface XWInterrupts
{
    /**
     * This initializes IRQ counter
     * @return true on success false otherwise
     */
		public boolean initialize ();
		/**
		 * <p>Read keyboard interrupts occurences since last reboot</p>
		 * <p><i>Actually neither this method nor <code>readMouse()</code> needs to return
		 * the exact number of interrupts occurences since last reboot. It must return an integer 
		 * that change  between two calls if an interrupts occured.</i></p>
		 */ 
		public int readKey();
		/**
		 * Read mouse interrupts occurences since last reboot
		 */ 
		public int readMouse();
}

