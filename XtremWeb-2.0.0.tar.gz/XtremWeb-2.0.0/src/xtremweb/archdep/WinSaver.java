package xtremweb.archdep;

public class WinSaver {
	/** 
	 * Retreive whether the screen saver is running
	 * @return true if screen saver is running
	 */
	public static native boolean screenSaverRunning();
	/** 
	 * Retreive whether the low power is enabled for this station
	 * @return true if low power is enabled
	 */
	public static native boolean lowPowerActive();
	/** 
	 * Disable the low power for this station
	 */
	public static native void disableLowPower();
	/** 
	 * Enable the low power for this station
	 */
	public static native void enableLowPower();
	/** 
	 * Retreive whether the power off is enabled for this station
	 * @return true if power off is enabled
	 */
	public static native boolean powerOffActive();
	/** 
	 * Disable the power off for this station
	 */
	public static native void disablePowerOff();
	/** 
	 * Enable the power off for this station
	 */
	public static native void enablePowerOff();
	/** 
	 * Retreive time out to low power 
	 * @return the low power time out in seconds
	 */
	public static native int lowPowerTimeOut();
	/** 
	 * Retreive time out to power off
	 * @return the power off time out in seconds
	 */
	public static native int powerOffTimeOut();
}
