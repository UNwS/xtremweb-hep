/**
 * Project : XTremWeb
 * File    : XWTracer.java
 *
 * Initial revision : July 2001
 * By               : Anna Lawer
 *
 * New revision : January 2002
 * Author       : Oleg Lodygensky
 * e-mail       : lodygens /at\ lal.in2p3.fr
 */

package xtremweb.archdep;



public class XWTracerImpl implements XWTracerNative
{
  public native void collectNodeConfig(int i);
  public native void checkNodeState(int i); 
  public native void checkNetwork(int i);
  public native void fermera();
  public native void setOutputDir(String dir);
}
