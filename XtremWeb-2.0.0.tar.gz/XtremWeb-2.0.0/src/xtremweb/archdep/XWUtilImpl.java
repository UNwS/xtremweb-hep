package xtremweb.archdep;

//
//  XWUtilImpl.java
//  Samuel Heriard
//  
//  Generic implementation of XWUtil
//  all methods are native.

public class XWUtilImpl implements XWUtil {
    public native void cd(String s);
    public native void chmodpx(String s);
    public native boolean isRunning(int pid);
    /** this retreives process id */
    public native int getPid();
    public native int getNumProc();
    public native int getSpeedProc();
    public native String getProcModel();
    public native int getTotalMem();
    public native int getTotalSwap();

    /** this retreives this host average cpu load */
    public native int getCpuLoad();
    /** this retreives this process average cpu load */
    public native int getProcessLoad();
    public native void raz ();
    /**
     * This retreives the group id of the current process
     */
    public native int getGid();
    /**
     * This retreives user id of the current process
     */
    public native int getUid();
}
