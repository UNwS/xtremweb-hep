package xtremweb.archdep;

import xtremweb.exec.*;
import java.io.*;

//  XWUtilWin32.java
//  
//  Created: 28 fevrier 2007

/**  
 *      <p>Mac OS X implementation of <code>XWUtil</code></p>
 *      
 *      @author Oleg Lodygensky
 */
public class XWUtilMacOSX extends XWUtilImpl {

    public XWUtilMacOSX() {
        System.out.println("new XWUtilMacOSX");
    }

    /**
     * This executes a command
     * 
     * @param cmdLine command line for execution
     */
    protected String execCommand(String command) throws IOException {

        File tmp = new File(System.getProperty("java.io.tmpdir"));
        FileInputStream in = null;
        File stdout = new File(tmp, "stdout.txt");
        FileOutputStream out = new FileOutputStream(stdout);
        FileOutputStream err = new FileOutputStream(new File(tmp,
                                                             "stderr.txt"));
        Executor exec = new Executor(command,
                                     tmp.getAbsolutePath(), in, out, err,
                                     10);
        try {
            int processReturnCode = exec.startAndWait();
            if (processReturnCode != 0 ) 
                throw new IOException("Exec error " + command);
        }
        catch(Exception e) {
            throw new IOException (e.toString());
        }

        BufferedReader bufferFile = new BufferedReader(new FileReader(stdout));
        String ret = null;
        try {
            ret = bufferFile.readLine();	
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        bufferFile.close();
        return ret;
    }

    /**
     * This retreives the amount of CPU available on this machine
     */
    public int getNumProc() {
        try {
            String val = execCommand("sysctl -n hw.ncpu");
            return Integer.parseInt(val);
        }
        catch(IOException e) {
        }
        return 0;
    }

    /**
     * This retreives CPU clock in Mhz
     */
    public int getSpeedProc() {
        try {
            String val = execCommand("sysctl -n hw.cpufrequency");
            return (int)(Long.parseLong(val) / 1000000);
        }
        catch(IOException e) {
        }
        return 0;
    }

    public String getProcModel() {
        try {
            return execCommand("sysctl -n machdep.cpu.model_string");
        }
        catch(IOException e) {
        }
        return null;
    }


    /**
     * This retreives RAM size in Mb
     */
    public int getTotalMem() {
        try {
            String val = execCommand("sysctl -n hw.memsize");
            return (int)(Long.parseLong(val) / (1024 * 1024));
        }
        catch(IOException e) {
        }
        return 0;
    }


    public int getTotalSwap() {
        System.out.println("XWUtilMacOSX#getTotalSwap() is not implemented");
        /*
        try {
            String val = execCommand("sysctl -n hw.ncpu");
            return Integer.parseInt(val);
        }
        catch(IOException e) {
        }
        */
        return 0;
    }

    /**
     * This is the standard main () method
     * args[0] may contain a PID to calculate its user CPU usage
     */
    public static void main(String[] args) {
  
        XWUtilMacOSX cpu = new XWUtilMacOSX();

        System.out.println("CPU model = " + cpu.getProcModel());
        System.out.println("CPU speed = " + cpu.getSpeedProc());
        System.out.println("Mem       = " + cpu.getTotalMem());
        System.out.println("Swap      = " + cpu.getTotalSwap());
    }

}
