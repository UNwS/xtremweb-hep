/**
 * XWTracerNative.java
 */

package xtremweb.archdep;



public interface XWTracerNative
{
  public void setOutputDir (String dir);
  public void collectNodeConfig (int i);
  public void checkNodeState (int i); 
  public void checkNetwork (int i);
  public void fermera ();
}
