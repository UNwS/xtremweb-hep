package xtremweb.archdep;


/**
 * This class does just nothing!!
 * Its aim is only to provide a generic utility class so that
 * the worker runs in a minimal configuration but do nothing
 * :(
 */
public class XWUtilDummy implements XWUtil {


    /**
     * This does nothing
     */
    public void cd(String s) {
        System.err.println ("XWUtilDummy::cd () does nothing!");
    }


    /** This sets the execute bit of the specified file */
    public void chmodpx(String s) {
        String [] cmdArray = new String[3];
        Process workProcess = null;
        int processReturnCode;

        cmdArray [0] = "/bin/sh";
        cmdArray [1] = "-c";
        cmdArray [2] = "chmod u+x "+s;

        try {
            workProcess =  Runtime.getRuntime().exec(cmdArray, null, null);	
            processReturnCode = workProcess.waitFor();	 
        }
        catch (Exception e) {
        }
    }


    /**
     * This does nothing
     */  
    public void raz () {
        System.err.println ("XWUtilDummy::raz () does nothing!");
    }

    /**
     * This does nothing
     * @return false
     */  
    public boolean isRunning (int pid) {
        System.err.println ("XWUtilDummy::isRunning () does nothing!");
        return false;
    }


    /**
     * This does nothing
     * @return 0
     */  
    public int getPid () {
        System.err.println ("XWUtilDummy::getPid () does nothing!");
        return 0;
    }
    /**
     * This does nothing
     * @return 0
     */  
    public int getUid () {
        System.err.println ("XWUtilDummy::getUid () does nothing!");
        return 0;
    }
    /**
     * This does nothing
     * @return 0
     */  
    public int getGid () {
        System.err.println ("XWUtilDummy::getGid () does nothing!");
        return 0;
    }


    /**
     * This does nothing
     * @return 1
     */
    public int getNumProc () {
        System.err.println ("XWUtilDummy::getNumProc () does nothing!");
        return 1;
    }


    /**
     * This does nothing
     * @return 0
     */  
    public int getSpeedProc () {
        System.err.println ("XWUtilDummy::getSpeedProc () does nothing!");
        return 0;
    }


    /**
     * This does nothing
     * @return null
     */  
    public String getProcModel () {
        System.err.println ("XWUtilDummy::getProcModel () does nothing!");
        return null;
    }


    /**
     * This does nothing
     * @return 0
     */  
    public int getTotalMem () {
        System.err.println ("XWUtilDummy::getTotalMem () does nothing!");
        return 0;
    }


    /**
     * This does nothing
     * @return 0
     */  
    public int getTotalSwap () {
        System.err.println ("XWUtilDummy::getTotalSwap () does nothing!");
        return 0;
    }


    /**
     * This does nothing
     * @return 100
     */
    public int getCpuLoad () {
        System.err.println ("XWUtilDummy::getCpuLoad () does nothing!");
        return 100;
    }


    /**
     * This does nothing
     * @return 0
     */  
    public int getProcessLoad () {
        System.err.println ("XWUtilDummy::getProcessLoad () does nothing!");
        return 0;
    }

}

