package xtremweb.archdep;

public class MacSaver {
    /** return true if the screen saver is NOT running */
    public static native int running();
}
