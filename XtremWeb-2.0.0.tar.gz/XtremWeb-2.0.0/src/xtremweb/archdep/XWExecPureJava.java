package xtremweb.archdep;

import java.io.*;                                                               
import java.util.*;                                                             
import xtremweb.common.*;              
import xtremweb.worker.*;              
                                                                  
public class  XWExecPureJava extends Logger implements XWExec{
    private Process workProcess = null;
    private boolean isRunning = false;
	
    private Thread outThread = null; 
    private Thread errThread = null;
    private Thread inThread = null;
    private OutputStream stdoutFile;
    private OutputStream stderrFile;
    private InputStream stdinFile = null;

    
    public XWExecPureJava(LoggerLevel l) {
        super(l);
        init();
    }

    public void init() {
        isRunning = false;
    }

    //Launch the execution on a separate process
    public boolean exec(String[] args, String stdin, String stdout, String stderr, String workingDir) {
        if(isRunning) {
            error("Cannot exec: a process already running");	    
            return false;
        }

        debug("Exec "+args[0]);

        try {
            stdoutFile = new FileOutputStream(new File(workingDir, stdout));
            stderrFile = new FileOutputStream(new File(workingDir, stderr));
        }
        catch (Throwable e) {
            error("executeNativeJob: can't create "+stdout+" and "+stderr);
            e.printStackTrace ();
            return false;
        } // end of try-catch

        try {
            workProcess =  Runtime.getRuntime().exec(args, null, new File(workingDir));	
        } 
        catch (Exception e) {
            error("ThreadLaunch in executeNativeJob: cannot spawn a new process" + e);
            return false;
        } // end of try-catch
    

        debug("apres exec");
        StreamPiper outPiper = new StreamPiper(workProcess.getInputStream(), stdoutFile);
        StreamPiper errPiper = new StreamPiper(workProcess.getErrorStream(), stderrFile);

        StreamPiper inPiper;
        outThread = new Thread((Runnable)outPiper);
        errThread = new Thread((Runnable)errPiper);
        inThread = null;
        outThread.start();
        errThread.start();


        if (workingDir != null && stdin != null) {
            File inputFile = new File(workingDir, stdin);
	
            if (stdin == null) {
                try { 
                    FileWriter fw = new FileWriter (inputFile);
                    fw.write ("");
                    fw.flush();
                    fw.close();								
                } catch  (Exception e) {
                    error("Exception: " + e);
                } 
            }
	    
            debug ("stdin :" + inputFile.getAbsolutePath ());
	    
            try {
                stdinFile = new FileInputStream(inputFile);
            }
            catch (FileNotFoundException e) {
                error("executeNativeJob: cannot open stdin file" + e);
                kill();
                return false;
            } // end of try-catch
	    
            inPiper = new StreamPiper(stdinFile, workProcess.getOutputStream());
            inThread = new Thread((Runnable)inPiper);
            inThread.start();
        }
        debug("isRunning true");
        isRunning = true;
        return true;
    }

    //Stop the curant execution
    public boolean kill() {
        debug("kill process");
        workProcess.destroy();
        isRunning = false;
        try { 
            if (outThread != null) {
                stdoutFile.close();
                outThread.join();
            }
            if (errThread != null) {
                stderrFile.close();
                errThread.join();
            }
            if (inThread != null) {
                stdinFile.close();
                inThread.join();
            }
        }
        catch (Exception e) {
            error("ThreadLaunch::executeNativeJob() : finalization error " + e);
            workProcess.destroy();
            return false;
        } // end of try-catch
	
        return true;
    }
    public boolean destroy() {
        return kill();
    }

    //Wait for the end of the current execution
    public int waitFor() {
        int res;
        try {
            res = workProcess.waitFor();
            isRunning=false;
            kill();	 
            return res;
        }
        catch (Exception e) {
            error ("run binary app failed: " + e);
            e.printStackTrace ();
            isRunning = true;
            return -1;
        }
    }

    //Suspend the current execution
    public boolean suspend() {
        return false;
    }

    //Re-activate the current execution
    public boolean activate() {
        return false;
    }

    public boolean isRunning() {
        return isRunning;
    }
}
