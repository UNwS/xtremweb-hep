package xtremweb.archdep;

// XWInterruptsLinux.java
// Created: Thu Jun 29 17:47:11 2000 by Gilles Fedak
//
// Tue May 28 2002 -- Samuel Heriard
//    - isActive() method moved to xtremweb.worker.MouseKbdActivator

import xtremweb.common.util;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 * <p>Linux implementation of <code>XWInterrupts</code></p>
 * <p>This implementation directly parse <code>/proc/interrupts</code></p>
 *
 * @author Gilles Fedak
 * @version %I% %G%
 */

public class XWInterruptsLinux implements XWInterrupts {

    /** 
     * This does nothing since there is no initialization need here.
     * @return always true
     */
    public boolean initialize () {
				return true;
    }

    /** Read /proc/interrupts to get the number binded to keyboard */
    public int readKey() {

        try {
            BufferedReader bufferFile =
                    new BufferedReader(new FileReader("/proc/interrupts"));
            String l = "";

            while (l != null) {
                if ((l.toLowerCase ().indexOf("keyboard") > -1) ||
										((l.toLowerCase ().indexOf(" 1:") > -1) && (l.toLowerCase ().indexOf("i8042") > -1))) {
                    l = l.substring(l.indexOf(':') + 1, l.length());
                    l = l.trim();
                    l = l.substring(0, l.indexOf(' '));
                    bufferFile.close();
                    return (new Integer(l)).intValue();
                }
                l = bufferFile.readLine();
            }

            bufferFile.close();
        } catch (Exception e) {
            System.err.println("Unrecoverable exception " + e);
						System.exit (1);
        }

        return 0;

    }

    /** Read /proc/interrupts to get the number binded to mouse */
    public int readMouse() {
        try {
            BufferedReader bufferFile =
                    new BufferedReader(new FileReader("/proc/interrupts"));
            String l = "";

            while (l != null) {
                if (l.toLowerCase ().indexOf("mouse") > -1) {
                    l = l.substring(l.indexOf(':') + 1, l.length());
                    l = l.trim();
                    l = l.substring(0, l.indexOf(' '));
                    bufferFile.close();
                    return (new Integer(l)).intValue();
                }
                l = bufferFile.readLine();
            }
            bufferFile.close();
        } catch (Exception e) {
            System.err.println("Unrecoverable exception" + e);
						System.exit (-1);
        }

        return 0;
    }
}

