package xtremweb.archdep;

import java.io.*;

//
//  XWUtilLinux.java
//  Samuel Heriard
//  
//  Linux impl. of XWUtil

public class XWUtilSolaris extends XWUtilDummy {

    private Runtime machine = Runtime.getRuntime();

    public void chmodpx(String s) {
        String [] cmdArray = new String[3];
        Process workProcess = null;
        int processReturnCode;

        System.err.println("chmod with sh "+s);

        cmdArray [0] = "/bin/sh";
        cmdArray [1] = "-c";
        cmdArray [2] = "chmod u+x "+s;

        try {
            workProcess =  Runtime.getRuntime().exec(cmdArray, null, null);	
            processReturnCode = workProcess.waitFor();	 
        }
        catch (Exception e) {
            System.err.println("chmod +x failed: " + e);
            e.printStackTrace ();
            //	    throw new WorkException (e.toString());
        }
    }

    public int getNumProc() {

        Process workProcess = null;
        int i = 0;
        int processReturnCode = 0;

        File tempFile = null;
        try {
            File.createTempFile("numProc", "txt");
        }
        catch(Exception  e) {
            System.err.println("Cannot create temp file");
            return -1;
        }
        if (!tempFile.exists())
            tempFile.delete ();

        try {
            workProcess = machine.exec ("/usr/sbin/psrinfo > " + tempFile.getAbsolutePath());
        } 
        catch (IOException e) {
            System.err.println ("XWUtilSolaris : cannot spawn a new process" + e);
            return -1;
        }

        try {
            processReturnCode = workProcess.waitFor();	 
        }
        catch (InterruptedException e) {
            System.out.println("ThreadLaunch in executeNativeJob: cannot wait for the end of the job ?!?" + e);
            return -1;
        }

        try {
            BufferedReader bufferFile = new BufferedReader (new FileReader(tempFile));
            String l = "";

            // one line per processor
            while (l != null ) {
                i = i + 1;
                l = bufferFile.readLine();
            }
            bufferFile.close ();
        }
        catch  (Exception e) {
            System.err.println(" Exception: " + e);
            return -1;
        }
      
        return i;
    }


    public int getSpeedProc() {
        String valStr = null;
        Process workProcess = null;
        int i = 0;
        int processReturnCode = 0;

        File tempFile = null;
        try {
            tempFile = File.createTempFile ("speedProc", "txt");
        }catch(Exception e) {
            System.err.println("Cannot create temp file");
            return -1;
        }

        if (!tempFile.exists())
            tempFile.delete ();

        try {
            workProcess = machine.exec ("/usr/sbin/psrinfo -v > " + tempFile.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("XWUtilSolaris : cannot spawn a new process" + e);
            return -1;
        }

        try {
            processReturnCode = workProcess.waitFor();	 
        } catch (InterruptedException e) {
            System.out.println("ThreadLaunch in executeNativeJob: cannot wait for the end of the job ?!?" + e);
            return -1;
        }

        try {
            BufferedReader bufferFile = new BufferedReader( new FileReader(tempFile));
            String l="";

            while ((l!= null) && (valStr == null)) {
                // each processor section has
                // operates at xxx MHz
                String operates = new String ("operates at ");
                int idx = l.indexOf (operates);
                if (idx != -1) {
                    valStr = l.substring(idx + operates.length () + 1,
                                         l.indexOf ("MHz") - 1);
                    break;
                }
                l = bufferFile.readLine();	
            }
            bufferFile.close();
        } catch  ( Exception e) {
            System.err.println(" Exception: " + e);
            return 0;
        }

        if (valStr != null)
            return new Float (valStr).intValue ();
        return 0;
    }

    public String getProcModel() {
        return new String ("");
    }


    public int getTotalSwap() {
        return 0;
    }

} //class XWUtilImpl
