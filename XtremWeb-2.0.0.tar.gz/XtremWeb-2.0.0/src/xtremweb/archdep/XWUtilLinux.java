package xtremweb.archdep;

import java.io.*;
import java.util.Vector;
import java.util.Iterator;
import java.util.StringTokenizer;

/**
 *  XWUtilLinux.java
 *  Samuel Heriard
 *  
 *  Linux impl. of XWUtil
 */
public class XWUtilLinux extends XWUtilImpl {


    private long machineTotal = 0, machineTotalOld = 0;
    private long machineUser  = 0, machineUserOld  = 0;
    private long machineNice  = 0, machineNiceOld  = 0;
    private long machineIdle  = 0, machineIdleOld  = 0;
    private long machineSys   = 0, machineSysOld  = 0;

    private long totalPidUserOld = 0;


    private Vector pids = null;

    public XWUtilLinux (){
    }


    /**
     * This retreives family PIDs
     *
     */
    public void raz () {
        pids = getProcessFamily (getPid ());
        if (pids == null)
            System.err.println("XWUtilLinux::raz () : can't pids");
        else {
            //System.out.println("XWUtilLinux::raz () : " + pids.size ());						
        }
    }


    /**
     * This retreives the CPU loads : user, nice, sys, idle and total loads
     * Param : $1 is the CPU number
     *
     */
    private void cpuLoads () {

        File procStats = new File( "/proc/stat");

        if (!procStats.exists()) {

            System.err.println( "Cannot read /proc/stat" );
            return;
        }

        try {
            BufferedReader bufferFile = new BufferedReader( new
                                                            FileReader(procStats));
            String line = "";

            line = bufferFile.readLine();	
            bufferFile.close();

            // each processor section begins with
            // cpu : jiffies ...

            if (line.indexOf("cpu") == 0) {

                StringTokenizer tokenizer = new StringTokenizer (line, "\t ");

                tokenizer.nextToken ();

                try {
                    long machineUserTmp = machineUser;
                    long machineNiceTmp = machineNice;
                    long machineSysTmp  = machineSys;
                    long machineIdleTmp = machineIdle;

                    long machineTotalTmp = machineTotal;

                    machineUser = new Long (tokenizer.nextToken ()).longValue ();
                    machineNice = new Long (tokenizer.nextToken ()).longValue ();
                    machineSys  = new Long (tokenizer.nextToken ()).longValue ();
                    machineIdle = new Long (tokenizer.nextToken ()).longValue ();

                    machineTotal = machineUser + machineNice + machineSys + machineIdle;


                    machineUserOld = machineUserTmp;
                    machineNiceOld = machineNiceTmp;
                    machineSysOld  = machineSysTmp;
                    machineIdleOld = machineIdleTmp;

                    machineTotalOld = machineTotalTmp;

                }
                catch (Exception e) {
                    System.err.println(" Exception: " + e);
                    return;
                }

            }
            else {
                System.err.println("can't find cpu line in /proc/stat");
            }

        } 
        catch  ( Exception e) {
            System.err.println(" Exception: " + e);
        }

        return;
    }


    /**
     * This retreives this machine average cpu load percentage
     * @return the average cpu load percentage (0 <= ret <= 100)
     */
    public int getCpuLoad () {


        cpuLoads ();

        long diffMachineTotal = machineTotal - machineTotalOld;
        long diffMachineUser  = machineUser  - machineUserOld;

        if (diffMachineTotal == 0)
            return 100;
        return (int)(diffMachineUser * 100 / diffMachineTotal);
    }


    /**
     * This retrieves the process group ID of the provided process
     * which is set by default to the PPID
     * See : man getpgrp
     * @param pid is the process PID
     * @return -1 on error
     */
    private int getProcessGroup (int pid) {

        File procStat = new File ("/proc/" + pid + "/stat");

        if (!procStat.exists ()) {
            System.err.println("can't get process group from /proc/" + pid + "/stat");
            return -1;
        }

        try {
            BufferedReader bufferFile = null;
            String line = "";

            try {
                bufferFile = new BufferedReader (new FileReader (procStat));
                line = bufferFile.readLine();	
            }
            catch (Throwable b) {
                b.printStackTrace ();
                System.err.println("XWUtilLinux::getProcessGroup () 00 : " + b);
                return -1;
            }

            bufferFile.close();

            StringTokenizer tokenizer = new StringTokenizer (line, "\t ");

            int thisChildPid = new Integer (tokenizer.nextToken ()).intValue ();

            for (int j = 0 ; j < 3; j++)
                tokenizer.nextToken ();


            try {
                return new Integer (tokenizer.nextToken ()).intValue ();
            }
            catch (Throwable e) {
                e.printStackTrace ();
                System.err.println("XWUtilLinux::getProcessGroup () 01 : " + e);
                return -1;
            }
        }
        catch  (Throwable e) {
            e.printStackTrace ();
            System.err.println("XWUtilLinux::getProcessGroup () 02: " + e);
        }

        return -1;
    }


    /**
     * This retreives the children PID of this process
     * including this process PID itself.
     * It is based on process groud ID which is set by defautl
     * to the PPID
     * See : man getpgrp
     * @param parent is the process PID
     * @see #getProcessGroup (int)
     */
    private Vector getProcessFamily (int parent) {

        Vector ret = new Vector ();
        File dir = new File ("/proc/");
        int grp = getProcessGroup (parent);

        if (grp == -1)
            return null;

        String[] list = dir.list ();

        for (int i = 0; i < list.length; i++) {

            File file = new File (dir, list [i]);
            File procStats = null;

            if (!file.isDirectory())
                continue;

            procStats = new File (file, "stat");
            if (!procStats.exists () || !procStats.isFile ())
                continue;

            try {
                BufferedReader bufferFile = null;
                String line = "";

                try {
                    bufferFile = new BufferedReader (new FileReader(procStats));
                    line = bufferFile.readLine();	
                }
                catch (Throwable b) {
                    b.printStackTrace ();
                    System.err.println("XWUtilLinux::getProcessFamily () 00 : " + b);
                    return null;
                }

                bufferFile.close();

                StringTokenizer tokenizer = new StringTokenizer (line, "\t ");

                int thisChildPid = new Integer (tokenizer.nextToken ()).intValue ();

                try {
                    int thisChildGid = getProcessGroup (thisChildPid);

                    if (thisChildGid == grp) {
                        ret.add (new Integer (thisChildPid));
                    }
                }
                catch (Throwable e) {
                    e.printStackTrace ();
                    System.err.println("XWUtilLinux::getProcessFamily () 01 : " + e);
                    return null;
                }
            } 
            catch (Throwable e) {
                e.printStackTrace ();
                System.err.println("XWUtilLinux::getProcessFamily () 02 : " + e);
                ret = null;
            }
        }

        return ret;
    }


    /**
     * This retreives the CPU load in user mode for the given PID
     * Param : $1 is the PID
     *
     */
    private int processUser (int pid) {

        File procStats = new File( "/proc/" + pid + "/stat");

        if (!procStats.exists()) {
            System.err.println("can't get process user from /proc/" + pid + "/stat");
            return 0;
        }

        try {
            BufferedReader bufferFile = null;
            String line = "";

            try {
                bufferFile = new BufferedReader (new FileReader(procStats));
                line = bufferFile.readLine();	
            }
            catch (Throwable b) {
                b.printStackTrace ();
                System.err.println("XWUtilLinux::getProcessUser () 00 : " + b);
                return 0;
            }

            bufferFile.close();

            StringTokenizer tokenizer = new StringTokenizer (line, "\t ");

            for (int i = 0 ; i < 13; i++)
                tokenizer.nextToken ();


            try {
                return new Long (tokenizer.nextToken ()).intValue ();
            }
            catch (Throwable e) {
                e.printStackTrace ();
                System.err.println("XWUtilLinux::getProcessUser () 01 : " + e);
                return 0;
            }
        } 
        catch (Throwable e) {
            e.printStackTrace ();
            System.err.println("XWUtilLinux::getProcessUser () 02 : " + e);
        }

        return 0;
    }


    /**
     * This retreives this process cpu load average, including all its children
     * @return the average cpu load percentage (0 <= ret <= 100)
     */
    public int getProcessLoad () {


        long diffMachineTotal = machineTotal - machineTotalOld;
        long diffMachineUser  = machineUser  - machineUserOld;

        /*
          if (diffMachineTotal == 0)
          return 0;
          long cpuPercentage = diffMachineUser * 100 / diffMachineTotal;

          if (cpuPercentage > 100) {
          Debug.debug ("processLoad () : cpuPercentage > 100");
          return 0;
          }
        */

        long totalPidUser = 0;

        if (pids == null) {
            System.err.println("processLoad () : pids == null");
            return 0;
        }

        Iterator theIterator = pids.iterator ();

        while (theIterator.hasNext()) {

            int pid = ((Integer)theIterator.next()).intValue ();

            totalPidUser = totalPidUser + (long)processUser (pid);
        }

        long diffPidUser = totalPidUser - totalPidUserOld;

        if (diffMachineTotal == 0)
            //return 0;
            diffMachineTotal = 100;

        int pidPercentage = (int)(diffPidUser * 100 / diffMachineTotal);

        totalPidUserOld = totalPidUser;

        //if (pidPercentage > 100)
        //		pidPercentage = 100;
        return pidPercentage;
    }


    /**
     * This retreives the amount of CPU available on this machine
     */
    public int getNumProc() {
        int i = 0;
        File procInterrupts = new File( "/proc/cpuinfo");

        if (!procInterrupts.exists()) {
            System.err.println( "Cannot read /proc/cpuinfo" );
            return 1;
        }

        try {
            BufferedReader bufferFile = new BufferedReader( new
                                                            FileReader(procInterrupts));
            String l="";

            while ( l!= null ) {
                // each processor section begins with
                // processor    : [proc #]
                if (l.indexOf("processor") == 0)
                    i = i + 1;
                l = bufferFile.readLine();	
            }
            bufferFile.close();
        }
        catch  ( Exception e) {
            System.err.println(" Exception: " + e);
            return 1;
        }
      
        return i;
    }


    public int getSpeedProc() {
        String valStr = null;
        File procInterrupts = new File( "/proc/cpuinfo");

        if (!procInterrupts.exists()) {
            System.err.println( "Cannot read /proc/cpuinfo" );
            return 0;
        }

        try {
            BufferedReader bufferFile = new BufferedReader( new
                                                            FileReader(procInterrupts));
            String l="";

            while ((l!= null) && (valStr == null)) {
                // each processor section has
                // cpu Mhz    : [speed]
                if (l.indexOf("cpu MHz") != -1) {
                    int start = l.indexOf(":") + 1;
                    if (start != -1)
                        valStr = l.substring(start);
                }
                l = bufferFile.readLine();	
            }
            bufferFile.close();
        } catch  ( Exception e) {
            System.err.println(" Exception: " + e);
            return 0;
        }

        if (valStr != null)
            return new Float (valStr).intValue ();
        return 0;
    }

    public String getProcModel() {
        String valStr = null;
        File procInterrupts = new File( "/proc/cpuinfo");

        if (!procInterrupts.exists()) {
            System.err.println( "Cannot read /proc/cpuinfo" );
            return new String ();
        }

        try {
            BufferedReader bufferFile = new BufferedReader( new
                                                            FileReader(procInterrupts));
            String l="";

            while ((l!= null) && (valStr == null)) {

                if (l.indexOf("model name") != -1) {
                    int start = l.indexOf(":") + 1;
                    if (start != -1)
                        valStr = l.substring(start);
                }
                l = bufferFile.readLine();	
            }
            bufferFile.close();
        } catch  ( Exception e) {
            System.err.println(" Exception: " + e);
            return new String ();
        }

        if (valStr != null)
            return valStr;
        return new String ();
    }


    public int getTotalMem() {
        String valStr = null;
        File procInterrupts = new File( "/proc/meminfo");

        if (!procInterrupts.exists()) {
            System.err.println( "Cannot read /proc/meminfo" );
            return 0;
        }

        try {
            BufferedReader bufferFile = new BufferedReader( new
                                                            FileReader(procInterrupts));
            String l="";

            while ((l!= null) && (valStr == null)) {
                if (l.indexOf("MemTotal") != -1) {
                    int start = l.indexOf(":") + 1;
                    if (start != -1)
                        valStr = l.substring(start);
                }
                l = bufferFile.readLine();	
            }
            bufferFile.close();
        } catch  ( Exception e) {
            System.err.println(" Exception: " + e);
            return 0;
        }

        if (valStr != null) {
            int kb = valStr.indexOf("kB");

            return new Float (valStr.substring (0,kb)).intValue ();
        }
        return 0;
    }


    public int getTotalSwap() {
        String valStr = null;
        File procInterrupts = new File( "/proc/meminfo");

        if (!procInterrupts.exists()) {
            System.err.println( "Cannot read /proc/meminfo" );
            return 0;
        }

        try {
            BufferedReader bufferFile = new BufferedReader( new
                                                            FileReader(procInterrupts));
            String l="";

            while ((l!= null) && (valStr == null)) {
                if (l.indexOf("SwapTotal") != -1) {
                    int start = l.indexOf(":") + 1;
                    if (start != -1)
                        valStr = l.substring(start);
                }
                l = bufferFile.readLine();	
            }
            bufferFile.close();
        } catch  ( Exception e) {
            System.err.println(" Exception: " + e);
            return 0;
        }

        if (valStr != null) {
            int kb = valStr.indexOf("kB");

            return new Float (valStr.substring (0,kb)).intValue ();
        }
        return 0;
    }

    /**
     * This is the standard main () method
     * args[0] may contain a PID to calculate its user CPU usage
     */
    public static void main(String[] args) {
  
        XWUtilLinux cpu = new XWUtilLinux ();

        while(true) {

            int cpuLoad = cpu.getCpuLoad ();
            if (args.length > 0)
                try {
                    cpu.pids = cpu.getProcessFamily (new Integer (args [0]).intValue ());
                    int processLoad = cpu.getProcessLoad ();
                    System.out.print ("%CPU = " + cpuLoad);
                    System.out.print ("  %CPU ["+ args [0] + "] = " + processLoad);
                    System.out.println ("  allocated = " + (int)(cpuLoad - processLoad));
                }
                catch (Exception e) {
                    System.out.print ("\n" + e.toString ());
                    e.printStackTrace ();
                }

            try {
                //intervalle en ms.
                java.lang.Thread.sleep(1000);
            }
            catch (Exception e) {
            }
        }
    }

} //class XWUtilLinux
