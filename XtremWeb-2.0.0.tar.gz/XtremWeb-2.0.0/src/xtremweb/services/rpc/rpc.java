package xtremweb.services.rpc;

/**
 * Date    : Mar 25th, 2005
 * Project : RPCXW / RPCXW-C
 * File    : CallbackPipe.java
 *
 * @author <a href="mailto:lodygens_a_lal.in2p3.fr">Oleg Lodygensky</a>
 * @version
 * @since RPCXW
 */

import xtremweb.common.*;
import xtremweb.archdep.*;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This class forwards RCP on UDP.
 * @see xtremweb.archdep.PortMapperItf
 */
public class rpc extends Logger implements Interface  {

		/**
		 * This aims to display some time printlns
		 */
		MileStone mileStone;
		/**
		 * This is the RPC port to forward client requests to This RPC server port
		 * must be determined at runtime
		 */
		protected int rpcServerPort = 0;
		/**
		 * This is the RPC host name to forward client requests to The RPC server is
		 * supposed to run on local host
		 */
		protected String hostName;
		/**
		 * This is the RPC host to forward client requests to The RPC server is
		 * supposed to run on local host
		 */
		protected InetAddress serverHost = null;
		/**
		 * This is the transfert buffer size
		 */
		protected final int BUFSIZE = 8192;
		/**
		 * This is the file name packet that RPCXW-S forwards to the SunRPC
		 * server We write content from SunRPC client to this file; RPCXW-S
		 * reads and forwards it to the SunRPC server
		 */
		protected final String FILEIN = "packet-in.bin";

		/**
		 * This is the file name packet that RPCXW-S received from the SunRPC
		 * server RPCXW-S writes this file and we must forward the content to
		 * the SunRPC client
		 */
		protected final String FILEOUT = "packet-out.bin";
		/**
		 * This is the results
		 */
		private byte[] datas;
		/**
		 * This is the user id
		 */
		private int userID;
		/**
		 * This is the group id
		 */
		private int groupID;


		/**
		 * This contructs a new object, retreiving this host name and
		 * this application user and group ID<br />
		 * Logger level is set to Level.INFO
		 */
		public rpc() {

				datas = null;
				level = LoggerLevel.INFO;

				try {
						//serverHost = InetAddress.getByName(hostName);
						serverHost = InetAddress.getLocalHost();
						hostName = serverHost.getHostName();
				} catch (Exception e) {
						util.fatal("InetAddress.getLocalHost() : " + e);
				}
                groupID = ArchDepFactory.xwutil().getGid();
                debug("GID = " + groupID);
				userID  = ArchDepFactory.xwutil().getUid();
                debug("UID = " + userID);

				mileStone = new MileStone(getClass().getName());

// 				System.out.print("\n\n\nStarting services.rpc.rpc  ");
// 				System.out.print("UID = " + userID + "  GID = " + groupID + "  hostName = " + hostName);
// 				System.out.println("\n\n\n");
		}

		/**
		 * This calls the default constructor and set logger level
		 * @param l is the logger level
		 * @see #rpc()
		 */
		public rpc(LoggerLevel l) {
				this();
				setLevel(l);
		}

		/**
		 * This sets the logger level
		 * @param l is the logger level
		 */
		public void setLevel(LoggerLevel l) {
            level = l;
				//io.setLevel(l);
		}

		/**
		 * This implements the Interface exec() method
		 * @see xtremweb.services.Interface
		 */
		public int exec(String cmdLine, byte[] stdin, byte[] dirin) {

            debug("rpc.exec " + cmdLine + " " + stdin + " " + dirin);

				int ret = -1;
				if (cmdLine == null) {
                    error("no param found!!!");
						return ret;
				}
				if (dirin == null) {
                    error("no packet found!!!");
						return ret;
				}

				try {
						if (cmdLine.indexOf("--udp") != -1)
								ret = udp(dirin);
						else
								util.fatal("unknwon command line : " + cmdLine);
				}
				catch(Exception e) {
						ret = -1;
                        error(e.toString());
				}

				return ret;
		}


		/**
		 * This implements the Interface getResult() method by returning the <code>datas</code> member
		 * @see xtremweb.services.Interface
		 * @see #datas
		 */
		public byte [] getResult(){
				return datas;
		}


		/**
		 * This connects RPC clients to RPC servers with a simple pipe. This is
		 * called on UDP connections.<br />
		 * 
		 * It first determines RPC server to connect to, thanks to client RPC
		 * message, forwards packet to RPC and waits for an answer
		 * 
		 * @param newDatas is the packet to forward to RPC
		 * @return 0 on success, 1 on error (couldn't determine RPC service)
		 * @see xtremweb.archdep.PortMapperItf
		 */
		protected int udp(byte[] newDatas) throws Exception {

				DatagramSocket serverSocket = null;
				DatagramPacket serverPacket = null;

				mileStone.println("XW RPC service started");

                debug("Callback length 00 = " + newDatas.length);

				Packet request = new Packet(newDatas, newDatas.length,
                                            level,hostName,
                                            userID, groupID);

				mileStone.println("XW RPC service packet ready");

                debug("Callback length 01 = " + request.getBuffer().length);

				int prog = request.getProg();
				int version = request.getVersion();
				String proc = null;

				switch (prog) {
				case rpcdefs.RPC_NFS:
						proc = rpcdefs.NFSPROC_TEXT[request.getProc()];
						break;
				case rpcdefs.RPC_MOUNT:
						proc = rpcdefs.MOUNTPROC_TEXT[request.getProc()];
						break;
				}


				rpcServerPort = ArchDepFactory.portMap().getudpport(prog, version);
				if(rpcServerPort <= 0) {
                    error("can't retreive RPC port");
						return 1;
				}

				//				System.out.println("Services.RPC;forwarding;" + new Date().getTime());

                debug("prog " + prog + " version " + version);

				serverSocket = new DatagramSocket();

                debug("newDatas.length = " + newDatas.length);
                debug("request.getLength() = " + request.getLength());
				serverPacket = new DatagramPacket(request.getBuffer(), request.getLength(),
																					serverHost, rpcServerPort);

                debug("writing to " + hostName + ":" + rpcServerPort);

				//
				// Sending the job
				//

				mileStone.println(proc + " sending");

				serverSocket.send(serverPacket);

				mileStone.println(proc + " waiting result");

				byte[] buf = new byte[BUFSIZE];
				serverPacket.setData(buf);
                debug("waiting answer from " + hostName + ":" + rpcServerPort);

				serverSocket.receive(serverPacket);

				mileStone.println(proc + " got result");

				int nbBytes = serverPacket.getLength();
                debug("nbBytes = " + nbBytes);

				datas = new byte[nbBytes];
 				if (datas != null)
 						debug("datas.length = " + datas.length);
 				else
 						debug("datas is null ?!?!?!?!?!");

				System.arraycopy(serverPacket.getData(), 0, datas, 0, nbBytes);

				mileStone.println(proc + " executed");

				return 0;
		}

}
