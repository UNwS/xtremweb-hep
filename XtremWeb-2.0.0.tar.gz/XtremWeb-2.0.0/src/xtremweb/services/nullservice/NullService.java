package xtremweb.services.nullservice;

/**
 * Date    : Nov 20th, 2005 <br />
 * File    : NullService.java
 *
 * @author <a href="mailto:lodygens_a_lal.in2p3.fr">Oleg Lodygensky</a>
 * @version
 * @since RPCXW
 */

import xtremweb.common.*;
import xtremweb.archdep.*;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This class does nothing. This is only an XtremWeb service test
 */
public class NullService extends Logger implements Interface {

		/**
		 * This aims to display some time printlns
		 */
		MileStone mileStone;

		/**
		 * This contructs a new object
		 */
		public NullService() {

				level = LoggerLevel.INFO;
				mileStone = new MileStone(getClass().getName());
		}

		/**
		 * This calls the default constructor and set logger level
		 * @param l is the logger level
		 * @see #rpc()
		 */
		public NullService(LoggerLevel l) {
				this();
				setLevel(l);
		}

		/**
		 * This sets the logger level
		 * @param l is the logger level
		 */
		public void setLevel(LoggerLevel l) {
            level = l;
		}
		/**
		 * This implements the Interface exec() method<br />
		 * This does nothing
		 * @return always 0
		 */
		public int exec(String cmdLine, byte[] stdin, byte[] dirin) {
				mileStone.println("XW NullService started");
				mileStone.println("XW NullService done");
				return 0;
		}
		/**
		 * This implements the Interface getResult() method
		 * @see xtremweb.services.Interface
		 * @return always null
		 */
		public byte [] getResult(){
				return null;
		}
}
