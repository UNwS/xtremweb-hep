package xtremweb.servreg;

import java.io.*;
import java.net.*;
import java.util.*;
import xtremweb.common.*;
import xtremweb.XwIDL.*;

/**
 * ServiceBrowser.java
 * This is a HTML interface to browse the available service
 *
 * Created: Fri May  2 15:06:46 2003
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */
public class ServiceBrowser {

    static int webPort = 8080;


    class WebConn extends Thread {
				Socket socket;
				private BufferedInputStream  input;
				private BufferedOutputStream output;

				public WebConn(Socket sock) throws IOException {
						socket = sock;
						input  = new BufferedInputStream (socket.getInputStream());
						output = new BufferedOutputStream (socket.getOutputStream());
				}

				public void run() {
						try {
								String line = readLine ();
								if ("".equals (line))
										line = readLine();
								System.out.println(line);
								print("<html><body>");
								print("<center><h1>Service Browser</h1></center>");

								if ( line.startsWith("GET ") && line.startsWith(" HTTP/1.1", (line.length()-9)) ) {
										print("<center><h1>OK</h1></center>");
								} else {
										print("<center><h1>PAS OK</h1></center>");
								} // end of else
		
		
								print("</html></body>\n\r");
								output.flush();
								socket.close();
						} catch ( IOException  ioe) {
								System.err.println("" + ioe);
						} // end of try-catch

				}

				private void  print(String s) throws IOException {
						output.write ( s.getBytes() );
				}

				byte[] buffer;
				private String readLine () throws IOException {

						if (buffer == null) {
								buffer = new byte[512];
						}
						int next;
						int count = 0;
						for (;;) {
								next = input.read();	
								if (next < 0 || next == '\n')
										break;
								if (next != '\r') {
										buffer[count++] = (byte) next;
								}
								if (count >= 512)
										throw new IOException ("HTTP Header too long");
						}
						return new String (buffer, 0, count);
				}
    } //class WebConn

    public ServiceBrowser(int port) {

				try {
						ServerSocket ss = new ServerSocket( port );
						while ( true ) {	    
								Socket socket = ss.accept();
								(new WebConn( socket)).start();
						} // end of while ()	    
				} catch (Exception e) {
						util.fatal("not able to start a web server on port :" + port + " because : " +e);
				} // end of try-catch

    } // ServiceBrowser constructor



    public static void main(String[] args) {
				//Load a Service Registry
				new ModuleLoader();
				ModuleLoader.rmiBackPort=4347;
				ModuleLoader.rmiPort=4342;
				try {
						ModuleLoader.addCallback( "servreg" );
				} catch (ModuleLoaderException e) {
						System.err.println("ModuleLoader main(): " +  e);
						System.exit( 1);
				}
				try {
						ModuleLoader.addHandler( "servreg", "RMI", 4342 );
				} catch (ModuleLoaderException e) {
						System.err.println("ModuleLoader main(): " +  e);
						System.exit( 1);
				}
				//push dispatcher as a remote servreg 
				try {
						((Callbackservreg) ModuleLoader.getModule("servreg")).sr.registerServices( "servreg", new UID(), InetAddress.getLocalHost() , 4322);
				} catch ( Exception uhe) {
						System.err.println("Cannot register dispatcher " +uhe);
				} // end of try-catch

				//create the service browser
				/*
					CommRMIservreg comm = new CommRMIservreg();
					try {
					comm.initComm( "him", 4342, "servreg");
					ServiceLocator sl = comm.findService( "servreg" );
					Debug.Info("Found service servreg :" + sl.uid + sl.ip );
					} catch ( CommException e) {
					Debug.Warning("Cannot find service " +e);
					} // end of try-catch
				*/
				ServiceBrowser sb = new ServiceBrowser(webPort);
	 
    } // end of main()
    
    
} // ServiceBrowser
