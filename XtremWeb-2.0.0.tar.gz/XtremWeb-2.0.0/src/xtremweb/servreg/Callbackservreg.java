package xtremweb.servreg;

import xtremweb.XwIDL.*;
import xtremweb.common.util;
import xtremweb.common.LoggerLevel;
import xtremweb.communications.*;

import java.util.*;
import java.net.*;
import java.rmi.server.UID;


/**
 * Callbackservreg.java
 *
 * From the outside world, a Service Registry is read only
 *
 * Created: Fri Apr 25 19:34:57 2003
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */
public class Callbackservreg extends CallbackTemplate {

    public ServiceRegistry sr;

    /**
     * <code>findService</code>.
     * provides a look up mecanism for the service
     *
     * @param service a <code>String</code> value is 
     * the name of the service
     * @return a <code>ServiceLocator</code> found
     */
    public ServiceLocator findService( String service ) {
        //Lookup the local services
        LinkedList lf = sr.getServiceLocators(service);
        for ( ListIterator li = lf.listIterator();
              li.hasNext(); ) { 
            ServiceLocator  sl = ((ServiceLocator) li.next());
            //						logger.info("Found LoCAL service "+ service+" on : " + sl.uid + ":" + sl.ip + ":" + sl.port);
        }
        //Let's look elsewhere
        LinkedList ll = sr.getServiceLocators("servreg");
        CommRMIservreg comm = new CommRMIservreg();
        for ( ListIterator li = ll.listIterator();
              li.hasNext(); )  {
            ServiceLocator  sl = ((ServiceLocator) li.next());
            //Not me please !
            if ( sl.uid.equals(sr.getUID()) == false) {	    
                //								logger.info("-> SERVREG: lookup on remote for [" +  service + "] host[ " + sl.ip +":"+ sl.port+"]");
                //one by one for every server
                try {
                    comm.initComm( sl.ip , sl.port, "servreg");
                    ServiceLocator sfist = comm.findService( service );
                    //										logger.info("Found REMOTE service "+ service+"on : " + sfist.uid + ":" + sfist.ip + ":" + sfist.port);
                    //lf.add(sfist);
                } catch (Exception e) {
                    //										logger.warn("Service servreg is registred but cannot be contacted" + e);
                } // end of try-catch
            }
        }
        //				logger.info("Preparing Result : " + lf.size());
        if ( lf.size() == 0) {
            //						logger.info("Reslt NULL");
            ServiceLocator sl = new ServiceLocator();
            sl.ip="null";
            sl.port=0;
            sl.uid=null;
            sl.comLayer="null";
            return sl;
        } else {
            //						logger.info("Reslut non NULL");
            ServiceLocator sl = (ServiceLocator) lf.getFirst();
            //						logger.info("-> RESULT [" +  service + "] host[ " + sl.ip +":"+ sl.port+"] " + sl.uid);
            return sl;
        } // end of else
    }

    /**
     * Creates a new <code>Callbackservreg</code> instance.
     *
     */
    public Callbackservreg(LoggerLevel l) {
        sr = new ServiceRegistry();
        //register itself as a service
        InetAddress myIP;
        try {
            myIP= InetAddress.getLocalHost();
            sr.registerServices( "servreg", sr.getUID(), myIP , ModuleLoader.rmiPort);
        } catch(UnknownHostException e) {
            System.err.println("Can't guess it's own ip");
            System.exit(1);
        }
    }
} 
