package xtremweb.servreg;

import xtremweb.common.UID;
import java.net.*;
import java.util.*;

/**
 * ServiceRegistry.java
 *
 *
 * Created: Mon Apr  8 19:20:56 2002
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version
 */

public class ServiceRegistry {

    private Hashtable servicesRegistry;
    private UID uid;

    public ServiceRegistry () {
        servicesRegistry = new Hashtable();
        uid = new UID();
    }

    public UID getUID() {
        return uid;
    }

    public void  registerServices( String serviceName, UID uid, InetAddress ip, int port) {
        //check if there is already one service named service Name and registered 
        LinkedList locators;
        if ( servicesRegistry.containsKey( serviceName) ) {
            locators = (LinkedList) servicesRegistry.get( serviceName
                                                          );
        } else {
            locators = new LinkedList();
            servicesRegistry.put( serviceName, locators);
        }
        ServiceLocator slor = new ServiceLocator();
        slor.uid=uid;
        slor.ip = ip.getHostAddress();
        slor.port=port;
        locators.add(slor);
        System.out.println("SERV: "+ "register remote service for " +  serviceName + " host: " + ip.getHostAddress() +":" +port);
        //	XWShell.sendEvent("SERV", "register remote service for " +  serviceName + " host: " + ip.getHostAddress() +":" +port);
    }

    public void unRegisterServices( String serviceName,
                                    UID uid) {
        if ( servicesRegistry.containsKey( serviceName) ) {
            LinkedList locators = (LinkedList) servicesRegistry.get( serviceName );
            //find out the correct server and remove it from the list
            for ( ListIterator li = locators.listIterator();
                  li.hasNext(); )  {
                ServiceLocator  sl = ((ServiceLocator) li.next());
                if (sl.uid.equals(uid)) {
                    System.out.println("SERV: "+ "un register remote service for " +  serviceName + " host: " + sl.ip + " UID("+ sl.uid + ")");
                    li.remove();
                    //	XWShell.sendEvent("SERV", "unregister remote service
                    //	for " +  serviceName + " host: " +
                    //	ip.getHostAddress() +":" +port);
                    break;
                } 
            } 	    
        } 
    }

    public void unRegisterServer( UID uid ) {
        //remove at every services 
        for (Enumeration e = servicesRegistry.keys() ; e.hasMoreElements() ;) {
            unRegisterServices( (String) e.nextElement(), uid);
        }
    }

    public LinkedList getServiceLocators( String serviceName){
        if ( servicesRegistry.containsKey( serviceName) ) {
            return (LinkedList) servicesRegistry.get( serviceName
                                                      );
        } else {
            return new LinkedList();
        } 
    }

    //just to debug
    public static void main (String[] args) {
        InetAddress myIP;
        ServiceRegistry sr = new ServiceRegistry();
        try {
            myIP= InetAddress.getLocalHost();
            sr.registerServices( "checkpoint", sr.uid , myIP, 4356);
            sr.registerServices( "mpi", sr.uid , myIP, 4356);
            sr.unRegisterServer(  sr.uid );
        } catch(UnknownHostException e) {
            System.err.println("Can't guess it's own ip");
            System.exit(1);
        }
    }

}// ServiceRegistry
