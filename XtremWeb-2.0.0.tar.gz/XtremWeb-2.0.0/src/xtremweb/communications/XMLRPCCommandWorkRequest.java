package xtremweb.communications;

import xtremweb.common.*;

import java.io.*;
import java.util.Vector;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLRPCCommandWorkRequest.java
 *
 * Created: Nov 16th, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class defines the XMLRPCCommand to send work definition
 */
public class XMLRPCCommandWorkRequest extends XMLRPCCommand {

    /**
     * This is the RPC id
     */
    public static final IdRpc IDRPC = IdRpc.WORKREQUEST;
    /**
     * This is the XML tag
     */
    public static final String THISTAG = IDRPC.toString();


    /**
     * This constructs a new commadn
     */
    public XMLRPCCommandWorkRequest() throws IOException {
	super(IDRPC);
    }
    /**
     * This constructs a new command
     * @param h defines the caller
     */
    public XMLRPCCommandWorkRequest(HostInterface h) throws IOException {
	this();
	setHost(h);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     */
    public XMLRPCCommandWorkRequest(DataInputStream input) throws IOException{
	this();
	super.fromXml(input);
    }


    /**
     * This does nothing since this has no attribute
     */
    public void fromXml(Attributes attrs) throws IOException {
    }

    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public void xmlElementStart(String uri, String tag, String qname, 
				Attributes attrs)
	throws IOException {

	debug("Start element - " + qname);

	if(qname.compareToIgnoreCase(XMLTAG) == 0)
	    fromXml(attrs);
	else if(qname.compareToIgnoreCase(UserInterface.THISTAG) == 0)
	    user = new UserInterface(attrs);
	else if(qname.compareToIgnoreCase(HostInterface.THISTAG) == 0)
	    host = new HostInterface(attrs);
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
	try {
	    XWConfigurator config = new XWConfigurator(argv[0], false);
	    XMLRPCCommandWorkRequest cmd = new XMLRPCCommandWorkRequest(config._host);
	    if(argv.length == 1) {
		System.out.println(cmd.toXml());
	    }
	    else {
		cmd = new XMLRPCCommandWorkRequest(new DataInputStream(new FileInputStream(argv[1])));
		System.out.println(cmd.toXml());
	    }
	}
	catch(Exception e) {
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}
