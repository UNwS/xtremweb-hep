package xtremweb.communications;

import xtremweb.common.*;

import java.io.*;
import java.util.Vector;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLRPCCommandDisconnect.java
 *
 * Created: Nov 16th, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class defines the XMLRPCCommand to disconnect
 */
public class XMLRPCCommandDisconnect extends XMLRPCCommand {

    /**
     * This is the RPC id
     */
    public static final IdRpc IDRPC = IdRpc.DISCONNECT;
    /**
     * This is the XML tag
     */
    public static final String THISTAG = IDRPC.toString();

    /**
     * This constructs a new command
     * @param cmd is an IrRpc
     * @see xtremweb.communications#IdRpc
     * @see XMLRPCCommandDisconnect(String)
     */
    public XMLRPCCommandDisconnect() throws IOException {
	super(IDRPC);
    }

    /**
     * This constructs a new command
     * @param cmd is an IrRpc
     * @see xtremweb.communications#IdRpc
     * @see XMLRPCCommandDisconnect(String)
     */
    public XMLRPCCommandDisconnect(UserInterface u) throws IOException {
	this();
	setUser(u);
    }

    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLRPCCommandDisconnect(DataInputStream input) throws IOException{
	this();
	super.fromXml(input);
    }


    /**
     * This always throws an exception since XMLRPCCommandDisconnect has no attributes
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {
    }

    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public void xmlElementStart(String uri, String tag, String qname, 
				Attributes attrs)
	throws IOException {

	debug("Start element - " + qname);

	if(qname.compareToIgnoreCase(XMLTAG) == 0)
	    fromXml(attrs);
	else if(qname.compareToIgnoreCase(UserInterface.THISTAG) == 0)
	    user = new UserInterface(attrs);
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
	try {
	    XWConfigurator config = new XWConfigurator(argv[0], false);
	    XMLRPCCommandDisconnect cmd = new XMLRPCCommandDisconnect(config._user);
	    if(argv.length == 1) {
		System.out.println(cmd.toXml());
	    }
	    else {
		cmd = new XMLRPCCommandDisconnect(new DataInputStream(new FileInputStream(argv[1])));
		System.out.println(cmd.toXml());
	    }
	}
	catch(Exception e) {
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}
