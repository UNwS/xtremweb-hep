package xtremweb.communications;

import xtremweb.common.util;
import xtremweb.common.LoggerableThread;
import xtremweb.common.LoggerLevel;

import java.util.Properties;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;


/**
 * This is the communications server part.
 * This listens to requests.
 * @author Oleg Lodygensky
 * @since RPCXW
 * @see #CommHandler
 */
public abstract class CommServer extends LoggerableThread {
    
    /**
     * This is the communication handler
     */
    protected CommHandler handler;

    protected int port;

    /** 
     ** This is the only constructor
     * @param l is the logger level
     */
    protected CommServer(String n, LoggerLevel l) {
        super(n, l);
    }

    /**
     * This initializes communications
     * @param p is a Properties object to retreive config (ports...)
     * @param h is a CommHandler object to handle communications
     */
    public abstract void initComm(Properties p, CommHandler h) throws RemoteException;

}//class CommServer
