package xtremweb.communications;

import xtremweb.common.XWPropertyDefs;
import xtremweb.common.LoggerLevel;
import xtremweb.common.util;

import java.io.IOException;
import java.nio.channels.Selector;
import java.nio.channels.SelectionKey;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.spi.SelectorProvider;
import java.rmi.RemoteException;
import java.net.Socket;
import java.net.ServerSocket;
import java.net.InetSocketAddress;
import java.util.Set;
import java.util.Iterator;
import java.util.Properties;

/**
 * <p>
 * This class implements a generic TCP server<br />
 * This instanciates a new CommHandler on each new connection.
 * </p>
 *
 * <p>Created: Jun 7th, 2005</p>
 *
 * @see CommHandler
 * @author Oleg Lodygensky
 * @since RPCXW
 */

public class TCPServer extends CommServer {

    /**
     * This is this thread name
     */
    private static final String NAME = "TCPServer";
    /**
     * This is the NIO server
     */
    private ServerSocketChannel nioServer = null;
    /**
     * This is the NIO socket selector
     */
    Selector acceptSelector = null;
    /**
     * This is the NIO socket key
     */
    SelectionKey acceptKey = null;
    /**
     * This is the standard IO server
     */
    private ServerSocket ioServer = null;
    /**
     * This tells whether to use NIO or not
     * This contains value is read from config file
     */
    private boolean nio;

    /**
     * This constructs a new instance
     * @param lable is this thread label
     * @param l is the logger level
     */
    protected TCPServer(String label, LoggerLevel l){
        super(label, l);
        nio = true;
    }

    /**
     * This constructs a new instance
     * @param l is the logger level
     */
    public TCPServer(LoggerLevel l){
        this(NAME, l);
    }

    /**
     * This initializes communications
     * @see CommServer#initComm(Properties, CommHandler)
     */
    public void initComm(Properties prop, CommHandler h) {

        port = Connection.TCP.defaultPortValue();

        try{
            String proptxt = prop.getProperty(Connection.TCP.propertyName());
            if (proptxt != null)
                port = new Integer (proptxt.trim ()).intValue ();

            handler = h;
            handler.setLoggerLevel(level);

            proptxt = prop.getProperty(XWPropertyDefs.NIO.toString());
            nio = true;
            if(proptxt != null)
                nio = (proptxt.compareToIgnoreCase("true") == 0);

            setName(NAME + (nio ? "NIO" : ""));

            if(nio) {
                nioServer = ServerSocketChannel.open();
                nioServer.configureBlocking(false);
                nioServer.socket().bind(new InetSocketAddress(port));
                acceptSelector = SelectorProvider.provider().openSelector();
                acceptKey = nioServer.register(acceptSelector,
                                               SelectionKey.OP_ACCEPT);
            }
            else
                ioServer = new ServerSocket(port);

            Runtime.getRuntime().addShutdownHook(new Thread(getName() + "Cleaner") {
                    public void run() {
                        cleanup();
                    }
                });
        }
        catch(Exception e) {
            util.fatal(getName() + ": could not listen on port " + port + " : " + e);
        }
    }

    /**
     * This indefinitly waits for incoming connections<br />
     * This uses the CommHandler to handle connections
     * @see CommServer#handler
     */
    public void run() {

        info("started, listening on port : " + port);

        while(true) {

            try{
                if(nio) {
                    /*
                      SocketChannel sChannel = nioServer.accept();

                      if(sChannel == null) {
                      try {
                      Thread.sleep(50);
                      }
                      catch(InterruptedException e) {
                      }

                      continue;
                      }

                      handler.setSocket(sChannel.socket());
                      handler.run();
                    */

                    int keysAdded = 0;
                    while ((keysAdded = acceptSelector.select()) > 0) {

                        // Someone is ready for I/O, get the ready keys
                        Set readyKeys = acceptSelector.selectedKeys();
                        Iterator i = readyKeys.iterator();
			
                        // Walk through the ready keys collection and process date requests.
                        while (i.hasNext()) {
                            SelectionKey sk = (SelectionKey)i.next();
                            i.remove();
                            // The key indexes into the selector so you
                            // can retrieve the socket that's ready for I/O
                            ServerSocketChannel nextReady = 
                                (ServerSocketChannel)sk.channel();
                            /*
                              handler.setSocket(nextReady.accept().socket());
                              handler.run();
                            */
                            CommHandler h  = (CommHandler)handler.getClass().newInstance();
                            h.setLoggerLevel(level);
                            h.setSocket(nextReady.accept().socket());
                            h.start();
                        }
                    }
                }
                else {
                    Socket socket = ioServer.accept();

                    CommHandler h  = (CommHandler)handler.getClass().newInstance();
                    h.setLoggerLevel(level);
                    h.setSocket(socket);
                    h.start();
                } 
            }
            catch(Exception e) {
                if(debug())
                    e.printStackTrace();
                util.fatal(getName() + " error " + e);
            }
						
        }

    } // run()

    /**
     * This is called on program termination (CTRL+C)
     * This deletes session from server
     */
    protected void cleanup() {
        try {
            debug("cleanup");
            if(nio)
                nioServer.close();
            else
                ioServer.close();
        }
        catch(Exception e) {
            error("can't clean up");
        }
    }

}
