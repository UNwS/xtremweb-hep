package xtremweb.communications;

import xtremweb.common.CommandLineParser;

import java.io.IOException;

/**
 * IdRpc.java
 * <br />
 *
 * Each value has an XMLRPCCommand object, expect if notified not
 * <br />
 *
 * Created: Thu May 31 10:03:43 2001
 * <br />
 *
 * This is used to create communication messages.
 * This is used as client command line argument.
 *
 * Available client command line arguments :
 * <ul>
 * <li> --xwdisconnect  : this closes session; this deletes all session jobs
 * <li> --xwclose  : this closes group; this deletes all group jobs
 * <li> --xwsendapp  appName cpuType osName URI : this sends/updates application; URI points to binary file
 * <li> --xwget  UID [UID ...] : this retrevies descriptions from server
 * <li> --xwgetapps : this retreives all app description from server
 * <li> --xwremove UID [UID...]  : this removes objects from server
 * <li> --xwsendgroup groupName sessionUID clientUID : this sends/updates a group
 * <li> --xwgetgroups  : this retreives all group description from server
 * <li> --xwgetgroupworks : this retreives all group works UID from server
 * <li> --xwgethosts  : this retrevies all host description from server
 * <li> --xwactivatehost hostUID [hostUID...] [on|off] : this activate/deactivate host for computation
 * <li> --xwsendsession sessionName clientUID : this sends/updates a session
 * <li> --xwgetsessions : this retreives all session description from server
 * <li> --xwsessionworks : this retreives all session works UID from server
 * <li> --xwgettasks : this retreives all task description from server
 * <li> --xwsendusergroup usergroupName : this sends/updates user group
 * <li> --xwgetusergroups : this retreives an user group description from server
 * <li> --xwsenduser login password email rights : this sends/updates user;
 *        see xtremweb.common.UserRights to see available values
 * <li> --xwgetusers : this retrevies all user description from server
 * <li> --xwsendwork workXmlFile.txt : to send work described in XML file (there may be several works in one file)
 * <li> --xwbroadcastwork workXmlFile.txt : to send work described in XML file to all worker (there may be several works in one file)
 * <li> --xwgetworks  : to retreive all works from server
 * <li> --xwsenddata  dataName cpuType osName [dataFile] : this sends/updates data and uploads data if dataFile provided
 * <li> --xwgetdatas  : to retreive all data description from server
 * <li> --xwchmod [ mod ] UID [UID...] : to change object (apps, datas, works) access rights
 * <li> --xwuploaddata dataUID dataFile : to send data content to server
 * <li> --xwdownloaddata dataUID : to retreive data content from server
 * </ul>
 *
 * @see xtremweb.common#CommandLineParser
 * @see XMLRPCCommand#xmlNew(DataInputStream)
 * @see XMLRPCCommand#xmlNew(String)
 * @author <a href="mailto: lodygens a t lal - in2p3 - fr">Oleg Lodygensky</a>
 * @version %I% %G%
 */

public enum IdRpc {

    NULL,
    DISCONNECT,
    CLOSE,
    GET,
    SENDAPP,
    GETAPPS,
    REMOVE,
    SENDGROUP,
    GETGROUPS,
    GETGROUPWORKS,
    SENDHOST,
    GETHOSTS,
    ACTIVATEHOST,
    SETWORKERSPARAMETERS,
    GETWORKERSPARAMETERS,
    SETWORKERSNB,
    SENDSESSION,
    GETSESSIONS,
    GETSESSIONWORKS,
    SENDTASK,
    GETTASKS,
    SENDTRACE,
    GETALLTRACES,
    GETTRACES,
    SENDUSERGROUP,
    GETUSERGROUPS,
    SENDUSER,
    GETUSERBYLOGIN,
    GETUSERS,
    SENDWORK,
    BROADCASTWORK,
    WORKREQUEST,
    GETWORKS,
    WORKALIVEBYUID,
    WORKALIVE,
    PING,
    GETWORKERBIN,
    TACTIVITYMONITOR,
    GETTRUSTEDADDRESSES,
    ADDTRUSTEDADDRESS,
    REMOVETRUSTEDADDRESS,
    TRACEWORKERS,
    MOUNT,
    UMOUNT,
    SHUTDOWN,
    SENDDATA,
    GETDATAS,
    //
    // This is an alias
    // To be used in client command line only
    // This has no XMLRPCCommand
    //
    CHMOD,

    UPLOADDATA,
    DOWNLOADDATA;

    public static final IdRpc LAST = DOWNLOADDATA;
    public static final int SIZE = LAST.ordinal() + 1;


    /**
     * This stores command line option helps
     */
    public static final String[] helpTexts = {
        " : this does nothing", //NULL
        " : this disconnects ", // DISCONNECT
        " : this closes communications", // CLOSE
        " UID  [UID...]  : this retrevies objects ", // GET
        " appName cpuType osName URI : this sends/updates application; URI points to binary file", // SENDAPP
        " :this retrevies all application descriptions ", // GETAPPS
        " uid  [uid...]  : this removes objects ", // REMOVE
        " groupName sessionUID clientUID : this sends/updates a group", // SENDGROUP
        " : this retreives all group description ", // GETGROUPS
        " : this retreives all work UID for the group group", // GETGROUPWORKS
        " : this is not usable by client", // SENDHOST
        " : this retrevies all host description ", // GETHOSTS
        " hostUID [hostUID...] [on|off] : this activate/deactivate host for computation", // ACTIVATEHOST
        " : this is not usable by client", // SETWORKERSPARAMETERS
        " : this is not usable by client", // GETWORKERPARAMETERS
        " : this is not usable by client", // SETWORKERNB
        " sessionName clientUID : this sends/updates a session", // SENDSESSION
        " : this retreives all session description ", // GETSESSIONS
        " : this retreives all session works UID ", // GETSESSIONWORKS
        " : this is not usable by client", // SENDTASK
        " : this retreives all task description ", // GETTASKS
        " : this is not implemented", // SENDTRACE
        " : this is not implemented", // GETALLTRACES
        " : this is not implemented", // GETTRACES
        " usergroupName : this sends/updates user group", //SENDUSERGROUP
        " : this retreives an user group ", // GETUSERGROUPS
        " login password email rights : this sends/updates user\n" + 
        " >>>>>> java -cp xtremweb.jar xtremweb.common.UserRights to see available values", // SENDUSER
        " userLogin [userLogin...] : this retrevies user description ", // GETUSERBYLOGIN
        " : this retrevies all user description ", // GETUSERS
        " workXmlFile.txt : to send work described in XML file (there may be several works in one file)", // SENDWORK
        " workXmlFile.txt : to send work described in XML file to all worker (there may be several works in one file)", // BROADCASTWORK
        " : this is not available from client", // WORKREQUEST
        " : to retreive all works ", // GETWORKS
        " : this is not available from client", // WORKALIVEBYUID
        " : this is not available from client", // WORKALIVE
        " : this helps to ping server", // PING
        " : this is not available from client", // GETWORKERBIN
        " : this is not available from client", // TACTIVITYMONITOR
        " : this is not implemented", // GETTRUSTEDADDRESS 
        " : this is not implemented", // ADDTRUSTEDADDRESS
        " : this is not implemented", // REMOVETRUSTEDADDRESS
        " : this is not available from client", // TRACEWORKERS
        " : this is not implemented", // MOUNT
        " : this is not implemented", // UMOUNT
        " : this is not implemented", // SHUTDOWN
        " dataName cpuType osName [dataFile] : this sends/updates data and uploads data if dataFile provided", // SENDDATA
        " : to retreive all data descriptions", // GETDATAS
        " newAccessRights UID [UID...] : to change access rights\n" + 
        " >>>>>> java -cp xtremweb.jar xtremweb.common.XWAccessRights to see available values", // CHMOD
        " dataUID dataFile : to send data content to server", // UPLOADDATA
        " dataUID : to retreive data content " // DOWNLOADDATA
    };

    public String help() {
        return helpTexts[this.ordinal()];
    }

    public static String help(IdRpc i) {
        return i.help();
    }

    public String usage() {
        return CommandLineParser.PREFIX + this.toString().toLowerCase() + help();
    }

    public String toXml() {
	return toXml(false);
    }
    public String toXml(boolean close) {
	return "<" + (close == true ? "/" : "") + this.toString().toLowerCase() + ">";
    }

    /**
     * This retreives an IdRpc from its integer value
     * @param v is the integer value of the IdRpc
     * @return an IdRpc
     */
    public static IdRpc fromInt(int v) throws IndexOutOfBoundsException {
        for (IdRpc i : IdRpc.values()) {
            if(i.ordinal() == v)
                return i;
        }
        throw new IndexOutOfBoundsException("unvalid IdRpc value " + v);
    }

    /**
     * This dumps enums to stdout
     */
    public static void main(String[] argv) {
        for (IdRpc i : IdRpc.values())
            System.out.println(i.ordinal() + " : " + i.toString() +
                               "; " + i.usage());
    }
}
