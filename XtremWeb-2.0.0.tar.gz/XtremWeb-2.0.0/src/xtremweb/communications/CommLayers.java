package xtremweb.communications;

/**
 * @author Oleg Lodygensky
 * @since RPCXW
 */

public class CommLayers {
		/**
		 * This is the first value
		 */
		public static final int LAYERS_FIRST = 0;

		public static final int RMI = LAYERS_FIRST;
		public static final int TCP = 1;
		public static final int XMLRPC = 2;

		/**
		 * This is the last value
		 */
		public static final int LAYERS_LAST = XMLRPC;
		public static final int LAYERS_MAX = LAYERS_LAST +1;

		private static String [] layersText;

		static {
				layersText = new String [LAYERS_MAX];
				layersText [RMI] = "RMI";
				layersText [TCP] = "TCP";
				layersText [XMLRPC] = "XMLRPC";
		}

		public static String toString (int s)
				throws Exception {

				try {
						return layersText [s];
				}
				catch (Exception e) {
				}
				throw new Exception ("unknown layers : " + s);
		}

		public static int fromString (String s)
				throws Exception {

				for (int i = LAYERS_FIRST; i < LAYERS_MAX; i++)
						if (s.toUpperCase ().compareTo (layersText [i])== 0) return (i);

				throw new Exception ("unknown layers : " + s);
		}

} // CommLayers
