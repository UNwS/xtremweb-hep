package xtremweb.communications;

/**
 * This enumerates HTTP POST parameter names.
 * This is used by the HTTPClient.
 *
 * You can also open your favorite web browser and do
 * http://yourXWServer:4325/?xwcommand=<getusers><user login="yourlogin" password="yourpassword" /></getuser>
 *
 * @since XWHEP 1.0.0
 * @author Oleg Lodygensky
 */

public enum XWPostParams {

    /**
     * This is the name of the parameter which contains the file to upload
     */
    XWUPLOAD,
    /**
     * This is the name of the parameter which contains the XMLRPCCommand
     */
    XWCOMMAND;

    /**
     * This is the max upload size : 500Mb
     */
    public static final long MAXUPLOADSIZE = 1024 * 1024 * 500;
}
