
package xtremweb.communications;

import java.util.*;
import java.security.Principal;

/**
 * AddressMatcher.java<br />
 * Bored to Helma Xmplrpc<br /><br />
 *
 * This aims to detect valid IP accordingly to this IP pattern.<br />
 * Example : if this stores 192.168.*.*, then 192.168.0.1 is a matching IP address
 * whereas 193.168.0.1 is not  <br /><br />
 * Created: Tue Jul 17 12:16:26 2001<br />
 * Modified: 15 juin 2006
 *
 * @author See Helma
 * @author Oleg Lodygensky
 * @version 
 */
public class AddressMatcher implements Principal {

    int pattern[];
    //    String ip;

		/**
		 * This contructs an IP address matcher with the provided parameter
		 * @param address is an IP address string representation, 
		 *                eventually a wilcdard address (e.g. "192.168.0.*")
		 * @exception NumberFormatException is thrown if address parameter is not 
		 *            made with 4 dot separated integers ot stars
		 */
    public AddressMatcher (String address) throws NumberFormatException {
				pattern = new int[4];
				StringTokenizer st = new StringTokenizer (address, ".");
				if (st.countTokens () != 4)
						throw new NumberFormatException ("\""+address+"\" does not represent a valid IP address");
				for (int i=0; i<4; i++) {
						String next = st.nextToken ();
						if ("*".equals (next))
								pattern[i] = 256; 
						else
								pattern[i] = (byte)  Integer.parseInt (next);
				}
    }
    
    public boolean matches (byte address[]) {
				for (int i=0; i<4; i++) {
						if (pattern[i] > 255) // wildcard
								continue;
						if (pattern[i] != address[i])
								return false;
				}
				return true;
    }

		/**
		 * This tests whether this address matcher matches provided parameter
		 * @param ip is an IP address string representation
		 * @return true if param matches this address matcher, false otherwise
		 */    
    public boolean matchesExact (String ip) {
				try {
						StringTokenizer st = new StringTokenizer (ip, ".");
						if (st.countTokens () != 4) return false;
						for (int i=0; i<4; i++) {
								String next = st.nextToken ();
								if ("*".equals (next)) {
										if (pattern[i] != 256) return false;
								} else 
										if (pattern[i] != (byte) Integer.parseInt (next))
												return false;
						}
						return true;
				}
				catch(Exception e) {
						// if IP is not a String... See #equals(Object)
				}
				return false;
		}

		/**
		 * This retreives the IP address as String
		 * @return this IP address match representation
		 */
    public  String toString() {
				String ret= "";
				for (int i=0; i<4; i++) {
						if (pattern[i]>255) 
								ret +=  "*";
						else if (pattern[i] < 0)
								ret += (127&pattern[i]) + 128;
						else 
								ret += pattern[i];
						ret+= ".";
						//	    ret= ret +( (pattern[i]>255) ? "*" : (new Byte((byte) pattern[i])).toString() ) + ".";

				}
				return ret.substring(0,ret.length()-1)+ " ";
    }


		/**
		 * This only calls toString()
		 * @see #toString()
		 */
		public String getName() {
				return toString();
		}

		/**
		 * This only calls matchesExact(String)
		 * @param ip is an IP address string representation
		 * @see #matchesExact(String)
		 */
		public boolean equals(Object ip) {
				return matchesExact((String)ip);
		}

}// AddressMatcher
