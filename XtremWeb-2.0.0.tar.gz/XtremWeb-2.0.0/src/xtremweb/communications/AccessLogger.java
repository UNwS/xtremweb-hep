package xtremweb.communications;

import xtremweb.common.CommonVersion;
import xtremweb.common.util;

import java.text.SimpleDateFormat;
import java.io.PrintStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * This class aims to store access log "a la" Apache httpd so that we can parse
 * access log with "standard" tools such as webalizer (http://www.mrunix.net/webalizer/)
 *
 * Format:
 * $RHOST - $user [dd/MM/yyyy:HH:mm:ss Z] "GET $file $PROTOCOL/$VERSION" $STATUS $SIZERETURNED "-" "XW/$VERSION ($OS)"
 *
 * This class create a log file per day; is automatically creates a new log file on each new day.
 * Log files are named $server-YYYY-MM-DD.log
 *
 * @author Oleg Lodygensky
 * @date Feb 28th, 2008
 * @since XWHEP 1.0.0
 *
 * @see http://httpd.apache.org/docs/1.3/mod/mod_log_common.html
 *
 */
public class AccessLogger {

    /**
     * This formats date for log file name as : "-yyyy-MM-dd.log"
     */
    private final SimpleDateFormat logFileNameFormat = new SimpleDateFormat("-yyyy-MM-dd", Locale.US);
    /**
     * This defines the stream to write access log to
     */
    private PrintStream out;
    /**
     * This is the directory where log files are stored
     */
    private File logPath;
    /**
     * This is the log date
     */
    private Calendar logDate;
    /**
     * This is the server name to log access for
     */
    private String server;
    /**
     * This stores XWHEP version as string
     */
    String version = CommonVersion.getCurrent().rev();

    /**
     * This constructs a new instance
     * @param root is the path where log files are stored
     * @param s is the server name to log access for
     */
    public AccessLogger(File root, String s) throws NullPointerException{
        logPath = root;
        server = s;
        out = null;
        logDate = Calendar.getInstance();
    }

    /**
     * This return the current log file name
     * @return a String containing the current log file name
     */
    public String getCurrentLogFileName() {
        return server + logFileNameFormat.format(logDate.getTime()) + ".log";
    }

    /**
     * This checks whether we should change log file; 
     * such changes occur for each new day.
     */
    private void checkLogFile() throws IOException {

        try {
            Calendar currentDate = Calendar.getInstance();

            if((out == null) || 
               (currentDate.get(Calendar.YEAR)  != logDate.get(Calendar.YEAR)) ||
               (currentDate.get(Calendar.MONTH) != logDate.get(Calendar.MONTH)) ||
               (currentDate.get(Calendar.DAY_OF_MONTH) != logDate.get(Calendar.DAY_OF_MONTH))) {


                if(out != null) {
                    out.flush();
                    out.close();
                }

                logDate = currentDate;
                out = new PrintStream(new FileOutputStream(new File(logPath, getCurrentLogFileName()), true));
            }
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }

    /**
     * This prints an entry to log file
     * @param fileAccessed is the accessed file path
     * @param user is the user name
     * @param proto is the communication protcol
     * @param status is the request status
     * @param returnSize is the size of the answer
     * @param rHost is the name of the remote host
     * @param ros is the OS of the remote host
     */
    public void println(String fileAccessed, 
                        String user,
                        String proto,
                        int status, int returnSize,
                        String rHost,
                        String ros) throws IOException{

        checkLogFile();

        out.print(rHost + " " + this.server + " - " + user + " " +
                  util.logDateFormat.format(new Date()) + " \"GET " + fileAccessed +
                  " " + proto + "/" + version + "\" " + status + " " + returnSize +
                  " \"-\" \"XW/" + version + " (" + ros + ")\"");
        out.println();
    }


    public static void main(String[]args) throws IOException{
        AccessLogger accessLog = new AccessLogger(new File("."), "auger9");

        for(int i = 0; i < 100; i++)
            accessLog.println("/toto", "oleg0", "HTTP/1.1", 200, 512, "toto.com", "WIN32");
        for(int i = 0; i < 100; i++)
            accessLog.println("/tata", "oleg1", "TCP/1.1", 200, 1024, "tata.com", "MACOSX");
        for(int i = 0; i < 100; i++)
            accessLog.println("/titi", "oleg2", "UDP/0.9", 200, 1024, "titi.com", "WIN32");

    }
}
