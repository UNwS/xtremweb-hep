package xtremweb.communications;


import xtremweb.common.XWPropertyDefs;
import xtremweb.common.LoggerLevel;
import xtremweb.common.util;
import xtremweb.common.BytePacket;

import java.io.IOException;
import java.nio.channels.Selector;
import java.nio.channels.SelectionKey;
import java.nio.channels.DatagramChannel;
import java.nio.channels.spi.SelectorProvider;
import java.rmi.RemoteException;
import java.net.Socket;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.util.Set;
import java.util.Iterator;
import java.util.Properties;


/**
 * <p>
 * This class implements a generic UDP server<br />
 * This instanciates a new CommHandler on each new connection.
 * </p>
 *
 * <p>Created: Jun 7th, 2005</p>
 *
 * @see CommHandler
 * @author Oleg Lodygensky
 * @since RPCXW
 */

public class UDPServer extends CommServer {

    /**
     * This is this thread name
     */
    private static final String NAME = "UDPServer";
    /**
     * This is the NIO server
     */
    protected DatagramChannel nioServer;
    /**
     * This is the standard IO server
     */
    private DatagramSocket ioServer = null;
    /**
     * This tells whether to use NIO or not
     * This contains value is read from config file
     */
    private boolean nio;

    /**
     * This constructs a new Thread to server UDP communications
     */
    public UDPServer(LoggerLevel l){
        super(NAME, l);
    }

    /**
     * This initializes communications
     * @see CommServer#initComm(Properties, CommHandler)
     */
    public void initComm(Properties prop, CommHandler h) {

        port = Connection.UDP.defaultPortValue();

        try{
            String proptxt = prop.getProperty(Connection.UDP.propertyName());
            if(proptxt != null)
                port = new Integer (proptxt.trim ()).intValue ();

            handler = h;
            handler.setLoggerLevel(level);

            proptxt = prop.getProperty(XWPropertyDefs.NIO.toString());
            nio = true;
            if(proptxt != null)
                nio = (proptxt.compareToIgnoreCase("true") == 0);

            if(nio) {
                nioServer = DatagramChannel.open();
                nioServer.configureBlocking(false);
                nioServer.socket().bind (new InetSocketAddress (port));
            }
            else
                ioServer = new DatagramSocket(port);

            setName(NAME + (nio ? "NIO" : ""));

            Runtime.getRuntime().addShutdownHook(new Thread(NAME + "Cleaner") {
                    public void run() {
                        cleanup();
                    }
                });
        }
        catch(Exception e) {
            util.fatal("UDPServer: Could not listen on port " + port + " : " + e);
        }
    }

    /**
     * This indefinitly waits for incoming connections<br />
     * This uses the CommHandler to handle connections
     * @see CommServer#handler
     */
    public void run() {

        debug("UDPServer started, listen on port: " + port);

        while(true) {

            try{
                if(nio) {
                    BytePacket buffer = new BytePacket(level);

                    while (true) {
                        buffer.getBuffer().clear();
                        SocketAddress remote = nioServer.receive(buffer.getBuffer());

                        if (remote == null) {
                            try {
                                Thread.sleep(50);
                            }
                            catch(InterruptedException e) {
                            }

                            continue;
                        }

                        buffer.getBuffer().clear();

                        handler.setPacket(nioServer, remote, buffer);
                        handler.run();
                    }
                }
                else {
                    byte[] buf = new byte[util.PACKETSIZE];
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    ioServer.receive(packet);
                    boolean done = false;
                    int doing = 0;
                    while(done == false) {
                        try {
                            CommHandler h  = (CommHandler)handler.getClass().newInstance();
                            h.setLoggerLevel(level);
                            h.setPacket(ioServer, packet);
                            h.start();
                            done = true;
                        }
                        catch(OutOfMemoryError ome) {
                            if(doing++ > 1000)
                                util.fatal("UDPServer memory error ; can't do more");

                            error("Still answering (" + doing + ") : " + ome);
                            sleep(100);
                        }
                    }
                }
            }
            catch(Exception e) {
                util.fatal("UDPServer error " + e);
            }
        }
    } // run()


    /**
     * This is called on program termination (CTRL+C)
     * This deletes session from server
     */
    private void cleanup() {
        try {
            debug("UDPServer cleanup");
            if(nio)
                nioServer.close();
            else
                ioServer.close();
        }
        catch(Exception e) {
            error("can't clean up");
        }
    }

}
