package xtremweb.communications;

import xtremweb.common.UID;
import xtremweb.common.XMLVector;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.XWStatus;

import java.io.File;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.net.SocketTimeoutException;
import java.util.Date;
import java.util.Vector;
import java.util.Hashtable;


/**
 * This interface defines client communications facilities.
 * This replaces RMIOutputInterface.java
 * @author Oleg Lodygensky
 * @since RPCXW
 */
public interface ClientAPI extends Remote {

    /**
     * This retreives the server name
     */
    public String getServerName();
    /**
     * This disconnects this client from server
     */
    public void disconnect() throws RemoteException, IOException;
    /**
     * This disconnects this client from server
     */
    public void disconnect(XMLRPCCommandDisconnect command) throws RemoteException, IOException;
    /**
     * This sends an XMLRPC command to be executed on server side
     * and closes communication channel
     */
    public void sendCommand(XMLRPCCommand cmd) throws RemoteException, IOException;
    /**
     * This retreives an object from server
     */
    public TableInterface get(UID uid) throws RemoteException, IOException;
    /**
     * This retreives an object from server
     */
    public TableInterface get(XMLRPCCommandGet command) throws RemoteException, IOException;
    /**
     * This creates or updates an application on server side
     */
    public void send(AppInterface app) throws RemoteException, IOException;
    /**
     * This creates or updates an application on server side
     */
    public void send(XMLRPCCommandSendApp command) throws RemoteException, IOException;
    /**
     * This retreives all applications from server
     * @return a Vector of UIDs
     */
    public Vector getApps() throws RemoteException, IOException;
    /**
     * This retreives all applications from server
     * @param command is the XMLRPC command to use
     * @return a Vector of UIDs
     */
    public XMLVector getApps(XMLRPCCommandGetApps command) throws RemoteException, IOException;
    /**
     * This removes an object definition from server
     * @param uid is the UID of the object to remove
     */
    public void remove(UID uid) throws RemoteException, IOException;
    /**
     * <p>
     * This sends a data definition to server <br />
     * This does not send data content.
     * </p>
     * <p>This gets a DataInterface containing some information set by server such as the URL</p>
     * <p>Data content must be sent separatly, using HTTP client or whatever</p>
     * @param data defines the data definition to store on server side
     */
    public void send(DataInterface data) throws RemoteException, IOException;
    /**
     * <p>
     * This sends a data definition to server <br />
     * This does not send data content.
     * </p>
     * <p>This gets a DataInterface containing some information set by server such as the URL</p>
     * <p>Data content must be sent separatly, using HTTP client or whatever</p>
     * @param data defines the data definition to store on server side
     */
    public void send(XMLRPCCommandSendData command) throws RemoteException, IOException;
    /**
     * This retreives all datas from server
     * @return a Vector of UIDs
     */
    public Vector getDatas() throws RemoteException, IOException;
    /**
     * This retreives all datas from server
     * @return a Vector of UIDs
     */
    public XMLVector getDatas(XMLRPCCommandGetDatas command) throws RemoteException, IOException;
    /**
     * This uploads a data to server
     * @param uid is the UID of the data to upload
     * @param content represents a File to get data to upload
     */
    public void uploadData(XMLRPCCommandUploadData command, File content) throws RemoteException, IOException;
    /**
     * This downloads a data from server
     * @param uid is the UID the data to download
     * @param content represents a File to store downloaded data
     */
    public void downloadData(UID uid, File content) throws RemoteException, IOException;
    /**
     * This downloads a data from server
     * @param uid is the UID of the data to download
     * @param content represents a File to store downloaded data
     */
    public void downloadData(XMLRPCCommandDownloadData command, File content) throws RemoteException, IOException;
    /**
     * This creates or updates an group on server side
     * @param group is the group to send
     */
    public void send(GroupInterface group) throws RemoteException, IOException;
    /**
     * This creates or updates an group on server side
     * @param group is the group to send
     */
    public void send(XMLRPCCommandSendGroup command) throws RemoteException, IOException;
    /**
     * This retreives all groups from server for the client
     * @return a Vector of UIDs
     */
    public Vector getGroups() throws RemoteException, IOException;
    /**
     * This retreives all groups from server for the client
     * @return a Vector of UIDs
     */
    public XMLVector getGroups(XMLRPCCommandGetGroups command) throws RemoteException, IOException;
    /**
     * This retreives all works for the given group
     * @param group is the group UID to retreive works for
     * @return a Vector of UIDs
     */
    public Vector getGroupWorks(UID group) throws RemoteException, IOException;
    /**
     * This retreives all works for the given group
     * @param group is the group UID to retreive works for
     * @return a Vector of UIDs
     */
    public XMLVector getGroupWorks(XMLRPCCommandGetGroupWorks command) throws RemoteException, IOException;
    /**
     * This creates or updates an worker on server side
     */
    public void send(HostInterface worker) throws RemoteException, IOException;
    /**
     * This creates or updates an worker on server side
     */
    public void send(XMLRPCCommandSendHost command) throws RemoteException, IOException;
    /**
     * This retreives all workers from server
     * @return a Vector of UIDs
     */
    public Vector getHosts() throws RemoteException, IOException;
    /**
     * This retreives all workers from server
     * @return a Vector of UIDs
     */
    public XMLVector getHosts(XMLRPCCommandGetHosts command) throws RemoteException, IOException;
    /** 
     * Set workers active flag.
     * @param uid is the worker uid
     * @param flag is the active flag
     */
    public void activateHost(UID uid, boolean flag) throws RemoteException, IOException;
    /** 
     * Set workers active flag.
     * @param uid is the worker uid
     * @param flag is the active flag
     */
    public void activateHost(XMLRPCCommandActivateHost command) throws RemoteException, IOException;
    /** 
     * Set workers running parameters.
     * @param nbWorkers is the expected number of workers to activate.
     * @param p is the worker parameters
     * @return the number of activated workers, -1 on error
     */
    public int setWorkersParameters(int nbWorkers,
				    WorkerParameters p) throws RemoteException, IOException;
    /** 
     * Get workers running parameters.
     * @return worker parameters
     */
    public WorkerParameters getWorkersParameters() throws RemoteException, IOException;
    /**
     * This set the expected number of workers
     * @return the number of activated workers, -1 on error
     */
    public int setWorkersNb(int nb) throws RemoteException, IOException;

    /**
     * This creates or updates an session on server side
     */
    public void send(SessionInterface session) throws RemoteException, IOException;
    /**
     * This creates or updates an session on server side
     */
    public void send(XMLRPCCommandSendSession command) throws RemoteException, IOException;
    /**
     * This retreives all sessions from server
     * @return a Vector of UIDs
     */
    public Vector getSessions() throws RemoteException, IOException;
    /**
     * This retreives all sessions from server
     * @return a Vector of UIDs
     */
    public XMLVector getSessions(XMLRPCCommandGetSessions command) throws RemoteException, IOException;
    /**
     * This retreives all works for the given session
     * @param session is the session UID to retreive works for
     * @return a Vector of UIDs
     */
    public Vector getSessionWorks(UID session) throws RemoteException, IOException;
    /**
     * This retreives all works for the given session
     * @param session is the session UID to retreive works for
     * @return a Vector of UIDs
     */
    public XMLVector getSessionWorks(XMLRPCCommandGetSessionWorks command) throws RemoteException, IOException;
    /**
     * This creates or updates an task on server side
     */
    public void send(TaskInterface task) throws RemoteException, IOException;
    /**
     * This creates or updates an task on server side
     */
    public void send(XMLRPCCommandSendTask command) throws RemoteException, IOException;
    /**
     * This retreives all tasks from server
     * @return a Vector of UIDs
     */
    public Vector getTasks() throws RemoteException, IOException;
    /**
     * This retreives all tasks from server
     * @return a Vector of UIDs
     */
    public XMLVector getTasks(XMLRPCCommandGetTasks command) throws RemoteException, IOException;
    /**
     * This creates or updates an trace on server side
     */
    public void send(TraceInterface trace) throws RemoteException, IOException;
    /**
     * This creates or updates an trace on server side
     */
    public void send(XMLRPCCommandSendTrace command) throws RemoteException, IOException;
    /**
     * This retreives all traces from server
     * @return a Vector of UIDs
     */
    public Vector getTraces() throws RemoteException, IOException;
    /**
     * This retreives all traces from server
     * @return a Vector of UIDs
     */
    public XMLVector getTraces(XMLRPCCommandGetTraces command) throws RemoteException, IOException;
    /** 
     * This retreives traces from server
     * @return a Vector of UIDs
     */
    public Vector getTraces(Date since, Date before) throws RemoteException, IOException;
    /**
     * This creates or updates an usergroup on server side
     */
    public void send(UserGroupInterface usergroup) throws RemoteException, IOException;
    /**
     * This creates or updates an usergroup on server side
     */
    public void send(XMLRPCCommandSendUserGroup command) throws RemoteException, IOException;
    /**
     * This retreives all usergroups from server
     * @return a Vector of UIDs
     */
    public Vector getUserGroups() throws RemoteException, IOException;
    /**
     * This retreives all usergroups from server
     * @return a Vector of UIDs
     */
    public XMLVector getUserGroups(XMLRPCCommandGetUserGroups command) throws RemoteException, IOException;
    /**
     * This creates or updates an user on server side
     */
    public void send(UserInterface user) throws RemoteException, IOException;
    /**
     * This creates or updates an user on server side
     */
    public void send(XMLRPCCommandSendUser command) throws RemoteException, IOException;
    /**
     * This retreives an user from server
     */
    public UserInterface getUser(String login) throws RemoteException, IOException;
    /**
     * This retreives an user from server
     */
    public UserInterface getUser(XMLRPCCommandGetUserByLogin command) throws RemoteException, IOException;
    /**
     * This retreives all users from server
     * @return a Vector of UIDs
     */
    public Vector getUsers() throws RemoteException, IOException;
    /**
     * This retreives all users from server
     * @return a Vector of UIDs
     */
    public XMLVector getUsers(XMLRPCCommandGetUsers command) throws RemoteException, IOException;
    /**
     * This creates or updates an work on server side
     */
    public void send(WorkInterface work) throws RemoteException, IOException;
    /**
     * This creates or updates an work on server side
     */
    public void send(XMLRPCCommandSendWork command) throws RemoteException, IOException;
    /**
     * This retreives the next work to compute
     */
    public WorkInterface workRequest(HostInterface h) throws RemoteException, IOException;
    /**
     * This retreives the next work to compute
     */
    public WorkInterface workRequest(XMLRPCCommandWorkRequest command) throws RemoteException, IOException;
    /**
     * This retreives all works from server
     * @return a Vector of UIDs
     */
    public Vector getWorks() throws RemoteException, IOException;
    /**
     * This retreives all works from server
     * @return a Vector of UIDs
     */
    public XMLVector getWorks(XMLRPCCommandGetWorks command) throws RemoteException, IOException;
    /**
     * This removes a set of jobs from server
     * @param uids is a Vector of UID of the works to delete
     */
    public void removeWorks(Vector uids) throws RemoteException, IOException;
    /**
     * This broadcasts a new work to all workers
     * @param work defines the work to broadcast
     */
    public void broadcast(WorkInterface work) throws RemoteException, IOException;
    /**
     * This broadcasts a new work to all workers
     * @param work defines the work to broadcast
     */
    public void broadcast(XMLRPCCommandBroadcastWork command) throws RemoteException, IOException;

    /**
     * This method waits for works to complete, with a time out<br />
     * If time out is reached, this returns
     * @param works a Vector of UID
     * @param t is the time out to wait, in seconds
     * @return a Vector of the UID of the completed works within timeout, if any
     * @exception RemoteException on connection error
     */
    public Vector getCompletedWorks(Vector works, long t) throws RemoteException, IOException;
    /**
     * This method waits(for ever) until all works are completed
     * @param works a Vector of UID
     * @exception RemoteException on connection error
     */
    public void waitForCompletedWorks(Vector works) throws RemoteException, IOException;
    /**
     * This method waits until all works are completed, with a time out
     * @param works a Vector of UID
     * @param timeOut is the time out to wait, in seconds
     * @exception RemoteException on connection error
     * @exception InterruptedException if time out reached
     */
    public void waitForCompletedWorks(Vector works, long timeOut)
	throws RemoteException, InterruptedException;
    /**
     * This method waits until the work is completed
     * @param uid is the UID of the expected work
     * @exception RemoteException on connection error
     */
    public void waitForCompletedWork(UID uid) throws RemoteException, IOException;
    /**
     * This method waits until the work is completed, with a time out
     * @param uid is the UID of the expected work
     * @param timeOut is the time out
     * @exception RemoteException on connection error
     * @exception InterruptedException if time out reached
     */
    public void waitForCompletedWork(UID uid, long timeOut)
	throws RemoteException, InterruptedException;
    /**
     * This waits until a work has the given status
     * @param status  is the status to wait for
     * @param uid is the uid of the expected work
     * @param timeOut is the time out
     * @exception RemoteException on connection error
     * @exception InterruptedException on time out error
     */
    public void waitForWork(XWStatus status, UID uid, long timeOut)
	throws RemoteException, InterruptedException;

    /**
     * This checks the provided work accordingly to the server status
     */
    public Hashtable  workAlive(UID workUID) throws RemoteException, IOException;
    /**
     * This synchronizes with the server
     */
    public Hashtable  workAlive(Hashtable params) throws RemoteException, IOException;

    /*
     * Tracer
     */
    public void  tactivityMonitor(long   start,
				  long   end,
				  byte[] file) throws RemoteException, IOException;

    /** 
     * Get trusted addresses
     * @return a String containing trused ip addresses separated by a
     * white space.
     */
    public String getTrustedAddresses() throws RemoteException, IOException;
    /** 
     * Add a trusted address
     * @param ip new trusted IP
     */
    public void addTrustedAddress(String ip) throws RemoteException, IOException;
    /** 
     * Remove a trusted address
     * @param ip trusted IP to remove
     */
    public void removeTrustedAddress(String ip) throws RemoteException, IOException;
    /** 
     * Set workers trace flag.
     * @param hosts is a hashtable which contains host name as key and their
     * dedicated trace flag as value.
     */
    public void traceWorkers(Hashtable hosts) throws RemoteException, IOException;


    /**
     * This reads a file from socket
     * @param f is the file to store received bytes
     */
    public void readFile(File f) throws RemoteException, IOException;
    /**
     * This writes a file to socket
     * @param f is the file to write
     */
    public void writeFile(File f) throws RemoteException, IOException;

}
