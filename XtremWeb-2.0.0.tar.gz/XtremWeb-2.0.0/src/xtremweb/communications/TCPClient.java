package xtremweb.communications;

/**
 * This class implements the TCP client part to connect to the dispatcher<br>
 *
 * @see xtremweb.dispatcher.TCPHandler
 * Created: Jun 2nd, 2005
 * @author Oleg Lodygensky
 * @since RPCXW
 */

import xtremweb.common.UID;
import xtremweb.common.LoggerLevel;
import xtremweb.common.util;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.StreamIO;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.XWOSes;
import xtremweb.common.XWCPUs;
import xtremweb.common.MileStone;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLVector;
import xtremweb.common.XMLHashtable;

import java.io.IOException;
import java.io.File;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.rmi.RemoteException;
import java.nio.channels.SocketChannel;
import java.net.InetSocketAddress;
import java.net.Socket;


public class TCPClient extends CommClient {

    /**
     * This is the NIO socket channel
     */
    private SocketChannel nioSocket = null;
    /**
     * This is the socket
     */
    private Socket socket = null;
    private StreamIO io;
    private boolean connectionLess;
    boolean nio;

    /**
     * This is the default constructor; this only calls super()
     */
    public TCPClient() {
        super();
    }

    /**
     * This only sets the server name to connect to.
     * This does not effectivly connects to server
     * @param server is the server name to connect to
     */
    public void initComm(String sname) throws RemoteException {
        initComm(sname, config.getPort(Connection.TCP, 
                                       Connection.TCP.defaultPortValue()));
    }
    /**
     * This only sets the server name to connect to.
     * This does not effectivly connects to server
     * @param sname is the server name to connect to
     * @param sport is the server port to connect to
     * @see #open()
     */
    public void initComm(String sname, int sport) throws RemoteException {
        if(sname == null)
            throw new RemoteException("server not defined");

        try {
            serverName = util.getHostName(sname);
        }
        catch(IOException e) {
            throw new RemoteException(e.toString());
        }
        serverPort = sport;

        if(opened) {
            // this is necessary on reconnection
            close(true);
        }

        connectionLess = config.getBoolean(XWPropertyDefs.CONNECTIONLESS,
                                           true);

        if(connectionLess == false)
            mileStone.clear();
    }

    /**
     * This opens connection to server
     * @see CommClient#opened
     */
    protected void open() throws RemoteException {

        if(opened)
            return;

        mileStone.println("<open>");

        try {
            nio = config.nio();

            if(nio) {
                nioSocket = SocketChannel.open();
                nioSocket.configureBlocking(true);

                nioSocket.connect(new InetSocketAddress(serverName, serverPort));

                while (!nioSocket.finishConnect()) {
                    info("still connecting");
                }
                socket = nioSocket.socket();
            }
            else {
                socket = new Socket(serverName, serverPort);
            }

            // mac os x don't like that :(
            if((config.getBoolean(XWPropertyDefs.OPTIMIZENET,
                                  true)) &&
               (XWOSes.getOs().isMacosx() == false)) {
                socket.setSoLinger(false, 0);          // don't wait on close
                socket.setTcpNoDelay(true);            // don't wait to send
                socket.setTrafficClass(0x08);          // maximize throughput
                socket.setKeepAlive(false);            // don't keep alive
            }

            io = new StreamIO(new DataOutputStream(socket.getOutputStream()),
                              new DataInputStream (socket.getInputStream()),
                              socket.getSendBufferSize(), 
                              level,
                              nio);

            opened = true;
        }
        catch(Exception e) {
//             if(util.debug(level))
//                 e.printStackTrace();
            opened = false;
            mileStone.println("</open error='yes'>");
            throw new RemoteException("TCPClient : open failed " + e.toString());
        } 
        mileStone.println("</open error='no'>");
   }
    /**
     * This closes communication channel
     * @see #close(boolean)
     */
    public void close() {
        close(false);
    }
    /**
     * This closes communication channel if we are in connectionless mode<br />
     * This does nothing on connected mode, except if "force" is set to true
     * @param force tells to close on any situation
     * @see xtremweb.common.XWConfigurator#connectionLess
     */
    public void close(boolean force) {

        if((config.getBoolean(XWPropertyDefs.CONNECTIONLESS, 
                              true) == false)
           && (force == false))
            return;
        if(opened == false)
            return;

        try {

            mileStone.println("<close>");

            io.close();
            socket.close();
        }
        catch(IOException e) {
        }

        io = null;
        socket = null;

        opened = false;
        mileStone.println("</close>");
    }

    protected void write(XMLRPCCommand cmd) throws IOException {
        mileStone.println("<write>");
        io.writeObject(cmd);
        mileStone.println("</write>");
    }

    /**
     * This creates an object from channel
     */
    protected TableInterface newTableInterface() throws RemoteException, IOException {
        mileStone.println("<newTableInterface>");
        TableInterface ret = TableInterface.newInterface(io);
        mileStone.println("</newTableInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected AppInterface newAppInterface() throws RemoteException, IOException {
        mileStone.println("<newAppInterface>");
        AppInterface ret = new AppInterface(io.readXmlString());
        mileStone.println("</newAppInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected DataInterface newDataInterface() throws RemoteException, IOException {
        mileStone.println("<newDataInterface>");
        DataInterface ret = new  DataInterface(io.readXmlString());
        mileStone.println("</newDataInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected GroupInterface newGroupInterface() throws RemoteException, IOException {
        mileStone.println("<newGroupInterface>");
        GroupInterface ret = new  GroupInterface(io.readXmlString());
        mileStone.println("</newGroupInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected HostInterface newHostInterface() throws RemoteException, IOException {
        mileStone.println("<newHostInterface>");
        HostInterface ret = new  HostInterface(io.readXmlString());
        mileStone.println("</newHostInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected SessionInterface newSessionInterface() throws RemoteException, IOException {
        mileStone.println("<newSessionInterface>");
        SessionInterface ret = new  SessionInterface(io.readXmlString());
        mileStone.println("</newSessionInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected TaskInterface newTaskInterface() throws RemoteException, IOException {
        mileStone.println("<newTaskInterface>");
        TaskInterface ret = new  TaskInterface(io.readXmlString());
        mileStone.println("</newTaskInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected TraceInterface newTraceInterface() throws RemoteException, IOException {
        mileStone.println("<newTraceInterface>");
        TraceInterface ret = new  TraceInterface(io.readXmlString());
        mileStone.println("</newTraceInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected UserInterface newUserInterface() throws RemoteException, IOException {
        mileStone.println("<newUserInterface>");
        UserInterface ret = new  UserInterface(io.readXmlString());
        mileStone.println("</newUserInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected UserGroupInterface newUserGroupInterface() throws RemoteException, IOException {
        mileStone.println("<newUserGroupInterface>");
        UserGroupInterface ret = new  UserGroupInterface(io.readXmlString());
        mileStone.println("</newUserGroupInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected WorkInterface newWorkInterface() throws RemoteException, IOException {
        mileStone.println("<newWorkInterface>");
        WorkInterface ret = new  WorkInterface(io.readXmlString());
        mileStone.println("</newWorkInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected XMLVector newXMLVector() throws RemoteException, IOException {
        mileStone.println("<newXMLVector>");
        XMLVector ret = new  XMLVector(io.readXmlString());
        mileStone.println("</newXMLVector>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected XMLHashtable newXMLHashtable() throws RemoteException, IOException {
        mileStone.println("<newXMLHashtable>");
        XMLHashtable ret = new  XMLHashtable(io.readXmlString());
        mileStone.println("</newXMLHashtable>");
        return ret;
    }

    /**
     * This writes a file to socket
     * @param f is the file to send
     */
    public void writeFile(File f) throws RemoteException, IOException {
        mileStone.println("<writeFile file='" + f + "'>");
        io.writeFile(f);
        mileStone.println("</writeFile>");
    }
    /**
     * This reads a file from socket
     * This is typically needed after a workRequest to get stdin and/or dirin files
     * @param f is the file to store received bytes
     */
    public void readFile(File f) throws RemoteException, IOException {
        mileStone.println("<readFile file='" + f + "'>");
        io.readFile(f);
        mileStone.println("</readFile>");
    }

}
