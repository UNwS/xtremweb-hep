package xtremweb.communications;

import xtremweb.common.util;

import java.security.Principal;
import java.security.acl.AclEntry;
import java.security.acl.NotOwnerException;
import java.security.acl.Permission;
import java.security.acl.Acl;
import sun.security.acl.AclImpl;
import sun.security.acl.AclEntryImpl;
import sun.security.acl.PrincipalImpl;
import sun.security.acl.PermissionImpl;
import java.util.Enumeration;
import java.util.Vector;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

/**
 * This manages connection access control list (ACL) from IP and resolved names.<br />
 * This contructs ACL list from a comma separated regular expressions (regexp)<br />
 *
 * Regexp examples :
 * <ul>
 *  <li> accept all incoming connection                : .*
 *  <li> accept incoming connection from '168.192.*.*' : 168\.192\..*
 *  <li> accept incoming connection from '*.in2P3.fr'  : .*\.in2p3\.fr
 *  <li> reject incoming connection from '168.192.*.*' : -168\.192\..*
 *  <li> reject incoming connection from '*.in2P3.fr'  : -.*\.in2p3\.fr
 * </ul>
 */
public class ACL {

    private final String _MOINS = "-";
    private final String _PLUS  = "+";

    private final String _ipregexp = "(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2(?:[0-4][0-9]|5[0-5]))";
    private final Pattern _IPPattern = Pattern.compile("^(?:"+_ipregexp+"\\.){3}"+_ipregexp+"$");
    private final String _hostnameregexp = "(\\w+\\.)(\\w+)(\\.\\w+)*";
    private final Permission _connect = new PermissionImpl("CONNECT");
    private final Principal _owner = new PrincipalImpl("localhost");
    private Acl _acl = new AclImpl(_owner, "ConnectACL"); 

    /**
     * This constructs a new object with ACL as provided as a comma separated string
     * @param acls contains comma separated ACLs
     */
    public ACL(String acls){

	Vector<String> acl_regexps = util.split(acls, ",");

        _acl = new AclImpl(_owner, "ConnectACL"); 
        AclEntry allowConnections = new AclEntryImpl(_owner); 
        allowConnections.addPermission(_connect); 
	try {
	    _acl.addEntry(_owner, allowConnections); 
	}
	catch(NotOwnerException e) {
	    e.printStackTrace();
	}

	Enumeration<String> aclenum = acl_regexps.elements();

	for (; aclenum.hasMoreElements() ;) {

             String regexp = aclenum.nextElement();

	     boolean negative = regexp.startsWith(_MOINS);
	     if(negative == true)
		 regexp = regexp.substring(1);

	     if(regexp.startsWith(_PLUS) == true)
		 regexp = regexp.substring(1);

// 	     System.out.println("regexp   = " + regexp);
// 	     System.out.println("negative = " + negative);

	     Principal prince = new PrincipalImpl(regexp);
	     AclEntry entry = new AclEntryImpl(prince); 
	     entry.addPermission(_connect); 
	     if(negative == true)
		 entry.setNegativePermissions(); 

	     try {
		 _acl.addEntry(_owner, entry);         
	     }
	     catch(NotOwnerException e) {
		 e.printStackTrace();
	     }
         }
     
    }
    /**
     * This checks whether rhost is a valid host IP or name
     * @param rhost is a String containing IP or name to check
     * @return true if rhost is a valid host IP or name
     */
    public boolean isValidHost(String rhost) {
	return ((_IPPattern.matcher(rhost).matches() == false) ||
		(rhost.matches(_hostnameregexp) == false));
    }
    /**
     * This checks whether rhost can connect accordingly to ACLs
     * @param rhost is a String containing IP or name
     * @return true if rhost can connect
     */
    public boolean canConnect(String rhost) {

	boolean ret = false;
        
	if(isValidHost(rhost) == false) {
	    //	    System.out.println(rhost + " is not a valid address");
	    return false;
	}
        Enumeration<AclEntry> entries = _acl.entries(); 
        while (entries.hasMoreElements() && (ret == false)) {
	    AclEntry entry = entries.nextElement();
	    Principal p = entry.getPrincipal();
// 	    System.out.println("rhost.matches(" + p.getName() + ") = " + rhost.matches(p.getName()));
// 	    System.out.println(p.getName() + ".isnegative = " + entry.isNegative());
	    if(rhost.matches(p.getName()) && entry.checkPermission(_connect))
		ret = (entry.isNegative() == false);
	}

	return ret;
    }

    /**
     * This is for debug purposes only
     */
    public static void main(String[] argv) {

	ACL aclregexp = new ACL(argv[0]);

	String rhost = argv[1];

	System.out.println("rhost = " + rhost);

	if(aclregexp.isValidHost(rhost) == false) {
	    System.out.println(rhost + " is not a valid address");
	    return;
	}

	System.out.println(rhost + " can connect = " + aclregexp.canConnect(rhost));
    }

}
