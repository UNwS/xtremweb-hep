package xtremweb.communications;

import xtremweb.common.*;

import java.io.*;
import java.util.Vector;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLRPCCommandGetHosts.java
 *
 * Created: Nov 16th, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class defines the XMLRPCCommand to retreive hosts UID
 */
public class XMLRPCCommandGetHosts extends XMLRPCCommand {

    /**
     * This is the RPC id
     */
    public static final IdRpc IDRPC = IdRpc.GETHOSTS;
    /**
     * This is the XML tag
     */
    public static final String THISTAG = IDRPC.toString();


    /**
     * This constructs a new command
     */
    public XMLRPCCommandGetHosts() throws IOException {
	super(IDRPC);
    }
    /**
     * This constructs a new command
     * @param u defines the user who executes this command
     */
    public XMLRPCCommandGetHosts(UserInterface u) throws IOException {
	this();
	setUser(u);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see XMLable#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLRPCCommandGetHosts(DataInputStream input) throws IOException{
	this(new UserInterface());
	super.fromXml(input);
    }


    /**
     * This does nothing since this has no attribute
     */
    public void fromXml(Attributes attrs) throws IOException {
    }

    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public void xmlElementStart(String uri, String tag, String qname, 
				Attributes attrs)
	throws IOException {

	debug("Start element - " + qname);

	if(qname.compareToIgnoreCase(XMLTAG) == 0)
	    fromXml(attrs);
	else if(qname.compareToIgnoreCase(user.xmlTag()) == 0)
	    user = new UserInterface(attrs);
    }

    /**
     * This sends this command to server and returns answer
     * @param comm is the communication channel
     * @return always null since this expect no answer
     * @exception RemoteException is thrown on comm error
     */
    public XMLable exec(CommClient comm) throws IOException {
	return comm.getHosts(this);
    }
    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
	try {
	    XWConfigurator config = new XWConfigurator(argv[0], false);
	    XMLRPCCommandGetHosts cmd = new XMLRPCCommandGetHosts(config._user);
	    if(argv.length == 1) {
		System.out.println(cmd.toXml());
	    }
	    else {
		cmd = new XMLRPCCommandGetHosts(new DataInputStream(new FileInputStream(argv[1])));
		System.out.println(cmd.toXml());
	    }
	}
	catch(Exception e) {
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}
