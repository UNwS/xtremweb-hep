package xtremweb.communications;

import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.StreamIO;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.XWOSes;
import xtremweb.common.XWCPUs;
import xtremweb.common.MileStone;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLable;
import xtremweb.common.XMLVector;
import xtremweb.common.XMLHashtable;

import java.io.IOException;
import java.io.EOFException;
import java.io.File;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.rmi.RemoteException;
import java.net.URL;
import java.net.MalformedURLException;


// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLRPCCommand.java
 *
 * Created: March 22nd, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class defines XMLRPC command
 */
public abstract class XMLRPCCommand extends XMLable {

    IdRpc idrpc;

    /**
     * This is the UserInterface
     */
    protected UserInterface user;
    /**
     * This is the HostInterface, if any.
     * This is needed by workAlive() and workRequest()
     */
    protected HostInterface host;
    /**
     * This is an optionnal parameter
     */
    protected XMLable parameter;
    /**
     * This stores attribute values, if any
     */
    protected Object[] values;

    /**
     * This constructor a new object accordingly to the RPCcommand provided
     * @exception IOException is throws if cmdName is not a valid RPC command
     * @see xtremweb.communications#IdRpc
     */
    protected XMLRPCCommand(String cmdName) throws IOException {
        // this throws an exception if cmdName is not a valid RPC command name
        // this class has no attribute (LAST_ATTRIBUTE = -1; hence MAX_ATTRIBUTE = 0)
        super(IdRpc.valueOf(cmdName).toString().toLowerCase(), -1);
        idrpc = IdRpc.valueOf(cmdName);
        values = null;
        columns = null;
        user = null;
        host = null;
        parameter = null;
    }
    /**
     * This constructor a new object accordingly to the IdRpc command provided
     * @see #XMLRPCCommand(String)
     */
    protected XMLRPCCommand(IdRpc cmd) throws IOException {
        this(cmd.toString());
    }
    /**
     * This constructor sets user attribute
     * @see #XMLRPCCommand(String)
     */
    protected XMLRPCCommand(String cmdName, UserInterface u) throws IOException {
        // this throws an exception if cmdName is not a valid RPC command name
        // this class has no attribute (LAST_ATTRIBUTE = -1; hence MAX_ATTRIBUTE = 0)
        this(cmdName);
        user = u;
    }
    /**
     * This constructor sets user attribute
     * @see #XMLRPCCommand(String)
     */
    protected XMLRPCCommand(IdRpc cmd, UserInterface u) throws IOException {
        this(cmd);
        user = u;
    }
    /**
     * This constructor sets host attribute
     * @see #XMLRPCCommand(String)
     */
    protected XMLRPCCommand(String cmdName, HostInterface h) throws IOException {
        // this throws an exception if cmdName is not a valid RPC command name
        // this class has no attribute (LAST_ATTRIBUTE = -1; hence MAX_ATTRIBUTE = 0)
        this(cmdName);
        host = h;
    }
    /**
     * @see #XMLRPCCommand(String, HostInterface)
     */
    protected XMLRPCCommand(IdRpc cmd, HostInterface h) throws IOException {
        this(cmd.toString(), h);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    protected XMLRPCCommand(DataInputStream input) throws IOException{
        super.fromXml(input);
    }

    /**
     * This sends this command to server and returns answer
     * @param comm is the communication channel
     * @return server answer or null if no anwser
     * @exception RemoteException is thrown on comm error
     */
    public XMLable exec(CommClient comm) throws IOException {
        comm.sendCommand(this);
        return null;
    }

    /**
     * This convers id rpc to string.
     * This catches IOException so that this may be used to create THISTAG
     */
    public static String idRpc(IdRpc id) {
	    return id.toString();
    }
    /**
     * This retreives this command parameter
     * @return this command parameter
     */
    public XMLable getParam() {
        return parameter;
    }
    /**
     * This sets the user for this command
     * @param u defines this command user
     */
    public void setUser(UserInterface u) {
        user = u;
    }
    /**
     * This reterives the user for this command
     * @return the user executing this command
     */
    public UserInterface getUser() {
        return user;
    }

    /**
     * This sets the host for this command
     * @param h defines this command host
     */
    public void setHost(HostInterface h) {
        host = h;
    }
    /**
     * This reterives the host for this command
     * @return the host executing this command
     */
    public HostInterface getHost() {
        return host;
    }
    /**
     * This always return null and must be overriden
     * @return null
     */
    public UID  getUID() {
        return null;
    }
    /**
     * This does nothing and must be overriden
     */
    public void setUID(UID uid) {
    }

    /**
     * This retreives the RPC code
     * @return an integer representing the RPC code
     * @see xtremweb.communications.IdRpc
     */
    public IdRpc getIdRpc() throws IOException {
        return idrpc;
    }

    /**
     * This serializes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    protected String elementXml(boolean open) {

        try {
            String ret;
            if(open) {
                ret = new String("<" + XMLTAG + " ");
                for(int i = FIRST_ATTRIBUTE; i < MAX_ATTRIBUTE; i++) {
                    if(values[i] != null) {
                        ret += columns[i] + "=\"" + values[i] + "\" ";
                    }
                    else {
                        if(DUMPNULLS) {
                            ret += columns[i] + "=\"" + NULLVALUE + "\" ";
                        }
                    }
                }
                ret += ">";
            }
            else
                ret = new String("</" + XMLTAG + ">");

            return ret;
        }
        catch(Exception e) {
        }
        return null;
    }
    /**
     * This serializes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    public String toXml() {

        String ret = elementXml(true);
        if (user != null)
            ret += user.toXml();
        if (host != null)
            ret += host.toXml();
        if (parameter != null)
            ret += parameter.toXml();
        ret += elementXml(false);

        return ret;
    }
    /**
     * This writes this object XML representation to output stream
     * @param o is the output stream to write to
     */
    public void toXml(DataOutputStream o) throws IOException {

        String ret = elementXml(true);
        o.writeUTF(ret);

        if (user != null)
            user.toXml(o);
        if (host != null)
            host.toXml(o);
        if (parameter != null)
            parameter.toXml(o);

        ret = elementXml(false);
        o.writeUTF(ret);
    }
    /**
     * This always throws an exception since XMLRPCCommand has no attributes
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

        if(attrs == null) {
            throw new IOException("attrs is null");
        }

        String infoSetType = null;

        debug("    XMLRPCCommand nb attributes  : " + attrs.getLength());

        for(int a = 0; a < attrs.getLength(); a++) {
            String attribute = attrs.getQName(a);
            String value = attrs.getValue(a);
            debug("     attribute #" + a + 
                  ": name=\"" + attribute + "\"" +
                  ", value=\"" + value + "\"");
        }
    }

    /**
     * This constructs a new XMLRPCCommand object
     * @param io is stream handler to read XML representation from
     */
    public static XMLRPCCommand newCommand(StreamIO io) throws IOException {

        try {
            return newCommand(io.readXmlString());
        }
        catch(EOFException e) {
            e.printStackTrace();
            throw new IOException(e.toString());
        }
    }

    /**
     * This constructs a new XMLRPCCommand object.
     * This first checks the opening tag and then instanciate the right object
     * accordingly to the opening tag.
     * @param xmlString is a String containing a full XML representation
     */
    public static XMLRPCCommand newCommand(String xmlString) throws IOException {

        XMLRPCCommand ret = null;

        //        System.out.println("XMLRPCCommand#newCommand " + xmlString);

        if(xmlString == null)
            throw new IOException("xmlString is null");

        int xmlHeaderIdx = 0;

        if(xmlString.startsWith(XMLable.XMLHEADER) == true)
            xmlHeaderIdx = XMLable.XMLHEADER.length();

        int openIdx = xmlString.indexOf('<', xmlHeaderIdx);
        int spcIdx = xmlString.indexOf(' ', openIdx);
        if(spcIdx < 0)
            spcIdx = xmlString.length();
        int closeIdx = xmlString.indexOf('>', openIdx);
        if(closeIdx < 0)
            closeIdx = xmlString.length();
        String xmltag = xmlString.substring(openIdx + 1, Math.min(spcIdx, closeIdx));
        IdRpc idRpc = IdRpc.valueOf(xmltag.toUpperCase());

        DataInputStream inputStream =
            new DataInputStream(new ByteArrayInputStream(xmlString.
                                                         substring(xmlHeaderIdx).
                                                         getBytes()));

        switch(idRpc) {
        case ACTIVATEHOST :
            ret = new XMLRPCCommandActivateHost(inputStream);
            break;
        case BROADCASTWORK :
            ret = new XMLRPCCommandBroadcastWork(inputStream);
            break;
        case DISCONNECT :
            ret = new XMLRPCCommandDisconnect(inputStream);
            break;
        case DOWNLOADDATA :
            ret = new XMLRPCCommandDownloadData(inputStream);
            break;
        case GET :
            ret = new XMLRPCCommandGet(inputStream);
            break;
        case GETAPPS :
            ret = new XMLRPCCommandGetApps(inputStream);
            break;
        case GETDATAS :
            ret = new XMLRPCCommandGetDatas(inputStream);
            break;
        case GETGROUPWORKS :
            ret = new XMLRPCCommandGetGroupWorks(inputStream);
            break;
        case GETGROUPS :
            ret = new XMLRPCCommandGetGroups(inputStream);
            break;
        case GETHOSTS :
            ret = new XMLRPCCommandGetHosts(inputStream);
            break;
        case GETSESSIONWORKS :
            ret = new XMLRPCCommandGetSessionWorks(inputStream);
            break;
        case GETSESSIONS :
            ret = new XMLRPCCommandGetSessions(inputStream);
            break;
        case GETTASKS :
            ret = new XMLRPCCommandGetTasks(inputStream);
            break;
        case GETTRACES :
            ret = new XMLRPCCommandGetTraces(inputStream);
            break;
        case GETUSERBYLOGIN :
            ret = new XMLRPCCommandGetUserByLogin(inputStream);
            break;
        case GETUSERGROUPS :
            ret = new XMLRPCCommandGetUserGroups(inputStream);
            break;
        case GETUSERS :
            ret = new XMLRPCCommandGetUsers(inputStream);
            break;
        case GETWORKS :
            ret = new XMLRPCCommandGetWorks(inputStream);
            break;
        case REMOVE :
            ret = new XMLRPCCommandRemove(inputStream);
            break;
        case SENDAPP :
            ret = new XMLRPCCommandSendApp(inputStream);
            break;
        case SENDDATA :
            ret = new XMLRPCCommandSendData(inputStream);
            break;
        case SENDGROUP :
            ret = new XMLRPCCommandSendGroup(inputStream);
            break;
        case SENDHOST :
            ret = new XMLRPCCommandSendHost(inputStream);
            break;
        case SENDSESSION :
            ret = new XMLRPCCommandSendSession(inputStream);
            break;
        case SENDTASK :
            ret = new XMLRPCCommandSendTask(inputStream);
            break;
        case SENDTRACE :
            ret = new XMLRPCCommandSendTrace(inputStream);
            break;
        case SENDUSER :
            ret = new XMLRPCCommandSendUser(inputStream);
            break;
        case SENDUSERGROUP :
            ret = new XMLRPCCommandSendUserGroup(inputStream);
            break;
        case SENDWORK :
            ret = new XMLRPCCommandSendWork(inputStream);
            break;
        case UPLOADDATA :
            ret = new XMLRPCCommandUploadData(inputStream);
            break;
        case WORKALIVE :
            ret = new XMLRPCCommandWorkAlive(inputStream);
            break;
        case WORKALIVEBYUID :
            ret = new XMLRPCCommandWorkAliveByUID(inputStream);
            break;
        case WORKREQUEST :
            ret = new XMLRPCCommandWorkRequest(inputStream);
            break;
        case PING :
            ret = new XMLRPCCommandPing(inputStream);
            break;
        default :
            throw new IOException("unknown rpc id : " + idRpc);
        }

        return ret;
    }
    /**
     * This calls toString(false)
     */
    public String toString() {
        return toString(false);
    }
    /**
     * This retreives String representation
     * @return this object String representation
     * @see xtremweb.common.TableInterface#toString(boolean)
     */
    public String toString(boolean csv) {
        String ret = new String();

        if (user != null)
            ret += user.toString(csv);
        if (host != null)
            ret += host.toString(csv);
        if (parameter != null)
            ret += parameter.toString(csv);

        return ret;
    }

    /**
     * This is for testing only.<br />
     * This creates a XMLRPCCommand from given XML String representation 
     * of any XMLRPCCommand descendant<br />
     * argv[0] must contain a config file name
     * argv[1] must contain an XML representation.<br />
     * The object is finally dumped
     */
    public static void main(String[] argv) {
        try {
            XWConfigurator config = new XWConfigurator(argv[0], false);
            XMLRPCCommand cmd = XMLRPCCommand.newCommand(argv[1]);
            System.out.println(cmd.toXml());
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
