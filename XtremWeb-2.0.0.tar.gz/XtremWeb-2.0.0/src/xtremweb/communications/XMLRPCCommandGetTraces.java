package xtremweb.communications;

import xtremweb.common.*;

import java.io.*;
import java.util.Vector;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLRPCCommandGetTraces.java
 *
 * Created: Nov 16th, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class defines the XMLRPCCommand to retreive traces UID
 */
public class XMLRPCCommandGetTraces extends XMLRPCCommand {

    /**
     * This is the RPC id
     */
    public static final IdRpc IDRPC = IdRpc.GETTRACES;
    /**
     * This is the XML tag
     */
    public static final String THISTAG = IDRPC.toString();


    /**
     * Thisconstructs a new command
     */
    public XMLRPCCommandGetTraces() throws IOException {
	super(IDRPC);
    }
    /**
     * Thisconstructs a new command
     * @param u defines the user who executes this command
     */
    public XMLRPCCommandGetTraces(UserInterface u) throws IOException {
	this();
	setUser(u);
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLRPCCommandGetTraces(DataInputStream input) throws IOException{
	this();
	super.fromXml(input);
    }


    /**
     * This always throws an exception since XMLRPCCommandGetTraces has no attributes
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

	if(attrs == null) {
	    throw new IOException("attrs is null");
	}

	String infoSetType = null;

	debug("    XMLRPCCommandGetTraces nb attributes  : " + attrs.getLength());

	for(int a = 0; a < attrs.getLength(); a++) {
	    String attribute = attrs.getQName(a);
	    String value = attrs.getValue(a);
	    debug("     attribute #" + a + 
		  ": name=\"" + attribute + "\"" +
		  ", value=\"" + value + "\"");
	}
    }

    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public void xmlElementStart(String uri, String tag, String qname, 
				Attributes attrs)
	throws IOException {

	debug("Start element - " + qname);

	if(qname.compareToIgnoreCase(XMLTAG) == 0)
	    fromXml(attrs);
	else if(qname.compareToIgnoreCase(UserInterface.THISTAG) == 0)
	    user = new UserInterface(attrs);
    }

    /**
     * This sends this command to server and returns answer
     * @param comm is the communication channel
     * @return always null since this expect no answer
     * @exception RemoteException is thrown on comm error
     */
    public XMLable exec(CommClient comm) throws IOException {
	return comm.getTraces(this);
    }
    /**
     * This is for testing only.<br />
     * argv[0] must containt config file name<br />
     * If argv[1] is empty this creates a dummy XML representation<br />
     * Otherwise, argv[1] may content an XML file name containing 
     * an XML representation to read. <br />
     * <br />
     * The dummy or read representation is finally dumped
     */
    public static void main(String[] argv) {
	try {
	    XWConfigurator config = new XWConfigurator(argv[0], false);
	    XMLRPCCommandGetTraces cmd = new XMLRPCCommandGetTraces(config._user);
	    if(argv.length == 1) {
		System.out.println(cmd.toXml());
	    }
	    else {
		cmd = new XMLRPCCommandGetTraces(new DataInputStream(new FileInputStream(argv[1])));
		System.out.println(cmd.toXml());
	    }
	}
	catch(Exception e) {
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}
