package xtremweb.communications;

/**
 * @since v1r2-rc3 (RPC-V)
 * @author <a href="mailto:lodygens a t lal.in2p3.fr">Oleg Lodygensky</a>
 * 
 * This classes defines port as used by XtremWeb
 * <ul>
 * <li>TCP    : the TCP port</li>
 * <li>UDP    : the UDP port</li>
 * <li>HTTPWORKER : the HTTP port for the worker</li>
 * <li>HTTP   : the HTTP port</li>
 * <li>HTTPS  : the HTTPS port</li>
 * <li>XMLRPC : the XMLRPC port</li>
 * <li>SUNRPC : the SUNRPC interposition port</li>
 * </ul>
 */

public enum Connection {

    TCP,
    UDP,
    HTTPWORKER,
    HTTP,
    HTTPS,
    XMLRPC,
    SUNRPC;

    /**
     * This defines the XtremWeb URI scheme name
     */
    public static final String XWSCHEME = "xw";
    /**
     * This is '://'
     */
    public static final String SCHEMESEPARATOR = "://";

    /**
     * This defines the HTTP URI scheme name
     */
    public static final String HTTPSCHEME = "http";

    /**
     * This defines the Web standard HTTP port : 80
     */
    public static final int WEBDEFAULTPORT = 80;
    /**
     * This defines the first port used by XtremWeb
     * Other ports are defined as BASEPORT + Connection.ordinal()
     */
    public static final int BASEPORT = 4321;

    /**
     * This defines port given is property index
     * @return BASEPORT + this.ordinal()
     * @see #BASEPORT
     */
    public int defaultPortValue() {
        return BASEPORT + this.ordinal();
    };


    /**
     * This defines properties names that should be used in config file
     */
    public static final String[] propertyNames = {
        "port.tcp",
        "port.udp",
        "port.worker.http",
        "port.http",
        "port.https",
        "port.xmlrpc",
        "port.sunrpc"
    };
    /**
     * This defines layers that should be used for each communication type
     */
    public static final String[] layers = {
        "xtremweb.communications.TCPClient",
        "xtremweb.communications.UDPClient",
        "xtremweb.communications.HTTPClient",
        "xtremweb.communications.HTTPClient",
        "xtremweb.communications.HTTPClient",
        "xtremweb.communications.TCPClient",
        "xtremweb.communications.UDPClient"
    };

    /** 
     * This retreives the communication layer
     * @param c is the value to convert
     * @return a string containing this communication lauyer
     */
    public String layer() {
        return layers[this.ordinal()];
    }

    /** 
     * This converts connection port to a String.
     * @param c is the value to convert
     * @return a string containing this connection port
     */
    public String propertyName() {
        return propertyNames[this.ordinal()];
    }

    public static Connection fromLayer(String layer) 
    throws IndexOutOfBoundsException {
        for (Connection c : Connection.values()) {
            if(c.layer().compareTo(layer) == 0)
                return c;
        }
        throw new IndexOutOfBoundsException("invalid layer " + layer);
    }

}
