package xtremweb.communications;

import xtremweb.common.*;

import java.io.*;
import java.util.Vector;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLRPCCommandGet.java
 *
 * Created: Nov 16th, 2006
 *
 * @author <a href="mailto:lodygens /a|t\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This class defines the XMLRPCCommand to retreive group definition
 */
public class XMLRPCCommandGet extends XMLRPCCommand {

    /**
     * This is the RPC id
     */
    public static final IdRpc IDRPC = IdRpc.GET;
    /**
     * This is the XML tag
     */
    public static final String THISTAG = IDRPC.toString();
    /**
     * This is the uid column index
     */
    private final int UID = 0;

    /**
     * This constructs a new command
     */
    public XMLRPCCommandGet() throws IOException {
        super(IDRPC);

        LAST_ATTRIBUTE = UID;
        MAX_ATTRIBUTE = LAST_ATTRIBUTE + 1;

        values  = new Object[MAX_ATTRIBUTE];
        columns = new String[MAX_ATTRIBUTE];
        columns[UID] = "UID";
    }
    /**
     * This constructs a new command
     * @param uid is the UID of the group to retreive
     */
    public XMLRPCCommandGet(UID uid) throws IOException {
        this();
        values [UID] = uid;
    }
    /**
     * This constructs a new command
     * @param uid is the UID of the group to retreive
     */
    public XMLRPCCommandGet(UserInterface u, UID uid) throws IOException {
        this(uid);
        setUser(u);
    }

    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @see TableInterface#fromXml(DataInputStream)
     * @throws IOException on XML error
     */
    public XMLRPCCommandGet(DataInputStream input) throws IOException{
        this(new UserInterface(), new UID());
        super.fromXml(input);
    }


    /**
     * This retreives UID from XML attributes
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

        String infoSetType = null;

        for(int a = 0; a < attrs.getLength(); a++) {
            String attribute = attrs.getQName(a);
            String value = attrs.getValue(a);
            if(attribute.compareToIgnoreCase(columns[UID]) == 0)
                values[UID] = new UID(value);
        }
    }

    /**
     * This is called to decode XML elements
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public void xmlElementStart(String uri, String tag, String qname, 
                                Attributes attrs)
        throws IOException {

        debug("Start element - " + qname);

        if(qname.compareToIgnoreCase(XMLTAG) == 0)
            fromXml(attrs);
        else if(qname.compareToIgnoreCase(UserInterface.THISTAG) == 0)
            user = new UserInterface(attrs);
    }
    /**
     * This sends this command to server and returns answer
     * @param comm is the communication channel
     * @return always null since this expect no answer
     * @exception RemoteException is thrown on comm error
     */
    public XMLable exec(CommClient comm) throws IOException {
        return comm.get(this);
    }
    /**
     * This retreives this command UID
     * @return the UID of the host to activate
     */
    public UID getUID() {
        return (UID)values[UID];
    }

    /**
     * This is for testing only
     */
    public static void main(String[] argv) {
        try {
            XWConfigurator config = new XWConfigurator(argv[0], false);
            XMLRPCCommandGet cmd = new XMLRPCCommandGet(config._user, new UID());
            if(argv.length == 1) {
                System.out.println(cmd.toXml());
            }
            else {
                cmd = new XMLRPCCommandGet(new DataInputStream(new FileInputStream(argv[1])));
                System.out.println(cmd.toXml());
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
