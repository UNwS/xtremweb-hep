package xtremweb.communications;


import xtremweb.common.UID;
import xtremweb.common.Loggerable;
import xtremweb.common.XMLVector;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.XWStatus;

import java.io.File;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.Vector;
import java.util.Hashtable;
import java.security.InvalidKeyException;
import java.security.AccessControlException;


/**
 * This interface defines server communications facilities.
 * <br /><br />
 * Names may be disturbing since methods are named from client point of view<br />
 * <blockquote>
 * e.g. : sendApp() would certainly be clearer if it was named receiveApp()
 * </blockquote>
 *
 * On the other hand, this way unifies method names.<br />
 * <blockquote>
 * e.g. : client.sendApp() reaches server.sendApp()
 * </blockquote>
 *
 * @author Oleg Lodygensky
 * @since RPCXW
 */
public interface ServerAPI extends Remote, Loggerable {

    /**
     * This disconnects this client from server
     * @param client defines this client attributes, such as user ID, password etc.
     */
    void disconnect(UserInterface client)
        throws RemoteException, InvalidKeyException;

    /**
     * This disconnectes a worker so that we can reschedule its jobs
     * @param client is the client definition
     * @param host is the host definition
     */
    void shutDown(UserInterface client, HostInterface host) 
	throws RemoteException;

    /**
     * This creates or updates an application on server side
     * @param client is the caller attributes
     * @param app is the application to create or update
     */
    void sendApp(UserInterface client, AppInterface app)
        throws RemoteException, InvalidKeyException;
    /**
     * This retreives an application from server thanks to its name
     * @param client is the caller attributes
     * @param name is the application name
     * @return an AppInterface object
     */
    AppInterface getApp(UserInterface client, String name)
        throws IOException, InvalidKeyException, AccessControlException;
    /**
     * This retreives an object from server thanks to its uid
     * @param client is the caller attributes
     * @param uid is the application uid
     * @return an AppInterface object
     */
    TableInterface get(UserInterface client, UID uid)
        throws RemoteException, InvalidKeyException, AccessControlException;
    /**
     * This retreives all applications from server
     * @param client is the caller attributes
     * @return a vector of UIDs
     */
    Vector getApps(UserInterface client)
        throws IOException, InvalidKeyException;
    /**
     * This remove application from server
     * @param client is the caller attributes
     * @param appUID is the UID of the application to remove
     * @since 2.0.0
     */
    void remove(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException;
    /**
     * @deprecated this is deprecated since 1.9.0 ; please use sendData() instead
     * @see #get(UserInterface, UID)
     */
    public DataInterface getResult(UserInterface client, UID work) throws RemoteException;
    /**
     * @deprecated this is deprecated since 1.9.0 ; please use sendData() instead
     * @see #sendData(UserInterface, DataInterface)
     */
    public void sendResult(UserInterface client, DataInterface result) throws RemoteException;
    /**
     * This creates or updates data on server side
     * @param client is the caller attributes
     * @param data is the data to create
     */
    DataInterface sendData(UserInterface client, DataInterface data)
        throws RemoteException, InvalidKeyException;
    /**
     * This retreives all datas from server
     * @param client is the caller attributes
     * @return a vector of data UIDs
     */
    Vector getDatas(UserInterface client)
        throws RemoteException, InvalidKeyException;
    /**
     * This uploads a data to server
     * @return the size of the uploaded data
     */
    long uploadData(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException;
    /**
     * This downloads a data from server
     * @return the size of the downloaded data
     */
    long downloadData(UserInterface client, UID uid)
        throws IOException, InvalidKeyException, AccessControlException;
    /**
     * This creates or updates an group on server side
     * @param client is the caller attributes
     * @param group is the group to create or update
     */
    void sendGroup(UserInterface client, GroupInterface group)
        throws IOException, InvalidKeyException;
    /**
     * This retreives the client groups from server
     * @param client is the caller attributes
     * @return a vector of UIDs
     */
    Vector getGroups(UserInterface client)
        throws IOException, InvalidKeyException;
    /**
     * This retreives all works for the given group
     * @param client is the caller attributes
     * @param group is the group UID to retreive works for
     * @return a vector of work UIDs
     */
    Vector getGroupWorks(UserInterface client, UID group)
        throws IOException, InvalidKeyException, AccessControlException;
    /**
     * This creates or updates an session on server side
     * @param client is the caller attributes
     * @param session is the session to create to update
     */
    void sendSession(UserInterface client, SessionInterface session) throws RemoteException;
    /**
     * This retreives the client sessions from server
     * @param client is the caller attributes
     * @return a vector of UIDs
     */
    Vector getSessions(UserInterface client) throws RemoteException;
    /**
     * This retreives all works for the given session
     * @param client is the caller attributes
     * @param session is the session UID to retreive works for
     * @return a Vector of work UID
     */
    Vector getSessionWorks(UserInterface client, UID session) throws RemoteException;
    /**
     * This creates or updates an worker on server side
     * @param client is the caller attributes
     * @param worker is the worker to create or update
     */
    void sendWorker(UserInterface client, HostInterface worker) throws RemoteException;
    /**
     * This retreives all workers from server
     * @param client is the caller attributes
     * @return a vector of UIDs
     */
    Vector getWorkers(UserInterface client) throws RemoteException;
    /**
     * This sets workers active flag.
     * @param client is the caller attributes
     * @param uid is the worker uid
     * @param flag is the active flag
     */
    void activateWorker(UserInterface client, UID uid, boolean flag)
	throws RemoteException;
    /** 
     * Set workers running parameters.
     * @param client is the caller attributes
     * @param nbWorkers is the expected number of workers to activate.
     * @param p is the worker parameters
     * @return the number of activated workers, -1 on error
     */
    int setWorkersParameters(UserInterface client,
			     int nbWorkers,
			     WorkerParameters p) throws RemoteException, InvalidKeyException;
    /** 
     * Get workers running parameters.
     * @param client is the caller attributes
     * @return worker parameters
     */
    WorkerParameters getWorkersParameters(UserInterface client) throws RemoteException;
    /**
     * This set the expected number of workers
     * @param client is the caller attributes
     * @param nb the number of workers
     * @return the effective number of workers
     */
    int setWorkersNb(UserInterface client, int nb) throws RemoteException;
    /**
     * This creates or updates a task on server side
     * This should never  be used by clients
     * This is only intended for server replication
     * @param client is the caller attributes
     * @param task is the task to create or update
     */
    void sendTask(UserInterface client, TaskInterface task) throws RemoteException;
    /**
     * This retreives the client tasks from server
     * @param client is the caller attributes
     * @return a vector of UIDs
     */
    Vector getTasks(UserInterface client) throws RemoteException;
    /**
     * This creates or updates an work on server side
     * @param client is the caller attributes
     * @param work is the work to create
     */
    void sendWork(UserInterface client, WorkInterface work) throws RemoteException;
    /**
     * This retreives the next work to compute from server
     * This is typically called by worker
     * @param client is the client definition
     * @param host is the host definition
     * @return a WorkInterface object
     */
    WorkInterface workRequest(UserInterface client, HostInterface host) 
        throws RemoteException, InvalidKeyException;
    /**
     * This retreives all works from server
     * @param client is the caller attributes
     * @return a vector of UIDs
     */
    Vector getWorks(UserInterface client) throws RemoteException;
    /**
     * This broadcasts a new work to all workers
     * @param client is the caller attributes
     * @param work defines the work to broadcast
     * @return a Vector of String containing submitted work UIDs
     */
    Vector broadcast(UserInterface client, WorkInterface work) throws RemoteException;
    /**
     * This creates or updates an user on server side
     * @param client is the caller attributes
     * @param user is the user to create or update
     */
    void sendUser(UserInterface client, UserInterface user) throws RemoteException;
    /**
     * This retreives an user from server thanks to its login
     * @param client is the caller attributes
     * @param login is the user login
     * @return a UserInterface object
     */
    UserInterface getUser(UserInterface client, String login) throws RemoteException;
    /**
     * This retreives all users from server
     * @param client is the caller attributes
     * @return a vector of UIDs
     */
    Vector getUsers(UserInterface client) throws RemoteException;
    /**
     * This creates or updates an usergroup on server side
     * @param client is the caller attributes
     * @param usergroup is the user group to create or update
     */
    void sendUserGroup(UserInterface client, UserGroupInterface usergroup) throws RemoteException;
    /**
     * This retreives all usergroups from server
     * @param client is the caller attributes
     * @return a vector of UIDs
     */
    Vector getUserGroups(UserInterface client) throws RemoteException;
    /**
     * This creates or updates an trace on server side
     * @param client is the caller attributes
     * @param trace is the trace to create or update
     */
    void sendTrace(UserInterface client, TraceInterface trace) throws RemoteException;
    /**
     * This retreives all traces from server
     * @param client is the caller attributes
     * @return a vector of UIDs
     */
    Vector getTraces(UserInterface client) throws RemoteException;
    /** 
     * This retreives traces from server according to dates
     * @param client is the caller attributes
     * @param since is the first date
     * @param before is the last date
     * @return an vector of UIDs
     */
    Vector getTraces(UserInterface client, Date since, Date before) throws RemoteException;
    /**
     * This checks the provided work accordingly to the server status
     * @param id is the caller attributes
     * @see xtremweb.worker.ThreadAlive#workAlive(UID)
     */
    Hashtable  workAlive  (UserInterface client, HostInterface host, UID uid ) 
        throws RemoteException, InvalidKeyException;
    /**
     * This synchronizes with the server
     * @param id is the caller attributes
     * @see xtremweb.worker.ThreadAlive#workAlive(UID)
     * @see xtremweb.worker.ThreadAlive#synchronize()
     */
    Hashtable  workAlive  (UserInterface client, HostInterface host, Hashtable params)
        throws RemoteException, InvalidKeyException;
    /** 
     * This creates a Mobile Work filled with worker software. It is
     * used to update worker as needed.
     * @param wid is the caller attributes
     * @return a filled mobileWork
     */ 
    DataInterface getWorkerBin(UserInterface client, HostInterface host) throws RemoteException;
    /*
     * Tracer
     */
    void  tactivityMonitor(HostInterface host,
			   long   start,
			   long   end,
			   byte[] file) throws RemoteException;
    /** 
     * Get trusted addresses
     * @param client is the caller attributes
     * @return a string containing trused ip addresses separated by a white space.
     */
    String getTrustedAddresses(UserInterface client) throws RemoteException;
    /** 
     * Add a trusted address
     * @param client is the caller attributes
     * @param ip new trusted IP
     */
    void addTrustedAddress(UserInterface client, String ip) throws RemoteException;
    /** 
     * Remove a trusted address
     * @param client is the caller attributes
     * @param ip trusted IP to remove
     */
    void removeTrustedAddress(UserInterface client, String ip) throws RemoteException;
    /** 
     * Set workers trace flag.
     * @param client is the caller attributes
     * @param hosts is a hashtable which contains host name as key and their
     * dedicated trace flag as value.
     */
    void traceWorkers(UserInterface client, Hashtable hosts) throws RemoteException;


}
