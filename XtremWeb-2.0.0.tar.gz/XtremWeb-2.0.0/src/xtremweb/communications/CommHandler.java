package xtremweb.communications;

import xtremweb.common.UID;
import xtremweb.common.StreamIO;
import xtremweb.common.BytePacket;
import xtremweb.common.XMLVector;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLable;
import xtremweb.common.XWOSes;
import xtremweb.communications.CommHandler;
import xtremweb.communications.XMLRPCCommand;


import java.io.IOException;
import java.io.File;
import java.io.DataOutputStream;
import java.nio.channels.DatagramChannel;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.rmi.RemoteException;

import org.mortbay.jetty.Handler;

/**
 * This is just an alias to ServerAPI
 * This should not have been a class because RMIHandler extends UnicastRemoteObject
 * @author Oleg Lodygensky
 * @since RPCXW
 */
public interface CommHandler extends ServerAPI,org.mortbay.jetty.Handler {

    /**
     * This is only needed for handlers that extends java.lang.Thread
     * Such handlers have the start() method; others (i.e. not extending java.lang.Thread)
     * must implements an empty method
     * Thanks to this declaration we can call java.lang.Thread#start()
     */
    public void start() throws RemoteException;
    /**
     * This is only needed for handlers that extends java.lang.Thread
     * Such handlers have the start() method; others (i.e. not extending java.lang.Thread)
     * must implements an empty method
     * Thanks to this declaration we can call java.lang.Thread#run()
     */
    public void run() throws RemoteException;
    /**
     * This closes communication channels
     */
    public void close();
    /**
     * This sets the communication socket for TCP comms
     * @param s is the socket
     */
    public void setSocket(Socket s) throws RemoteException;
    /**
     * This sets the datagram packet and socket for UDP comms
     * @param s is the socket
     * @param p is the packet
     */
    public void setPacket(DatagramSocket s, DatagramPacket p) throws RemoteException;
    /**
     * This sets the server addr and byte packet
     * @param c is the channel to server
     * @param r is the client address
     * @param p is the packet
     */
    public void setPacket(DatagramChannel c, SocketAddress r, BytePacket p) throws RemoteException;
}
