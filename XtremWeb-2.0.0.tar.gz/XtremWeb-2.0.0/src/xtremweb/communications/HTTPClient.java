package xtremweb.communications;

/**
 * This class implements HTTP client part to connect to the dispatcher<br>
 *
 * Created: Oct 5th, 2007
 * @author Oleg Lodygensky
 * @since XWHEP 1.0.0
 */

import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.StreamIO;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.XWOSes;
import xtremweb.common.XWCPUs;
import xtremweb.common.MileStone;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLable;
import xtremweb.common.XMLVector;
import xtremweb.common.XMLHashtable;

import java.io.IOException;
import java.io.File;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.rmi.RemoteException;
import java.net.URL;
import java.net.MalformedURLException;


import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.HttpConnection;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity; 
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;



public class HTTPClient extends CommClient {

    private boolean connectionLess;
    boolean nio;

    HttpClient client;
    PostMethod post;

    /**
     * This is the default constructor; this only calls super()
     */
    public HTTPClient() {
        super();
        client = null;
    }

    /**
     * This only sets the server name to connect to.
     * This does not effectivly connects to server
     * @param server is the server name to connect to
     */
    public void initComm(String sname) throws RemoteException {
        initComm(sname, config.getPort(Connection.HTTP, 
                                       Connection.HTTP.defaultPortValue()));
    }
    /**
     * This only sets the server name to connect to.
     * This does not effectivly connects to server
     * @param sname is the server name to connect to
     * @param sport is the server port to connect to
     * @see #open()
     */
    public void initComm(String sname, int sport) throws RemoteException {
        if(sname == null)
            throw new RemoteException("server not defined");
        try {
            serverName = util.getHostName(sname);
        }
        catch(IOException e) {
            throw new RemoteException(e.toString());
        }
        serverPort = sport;

        if(opened) {
            // this is necessary on reconnection
            close(true);
        }

        connectionLess = config.getBoolean(XWPropertyDefs.CONNECTIONLESS,
                                           true);

        if(connectionLess == false)
            mileStone.clear();

        client = new HttpClient(new MultiThreadedHttpConnectionManager());
        client.getHttpConnectionManager().getParams().setConnectionTimeout(30000);
        HostConfiguration hConfig = new HostConfiguration();
        hConfig.setHost(serverName, serverPort);
        client.setHostConfiguration(hConfig);
    }

    /**
     * This does nothing; everything is done in write()
     * @see CommClient#opened
     * @see #write(XMLRPCCommand)
     */
    protected void open() throws RemoteException {

        if(opened)
            return;

        mileStone.println("<open>");

        try {
            //
            // 2 dec 2007 : we force nio to false
            //
            nio = false;

            // mac os x don't like that :(
            if((config.getBoolean(XWPropertyDefs.OPTIMIZENET,
                                  true)) &&
               (XWOSes.getOs().isMacosx() == false)) {
                HttpConnectionManagerParams params = 
                    client.getHttpConnectionManager().getParams();
                params.setLinger(0);                   // don't wait on close
                params.setTcpNoDelay(true);            // don't wait to send
            }

            HttpConnection connection = client.getHttpConnectionManager().
                getConnection(client.getHostConfiguration());

            connection.open();
            opened = true;
        }
        catch(Exception e) {
            opened = false;
            mileStone.println("</open error='yes'>");
            throw new RemoteException("HTTPClient : open failed " + e.toString());
        }
        mileStone.println("</open error='no'>");
    }
    /**
     * This calls close(false);
     * @see #close(boolean)
     */
    public void close() {
        close(false);
    }
    /**
     * This closes communication channel if we are in connectionless mode<br />
     * This does nothing on connected mode, except if "force" is set to true
     * @param force tells to close on any situation
     * @see xtremweb.common.XWConfigurator#connectionLess
     */
    public void close(boolean force) {

        if((config.getBoolean(XWPropertyDefs.CONNECTIONLESS, 
                              true) == false)
           && (force == false))
            return;
        if(opened == false)
            return;

        mileStone.println("<close>");

        post.releaseConnection();
        HttpConnection connection = client.getHttpConnectionManager().
            getConnection(client.getHostConfiguration());
        connection.close();

        //        io = null;
        opened = false;

        mileStone.println("</close>");
    }

    /**
     * This sends a command to server
     * @param cmd is the command to send
     */
    protected void write(XMLRPCCommand cmd) throws IOException {

        mileStone.println("<write cmd='" + cmd.getIdRpc() + "'>");

        //        System.out.println("\n\n\nwrite(" + cmd.toXml() + ")\n\n\n");

        post = new PostMethod(client.getHostConfiguration().getHostURL());
        post.addParameter(XWPostParams.XWCOMMAND.toString(), cmd.toXml());
        client.executeMethod(post);

        mileStone.println("</write>");
    }

    /**
     * This creates an object from channel
     */
    protected TableInterface newTableInterface() throws RemoteException, IOException {
        mileStone.println("<newTableInterface>");
        String str = post.getResponseBodyAsString();
        //        System.out.println("\n\n\read = " + str + "\n\n\n");
        TableInterface ret = TableInterface.newInterface(str);
        mileStone.println("</newTableInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected AppInterface newAppInterface() throws RemoteException, IOException {
        mileStone.println("<newAppInterface>");
        String str = post.getResponseBodyAsString();
        AppInterface ret = new AppInterface(StreamIO.stream(str)); 
        mileStone.println("</newAppInterface>");
       return ret;
    }
    /**
     * This creates an object from channel
     */
    protected DataInterface newDataInterface() throws RemoteException, IOException {
        mileStone.println("<newDataInterface>");
        String str = post.getResponseBodyAsString();
        DataInterface ret = new  DataInterface(StreamIO.stream(str));
        mileStone.println("</newDataInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected GroupInterface newGroupInterface() throws RemoteException, IOException {
        mileStone.println("<newGroupInterface>");
        String str = post.getResponseBodyAsString();
        GroupInterface ret = new  GroupInterface(StreamIO.stream(str));
        mileStone.println("</newGroupInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected HostInterface newHostInterface() throws RemoteException, IOException {
        mileStone.println("<newHostInterface>");
        String str = post.getResponseBodyAsString();
        HostInterface ret = new  HostInterface(StreamIO.stream(str));
        mileStone.println("Read HostInterface");
        mileStone.println("</newHostInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected SessionInterface newSessionInterface() throws RemoteException, IOException {
        mileStone.println("<newSessionInterface>");
        String str = post.getResponseBodyAsString();
        SessionInterface ret = new  SessionInterface(StreamIO.stream(str));
        mileStone.println("</newSessionInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected TaskInterface newTaskInterface() throws RemoteException, IOException {
        mileStone.println("<newTaskInterface>");
        String str = post.getResponseBodyAsString();
        TaskInterface ret = new  TaskInterface(StreamIO.stream(str));
        mileStone.println("</newTaskInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected TraceInterface newTraceInterface() throws RemoteException, IOException {
        mileStone.println("<newTraceInterface>");
        String str = post.getResponseBodyAsString();
        TraceInterface ret = new  TraceInterface(StreamIO.stream(str));
        mileStone.println("</newTraceInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected UserInterface newUserInterface() throws RemoteException, IOException {
        mileStone.println("<newUserInterface>");
        String str = post.getResponseBodyAsString();
        UserInterface ret = new  UserInterface(StreamIO.stream(str));
        mileStone.println("</newUserInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected UserGroupInterface newUserGroupInterface() throws RemoteException, IOException {
        mileStone.println("<newUserGroupInterface>");
        String str = post.getResponseBodyAsString();
        UserGroupInterface ret = new  UserGroupInterface(StreamIO.stream(str));
        mileStone.println("</newUserGroupInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected WorkInterface newWorkInterface() throws RemoteException, IOException {
        mileStone.println("<newWorkInterface>");
        String str = post.getResponseBodyAsString();
        WorkInterface ret = new  WorkInterface(StreamIO.stream(str));
        mileStone.println("</newWorkInterface>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected XMLVector newXMLVector() throws RemoteException, IOException {
        mileStone.println("<newXMLVector>");
        String str = post.getResponseBodyAsString();
        XMLVector ret = new  XMLVector(StreamIO.stream(str));
        mileStone.println("</newXMLVector>");
        return ret;
    }
    /**
     * This creates an object from channel
     */
    protected XMLHashtable newXMLHashtable() throws RemoteException, IOException {
        mileStone.println("<newXMLHashtable>");
        String str = post.getResponseBodyAsString();
        XMLHashtable ret = new  XMLHashtable(StreamIO.stream(str));
        mileStone.println("</newXMLHashtable>");
        return ret;
    }

    /**
     * This uploads a data content to server
     * @param uid is the UID of the data to upload
     * @param content represents a File to get data to upload
     * @since XWHEP 1.0.0
     */
    public void uploadData(XMLRPCCommandUploadData command, File content)
        throws RemoteException, IOException {

        try {
            mileStone.println("<uploadData>");

            open();

            command.setUser(config._user);

            mileStone.println("Uploading " + command.toXml());

            post = new PostMethod(client.getHostConfiguration().getHostURL());
            Part[] parts = {
                new StringPart(XWPostParams.XWCOMMAND.toString(), command.toXml()),
                new FilePart(XWPostParams.XWUPLOAD.toString(), content)
            };

            post.setRequestEntity(new MultipartRequestEntity(parts, post.getParams()));

            int status = client.executeMethod(post);
            post.releaseConnection();
            close();
            if (status != HttpStatus.SC_OK) {
                mileStone.println("</uploadData error='yes'>");
                throw new RemoteException("can't upload data");
            }
            mileStone.println("Uploaded " + command.getUID());
        }
        catch(Exception e) {
            error("Upload error " + command.getUID() + " " + e);
            mileStone.println("</uploadData error='yes'>");
            post.releaseConnection();
            close();
        }
        mileStone.println("</uploadData error='no'>");
    }

    /**
     * This always throws an IOException.
     * Please use uploadData instead
     * @see #uploadData(XMLRPCCommandUploadData, File)
     * @deprecated
     */
    public void writeFile(File f) throws RemoteException, IOException {
        throw new IOException("HTTPClient#writeFile() is not implemented; please use HTTPClient#uploadData()");
     }
    /**
     * This reads a file from socket
     * This is typically needed after a workRequest to get stdin and/or dirin files
     * @param f is the file to store received bytes
     */
    public void readFile(File f) throws RemoteException, IOException {
        StreamIO io = null;
        try {
            mileStone.println("<readFile>");
            io = new StreamIO(null,
                              new DataInputStream(post.getResponseBodyAsStream()),
                              level,
                              nio);

            io.readFile(f);
        }
        catch(Exception e) {
            if(io != null)
                io.close();
            if(debug())
                e.printStackTrace();
            mileStone.println("</readFile error='yes'>");
            throw new IOException(e.toString());
        }
        mileStone.println("</readFile error='no'>");
    }
}
