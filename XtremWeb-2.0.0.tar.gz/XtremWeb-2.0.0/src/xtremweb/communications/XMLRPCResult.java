package xtremweb.communications;

import xtremweb.common.*;

import java.io.*;
import java.util.Vector;

// SAX packages
// ------------
import org.xml.sax.Attributes;


/**
 * XMLRPCResult.java
 *
 * Created: Novembre 16th, 2006
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @since 1.9.0
 */

/**
 * This abstract class defines XMLRPC result
 */
public abstract class XMLRPCResult extends XMLable {

    /**
     * This is the UserInterface
     */
    protected XMLable user;
    /**
     * This is the HostInterface, if any
     */
    protected XMLable host;
    /**
     * This is an optionnal parameter
     */
    protected XMLable parameter;

    /**
     * This default constructor sets all attributes to null
     * @exception Exception is throws if cmdName is not a valid RPC result name
     * @see xtremweb.communications#IdRpc
     */
    public XMLRPCResult(String cmdName) throws Exception {
	// this throws an exception if cmdName is not a valid RPC result name
	// this class has no attribute (LAST_ATTRIBUTE = 0)
	super(IdRpc.valueOf(cmdName).toString(), 0);
	columns = null;
	user = null;
	host = null;
	parameter = null;
    }
    /**
     * This calls this(IdRpc.toString(cmd))
     * @param cmd is an IrRpc
     * @see xtremweb.communications#IdRpc
     * @see #XMLRPCResult(String)
     */
    public XMLRPCResult(IdRpc cmd) throws Exception {
	this(cmd.toString());
    }
    /**
     * This constructs a new object from XML attributes 
     * received from input stream
     * @param input is the input stream
     * @throws IOException on XML error
     */
    public XMLRPCResult(DataInputStream input) throws IOException{
	super.fromXml(input);
    }


    /**
     * This serializes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    protected String elementXml(boolean open) {

	try {
	    return new String("<" + (open == false ? "/" : "") + XMLTAG + ">");
	}
	catch(Exception e) {
	}
	return null;
    }
    /**
     * This serializes this object to a String as an XML object<br />
     * @return a String containing this object definition as XML
     * @see #fromXml(Attributes)
     */
    public String toXml() {

	String ret = elementXml(true);
	if (user != null)
	    ret += user.toXml();
	if (host != null)
	    ret += host.toXml();
	if (parameter != null)
	    ret += parameter.toXml();
	ret += elementXml(false);

	return ret;
    }
    /**
     * This always throws an exception since XMLRPCResult has no attributes
     * @param attrs contains attributes XML representation
     */
    public void fromXml(Attributes attrs) throws IOException {

	if(attrs == null) {
	    throw new IOException("attrs is null");
	}

	String infoSetType = null;

	debug("    XMLRPCResult nb attributes  : " + attrs.getLength());

	for(int a = 0; a < attrs.getLength(); a++) {
	    String attribute = attrs.getQName(a);
	    String value = attrs.getValue(a);
	    debug("     attribute #" + a + 
		  ": name=\"" + attribute + "\"" +
		  ", value=\"" + value + "\"");
	}
    }

    /**
     * This is called to decode XML elements<br />
     * This is an abstract method and must be overriden
     * @see xtremweb.common.XMLable.DescriptionHandler
     */
    public abstract void xmlElementStart(String uri, String tag, String qname, 
					 Attributes attrs)
	throws IOException;

    /**
     * This retreives String representation
     */
    public String toString() {
	String ret = new String();

	if (user != null)
	    ret += user.toString();
	if (host != null)
	    ret += host.toString();
	if (parameter != null)
	    ret += parameter.toString();

	return ret;
    }

}
