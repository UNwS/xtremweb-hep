package xtremweb.communications;

import xtremweb.common.util;
import xtremweb.common.XWRole;
import xtremweb.common.LoggerLevel;

import java.net.ServerSocket;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mortbay.jetty.Connector;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HandlerContainer;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.bio.SocketConnector;
import org.mortbay.jetty.webapp.WebAppContext;
import org.mortbay.jetty.handler.AbstractHandler;
import org.mortbay.jetty.handler.HandlerCollection;
import org.mortbay.jetty.handler.ResourceHandler;
import org.mortbay.jetty.servlet.Context;
import org.mortbay.thread.BoundedThreadPool;

/**
 * <p>
 * This class implements a generic HTTP server<br />
 * This instanciates a new CommHandler on each new connection.
 * </p>
 * <p>
 * This is subject to replace WebServer so that all our servers extend CommServer 
 * </p>
 * <p>
 * This uses org.mortbay.jetty.Server where everything is done.<br />
 * </p>
 *
 * <p>Created: March 30th, 2006</p>
 *
 * @see #TCPServer
 * @author Oleg Lodygensky
 * @since RPCXW
 */

public class HTTPServer extends CommServer {

    /**
     * This is the jetty HTTP server
     */
    private Server httpServer;
    /**
     * This only calls super()
     */
    public HTTPServer(LoggerLevel l){
        super("HTTPServer", l);
        httpServer = new Server();
    }

    /**
     * This initializes communications
     * @see CommServer#initComm(Properties, CommHandler)
     */
    public void initComm(Properties prop, CommHandler h) {

        port = Connection.HTTP.defaultPortValue();

        if(XWRole.isWorker())
            port = Connection.HTTPWORKER.defaultPortValue();

        try{
            String porttxt = prop.getProperty(Connection.HTTP.propertyName());

            if(XWRole.isWorker())
                porttxt = prop.getProperty(Connection.HTTPWORKER.propertyName());

            if (porttxt != null)
                port = new Integer (porttxt.trim ()).intValue ();

            httpServer = new Server();
            Connector connector = new SocketConnector();
            connector.setPort(port);

            System.out.println("HTTP port = " + port);

            httpServer.setConnectors(new Connector[]{connector});
            handler = h;
            HandlerCollection handlers = new HandlerCollection();
            httpServer.setHandler(handlers);
            addHandler("/", handler);

            Runtime.getRuntime().addShutdownHook(new Thread(getName() + "Cleaner") {
                    public void run() {
                        cleanup();
                    }
                });
        }
        catch(Exception e) {
            e.printStackTrace();
            util.fatal(getName() + ": could not listen on port " + port + " : " + e);
        }
    }
    /**
     * This adds an handler
     * @param context is the path of the url accessed
     * @param lpath is the local path where to find HTML files
     */
    public void addHandler(Handler h) {
        Handler handlers = httpServer.getHandler();
        if (!(handlers instanceof HandlerContainer))
            util.fatal("HTTPServer : Cannot add handler");
        ((HandlerContainer)handlers).addHandler(h);
    }
    /**
     * This adds an resource handler which will answer from HTML files
     * @param contextPath is the path of the url accessed
     * @param lpath is the local path where to find HTML files
     */
    public void addHandler(String contextPath, Handler h) {
        Context context = new Context();
        context.setContextPath(contextPath);
        context.setHandler(h);
        addHandler(context);
    }
    /**
     * This adds an resource handler which will answer from HTML files
     * @param contextPath is the path of the url accessed
     * @param lpath is the local path where to find HTML files
     */
    public void addHandler(String contextPath, String lpath) {
        Context context = new Context();
        context.setContextPath(contextPath);
        context.setResourceBase(lpath);
        context.setHandler(new ResourceHandler());
        addHandler(context);
    }

    /**
     * This starts this thread
     */
    public void start() {
        super.start();
    }

    /**
     * This calls httpServer#start()
     */
    public void run() {

        info("started, listening on port : " + port);

        try {
            BoundedThreadPool threadpool = new BoundedThreadPool();
            //            threadpool.setMaxThreads(50);
            httpServer.setThreadPool(threadpool);
            httpServer.start();
            httpServer.join();
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            error("could not listen on port " + port + " : " + e);
        }   
    }

    /**
     * This is called on program termination (CTRL+C)
     * This deletes session from server
     */
    protected void cleanup() {
        try {
            debug("cleanup");
            httpServer.getHandler().stop();
        }
        catch(Exception e) {
            error("can't clean up");
        }
    }

}// HTTPServer
