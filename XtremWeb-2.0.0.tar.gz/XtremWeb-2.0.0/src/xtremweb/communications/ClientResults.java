package xtremweb.communications;

import xtremweb.common.*;

import java.io.*;
import java.rmi.*;
import java.util.Vector;


public class ClientResults implements Serializable {
    public int timeOut;
    public Vector jobs;
    public ClientResults() {
				jobs = new Vector();
    }
}
