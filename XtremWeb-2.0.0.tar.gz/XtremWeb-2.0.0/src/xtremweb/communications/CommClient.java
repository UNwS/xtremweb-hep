package xtremweb.communications;

/**
 * CommClient.java
 *
 *
 * Created: Jun 2nd, 2005
 *
 * @author Oleg Lodygensky
 * @since RPCXW
 */

import xtremweb.common.LoggerLevel;
import xtremweb.common.Logger;
import xtremweb.common.Cache;
import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.util;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.MileStone;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLVector;
import xtremweb.common.XMLHashtable;
import xtremweb.common.XWPropertyDefs;

import java.io.IOException;
import java.io.File;
import java.util.Enumeration;
import java.util.Date;
import java.util.Iterator;
import java.util.Vector;
import java.util.Hashtable;
import java.net.ConnectException;
import java.net.UnknownHostException;
import java.rmi.RemoteException;


public abstract class CommClient extends Logger implements ClientAPI {

    /**
     * This is the cache where download object are cached
     */
    protected static Cache cache = null;
    /** 
     * This hashtable stores known communication handlers.
     * Keys are communications schemes; values are CommClient objects.<br />
     * This is automatically initialized with the tuple:<br />
     *  (xtremweb.communications.Connection.XWSCHEME, xtremweb.common.XWPropertyDefs.COMMLAYER)<br />
     * This is then filled as needs
     *
     * @see #getClient(URI) 
     * @see xtremweb.communications.Connection#XWSCHEME
     * @see xtremweb.common.XWPropertyDefs#COMMHANDLERS
     */
    private static Hashtable commHandlers = null;

    /**
     * This contains configuration
     */
    protected static XWConfigurator config = null;


    /** 
     * This tells whether the channels are opened on non-connectionless  mode 
     */
    protected boolean opened;
    /**
     * This is the server name to connect to
     */
    protected String serverName;
    /**
     * This is the server port to connect to
     */
    protected int serverPort;

    /**
     * This aims to display some time stamps
     */
    MileStone mileStone;

    /**
     * This is the default constructor; this set connectionless to true, opened to false
     */
    protected CommClient() {
        super();
        opened = false;
        mileStone = new MileStone(getClass().getName());
    }
    /**
     * This opens communications channel
     */
    protected abstract void open() throws RemoteException;
    /**
     * This closes communications channel
     */
    public abstract void close();
    /**
     * This closes communications channel
     * @param b forces to close even if not on connectionless mode
     */
    public abstract void close(boolean b);
    /**
     * This writes an object to output channel
     */
    protected abstract void write(XMLRPCCommand cmd) throws IOException;

    /**
     * This call initComm(sname, defaultPort)
     * @param sname is the server name to connect to
     */
    public abstract void initComm(String sname) 
        throws RemoteException,
               ConnectException,
               UnknownHostException;
    /**
     * This initializes communication layer
     * @param sname is the server name to connect to
     * @param sport is the server port to connect to
     */
    public abstract void initComm(String sname, int sport) 
        throws RemoteException,
               ConnectException,
               UnknownHostException;

    /**
     * This retreives the server name
     */
    public String getServerName() {
        return serverName;
    }
    /**
     * This configures this object
     * @param c is the configuration
     */
    public static void setConfig(XWConfigurator c) {
        if(config != null) {
            return;
        }

        config = c;
        cache = new Cache(config);
        cache.clear();
        commHandlers = new Hashtable();

        Hashtable layers = util.hash(config.getProperty(XWPropertyDefs.COMMHANDLERS.toString()));
        Enumeration enumLayers = layers.keys();

        while(enumLayers.hasMoreElements()) {

            String key = (String)enumLayers.nextElement();
            String value = (String)layers.get(key);

            try {
                addHandler(key, value);
            }
            catch(Exception e) {
                System.err.println("Init comm layers: ignoring (" + key +
                                   ", " + value + ") : " + e);
            }
        }

        try {
            if(commHandlers.get(Connection.XWSCHEME) == null) {
                String defaultLayer = XWPropertyDefs.COMMLAYER.value();
                if((config.getProperty(XWPropertyDefs.COMMLAYER.toString()) != null) &&
                   (config.getProperty(XWPropertyDefs.COMMLAYER.toString()).length() > 0))
                    defaultLayer = config.getProperty(XWPropertyDefs.COMMLAYER.toString());

                addHandler(Connection.XWSCHEME, defaultLayer);
            }


            if(commHandlers.get(Connection.HTTPSCHEME) == null) {
                addHandler(Connection.HTTPSCHEME, Connection.HTTP.layer());
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            util.fatal("init comm layers : " + e);
        }
    }
//     /**
//      * This adds or replaces a comm handler
//      */
//     public static void addHandler(String schema, String className) 
//         throws ClassNotFoundException,
//                InstantiationException,
//                IllegalAccessException {

//         commHandlers.put(schema, 
//                          (CommClient)Class.forName(className).newInstance());
//     }
//     /**
//      * This constructs an object accordingly to the URI scheme
//      * @see #commHandlers
//      * @param scheme is the URI scheme to retreive client for
//      */
//     public static CommClient getClient(String scheme) 
//         throws ClassNotFoundException {

//         try {
//             if(commHandlers == null)
//                 throw new ClassNotFoundException("Comm Handlers not initialized");
//             return (CommClient)commHandlers.get(scheme);
//         }
//         catch(Exception e) {
//             e.printStackTrace();
//             throw new ClassNotFoundException(e.toString());
//         }
//     }
    /**
     * This adds or replaces a comm handler
     */
    public static void addHandler(String schema, String className) {

        commHandlers.put(schema, className);
    }
    /**
     * This constructs an object accordingly to the URI scheme
     * @see #commHandlers
     * @param scheme is the URI scheme to retreive client for
     */
    public static CommClient getClient(String scheme) 
         throws ClassNotFoundException,
                InstantiationException,
                IllegalAccessException {
        //        throws ClassNotFoundException {

	//        try {
            if(commHandlers == null)
                throw new InstantiationException("Comm Handlers not initialized");
            //            return (CommClient)commHandlers.get(scheme);
            return (CommClient)(Class.forName((String)commHandlers.get(scheme))).newInstance();
//         }

//         catch(Exception e) {
// 	    //	    e.printStackTrace();
//             throw new ClassNotFoundException(e.toString());
//         }
    }
    /**
     * This calls getClient(uri.getScheme())
     * @see #commHandlers
     * @see #getClient(String)
     * @param uri is the URI to connect to
     */
    public static CommClient getClient(URI uri) 
         throws ClassNotFoundException,
                InstantiationException,
                IllegalAccessException {
//        throws ClassNotFoundException {
        return getClient(uri.getScheme());
    }
    /**
     * This retreives the configuration
     * @return this client configuration
     */
    public XWConfigurator getConfig() {
        return config;
    }

    /**
     * This sends an XMLRPC command to be executed on server side
     * @param cmd is the command to send
     * @param close tells whether to close communication channel
     */
    public void sendCommand(XMLRPCCommand cmd, boolean close) 
        throws RemoteException {

        try {
            mileStone.println("<sendCommand idrpc='" + cmd.getIdRpc().toString() + "'>");

            open();

            cmd.setUser(config._user);

            write(cmd);

            if(close) {
                debug("closing channel");
                close();
            }
             else
                 debug("not closing channel");
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            close(true);
            mileStone.println("</sendCommand error='yes'>");
            throw new RemoteException(e.toString());
        }
        mileStone.println("</sendCommand error='no'>");
    }
    /**
     * This sends an XMLRPC command to be executed on server side
     * and closes communication channel
     */
    public void sendCommand(XMLRPCCommand cmd) throws RemoteException, IOException {
        sendCommand(cmd, true);
    }

    /**
     * This writes a file to output channel
     */
    public abstract void writeFile(File f) throws RemoteException, IOException;
    /**
     * This reads a file from input channel
     */
    public abstract void readFile(File f) throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract AppInterface newAppInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract DataInterface newDataInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract TableInterface newTableInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract GroupInterface newGroupInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract HostInterface newHostInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract SessionInterface newSessionInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract TaskInterface newTaskInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract TraceInterface newTraceInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract UserInterface newUserInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract UserGroupInterface newUserGroupInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract WorkInterface newWorkInterface()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract XMLVector newXMLVector()throws RemoteException, IOException;
    /**
     * This creates an object from channel
     */
    protected abstract XMLHashtable newXMLHashtable()throws RemoteException, IOException;

    /**
     * This disconnects this client from server.
     * Disconnection removes sessions from server
     */
    public void disconnect() throws RemoteException, IOException {
        disconnect(new XMLRPCCommandDisconnect());
    }
    /**
     * This disconnects this client from server.
     * Disconnection removes sessions from server
     */
    public void disconnect(XMLRPCCommandDisconnect command)
        throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * This adds an URI to cache to be able to manage URL too
     */
    public void addToCache(URI uri) throws IOException {
        cache.add(uri);
    }
    /**
     * This retreives content file for the given UID
     * The object must be already cached
     * @return a File where to store content for the cached object, null otherwise
     */
    public File getContentFile(UID uid) throws IOException {
        return cache.getContentFile(uid);
    }
    /**
     * This retreives content file for the given UID
     * The object must be already cached
     * @return a File where to store content for the cached object, null otherwise
     */
    public File getContentFile(URI uri) throws IOException {
        return cache.getContentFile(uri);
    }
    /**
     * This call get(uri, true)
     * @param uri is the URI to get the object from
     * @see #get(URI, boolean)
     * @since XWHEP 1.0.0
     */
    public TableInterface get(URI uri)
        throws RemoteException, IOException {
        return get(uri, true);
    }
    /**
     * This calls get(uri.getUID(), bypass)
     * @param uri is the URI to get the object from
     * @param bypass tells to force download
     * @see #get(UID, boolean)
     * @since XWHEP 1.0.0
     */
    public TableInterface get(URI uri, boolean bypass)
        throws RemoteException, IOException {
        return get(uri.getUID(), bypass);
    }
    /**
     * This calls get(uid, true)
     * @param uid is the UID of the object to get
     * @see #get(UID, boolean)
     * @since XWHEP 1.0.0
     */
    public TableInterface get(UID uid)
        throws RemoteException, IOException {
        return get(uid, true);
    }
    /**
     * This calls get(new XMLRPCCommandGet(uid), bypass)
     * @param uid is the UID of the object to get
     * @param bypass tells to force download
     * @see #get(XMLRPCCommanGet, boolean)
     * @since XWHEP 1.0.0
     */
    public TableInterface get(UID uid, boolean bypass) 
        throws RemoteException, IOException {
        return get(new XMLRPCCommandGet(uid), bypass);
    }
    /**
     * This calls get(command, true)
     * @param command is the GET command to send to server
     * @see #get(XMLRPCCommanGet, boolean)
     * @since XWHEP 1.0.0
     */
    public TableInterface get(XMLRPCCommandGet command) 
        throws RemoteException, IOException {
        return get(command, true);
    }
    /**
     * This retreives an object definition given its URI, from server or
     * from cache, if already in cache.
     * @param command is the GET command to send to server
     * @param bypass if true object is downloaded from server even if already in cache
     *               if false, object is only downloaded if not already in cache
     * @return an object definition
     * @since XWHEP 1.0.0
     */
    public TableInterface get(XMLRPCCommandGet command, boolean bypass) 
        throws RemoteException, IOException {

        TableInterface object = null;

        if(bypass == false) {
            object = cache.get(command.getUID());
            if(object != null)
                return (TableInterface)object;
        }

        sendCommand(command, false);
        IOException ioe = null;
        try {
            object = newTableInterface();
            if(object != null)
                cache.add(object);
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return object;
    }
    /**
     * This sends (creates or updates) an application definition
     */
    public void send(AppInterface obj) throws RemoteException, IOException {
        send(new XMLRPCCommandSendApp(obj));
    }
    /**
     * This sends (creates or updates) an application definition
     */
    public void send(XMLRPCCommandSendApp command)
        throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * This retreives an application definition from server, given its name
     * @return an application definition
     * @since 2.0.0
     */
    public AppInterface getApp(String name) 
        throws RemoteException, IOException {

        Vector apps = getApps();

        Enumeration myenum = apps.elements();
        for(; myenum.hasMoreElements(); ) {

            UID uid = (UID)myenum.nextElement();
            if(uid == null)
                continue;

            AppInterface app = (AppInterface)get(uid);
            if((app != null) && (app.getName().compareToIgnoreCase(name) == 0))
                return app;
        }
        return null;
    }
    /**
     * This retreives all applications UID from server
     * @return a vector of UIDs
     */
    public Vector getApps() throws RemoteException, IOException {

        return getApps(new XMLRPCCommandGetApps()).getVector();
    }
    /**
     * This retreives all applications UID from server
     * @return a vector of UIDs
     */
    public XMLVector getApps(XMLRPCCommandGetApps command)
        throws RemoteException, IOException {

        sendCommand(command, false);
        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /**
     * This removes an application from server
     * @param uid is the UID of the object to remove
     */
    public void remove(UID uid) throws RemoteException, IOException {

        remove(new XMLRPCCommandRemove(uid));
    }
    /**
     * This removes an object definition from server
     * @param command is the command to use
     */
    public void remove(XMLRPCCommandRemove command)
        throws RemoteException, IOException {

        sendCommand(command);
    }
    /**
     * This sends (creates or updates) a data definition.
     * <strong>This does not send data content</strong><br />
     * Since 1.9.0 data definition are separated from data content.
     * Data content must be explicitly uploaded by uploadData().
     * @see #uploadData(UID, File)
     * @since 2.0.0
     */
    public void send(DataInterface data)
        throws RemoteException, IOException {

        send(new XMLRPCCommandSendData(data));
    }
    /**
     * This sends (creates or updates) a data definition.
     * <strong>This does not send data content</strong><br />
     * Since 1.9.0 data definition are separated from data content.
     * Data content must be explicitly uploaded by uploadData().
     * @see #uploadData(UID, File)
     * @since 2.0.0
     */
    public void send(XMLRPCCommandSendData command)
        throws RemoteException, IOException {

        sendCommand(command);
    }
    /**
     * This retreives all datas UID from server
     * @return a vector of UIDs
     * @since 2.0.0
     */
    public Vector getDatas() throws RemoteException, IOException {
        return getDatas(new XMLRPCCommandGetDatas()).getVector();
    }
    /**
     * This retreives all datas UID from server
     * @return a vector of UIDs
     * @since 2.0.0
     */
    public XMLVector getDatas(XMLRPCCommandGetDatas command)
        throws RemoteException, IOException {

        sendCommand(command, false);
        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /**
     * This uploads a data content to server, given its URI.
     * @param uri is the URI of the data to download
     * @param content represents a File to store downloaded data
     * @since 2.0.0
     */
    public void uploadData(URI uri, File content) 
        throws RemoteException, IOException {
        uploadData(uri.getUID(), content);
    }
    /**
     * This uploads a data content to server
     * @param uid is the data UID to upload
     * @param content represents a File to get data to upload
     * @since 2.0.0
     */
    public void uploadData(UID uid, File content)
        throws RemoteException, IOException {

        uploadData(new XMLRPCCommandUploadData(uid), content);
    }
    /**
     * This uploads a data content to server
     * @param uid is the UID of the data to upload
     * @param content represents a File to get data to upload
     * @since 2.0.0
     */
    public void uploadData(XMLRPCCommandUploadData command, File content)
        throws RemoteException, IOException {

        if(content.exists() == false) 
            throw new IOException (content.getCanonicalPath() + " not found");

        sendCommand(command, false);
        IOException ioe = null;
        try {
            mileStone.println("<uploadData>");
            writeFile(content);
        }
        catch(Exception e) {
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null) {
            mileStone.println("</uploadData error='yes'>");
            throw ioe;
        }
        mileStone.println("</uploadData error='no'>");
    }
    /**
     * This downloads a data content from server, given its URI.
     * @param uri is the URI of the data to download
     * @param content represents a File to store downloaded data
     * @since 2.0.0
     */
    public void downloadData(URI uri, File content) 
        throws RemoteException, IOException {
        downloadData(uri.getUID(), content);
    }
    /**
     * This downloads a data from server
     * @param uid is the UID of the data to download
     * @param content represents a File to store downloaded data
     * @since 2.0.0
     */
    public void downloadData(UID uid, File content)
        throws RemoteException, IOException {

        downloadData(new XMLRPCCommandDownloadData(uid), content);
    }
    /**
     * This downloads a data from server
     * @param command is the XMLRPC command
     * @param content represents a File to store downloaded data
     * @since 2.0.0
     */
    public void downloadData(XMLRPCCommandDownloadData command, File content)
        throws RemoteException, IOException {

        sendCommand(command, false);
        IOException ioe = null;
        try {
            mileStone.println("<downloadData>");
            readFile(content);
        }
        catch(Exception e) {
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null){
            mileStone.println("</downloadData error='yes'>");
            throw ioe;
        }
        mileStone.println("</downloadData error='no'>");
    }
    /**
     * This creates or updates an group on server side
     * @param obj is the object to send
     */
    public void send(GroupInterface obj)
        throws RemoteException, IOException {

        send(new XMLRPCCommandSendGroup(obj));
    }
    /**
     * This creates or updates an group on server side
     * @param obj is the object to send
     */
    public void send(XMLRPCCommandSendGroup command) 
        throws RemoteException, IOException {

        sendCommand(command);
    }
    /**
     * This retreives all groups UID from server
     * @return a vector of UIDs
     */
    public Vector getGroups() throws RemoteException, IOException {
        return getGroups(new XMLRPCCommandGetGroups()).getVector();
    }
    /**
     * This retreives all groups UID from server
     * @return a vector of UIDs
     */
    public XMLVector getGroups(XMLRPCCommandGetGroups command)
        throws RemoteException, IOException {

        sendCommand(command, false);
        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /**
     * This retreives all works for the given group
     * @return a Vector of UIDs
     */
    public Vector getGroupWorks(UID uid) throws RemoteException, IOException {
        return getGroupWorks(new XMLRPCCommandGetGroupWorks(uid)).getVector();
    }
    /**
     * This retreives all works for the given group
     * @return a Vector of UIDs
     */
    public XMLVector getGroupWorks(XMLRPCCommandGetGroupWorks command) 
        throws RemoteException, IOException {

        sendCommand(command, false);
        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /**
     * @see #sendHost(HostInterface)
     * @deprecated this method is replaced by sendHost(HostInterface) to conform to method names
     */
    public void sendWorker(HostInterface obj) throws RemoteException, IOException {
        send(obj);
    }
    /**
     * This creates or updates a host on server side.<br />
     * This sends objects sent by sendUserInterface(int, XMLable)<br />
     * This receives nothing<br />
     * This closes communication channel
     * @param obj is the object to send
     * @see #sendUserInterface(int, XMLable)
     */
    public void send(HostInterface obj) throws RemoteException, IOException {
        send(new XMLRPCCommandSendHost(obj));
    }
    /**
     * This creates or updates a host on server side.<br />
     * This sends objects sent by sendUserInterface(int, XMLable)<br />
     * This receives nothing<br />
     * This closes communication channel
     * @param obj is the object to send
     * @see #sendUserInterface(int, XMLable)
     */
    public void send(XMLRPCCommandSendHost command)
        throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * @see #getHosts()
     * @deprecated this method is replaced by getHosts() to conform to method names
     */
    public Vector getWorkers() throws RemoteException, IOException {
        return getHosts();
    }
    /**
     * This retreives all hosts from server
     * @return a vector of host UIDs
     */
    public Vector getHosts() throws RemoteException, IOException {

        return getHosts(new XMLRPCCommandGetHosts()).getVector();
    }
    /**
     * This retreives all hosts from server
     * @return a vector of host UIDs
     */
    public XMLVector getHosts(XMLRPCCommandGetHosts command)
        throws RemoteException, IOException {

        sendCommand(command, false);

        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /** 
     * @see #activateHost(UID, int)
     * @deprecated this method is replaced by activateHost(UID, int) to conform to method names
     */
    public void activateWorker(UID uid, boolean flag) throws RemoteException, IOException {
        activateHost(uid, flag);
    }
    /** 
     * Set host active flag.<br />
     * @param uid is the host uid
     * @param flag is the active flag
     */
    public void activateHost(UID uid, boolean flag) throws RemoteException, IOException {
        activateHost(new XMLRPCCommandActivateHost(uid, flag));
    }
    /** 
     * Set host active flag.<br />
     * @param uid is the host uid
     * @param flag is the active flag
     */
    public void activateHost(XMLRPCCommandActivateHost command)
        throws RemoteException, IOException {
        sendCommand(command);
    }
    /** 
     * This is not implemented yet
     */
    public int setWorkersParameters(int nbWorkers,
                                    WorkerParameters p) throws RemoteException, IOException {
        throw new RemoteException("TCPClient#setWorkersParameters is not implemented yet");
        /*
          send(IdRpc.SETWORKERSPARAMETERS, new Integer(nbWorkers));
          io.writeObject(p);
          int ret = ((Integer)io.readObject()).intValue();
          close();
          return ret;
        */
    }

    /** 
     * This is not implemented yet
     */
    public WorkerParameters getWorkersParameters() throws RemoteException, IOException {
        throw new RemoteException("TCPClient#getWorkersParameters is not implemented yet");
        /*
          send(IdRpc.GETWORKERSPARAMETERS);
          WorkerParameters ret = (WorkerParameters)io.readObject();
          close();
          return ret;
        */
    }

    /**
     * This is not implemented yet
     */
    public int setWorkersNb(int nb) throws RemoteException, IOException {
        throw new RemoteException("TCPClient#setWorkersNb is not implemented yet");
        /*
          sendUserInterface(IdRpc.SETWORKERSNB, new Integer(nb));
          int ret = ((Integer)io.readObject()).intValue();
          close();
          return ret;
        */
    }


    /**
     * This creates or updates a session on server side
     * @param obj is the object to send
     */
    public void send(SessionInterface obj)
        throws RemoteException, IOException {
        send(new XMLRPCCommandSendSession(obj));
    }
    /**
     * This creates or updates a session on server side
     * @param obj is the object to send
     */
    public void send(XMLRPCCommandSendSession command)
        throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * This retreives all sessions from server
     * @return a vector of UIDs
     */
    public Vector getSessions() throws RemoteException, IOException {
        return getSessions(new XMLRPCCommandGetSessions()).getVector();
    }
    /**
     * This retreives all sessions from server
     * @return a vector of UIDs
     */
    public XMLVector getSessions(XMLRPCCommandGetSessions command)
        throws RemoteException, IOException {

        sendCommand(command, false);

        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /**
     * This retreives all works for the given session
     * @param uid is the session UID to retreive works for
     * @return a Vector of UID
     */
    public Vector getSessionWorks(UID uid) throws RemoteException, IOException {
        return getSessionWorks(new XMLRPCCommandGetSessionWorks(uid)).getVector();
    }
    /**
     * This retreives all works for the given session
     * @param uid is the session UID to retreive works for
     * @return a Vector of UID
     */
    public XMLVector getSessionWorks(XMLRPCCommandGetSessionWorks command)
        throws RemoteException, IOException {

        sendCommand(command, false);

        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /**
     * This creates or updates an task on server side
     * @param obj is the object to send
     */
    public void send(TaskInterface obj) throws RemoteException, IOException {
        send(new XMLRPCCommandSendTask(obj));
    }
    /**
     * This creates or updates an task on server side
     * @param obj is the object to send
     */
    public void send(XMLRPCCommandSendTask command) throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * This retreives all tasks from server
     * @return a vector of UIDs
     */
    public Vector getTasks() throws RemoteException, IOException {
        return getTasks(new XMLRPCCommandGetTasks()).getVector();
    }
    /**
     * This retreives all tasks from server
     * @return a vector of UIDs
     */
    public XMLVector getTasks(XMLRPCCommandGetTasks command)
        throws RemoteException, IOException {
        sendCommand(command, false);
        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /**
     * @see #sendWork(WorkInterface)
     * @deprecated sendWork(WorkInterface) does all the job
     */
    public void submit(WorkInterface work) throws RemoteException, IOException {
        send(work);
    }
    /**
     * This creates or updates an work on server side.<br />
     * This sends objects sent by sendUserInterface(int, XMLable)<br />
     * This receives nothing<br />
     * This closes communication channel
     * @param obj is the object to send
     * @see #sendUserInterface(int, XMLable)
     */
    public void send(WorkInterface obj) throws RemoteException, IOException {
        send(new XMLRPCCommandSendWork(obj));
    }
    /**
     * This creates or updates an work on server side.<br />
     * This sends objects sent by sendUserInterface(int, XMLable)<br />
     * This receives nothing<br />
     * This closes communication channel
     * @param obj is the object to send
     * @see #sendUserInterface(int, XMLable)
     */
    public void send(XMLRPCCommandSendWork command)
        throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * This requests a work from server
     * @return a WorkInterface or null if no work available
     */
    public WorkInterface workRequest(HostInterface h) throws RemoteException, IOException {
        return workRequest(new XMLRPCCommandWorkRequest(h));
    }
    /**
     * This requests a work from server
     * @return a WorkInterface or null if no work available
     */
    public WorkInterface workRequest(XMLRPCCommandWorkRequest command)
        throws RemoteException, IOException {
        sendCommand(command, false);
        WorkInterface work = null;
        IOException ioe = null;
        try {
            work = newWorkInterface();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException("Can't get work to compute");
        }
        close();
        if(ioe != null)
            throw ioe;
        return work;
    }
    /**
     * This retreives all works from server
     * @return a vector of UIDs
     */
    public Vector getWorks() throws RemoteException, IOException {
        return getWorks(new XMLRPCCommandGetWorks()).getVector();
    }
    /**
     * This retreives all works from server
     * @return a vector of UIDs
     */
    public XMLVector getWorks(XMLRPCCommandGetWorks command)
        throws RemoteException, IOException {
        sendCommand(command, false);
        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /**
     * This broadcasts a new work to all workers
     * @param work defines the work to broadcast
     */
    public void broadcast(WorkInterface work)
        throws RemoteException, IOException {
        broadcast(new XMLRPCCommandBroadcastWork(work));
    }
    /**
     * This broadcasts a new work to all workers
     * @param work defines the work to broadcast
     */
    public void broadcast(XMLRPCCommandBroadcastWork command)
        throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * @deprecated this is deprecated since 1.9.0; uploadData(UID, File) should then be used
     * @see #uploadData(UID, File)
     */
    public void sendResult(DataInterface mr, File rfile) throws RemoteException, IOException {
        throw new RemoteException("TCPClient::sendResult() is deprecated, use uploadData() instead");
    }
    /**
     * @deprecated this is deprecated since 1.9.0; downloadData(UID, File) should then be used
     * @see #downloadData(UID, File)
     */
    public DataInterface getResult(WorkInterface work) throws RemoteException, IOException {
        throw new RemoteException("TCPClient::getResult() is deprecated, use downloadData() instead");
    }
    /**
     * @deprecated this is deprecated since 1.9.0; downloadData(UID, File) should then be used
     * @see #downloadData(UID, File)
     */
    public DataInterface getResult(UID uid) throws RemoteException{
        throw new RemoteException("TCPClient::getResult() is deprecated, use downloadData() instead");
    }

    /**
     * This checks the provided work accordingly to the server status
     * @param client defines the client
     * @param uid is the job UID
     * @return an hahtable containing some parameters
     */
    public Hashtable workAlive(UID uid) throws RemoteException, IOException {

        sendCommand(new XMLRPCCommandWorkAliveByUID(config._user, config._host, uid), false);

        XMLHashtable xmlh = null;
        IOException ioe = null;
        try {
            xmlh = newXMLHashtable();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlh.getHashtable();
    }

    /**
     * This synchronizes with the server
     * @param p is the workAlive parameter
     * @return an hahtable containing some parameters
     */
    public Hashtable  workAlive(Hashtable p) throws RemoteException, IOException {

        sendCommand(new XMLRPCCommandWorkAlive(config._user, config._host, p), false);

        XMLHashtable xmlh = null;
        IOException ioe = null;
        try {
            xmlh = newXMLHashtable();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlh.getHashtable();
    }

    /**
     * This pings the server
     */
    public void ping() throws RemoteException, IOException {
        sendCommand(new XMLRPCCommandPing());
    }


    /**
     * This creates or updates a trace on server side
     */
    public void send(TraceInterface obj) throws RemoteException, IOException {
        send(new XMLRPCCommandSendTrace(obj));
    }
    /**
     * This creates or updates a trace on server side
     */
    public void send(XMLRPCCommandSendTrace command) throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * This retreives all traces from server
     * @return a vector of UIDs
     */
    public Vector getTraces() throws RemoteException, IOException {

        return getTraces(new XMLRPCCommandGetTraces()).getVector();
    }
    /**
     * This retreives all traces from server
     * @return a vector of UIDs
     */
    public XMLVector getTraces(XMLRPCCommandGetTraces command)
        throws RemoteException, IOException {

        sendCommand(command, false);

        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /** 
     * Get all known traces.
     * @return an vector of traces UID
     */
    public Vector getTraces(Date since, Date before) throws RemoteException, IOException {
        throw new RemoteException("not implemented");
    }
    /**
     * This creates or updates an usergroup on server side
     */
    public void send(UserGroupInterface ug) throws RemoteException, IOException {
        send(new XMLRPCCommandSendUserGroup(ug));
    }
    /**
     * This creates or updates an usergroup on server side
     */
    public void send(XMLRPCCommandSendUserGroup command)
        throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * This retreives all usergroups from server
     * @return a vector of UIDs
     */
    public Vector getUserGroups() throws RemoteException, IOException {

        return getUserGroups(new XMLRPCCommandGetUserGroups()).getVector();
    }
    /**
     * This retreives all usergroups from server
     * @return a vector of UIDs
     */
    public XMLVector getUserGroups(XMLRPCCommandGetUserGroups command)
        throws RemoteException, IOException {

        sendCommand(command, false);

        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /**
     * This creates or updates an user on server side
     */
    public void send(UserInterface user) throws RemoteException, IOException {
        send(new XMLRPCCommandSendUser(user));
    }
    /**
     * This creates or updates an user on server side
     */
    public void send(XMLRPCCommandSendUser command) throws RemoteException, IOException {
        sendCommand(command);
    }
    /**
     * This retreives an user from server
     */
    public UserInterface getUser(String login) throws RemoteException, IOException {
        return getUser(new XMLRPCCommandGetUserByLogin(login));
    }
    /**
     * This retreives an user from server
     */
    public UserInterface getUser(XMLRPCCommandGetUserByLogin command)
        throws RemoteException, IOException {

        sendCommand(command, false);

        UserInterface u = newUserInterface();
        IOException ioe = null;
        try {
            u = newUserInterface();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return u;
    }
    /**
     * This retreives all users from server
     * @return a vector of UIDs
     */
    public Vector getUsers() throws RemoteException, IOException {
        return getUsers(new XMLRPCCommandGetUsers()).getVector();
    }
    /**
     * This retreives all users from server
     * @return a vector of UIDs
     */
    public XMLVector getUsers(XMLRPCCommandGetUsers command)
        throws RemoteException, IOException {

        sendCommand(command, false);

        XMLVector xmlv = null;
        IOException ioe = null;
        try {
            xmlv = newXMLVector();
        }
        catch(Exception e) {
            mileStone.println("Reading error");
            ioe = new IOException(e.toString());
        }
        close();
        if(ioe != null)
            throw ioe;
        return xmlv;
    }
    /** 
     * This creates a Mobile Work filled with worker software. It is
     * used to update worker as needed.
     * @return a filled mobileWork
     */ 
    public WorkInterface getWorkerBin() throws RemoteException, IOException {
        throw new RemoteException("CommClient#getWorkerBin not implemented yet");
    }


    /*
     * Tracer
     */
    public void  tactivityMonitor(long   start,
                                  long   end,
                                  byte[] file) throws RemoteException, IOException {
        throw new RemoteException("CommClient#tactivitymonotor not implemented yet");
    }


    /** 
     * Get trusted addresses
     * @return a string containing trused ip addresses separated by a
     * white space.
     */
    public String getTrustedAddresses() throws RemoteException, IOException {
        throw new RemoteException("CommClient#getTrustedAddresses not implemented yet");
    }

    /** 
     * Add a trusted address
     * @param ip new trusted IP
     */
    public void addTrustedAddress(String ip) throws RemoteException, IOException {
        throw new RemoteException("CommClient#addtrustedaddress not implemented yet");
    }

    /** 
     * Remove a trusted address
     * @param ip trusted IP to remove
     */
    public void removeTrustedAddress(String ip) throws RemoteException, IOException {
        throw new RemoteException("CommClient#removeTrustedAddress not implemented yet");
    }

    /** 
     * Set workers trace flag.
     * @param hosts is a hashtable which contains host name as key and their
     * dedicated trace flag as value.
     */
    public void traceWorkers(Hashtable hosts) throws RemoteException, IOException {
        throw new RemoteException("CommClient#traceWorkers not implemented yet");
    }


    /**
     * This removes a set of jobs
     * @param jobs is a Vector of  UID
     * @exception RemoteException on connection error
     */
    public void removeWorks(Vector jobs)
        throws RemoteException, IOException {
	
        Iterator li = jobs.iterator();

        while(li.hasNext()) {
            UID uid =(UID) li.next();
            remove(uid);
        }

    }

    /**
     * This retreives job status
     * @param uid is the UID of the job to retreive status for
     * @return XWStatus.ERROR on error, job status otherwise
     * @exception RemoteException on connection error
     */
    public XWStatus jobStatus(UID uid)
        throws RemoteException, IOException {
	
        XWStatus status = XWStatus.ERROR;
	
        WorkInterface work = (WorkInterface)get(uid);
        status = work.getStatus();
        return status;

    }//jobStatus

    /**
     * This retreives a group status
     * @param group describes the group
     * @return XWStatus.ERROR on error, XWStatus.COMPLETED if
     *         all this group jobs are completed, XWStatus.WAITING otherwise
     * @exception RemoteException on connection error
     * @exception IOException if the group UID is not set
     */
    public XWStatus groupStatus(GroupInterface group)
        throws RemoteException, IOException {
	
        XWStatus status = XWStatus.ERROR;
        Vector jobIDs = null;
	
        jobIDs = getGroupWorks(group.getUID());

        if(jobIDs == null)
            return status;

        boolean success = false;

        for(Enumeration e = jobIDs.elements() ; e.hasMoreElements() ;) {
            UID uid =(UID) e.nextElement();
            WorkInterface work = (WorkInterface)get(uid);
            if(work.getStatus() != XWStatus.COMPLETED)
                return XWStatus.WAITING;
        }

        return XWStatus.COMPLETED;
    }

    /**
     * This retreives a session status
     * @param session describes the session
     * @return XWStatus.ERROR on error, 
     *         XWStatus.COMPLETED if all results are completed,
     *         XWStatus.WAITING   if at least one is not completed
     * @exception RemoteException on connection error
     * @exception IOException if the session UID is not set
     */
    public XWStatus sessionStatus(SessionInterface session)
        throws RemoteException, IOException {

        XWStatus status = XWStatus.ERROR;
        Vector jobIDs = null;
	
        jobIDs = getSessionWorks(session.getUID());

        if(jobIDs == null)
            return status;

        for(Enumeration e = jobIDs.elements() ; e.hasMoreElements() ;) {
            UID uid =(UID) e.nextElement();
            WorkInterface work = (WorkInterface)get(uid);
            if(work.getStatus() != XWStatus.COMPLETED)
                return XWStatus.WAITING;
        }

        return XWStatus.COMPLETED;
    }

    /**
     * This retreives group results
     * @return a Vector of MobileResult or null on error
     * @exception RemoteException on connection error
     */
    public Vector getResults()
        throws RemoteException, IOException {
	
        Vector uids = getWorks();

        return getResults(uids);

    } // getResults
    
    /**
     * This retreives group results
     * @param uids is a Vector of UID
     * @return a Vector of MobileResult or null on error
     * @exception RemoteException on connection error
     */
    public Vector getResults(Vector uids)
        throws RemoteException {

        Vector results = null;

        throw new RemoteException("CommClient::getResult() not implemented");
        /*
          if(uids == null)
          return null;

          for(Enumeration e = uids.elements() ; e.hasMoreElements() ;) {
          UID uid =(UID) e.nextElement();
          MobileResult result = getResult(uid);
          results.add(result);
          }

          return results;
        */

    } // getResults
    
    /**
     * This retreives group results
     * @param group describes the group to retreive results for
     * @return a Vector of MobileResult or null on error
     * @exception RemoteException on connection error
     * @exception IOException if the group UID is not set
     */
    public Vector getGroupResults(GroupInterface group)
        throws RemoteException, IOException {
	
        Vector uids = null;
        uids = getGroupWorks(group.getUID());
        return getResults(uids);

    }//getGroupResults
    

    /**
     * This retreives session results
     * @param session describes the session to retreive results for
     * @return a Vector of MobileResult or null on error
     * @exception RemoteException on connection error
     * @exception IOException if the session UID is not set
     */
    public  Vector getSessionResults(SessionInterface session)
        throws RemoteException, IOException {
	
        Vector results = null;
        Vector uids = null;
	
        uids = getSessionWorks(session.getUID());

        return getResults(uids);

    }//getSessionResults

    /**
     * This method waits for works to complete, with a time out<br />
     * If time out is reached, this returns the works completed within the given time
     * @param works a Vector of UID
     * @param deltaT is the time out to wait, in milliseconds
     * @return a Vector of the UID of the completed works within timeout, if any
     * @exception RemoteException on connection error
     */
    public Vector getCompletedWorks(Vector works, long deltaT)
        throws RemoteException {

        long t0 = System.currentTimeMillis();
        Vector completed = new Vector();

        while((completed.size() < works.size()) &&
              (deltaT > (System.currentTimeMillis() - t0))) {

            Enumeration enums = works.elements();

            while(enums.hasMoreElements()) {
                UID uid = (UID)enums.nextElement();
                try {
                    waitForCompletedWork(uid, deltaT);
                }
                catch(InterruptedException e) {
                }
                completed.add(uid);
            }
        }
        return completed;
    }
    /**
     * This method waits (for ever) until all works are completed<br />
     * Keep in mind that this may never return
     * @param works a Vector of UID
     * @exception RemoteException on connection error
     */
    public void waitForCompletedWorks(Vector works) 
        throws RemoteException {
        try {
            waitForCompletedWorks(works, -1);
        }
        catch(InterruptedException e) {
            // this can never occur
        }
    }
    /**
     * This method waits until all works are completed, with a time out<br />
     * If time out is reached an InterruptedException is thrown
     * @param works a Vector of UID
     * @param deltaT is the time out to wait, in milliseconds
     * @exception RemoteException on connection error
     * @exception InterruptedException if time out reached
     */
    public void waitForCompletedWorks(Vector works, long deltaT)
        throws RemoteException, InterruptedException {

        long t0 = System.currentTimeMillis();
        Vector completed = new Vector();

        while(completed.size() < works.size()) {

            if(deltaT < (System.currentTimeMillis() - t0))
                throw new InterruptedException("waitForCompletedWorks reached "
                                               + deltaT);

            Enumeration enums = works.elements();

            while(enums.hasMoreElements()) {
                UID uid = (UID)enums.nextElement();

                debug("Waiting completion for " + uid);

                waitForCompletedWork(uid, deltaT);
                deltaT -= (System.currentTimeMillis() - t0);
                t0 = System.currentTimeMillis();

                completed.add(uid);
            }
        }
    }
    /**
     * This method waits until the work is completed<br />
     * Keep in mind that this may never return
     * @param uid is the UID of the expected work
     * @exception RemoteException on connection error
     */
    public void waitForCompletedWork(UID uid) 
        throws RemoteException {
        try {
            waitForCompletedWork(uid, -1);
        }
        catch(InterruptedException e) {
            // this can never occur
        }
    }
    /**
     * This method waits until the work is completed, with a time out
     * @param uid is the UID of the expected work
     * @param deltaT is the time out in milliseconds
     * @exception RemoteException on connection error
     * @exception InterruptedException if time out reached
     */
    public void waitForCompletedWork(UID uid, long deltaT)
        throws RemoteException, InterruptedException {

        waitForWork(XWStatus.COMPLETED, uid, deltaT);
    }
    /**
     * This waits until a work has the given status within the given time
     * @param status  is the status to wait for
     * @param uid is the uid of the expected work
     * @param deltaT is the time out in seconds
     * @exception RemoteException on connection error
     * @exception InterruptedException on time out error
     */
    public void waitForWork(XWStatus status, UID uid, long deltaT)
        throws RemoteException, InterruptedException {

        long t0 = System.currentTimeMillis();

        mileStone.println("waitForWork start");

        while(true) {

            if(deltaT < (System.currentTimeMillis() - t0))
                throw new InterruptedException("waitForWork " + 
                                               uid + "," + status + 
                                               " reached " + deltaT);
            try {
                WorkInterface work = (WorkInterface)get(uid);
                if(work.getStatus() == status) {
                    mileStone.println("waitForWork done");
                    return;
                }
            }
            catch(IOException e) {
            }
            Thread.sleep(Math.max(100,
                                  Integer.parseInt(config.getProperty(XWPropertyDefs.TIMEOUT.toString()))));
        }
    }

}
