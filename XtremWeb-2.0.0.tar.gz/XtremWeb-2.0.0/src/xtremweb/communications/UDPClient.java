package xtremweb.communications;

/**
 * Created: Jun 2nd, 2005<br />
 *
 * This class implements the UDP client part to connect to the dispatcher
 * This class is not thread safe!
 *
 * @see xtremweb.dispatcher.TCPHandler
 * @author Oleg Lodygensky
 * @since RPCXW
 */

import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.BytePacket;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.WorkerParameters;
import xtremweb.common.StreamIO;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.XWOSes;
import xtremweb.common.XWCPUs;
import xtremweb.common.MileStone;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWStatus;
import xtremweb.common.XMLVector;
import xtremweb.common.XMLHashtable;

import java.io.IOException;
import java.io.File;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.rmi.RemoteException;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.net.SocketTimeoutException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.DatagramPacket;
import java.net.DatagramSocket;


public class UDPClient extends CommClient {

    /**
     * This manages the packet byte array
     */
    private Selector selector;
    private int timeOut;
    InetSocketAddress serverAddr;

    /**
     * This is the channel used for I/O
     */
    DatagramChannel nioServer;
    /**
     * This aims to determine communication time out
     */
    protected SocketTimeoutException soTimeout;
    protected BytePacket packet;

    /**
     * This is the server host to send client requests to
     */
    protected InetAddress serverHost;
    /**
     * This is the datagram packet used for I/O
     */
    DatagramPacket serverPacket;
    /**
     * This is the datagram socket used for I/O
     */
    DatagramSocket serverSocket;

    protected boolean waitAnswer;
    protected boolean nio;
    /**
     * This is the default constructor; this only calls super()
     */
    public UDPClient() {
        super();
        nioServer    = null;
        serverHost   = null;
        serverPacket = null;
        serverSocket = null;
        soTimeout = new SocketTimeoutException();
    }

    /**
     * This only sets the server name to connect to.
     * This does not effectivly connects to server
     * @param server is the server name to connect to
     */
    public void initComm(String sname) throws RemoteException {
        initComm(sname, config.getPort(Connection.UDP, 
                                       Connection.UDP.defaultPortValue()));
    }
    /**
     * This only sets the server name to connect to.
     * This does not effectivly connects to server
     * @param server is the server name to connect to
     * @param sport is the server port to connect to
     */
    public void initComm(String sname, int sport) throws RemoteException {

        waitAnswer = false;
        try {
            serverName = util.getHostName(sname);
        }
        catch(IOException e) {
            throw new RemoteException(e.toString());
        }
        serverPort = sport;

        try {
            nio = config.nio();

            if(nio) {
                nioServer = DatagramChannel.open();
                nioServer.configureBlocking(false);
                serverAddr = new InetSocketAddress(serverName, serverPort);
                packet = new BytePacket(level);

                selector = Selector.open();
                nioServer.register(selector, SelectionKey.OP_READ);
                timeOut = config.getInt(XWPropertyDefs.SOTIMEOUT,
                                        Integer.parseInt(XWPropertyDefs.SOTIMEOUT.value()));
            }
            else {
                serverSocket = new DatagramSocket();
                serverSocket.setSoTimeout(config.getInt(XWPropertyDefs.SOTIMEOUT,
                                                        Integer.parseInt(XWPropertyDefs.SOTIMEOUT.value())));

                serverSocket.setTrafficClass(0x08);          // maximize throughput
		
                serverHost = InetAddress.getByName(serverName);
                //						packet = new ByteStack(logger.getEffectiveLevel());
                packet = new BytePacket(level);
		
                byte[] d = packet.getData();
                serverPacket = new DatagramPacket(d, d.length, 
                                                  serverHost, 
                                                  serverPort);
            }
        }
        catch(IOException e) {
            throw new RemoteException(e.toString());
        }
    }

    /**
     * This calls packet.reset()
     */
    protected void open() {
        packet.reset();
    }
    /**
     * This sends IdRpc.CLOSE
     * @param b is not used
     */
    public void close(boolean b) {
        close();
    }
    /**
     * This sends IdRpc.CLOSE
     */
    public void close() {
        try {
            open();
            packet.putInt(IdRpc.CLOSE.ordinal());
            send();
        }
        catch(Exception e) {
            debug("Can't send IdRpc.CLOSE " + e);
        }
    }
    /**
     * This waits for a packet
     * @see xtremweb.common.ByteStack#pack()
     */
    protected void receive() throws RemoteException, IOException {
        if(waitAnswer == false)
            throw new RemoteException("we can only receive answers...");
        //				packet.reset();
        serverPacket.setData(packet.getData());
        serverSocket.receive(serverPacket);
        packet.setData(serverPacket.getData());
        waitAnswer = false;
    }
    /**
     * This first packs the packet then sends it
     * @see xtremweb.common.ByteStack#pack()
     */
    protected void send() throws RemoteException {
        try {
            //						int port = config.getPort(Connection.UDPPORTTEXT, Connection.UDPPORT);
            packet.pack();
            byte[] buf = packet.getData();
            // 						byte[] buf = new byte[packet.getSize()];
            // 						System.arraycopy(packet.getData(), 0, buf, 0, packet.getSize());
            /*
              serverPacket = new DatagramPacket(buf, 
              buf.length,
              serverHost, 
              port);
            */
            serverPacket.setData(buf);
            serverSocket.send(serverPacket);
            waitAnswer = true;
        }
        catch(IOException e) {
            //            e.printStackTrace();
            error("send failed " + e);
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This puts the UserInterface and the IrRpc code
     */
    protected void write(XMLRPCCommand cmd) throws IOException {
        packet.putObject(cmd);
        send();
    }
    /**
     * This creates an object from channel
     */
    protected TableInterface newTableInterface() throws RemoteException, IOException {
        return TableInterface.newInterface(packet.getString());
    }
    /**
     * This creates an object from channel
     */
    protected AppInterface newAppInterface() throws RemoteException, IOException {
        return new AppInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected DataInterface newDataInterface() throws RemoteException, IOException {
        return new DataInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected GroupInterface newGroupInterface() throws RemoteException, IOException {
        return new GroupInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected HostInterface newHostInterface() throws RemoteException, IOException {
        return new HostInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected SessionInterface newSessionInterface() throws RemoteException, IOException {
        return new SessionInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected TaskInterface newTaskInterface() throws RemoteException, IOException {
        return new TaskInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected TraceInterface newTraceInterface() throws RemoteException, IOException {
        return new TraceInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected UserInterface newUserInterface() throws RemoteException, IOException {
        return new UserInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected UserGroupInterface newUserGroupInterface() throws RemoteException, IOException {
        return new UserGroupInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected WorkInterface newWorkInterface() throws RemoteException, IOException {
        return new WorkInterface(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected XMLVector newXMLVector() throws RemoteException, IOException {
        return new XMLVector(StreamIO.stream(packet.getString()));
    }
    /**
     * This creates an object from channel
     */
    protected XMLHashtable newXMLHashtable() throws RemoteException, IOException {
        return new XMLHashtable(StreamIO.stream(packet.getString()));
    }

    /**
     * This writes a file to socket
     * @param f is the file to send
     */
    public void writeFile(File f) throws RemoteException, IOException {
        throw new IOException("UDP does not implement writeFile");
    }
    /**
     * This reads a file from socket
     * This is typically needed after a workRequest to get stdin and/or dirin files
     * @param f is the file to store received bytes
     */
    public void readFile(File f) throws RemoteException, IOException {
        throw new IOException("UDP does not implement readFile");
    }

}
