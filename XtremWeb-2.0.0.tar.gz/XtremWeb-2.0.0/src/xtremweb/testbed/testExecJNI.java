import xtremweb.archdep.*;

public class testExecJNI {
    public static void main(String[] argv) {
	XWExec exec = ArchDepFactory.xwexec();
	String[] args = new String[2];
	args[0] = "/bin/echo";
	args[1] = "bonjour";
	try{
	    exec.exec(args, "", "stdout", "stderr", ".");
	}catch(java.lang.UnsatisfiedLinkError e) {
	    System.out.println("JNI "+e.toString());
	}
	System.out.println("Execussion ended "+exec.waitFor());
    }
}
