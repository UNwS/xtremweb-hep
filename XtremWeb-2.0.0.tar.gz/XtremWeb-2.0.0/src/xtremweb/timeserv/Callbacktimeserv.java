package xtremweb.timeserv;

/**
 * Callbacktimeserv.java
 *
 *
 * Created: Mon Apr  5 04:39:29 2004
 *
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */

import java.util.Hashtable;
import xtremweb.XwIDL.*;
import xtremweb.dispatcher.*;
import xtremweb.common.*;
import java.sql.*;
public class Callbacktimeserv  extends CallbackTemplate  {

    public Callbacktimeserv() {
    }

    public long  myTime( long workerUID, long timestamp ) {
	long ts = System.currentTimeMillis();	
	long shift = ts - timestamp;
	try {
	    //	    String str="UID='" + workerUID + "'";
	    //Host h = new Host ();
	    //h.setTimeShift((int)shift);                
	    //h.update(); 
	String query = "update hosts set timeShift=" + shift + " where uid='" + workerUID+"'";
   	ResultSet rs = DBConnPool.instance.executeQuery(query);	    
	} catch (Exception e) {
	    return 0;
	} // end of try-catch
	

	return shift;
    }
    
    
}
