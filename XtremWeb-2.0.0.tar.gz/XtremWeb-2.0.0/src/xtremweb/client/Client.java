package xtremweb.client;

import xtremweb.common.util;
import xtremweb.common.Logger;
import xtremweb.common.LoggerLevel;
import xtremweb.common.Loggerable;
import xtremweb.common.CommonVersion;
import xtremweb.common.Version;
import xtremweb.common.XWReturnCode;
import xtremweb.common.DataType;
import xtremweb.common.XWAccessRights;
import xtremweb.common.XWCPUs;
import xtremweb.common.XWOSes;
import xtremweb.common.XWRole;
import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.TableInterface;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.GroupInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.JobInterface;
import xtremweb.common.SessionInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.TraceInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.CommandLineParser;
import xtremweb.common.CommandLineOptions;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWStatus;
import xtremweb.common.Zipper;
import xtremweb.common.MileStone;
import xtremweb.common.XMLable;
import xtremweb.common.XMLVector;
import xtremweb.common.XMLHashtable;
import xtremweb.common.UserRights;
import xtremweb.common.MD5;
import xtremweb.communications.*;
import xtremweb.rpcd.client.*;

import java.io.IOException;
import java.io.EOFException;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Vector;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.net.ConnectException;
import java.net.UnknownHostException;



/**
 * Created: Oct 1st, 2003<br />
 *
 * This class describes a generic client to XtremWeb.
 * It is designed to submit, delete jobs as to get job status and results.
 * <br /><br />
 * Examples can be found in CommandLineParser.
 *
 * @see xtremweb.common.CommandLineParser
 *
 * @author <a href="mailto:lodygens a lal.in2p3.fr">Oleg Lodygensky</a>
 * @version %I%, %G%
 */


public class Client extends Logger {

    /**
     * This stores and tests the command line parameters
     */
    private CommandLineParser args;
    /**
     * This is needed to call this class methods from GUI
     */
    public void setArguments(CommandLineParser a) {
        args = a;
    }
    /**
     * This stores client config such as login, password, server addr etc.
     */
    private XWConfigurator config;
    public XWConfigurator getConfig() {
        return config;
    }
    public void setConfig(XWConfigurator c) {
        config = c;
    }
    /**
     * This stores the macro file line number.
     */
    private int macroLineNumber;
    /**
     * This is the macro file
     */
    private File macroFile;

    /**
     * This creates an new URI for the provided server and UID, 
     * with the correct port
     * @param server is the server name
     * @param uid is the object uid
     */
    public URI newURI(String server, UID uid) {
        return new URI(server,
                       uid);
    }

    /**
     * This retreives the default comm client and initializes it
     * @return the default comm client
     */
    public CommClient commClient() 
        throws RemoteException, 
               UnknownHostException, 
               ConnectException {
        try {
            CommClient commClient = config.defaultCommClient();
            commClient.initComm(config.getCurrentDispatcher());
            return commClient;
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
    }
    /**
     * This retreives the comm client for the given URI and initializes it
     * @param uri is the uri to retreive comm client for
     * @return the expected comm client 
     */
    public CommClient commClient(URI uri) 
        throws RemoteException, 
               UnknownHostException, 
               ConnectException {

        CommClient commClient = null;
        try {
            commClient = config.getCommClient(uri);
        }
        catch(Exception e) {
            throw new RemoteException(e.toString());
        }
        //        commClient.setConfig(config);
        if(uri.getPort() > 0)
            commClient.initComm(uri.getHost(), uri.getPort());
        else
            if(Connection.HTTPSCHEME.compareTo(uri.getScheme()) == 0)
                commClient.initComm(uri.getHost(), Connection.WEBDEFAULTPORT);
            else
                commClient.initComm(uri.getHost());
        return commClient;
    }
    /**
     * This retreives the data for the given URI
     * @param uri is the data uri
     * @return the data
     */
    private DataInterface getData(URI uri) 
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        DataInterface data = (DataInterface)commClient().get(uri);
        if(data != null)
            return data;

        CommClient commClient = commClient(uri);
        data = (DataInterface)commClient.get(uri);

        if(data == null)
            throw new IOException("can't retreive data " + uri);

        return data;
    }
    /**
     * This retreives the data for the given URI
     * This finally retreives the data content for the given URI
     * @param uri is the data uri
     */
    private void uploadData(URI uri) 
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        // insure data is in cache
        DataInterface data = getData(uri); 

        commClient(uri).uploadData(uri, commClient().getContentFile(uri));
    }
    /**
     * This calls downloadData(uri, false)
     * @see #downloadData(URI, boolean)
     */
    private void downloadData(URI uri)
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        downloadData(uri, false);
    }
    /**
     * This does nothing if uri parameter is null.
     * This retreives the data from server
     * @param uri is the data uri
     * @param download if false, data content is not downloaded if data already in cache;
     *                 if true, data content is downloaded even if data already in cache
     */
    private void downloadData(URI uri, boolean download)
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException,
               IOException {

        if(uri == null)
            return;

        // insure data is in cache
        DataInterface data = getData(uri); 

        if(download == false)
            return;

        CommClient commClient = commClient(uri);

        File fdata = null;
        UID uid = uri.getUID();

        String fext = "";
        if(data.getType() != null)
            fext = data.getType().getFileExtension();

        if(data.getName() != null)
            fdata = new File(uid.toString() + "_" + data.getName() + fext);
        else
            fdata = new File(uid.toString() + fext);

        commClient.downloadData(uri, fdata);
        if(data.getMD5() == null)
            throw new IOException(uri.toString() + " MD5 is null ?!?!");
        if(data.getMD5().compareTo(MD5.asHex(MD5.getHash(fdata))) != 0)
            throw new IOException(uri.toString() + " MD5 differs");
    }
    /**
     * This is the pass phrase to crypt the password 
     * This is generated at compil time
     */
    private final String passPhrase = "some chars to generate keys";
    /**
     * This retreives the pass phrase to crypt the password 
     */
    public String getPassPhrase() {
        return passPhrase;
    }
    /**
     * This is the zip file
     */
    private Zipper zipper;

    private static final String NAME = "CLIENT";

    /**
     * This sets the logger level.
     * This also sets the logger levels checkboxes menu item.
     */
    public void setLoggerLevel(LoggerLevel l) {
        level = l;
        if(zipper != null)
            zipper.setLoggerLevel(l);
    }

    /**
     * This aims to display some time stamps
     */
    MileStone mileStone;

    /**
     * This is the default constructor
     */
    public Client(String[] argv) throws ParseException {
        config = null;
        macroLineNumber = 0;
        macroFile = null;
        zipper = new Zipper(level);

        try {
            args = new CommandLineParser(argv);
        }
        catch(Exception e){
            if(debug())
                e.printStackTrace();
            usage(e.toString());
        }

        if(args.help() || 
           ((args.command() == IdRpc.NULL) && (args.getOption(CommandLineOptions.GUI) == null) &&
            (args.getOption(CommandLineOptions.MACRO) == null)))
            usage();

        try {
            config = (XWConfigurator)args.getOption(CommandLineOptions.CONFIG);
            level = config.getLoggerLevel();
        }
        catch(NullPointerException npe) {
            if(args.getOption(CommandLineOptions.GUI) == null) {
                System.err.println("You must provide a config file, using \"--xwconfig\" !");
                System.exit(1);
            }
            else {
                new MileStone(util.split(new String()));
                mileStone = new MileStone(getClass().getName());
            }
        }

    }


    /**
     * This shows application usage
     */
    private void usage() {
        usage(null);
    }


    /**
     * This shows application usage
     * @see xtremweb.common.CommandLineOptions#usage()
     */
    private void usage(String msg) {

        args.usage("This is the XWHEP client to use and manage the platform.");

//         System.out.println("Examples :");
//         System.out.println("   - to delete the jobs UID = 100 :");
//         System.out.println("     $> java -jar xtremweb.jar --xwconfig aConfigFile --xwremovework 100");
//         System.out.println("");
//         System.out.println("   - to retreive all your jobs (including results if available) :");
//         System.out.println("     $> java -jar xtremweb.jar --xwconfig aConfigFile --xwgetworks");
//         System.out.println("   - to retreive job number 100 (including results if available) :");
//         System.out.println("     $> java -jar xtremweb.jar --xwconfig aConfigFile --xwgetwork 100");
//         System.out.println("   - to retreive job number 100 excluding results even if available :");
//         System.out.println("     $> java -jar xtremweb.jar --xwconfig aConfigFile --xwgetwork 100 --xwnoresult");
//         System.out.println("");
//         System.out.println("   - to submit a new job app name or UID must be provided");
//         System.out.println("   - to submit a new job with no argument :");
//         System.out.println("     $> java -jar xtremweb.jar --xwconfig aConfigFile --xwsendwork appName");
//         System.out.println("   - to submit a new job with arguments :");
//         System.out.println("     $> java -jar xtremweb.jar --xwconfig aConfigFile --xwsendwork appName yourArg0 yourArg1 ...");
//         System.out.println("   - to submit a new job with an input file :");
//         System.out.println("     $> java -jar xtremweb.jar --xwconfig aConfigFile --xwsendwork appName < aTextFile");
//         System.out.println("   - to submit a new job with its environment(set of files) allready packed in a zip file :");
//         System.out.println("     $> java -jar xtremweb.jar --xwconfig aConfigFile --xwsendwork appName --xwenv <aZipFile.zip>");
//         System.out.println("   - to submit a new job with its environment(set of files) found in the current dir :");
//         System.out.println("     $> java -jar xtremweb.jar --xwconfig aConfigFile --xwsendwork appName --xwenv .");

        if(msg != null) {
            System.out.println("\n+-----------------------------------------------------------------------------+");
            System.out.println("  Usage :  " + msg);
            System.out.println("+-----------------------------------------------------------------------------+\n");
        }

        System.out.println("");
        System.exit(XWReturnCode.PARSING.ordinal());
    }


    /**
     * This summarizes action details to stdout
     */
    private String actionToString() {
        try {
            return args.command().toString();
        }
        catch(Exception e) {
            exit(e.toString(), XWReturnCode.PARSING);
        }
        return null;
    }


    /**
     * This summarizes action details to stdout
     * @see xtremweb.common.CommandLineOptions#verbose()
     */
    private void verbose() {
        if(args.isVerbose()) {
            System.out.println("server      = " + config.getCurrentDispatcher());
            System.out.println("login = " + config._user.getLogin());
        }
        args.verbose();
    }


    /**
     * This prints out a string, if expected.<br>
     * Output is formated accordingly to <code>args.outputFormat</code>.
     * @see #args
     * @param write tells whether to write or not
     * @param str is the string to eventually print out
     */
    private void println(boolean write, String str) {
        if(write == false)
            return;

        if(!args.html()) {
            System.out.println(str);
            return;
        }

        Vector array = util.split(str, "\t ,;");

        for(int i = 0; i < array.size(); i++) {
            System.out.println("<td align=\"center\">" + array.get(i) + "</td>");
        }
    }


    /**
     * This prints out a string if allowed(--verbose option)
     * @param str is the string to eventually print out
     */
    private void println(String str) {
        println(args.isVerbose(), str);
    }


    /**
     * This prints a message to std err and exits.
     * @param msg is the message to print to stderr
     * @param code is the return code to use on exit
     */
    private void exit(String msg, XWReturnCode code) {
        error(msg);
        try {
            commClient().close();
        }
        catch(Exception e) {
        }
        System.exit(code.ordinal());
    }


    /**
     * This is called when XtremWeb server is not reachable.
     * This terminates this application.
     */
    private void connectionRefused() {
        exit("connection refused", XWReturnCode.CONNECTION);
    }


    /**
     * This inserts an HTML header
     * This displays nothing on any other output format.
     * Header is only inserted if there is no macro or if force is true
     * @param force forces output if true
     */
    private void header() {

        if(args.xml()) {
	    System.out.println(args.command().toXml());
	}

        if(args.html() == false)
            return;

        Date currentDate = new Date();

        System.out.println("<html><head><title>XWHEP Client " +
                           actionToString() +
                           "(" + currentDate + ")" +
                           "</title></head><body><center>");

        System.out.println("<h1>XWHEP Client " +
                           actionToString() +
                           "(" + currentDate + ")" +
                           "</h1><br><table border='1'>");
    }


    /**
     * This inserts a trailer, depending on output format
     * This displays nothing on any other output format.
     * Trailer is only inserted if there is no macro or if force is true
     * @param force forces output if true
     */
    private void trailer() {

        if(args.xml()) {
	    System.out.println(args.command().toXml(true));
	}
        if(args.html())
            System.out.println("</table></center></body></html>");
    }


    /**
     * This writes out an HTML and XML tag. Does nothing for any other format.
     * @param t is the ML tag
     * @param open is true to open the tags, false to close it
     */
    private void tag(boolean open, String t) {

        if(args.html() || args.xml()) {
            if((t != null) &&(t.length() > 0))
                println(true, "<" +(open == true ? "" : "/") + t + ">");
        }
    }


    /**
     * This starts a new line, depending on output format.
     * For HTML format, this opens a TR tag; for XML format, this opens the provided tag.
     * This displays nothing on any other output format.
     * @param t is the XML tag to open, if any
     */
    private void startLine(String t) {

        if(args.html())
            t = new String("tr");
        if(args.html() || args.xml())
            tag(true, t);
    }

    /**
     * This opens a new HTML table row.
     * This does nothing if output format is not HTML.
     */
    private void startLine() {
        startLine(null);
    }


    /**
     * This ends a line, depending on output format.
     * For HTML format, this closes a TR tag; for XML format, this closes the provided tag.
     * This displays nothing on any other output format.
     * @param t is the XML tag to open 
     */
    private void endLine(String t) {

        if(args.html())
            t = new String("tr");
        if(args.html() || args.xml())
            tag(false, t);
    }


    /**
     * This closes an HTML table row.
     * This does nothing if output format is not HTML.
     */
    private void endLine() {
        endLine(null);
    }


    /**
     * This reads standard input to create the input file, if any
     */
    private File readInput(InputStream in, UID uid) {

        if(in == null)
            return null;

        File file = null;

        try { 
            InputStreamReader stdinput  = new InputStreamReader(in);
            if(stdinput.ready()) {

                String inputFileName = uid.toString() + ".txt";

                BufferedReader bufferFile = new BufferedReader(stdinput);
                file = new File(inputFileName);
                FileWriter fw = new FileWriter(file);

                for(String line = bufferFile.readLine();
                    line != null;
                    line = bufferFile.readLine()) {
                    fw.write(line + "\n");
                }

                fw.flush();
                fw.close();

                println(inputFileName + " created");
            }
        } 
        catch(Exception e) {
            exit("Exception: " + e, XWReturnCode.DISK);
        }

        return file;

    } // readInput()
    /**
     * This sends command to XtremWeb server and read answer
     * @param command is the XMLRPC command to send
     * @return an XMLable object or null
     */
    private XMLable sendCommand(XMLRPCCommand command, boolean display) 
        throws IOException {

        //        System.out.println("Client#sendCommand(" + command.toXml() + "," + display +")");
        XMLable result = null;

        try {
            result = command.exec(commClient());
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            throw new IOException(e.toString());
        }

        if(display == true) {
            startLine();

            if(args.xml() == true)
                println(true, result.toXml());
            else
                println(true, result.toString(args.csv() || args.html()));

            endLine();
        }

        return result;
    }
    /**
     * This changes access rights
     * <blockquote>
     * Command line parameters : --xwchmod MOD UID [UID...]
     * </blockquote>
     * MOD follows unix chmod syntax : 
     * <ul>
     * <li> [aoug][+-][rwx]
     * <li> an octal value (e.g. 777)
     * </ul>
     * UID may be any XtremWeb object UID (data, app, work...)
     */
    private void chmod() {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided", XWReturnCode.PARSING);

        Enumeration enumParams = params.elements();
        String rightsStr = null;
        try {
            rightsStr = (String)enumParams.nextElement();
            new XWAccessRights(rightsStr);
        }
        catch(Exception e) {
            exit("" + rightsStr + " is not a valid mod", XWReturnCode.PARSING);
        }

        while(enumParams.hasMoreElements()) {
            UID uid = null;
            try {
                uid = (UID)enumParams.nextElement();
            }
            catch(Exception e) {
                continue;
            }
            //
            // UID is an app UID ?
            //
            try{
                AppInterface app = (AppInterface)get(uid);
                if(app != null) {
                    XWAccessRights rights = app.getAccessRights();
                    rights.chmod(rightsStr);
                    app.setAccessRights(rights);
                    commClient().send(app);
                    continue;
                }
            }
            catch(Exception e) {
            }
            //
            // UID was not an app one; maybe a data one ?
            //
            try{
                DataInterface data = (DataInterface)get(uid);
                if(data != null) {
                    XWAccessRights rights = data.getAccessRights();
                    rights.chmod(rightsStr);
                    data.setAccessRights(rights);
                    commClient().send(data);
                    continue;
                }
            }
            catch(Exception e) {
            }
            //
            // UID was not a data one either ; finally, maybe a work one ?
            //
            try{
                WorkInterface work = (WorkInterface)get(uid);
                if(work != null) {
                    XWAccessRights rights = work.getAccessRights();
                    rights.chmod(rightsStr);
                    work.setAccessRights(rights);
                    commClient().send(work);
                    continue;
                }
            }
            catch(Exception e) {
            }
        }
    }
    /**
     * This retreives command line parameter and writes app description
     * <blockquote>
     * Command line parameters : --xwget UID [UID...]
     * </blockquote>
     * @see #get(UID, boolean)
     */
    private void get() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new AppInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            Object param = enumParams.nextElement();
            TableInterface obj;

            try {
                obj = get((UID)param, true);
            }
            catch(ClassCastException e) {
                // maybe it is an URI...
                obj = get(((URI)param).getUID(), true);
            }

            if((obj != null) &&
               (args.getOption(CommandLineOptions.DOWNLOAD) != null)) {

                URI uri = null;

                if(obj instanceof WorkInterface)
                    uri = ((WorkInterface)obj).getResult();
                if(obj instanceof DataInterface)
                    uri = ((DataInterface)obj).getURI();

                try {
                    downloadData(uri,true);
                }
                catch(Exception e) {
                    if(debug())
                        e.printStackTrace();
                    throw new IOException(e.toString());
                }
            }
        }

        trailer();
    }
    public TableInterface get(UID uid)
        throws IOException {
	    return get(uid, false);
    }
    /**
     * This retreives an object from XtremWeb server
     * This may write description to stdout accordingly to display parameter
     * <blockquote>
     * Command line parameters : --xwget UID [UID...]
     * </blockquote>
     * @param uid is the application UID
     * @param display tells whether to write app description to stdout
     * @return an AppInterface
     */
    private TableInterface get(UID uid, boolean display)
        throws IOException {
        return (TableInterface)sendCommand(new XMLRPCCommandGet(uid), display);
    }
    /**
     * This retreives command line parameter and writes app description
     * <blockquote>
     * Command line parameters : --xwgetapp UID [UID...]
     * </blockquote>
     * @return an AppInterface
     * @see #getApp(String, boolean)
     * @see #getApp(UID, boolean)
     */
    private void getApp() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new AppInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            Object param = enumParams.nextElement();
            try{
                getApp((String)param, true);
            }
            catch(ClassCastException e) {
                get((UID)param, true);
            }
        }

        trailer();
    }
    /**
     * This calls app(name, false)
     * <blockquote>
     * Command line parameters : --xwgetapp UID [UID...]
     * </blockquote>
     * @param name is the app name
     * @return an AppInterface
     * @see #getApp(String, boolean)
     */
    public AppInterface getApp(String name)
        throws IOException {
        return getApp(name, false);
    }
    /**
     * This retreives application from XtremWeb server
     * This may write app description to stdout, accordingly to dislay parameter
     * <blockquote>
     * Command line parameters : --xwgetapp UID [UID...]
     * </blockquote>
     * @param name is the application name
     * @param display tells to write descriptio to stdout, or not
     * @return an AppInterface
     */
    private AppInterface getApp(String name, boolean display)
        throws IOException {

        Vector apps = getApps();

        Enumeration myenum = apps.elements();
        for(; myenum.hasMoreElements(); ) {

            UID uid = (UID)myenum.nextElement();
            if(uid == null)
                continue;

            AppInterface app = null;
            try {
                app = (AppInterface)commClient().get(uid);
            }
            catch(Exception e) {
            }
            if((app != null) && (app.getName().compareToIgnoreCase(name) == 0))
                return app;
        }
        return null;
    }
    /**
     * This retreives, stores and displays applications installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwgetapps
     * </blockquote>
     * @see #getApps(boolean)
     */
    public Vector getApps()
        throws IOException {
        return getApps(false);
    }
    /**
     * This retreives, stores and displays applications installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwgetapps
     * </blockquote>
     * @param display is true to display applications
     */
    private Vector getApps(boolean display) throws IOException {

        XMLVector xmlUids = (XMLVector)sendCommand(new XMLRPCCommandGetApps(), false);
        Vector uids = xmlUids.getVector();
        Enumeration appsEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new AppInterface().getColumns());
        }


        while(appsEnum.hasMoreElements()) {

            UID uid =(UID)appsEnum.nextElement();

            try {
                get(uid, display);
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();

        return uids;
    }
    /**
     * This inserts/updates an application in server.<br>
     * <blockquote>
     * Command line parameters : --xwsendapp appName cpuType osName binFileName
     * </blockquote>
     * The user must have the right to do so
     */
    private void sendApp() throws IOException {

        Vector appParams = (Vector)args.commandParams();

        AppInterface app = null;

        try {
            try {
                app = getApp((String)appParams.elementAt(0));
            }
            catch(Exception appe){
            }
            if(app == null)
                app = new AppInterface(new UID());

            app.setName((String)appParams.elementAt(0));

            String cpu = (String)appParams.elementAt(1);
            String os = (String)appParams.elementAt(2);
            try {
                app.setBinary(XWCPUs.getCpu(cpu.toUpperCase()), 
                              XWOSes.valueOf(os.toUpperCase()),
                              new URI((String)appParams.elementAt(3)));
            }
            catch(ClassCastException e) {
                // the user provided an UID
                app.setBinary(XWCPUs.getCpu(cpu.toUpperCase()), 
                              XWOSes.valueOf(os.toUpperCase()),
                              newURI(commClient().getServerName(),
                                     (UID)appParams.elementAt(3)));
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            usage("sendapp <name> <cpu> <os> <bin URI>");
        }

        try {
            commClient().send(app);
        }
        catch(Exception e) {
            throw new IOException(e.toString());
        }
    }
    /**
     * This removes an application from server.<br>
     * <blockquote>
     * Command line parameters : --xwremoveapp UID [UID...]
     * </blockquote>
     * The user must have the right to do so
     */
    private void remove() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            Object param = enumParams.nextElement();
            try {
                remove((UID)param);
            }
            catch(ClassCastException e) {
                URI uri = (URI)param;
                remove(uri.getUID());
            }
        }
    }
    /**
     * This removes an application from server.<br>
     * <blockquote>
     * Command line parameters : --xwremoveapp UID
     * </blockquote>
     * The user must have the right to do so
     */
    public void remove(UID uid) throws IOException {
        sendCommand(new XMLRPCCommandRemove(uid), false);
    }
    /**
     * This retreives command line parameter and writes data description
     * <blockquote>
     * Command line parameters : --xwremoveapp UID
     * </blockquote>
     * @return an DataInterface
     * @see #getData(UID, boolean)
     */
    private void getData() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new DataInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            Object param = enumParams.nextElement();

            try {
                getData((UID)param, true);
            }
            catch(ClassCastException e) {
                URI uri = (URI)param;
                getData(uri.getUID(), true);
            }
        }

        trailer();
    }
    /**
     * This retreives data from XtremWeb server
     * This may write data description to stdout, accordingly to display parameter.
     * @param uid is the data UID
     * @param display tells whether to write data description to stdout
     * @return an DataInterface
     * @see #getDatas()
     */
    private DataInterface getData(UID uid, boolean display) 
        throws IOException {

        DataInterface data = (DataInterface)get(uid, display);

        if((data != null ) && args.getOption(CommandLineOptions.DOWNLOAD) != null){
            File fdata = null;

            String fext = "";
            if(data.getType() != null)
                fext = data.getType().getFileExtension();

            if(data.getName() != null)
                fdata = new File(uid.toString() + "_" + data.getName() + fext);
            else
                fdata = new File(uid.toString() + fext);
            try {
                commClient().downloadData(uid, fdata);
            }
            catch(Exception e) {
                throw new IOException(e.toString());
            }
        }
        return data;
    }
    /**
     * This retreives, stores and displays datas installed in XtremWeb server.
     * @see #getDatas(boolean)
     */
    public Vector getDatas() throws IOException {
        return getDatas(false);
    }
    /**
     * This retreives, stores and displays datas installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwdatas
     * </blockquote>
     * @param display is true to write data descriptions to stdout
     * @see #getDatas()
     */
    private Vector getDatas(boolean display) throws IOException {

        XMLVector xmluids = (XMLVector)sendCommand(new XMLRPCCommandGetDatas(), false);
        Vector uids = xmluids.getVector();
        Enumeration theEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new DataInterface().getColumns());
        }
        while(theEnum.hasMoreElements()) {

            UID uid =(UID)theEnum.nextElement();

            try {
                getData(uid, display);
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();

        return uids;
    }
    /**
     * This inserts a new data in server.<br>
     * <blockquote>
     * Command line parameters : --xwsenddata &lt;data name&gt; &lt;cpu type&gt; &lt;os name&gt; &lt;bin file name&gt;
     * </blockquote>
     * The user must have the right to do so
     */
    private void sendData() {

        Vector dataParams = (Vector)args.commandParams();

        String dataFileName = null;
	File fdata = null;
        String dname = null;
	XWCPUs cpu = null;
	XWOSes os = null;

	for(int i = 0; i < dataParams.size(); i++) {

	    String param = (String)dataParams.elementAt(i);

	    //
	    // is param a file name ?
	    //
	    fdata = new File(param);
	    if(fdata.exists())
		continue;

	    fdata = null;

	    //
	    // is param a cpu name ?
	    //
	    try {
		cpu = XWCPUs.getCpu(param);
		continue;
	    }
	    catch(Exception e) {
		cpu = null;
	    }

	    //
	    // is param an OS name ?
	    //
	    try {
		os = XWOSes.valueOf(param);
		continue;
	    }
	    catch(Exception e) {
		os = null;
	    }

	    //
	    // none of them ; it is certainly a data name
	    //
	    dname = param;
	}

        try {
            DataInterface data = new DataInterface(new UID());

	    if(fdata != null)
		debug("Data file = " + fdata.toString());
            else
                warn("no data content");

            if(dname != null)
                data.setName(dname);

	    if(cpu != null)
		data.setCpu(cpu);

	    if(os != null)
		data.setOs(os);

            sendData(data, fdata);
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            connectionRefused();
        }

    } //sendData
    /**
     * This inserts a new data in server.<br>
     * <blockquote>
     * Command line parameters : --xwsenddata &lt;data name&gt; &lt;cpu type&gt; &lt;os name&gt; &lt;bin file name&gt;
     * </blockquote>
     * The user must have the right to do so
     */
    public void sendData(DataInterface data, File fdata) {

        try {
            if(fdata == null)
                data.setStatus(XWStatus.AVAILABLE);
            else {
                if(fdata.exists() == false)
                    exit(fdata.getName() + " does not exist", XWReturnCode.DISK);

                data.setStatus(XWStatus.UNAVAILABLE);
                data.setSize((long)fdata.length());
                data.setMD5(MD5.asHex(MD5.getHash(fdata)));
            }

            commClient().send(data);
            boolean success = false;
            while(!success) {
                try {
                    commClient().get(data.getUID());
                    success = true;
                }
                catch(Exception e) {
                    try{
                        Thread.sleep(50);
                    }
                    catch(Exception s) {
                    }
                    // data not ready yet
                }
            }
            if(fdata != null) {
                commClient().uploadData(data.getUID(), fdata);
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            connectionRefused();
        }

    } //sendData
    /**
     * This retreives command line parameter and writes group description
     * @return an GroupInterface
     * @see #getGroup(UID, boolean)
     */
    private void getGroup() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new GroupInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            get((UID)enumParams.nextElement(), true);
        }

        trailer();
    }
    /**
     * This retreives, stores and displays groups installed in XtremWeb server.
     * @see #getGroups(boolean)
     */
    public Vector getGroups() throws IOException {
        return getGroups(false);
    }
    /**
     * This retreives, stores and displays groups installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwgroups
     * </blockquote>
     * @param display is true to write group descriptions to stdout
     */
    private Vector getGroups(boolean display) throws IOException {

        XMLVector xmluids = (XMLVector)sendCommand(new XMLRPCCommandGetGroups(), false);
        Vector uids = xmluids.getVector();
        Enumeration theEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new GroupInterface().getColumns());
        }
        while(theEnum.hasMoreElements()) {

            UID uid =(UID)theEnum.nextElement();

            try {
                get(uid, display);
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();

        return uids;
    }
    /**
     * This inserts a new group in server.<br>
     * <blockquote>
     * Command line parameters : --xwaddgroup &lt;group name&gt; &lt;cpu type&gt; &lt;os name&gt; &lt;bin file name&gt;
     * </blockquote>
     * The user must have the right to do so
     */
    private void sendGroup() {
        Vector params = (Vector)args.commandParams();

        try {
            GroupInterface group = new GroupInterface(new UID());
            int paramIdx = 0;
            try {
                group.setName((String)params.elementAt(paramIdx++));
                group.setSession((UID)params.elementAt(paramIdx++));
                group.setClient((UID)params.elementAt(paramIdx++));
            }
            catch(Exception e) {
                usage("sendgroup <name> <sessionUID> <clientUID>");
            }
            try {
                commClient().send(group);
            }
            catch(Exception e) {
                throw new IOException(e.toString());
            }
        }
        catch(Exception e) {
            try {
                commClient().close();
            }
            catch(Exception e2) {
            }
            if(debug())
		e.printStackTrace();
        }
    }
    /**
     * This retreives command line parameter and writes host description
     * @return an HostInterface
     * @see #getHost(UID, boolean)
     */
    private void getHost() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new HostInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            get((UID)enumParams.nextElement(), true);
        }

        trailer();
    }
    /**
     * This retreives, stores and displays hosts installed in XtremWeb server.
     * @see #getHosts(boolean)
     */
    public Vector getHosts() throws IOException {
        return getHosts(false);
    }
    /**
     * This retreives, stores and displays hosts installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwhosts
     * </blockquote>
     * @param display is true to write host descriptions to stdout
     * @see #getHosts
     */
    private Vector getHosts(boolean display) throws IOException {

        XMLVector xmluids = (XMLVector)sendCommand(new XMLRPCCommandGetHosts(), false);
        Vector uids = xmluids.getVector();
        Enumeration theEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new HostInterface().getColumns());
        }
        while(theEnum.hasMoreElements()) {

            UID uid =(UID)theEnum.nextElement();

            try {
                get(uid, display);
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();

        return uids;
    }
    /**
     * This inserts a new host in server.<br>
     * <blockquote>
     * Command line parameters : --xwaddhost &lt;host name&gt; &lt;cpu type&gt; &lt;os name&gt; &lt;bin file name&gt;
     * </blockquote>
     * The user must have the right to do so
     */
    private void sendHost() throws IOException {
    }
    /**
     * This retreives command line parameter and writes session description
     * @return an SessionInterface
     * @see #getSession(UID, boolean)
     */
    private void getSession() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new SessionInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            get((UID)enumParams.nextElement(), true);
        }

        trailer();
    }
    /**
     * This retreives, stores and displays sessions installed in XtremWeb server.
     * @see #getSessions(boolean)
     */
    public Vector getSessions()	throws IOException {
        return getSessions(false);
    }
    /**
     * This retreives, stores and displays sessions installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwsessions
     * </blockquote>
     * @param display is true to write session descriptions to stdout
     * @see #getSessions
     */
    private Vector getSessions(boolean display)	throws IOException {

        XMLVector xmluids = (XMLVector)sendCommand(new XMLRPCCommandGetSessions(), 
                                                   false);
        Vector uids = xmluids.getVector();
        Enumeration theEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new SessionInterface().getColumns());
        }
        while(theEnum.hasMoreElements()) {

            UID uid =(UID)theEnum.nextElement();

            try {
                get(uid, display);
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();

        return uids;
    }
    /**
     * This inserts a new session in server.<br>
     * <blockquote>
     * Command line parameters : --xwaddsession &lt;session name&gt; &lt;cpu type&gt; &lt;os name&gt; &lt;bin file name&gt;
     * </blockquote>
     * The user must have the right to do so
     */
    private void sendSession() throws IOException {
    }
    /**
     * This retreives command line parameter and writes task description
     * @return an TaskInterface
     * @see #getTask(UID, boolean)
     */
    private void getTask() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new TaskInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            get((UID)enumParams.nextElement(), true);
        }

        trailer();
    }
    /**
     * This retreives, stores and displays tasks installed in XtremWeb server.
     * @see #getTasks(boolean)
     */
    public Vector getTasks() throws IOException {
        return getTasks(false);
    }
    /**
     * This retreives, stores and displays tasks installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwtasks
     * </blockquote>
     * @param display is true to write task descriptions to stdout
     * @see #getTasks
     */
    private Vector getTasks(boolean display) throws IOException {

        XMLVector xmluids = (XMLVector)sendCommand(new XMLRPCCommandGetTasks(), false);
        Vector uids = xmluids.getVector();
        Enumeration theEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new TaskInterface().getColumns());
        }
        while(theEnum.hasMoreElements()) {

            UID uid =(UID)theEnum.nextElement();

            try {
                get(uid, display);
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();

        return uids;
    }
    /**
     * This inserts a new task in server.<br>
     * <blockquote>
     * Command line parameters : --xwaddtask &lt;task name&gt; &lt;cpu type&gt; &lt;os name&gt; &lt;bin file name&gt;
     * </blockquote>
     * The user must have the right to do so
     */
    private void sendTask() throws IOException {
    }
    /**
     * This retreives command line parameter and writes trace description
     * @return an TraceInterface
     * @see #getTrace(UID, boolean)
     */
    private void getTrace() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new TraceInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            get((UID)enumParams.nextElement(), true);
        }

        trailer();
    }
    /**
     * This retreives, stores and displays traces installed in XtremWeb server.
     * @see #getTraces(boolean)
     */
    public Vector getTraces() throws IOException {
        return getTraces(false);
    }
    /**
     * This retreives, stores and displays traces installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwtraces
     * </blockquote>
     * @param display is true to write trace descriptions to stdout
     * @see #getTraces
     */
    private Vector getTraces(boolean display) throws IOException {

        XMLVector xmluids = (XMLVector)sendCommand(new XMLRPCCommandGetTraces(), false);
        Vector uids = xmluids.getVector();
        Enumeration theEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new TraceInterface().getColumns());
        }
        while(theEnum.hasMoreElements()) {

            UID uid =(UID)theEnum.nextElement();

            try {
                get(uid, display);
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();

        return uids;
    }
    /**
     * This inserts a new trace in server.<br>
     * <blockquote>
     * Command line parameters : --xwaddtrace &lt;trace name&gt; &lt;cpu type&gt; &lt;os name&gt; &lt;bin file name&gt;
     * </blockquote>
     * The user must have the right to do so
     */
    private void sendTrace() throws IOException {
    }
    /**
     * This retreives command line parameter and writes task description
     * @return an UserGroupInterface
     * @see #getUserGroup(UID, boolean)
     */
    private void getUserGroup() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new UserGroupInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            get((UID)enumParams.nextElement(), true);
        }

        trailer();
    }
    /**
     * This retreives, stores and displays userGroups installed in XtremWeb server.
     * @see #getUserGroups(boolean)
     */
    public Vector getUserGroups() throws IOException {
        return getUserGroups(false);
    }
    /**
     * This retreives, stores and displays userGroups installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwuserGroups
     * </blockquote>
     * @param display is true to write userGroup descriptions to stdout
     * @see #getUserGroups
     */
    public Vector getUserGroups(boolean display) throws IOException {

        XMLVector xmluids = (XMLVector)sendCommand(new XMLRPCCommandGetUserGroups(), false);
        Vector uids = xmluids.getVector();
        Enumeration theEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new UserGroupInterface().getColumns());
        }
        while(theEnum.hasMoreElements()) {

            UID uid =(UID)theEnum.nextElement();

            try {
                get(uid, display);
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();
        return uids;
    }
    /**
     * This inserts a new userGroup in server.<br>
     * <blockquote>
     * Command line parameters : --xwadduserGroup &lt;userGroup name&gt; &lt;cpu type&gt; &lt;os name&gt; &lt;bin file name&gt;
     * </blockquote>
     * The user must have the right to do so
     */
    private void sendUserGroup() throws IOException {

        Vector params = (Vector)args.commandParams();
        if(params == null)
            usage("xwsendusergroup <usergroupName>");

        String groupLabel = null;
        try {
            groupLabel = (String)params.elementAt(0);
        }
        catch(Exception e) {
        }
        if(groupLabel == null)
            usage("xwsendusergroup <usergroupName>");

        try {
            UserGroupInterface group = new UserGroupInterface(new UID());
            group.setLabel(groupLabel);
            commClient().send(group);
        }
        catch(Exception e) {
            try {
                commClient().close();
            }
            catch(Exception e2) {
            }
            System.err.println("Server Error " + e);
            if(debug())
		e.printStackTrace();
        }

    }
    /**
     * This retreives command line parameter and writes user description
     * @return an UserInterface
     * @see #getUser(UID, boolean)
     */
    private void getUser() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new UserInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            Object param = enumParams.nextElement();
            try{
                getUser((String)param, true);
            }
            catch(ClassCastException e) {
                get((UID)param, true);
            }	
        }

        trailer();
    }
    /**
     * This calls getUser(login, false)
     * @param login is the user login
     * @return an UserInterface
     * @see #getUser(String, boolean)
     */
    public UserInterface getUser(String login)
        throws IOException {
        return getUser(login, false);
    }
    /**
     * This retreives user from XtremWeb server
     * This may write description to stdout, accordingly to dislay parameter
     * @param login is the use login
     * @param display tells to write descriptio to stdout, or not
     * @return an UserInterface
     */
    private UserInterface getUser(String login, boolean display)
        throws IOException {
        return (UserInterface)sendCommand(new XMLRPCCommandGetUserByLogin(login), 
                                          display);
    }
    /**
     * This retreives, stores and displays users installed in XtremWeb server.
     * @see #getUsers(boolean)
     */
    public Vector getUsers() throws IOException {
        return getUsers(false);
    }
    /**
     * This retreives, stores and displays users installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwusers
     * </blockquote>
     * @param display is true to write user descriptions to stdout
     * @see #getUsers
     */
    private Vector getUsers(boolean display) throws IOException {

        XMLVector xmluids = (XMLVector)sendCommand(new XMLRPCCommandGetUsers(), false);
        Vector uids = xmluids.getVector();
        Enumeration theEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new UserInterface().getColumns());
        }
        while(theEnum.hasMoreElements()) {

            UID uid =(UID)theEnum.nextElement();

            try {
                get(uid, display);
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();

        return uids;
    }
    /**
     * This inserts a new user in server.<br>
     * <blockquote>
     * Command line parameters : --xwadduser &lt;user name&gt; &lt;cpu type&gt; &lt;os name&gt; &lt;bin file name&gt;
     * </blockquote>
     * The user must have the right to do so
     */
    private void sendUser() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            usage("xwsenduser <login> <password> <email> <right> [usergroupUID]");

        String  login     = null;
        String  password  = null;
        String  email     = null;
        UserRights rights = null;
        UID group         = null;

        try {
            login    = (String)params.elementAt(0);
            password = (String)params.elementAt(1);
            email    = (String)params.elementAt(2);
            try {
                rights = UserRights.valueOf(((String)params.elementAt(3)).toUpperCase());
            }
            catch(IllegalArgumentException iae) {
                rights = UserRights.fromInt(Integer.parseInt((String)params.elementAt(3)));
            } 
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            usage("xwsenduser <login> <password> <email> <right> [usergroupUID]");
        }
        try {
            group = (UID)params.elementAt(4);
        }
        catch(Exception eg) {
            // user group is optionnal
        }


        try {
            UserInterface user = new UserInterface(new UID());
            user.setLogin(login);
            user.setEMail(email);
            user.setRights(rights);
            if(group != null)
                user.setGroup(group);

            MD5	md5 = new MD5();
            String hex;
            md5.Init();
            md5.Update(password + passPhrase);
            hex = md5.asHex();
            user.setPassword(hex);

            commClient().send(user);

            System.out.println("# XWHEP client config file");
            System.out.println("# XWHEP server");
            System.out.println("dispatcher.hosts=" + config.getCurrentDispatcher());
            System.out.println("# Login and password to connect to the server");
            System.out.println("login=" + user.getLogin());
            System.out.println("password=" + user.getPassword());
            System.out.println("# logger level");
            System.out.println("logger.level=info");

        }
        catch(Exception e) {
            if(debug())
		e.printStackTrace();
            connectionRefused();
        }
    }
    /**
     * This retreives command line parameter and writes work description
     * @return an WorkInterface
     * @see #getWork(UID, boolean)
     */
    private void getWork() throws IOException {
        Vector params = (Vector)args.commandParams();
        if(params == null)
            exit("no UID provided",XWReturnCode.PARSING);

        header();
        if(args.html() || args.csv())
            println(true, new WorkInterface().getColumns());

        Enumeration enumParams = params.elements();
        while(enumParams.hasMoreElements()) {
            get((UID)enumParams.nextElement(), true);
        }

        trailer();
    }
    /**
     * This retreives, stores and displays works installed in XtremWeb server.
     * @see #getWorks(boolean)
     */
    public Vector getWorks() throws IOException {
        return getWorks(false);
    }
    /**
     * This retreives, stores and displays works installed in XtremWeb server.
     * <blockquote>
     * Command line parameters : --xwworks
     * </blockquote>
     * @param display is true to write work descriptions to stdout
     * @see #getWorks
     */
    private Vector getWorks(boolean display) throws IOException {

        XMLVector xmluids = (XMLVector)sendCommand(new XMLRPCCommandGetWorks(), false);
        Vector uids = xmluids.getVector();
        Enumeration theEnum = uids.elements();

        if(display) {
            header();
            if(args.html() || args.csv())
                println(true, new WorkInterface().getColumns());
        }
        while(theEnum.hasMoreElements()) {

            UID uid =(UID)theEnum.nextElement();

            try {
                WorkInterface job = (WorkInterface)get(uid, display);
                if((args.getOption(CommandLineOptions.DOWNLOAD) != null) &&
                   (job.getResult() != null)) {
                    getData(job.getResult().getUID(), display);
                }
            }
            catch(Exception ce) {
                error(ce.toString());
		if(debug())
		    ce.printStackTrace();
                continue;
            }
        }

        if(display)
            trailer();

        return uids;
    }


    private String zipFileName;

    /**
     * This zippes dirin, if any
     */
    protected boolean zipDirin(WorkInterface work) throws IOException {

	    mileStone.println("zipping dirin");

	    boolean newZip = true;

	    String[] filesHierarchy = new String[1];
	    String savname = zipFileName;
	    filesHierarchy[0] = zipFileName;
	    //
	    // replacing ":" by "_" to comply to Win32
	    //
	    zipFileName = work.getUID().toString() + ".zip";
        zipper.setFileName(zipFileName);
	    try {
            if(zipper.zip(filesHierarchy, true) == false) {
                zipFileName = savname;
                debug(zipFileName + " is not zipped; it is kept 'as is'");
                newZip = false;
            }
	    }
	    catch(Exception ze) {
            if(debug())
                ze.printStackTrace();
            throw new IOException("can't create zip file");
            //								exit("can't create zip file", util.DISK);
	    }

	    mileStone.println("zipped dirin");

        return newZip;
	}
    /**
     * This inserts (submits) a new work in server.<br>
     * <blockquote>
     * Command line parameters : --xwsendwork &lt;app name or UID&gt; [ --xwenv &lt;dirin URI or UID&gt; ] &lt; stdinFile
     * </blockquote>
     */
    private void sendWork() throws IOException {

        boolean newZip = false;

        try {
            Vector params = (Vector)args.commandParams();
            WorkInterface work = new WorkInterface();
            work.setUID(new UID());

            AppInterface app = null;
            try{
                app = getApp((String)params.elementAt(0));
            }
            catch(IOException e) {
                usage("Can't retreive " + (String)params.elementAt(0));
            }
            catch(ClassCastException e) {
		if(debug())
		    e.printStackTrace();
                app = (AppInterface)get((UID)params.elementAt(0));
            }

            work.setApplication(app.getUID());

            if(args.getOption(CommandLineOptions.ENV) != null) {
                try {
                    // user provided an URI
                    work.setDirin((URI)args.getOption(CommandLineOptions.ENV));
                }
                catch(ClassCastException e) {
                    try {
                        // the user provided an UID
                        work.setDirin(newURI(commClient().getServerName(),
                                             (UID)args.getOption(CommandLineOptions.ENV)));
                    }
                    catch(ClassCastException e2) {
                        // the user provided a local file
                        zipFileName = (String)args.getOption(CommandLineOptions.ENV);

                        if(zipFileName != null) {

                            if(zipFileName.toLowerCase().endsWith(".zip") == false) {
                                newZip = zipDirin(work);
                            }

                            DataInterface data = new DataInterface();
                            data.setUID(new UID());
                            data.setName(zipFileName);
                            if(newZip == true)
                                data.setType(DataType.ZIP);

                            sendData(data, new File(zipFileName));

                            work.setDirin(newURI(commClient().getServerName(),
                                                 data.getUID()));
                        }
                    }
                }
            }

            File stdin = readInput(System.in, new UID());
            if(stdin != null) {
                DataInterface data = new DataInterface();
                data.setUID(new UID());
                data.setName("stdin");
                data.setType(DataType.TEXT);

                sendData(data, stdin);

                work.setStdin(newURI(commClient().getServerName(),
                                     data.getUID()));
            }

            String cmdLineStr = new String(" ");
            // i = 1 to bypass application name
            for(int i = 1; i < params.size() ; i++){
                cmdLineStr += (String)params.elementAt(i) + " ";
            }

            // 6 decembre 2005
            if(cmdLineStr.indexOf(util.QUOTE) != -1)
                throw new ParseException("6 dec 2005 : command line cannot have \"" + 
                                         util.QUOTE + "\" character until further notification",
                                         0);
            work.setCmdLine(cmdLineStr);
            commClient().send(work);

            if(newZip == true) {
                File file = new File(zipFileName);
                if(file.exists())
                    file.delete();
            }
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();

            if(newZip == true) {
                File file = new File(zipFileName);
                if(file.exists())
                    file.delete();
            }
            usage("sendwork <application name or UID> [stdin URI or UID] [dirin URI or UID]");
        }
    }
    /**
     * This pings the server
     * @see #synchronize()
     */
    private void ping()  {

        try {
            while(true) {
                long start = System.currentTimeMillis();
                commClient().ping();
                long end = System.currentTimeMillis();
                int pingdelai = (int)(end - start);
                System.out.println("Ping to " + config.getCurrentDispatcher() +
                                   ": time=" + pingdelai + " ms");
                Thread.sleep(500);
            }
        }
        catch(Exception e) {
            error(e.toString());
            if(debug())
                e.printStackTrace();
        }
    }
    /**
     * This is for communications testing<br>
     * <blockquote>
     * Command line parameters : --xwworkalive [UID]
     * </blockquote>
     */
    private void workAlive() throws IOException {

        Vector params = (Vector)args.commandParams();
        Hashtable rmiResults = null;

        try {
            rmiResults = commClient().workAlive((UID)params.elementAt(0));
            Boolean keepWorking = (Boolean) rmiResults.get("keepWorking");
            if(keepWorking != null)
                System.out.println("Alive to " + config.getCurrentDispatcher() +
                                   " : keepWorking = " + keepWorking);
        }
        catch(Exception e) {
            Vector jobResults = new Vector();
            /*
              jobResults.add(new UID());
              jobResults.add(new UID());
              jobResults.add(new UID());
            */
            System.out.println("Alive to " + config.getCurrentDispatcher() +
                               " : jobResults.size() = " + jobResults.size());
            Hashtable rmiParams = new Hashtable();
            rmiParams.put("jobResults", jobResults);

            try {
                rmiResults = commClient().workAlive(rmiParams);
            }
            catch(Exception e2) {
                if(debug())
                    e.printStackTrace();
                exit("Alive to " + config.getCurrentDispatcher() +
                     " : connection error ", XWReturnCode.CONNECTION);
                return;
            }

            if(rmiResults == null) {
                exit("Alive to " + config.getCurrentDispatcher() +
                     " : rmiResults = null", XWReturnCode.CONNECTION);
                return;
            }

            Vector finishedTasks = (Vector) rmiResults.get("finishedTasks");

            if(finishedTasks != null) {
                System.out.println("Alive to " + config.getCurrentDispatcher() +
                                   " : finishedTasks.size() = " +
                                   finishedTasks.size());
                Iterator li = finishedTasks.iterator();

                while(li.hasNext()) {
                    UID uid = (UID) li.next();
                    if(uid != null)
                        System.out.println("Alive to " + config.getCurrentDispatcher() +
                                           " : finishedTasks = " + uid);
                }
            }

            Vector resultsExpected = (Vector) rmiResults.get("resultsExpected");

            if(resultsExpected != null) {
                System.out.println("Alive to " + config.getCurrentDispatcher() +
                                   " : resultsExpected.size() = " +
                                   resultsExpected.size());

                Iterator li = resultsExpected.iterator();

                while(li.hasNext()) {
                    UID uid =(UID) li.next();
                    if(uid != null)
                        System.out.println("Alive to " + config.getCurrentDispatcher() +
                                           " : resultExpected = " + uid);
                }
            }

            String newServer =(String) rmiResults.get("newServer");
            if(newServer != null) {
                System.out.println("Alive to " + config.getCurrentDispatcher() +
                                   " : new server = " + newServer);
            }

            Boolean traces =(Boolean) rmiResults.get("traces");
            String dbgMsg = "";
            if(traces != null)
                System.out.println("Alive to " + config.getCurrentDispatcher() +
                                   " : tracing = " + traces);

            Integer tracesSendResultDelay =(Integer) rmiResults.get("tracesSendResultDelay");
            int sDelay = 0;

            if(tracesSendResultDelay != null)
                System.out.println("Alive to " + config.getCurrentDispatcher() +
                                   " : tracesSendResultDelay = " + tracesSendResultDelay);

            Integer tracesResultDelay =(Integer) rmiResults.get("tracesResultDelay");
            int rDelay = 0;
            if(tracesResultDelay != null)
                System.out.println("Alive to " + config.getCurrentDispatcher() +
                                   " : tracesResultDelay = " + tracesResultDelay);

            Integer newAlivePeriod = (Integer)rmiResults.get("alivePeriod");
            if(newAlivePeriod != null) {
                System.out.println("Alive to " + config.getCurrentDispatcher() +
                                   ": new alive period = " + newAlivePeriod);
            }


        }
    }
    /**
     * This updates a worker in server by setting its status to true or false<br />
     * <blockquote>
     * Command line parameters : --xwupdateworkers &lt;on|off&gt;  [uids list]
     * </blockquote>
     * Administrator privileges required
     */
    private void updateWorkers() throws IOException {

        Vector UIDs = (Vector)args.commandParams();

        if(UIDs == null)
            usage("update worker needs worker UID");

        try {

            boolean status = false;
            Iterator li = UIDs.iterator();

            String onoff = (String)li.next();

            if(onoff == null)
                usage("missing valid parameter : on | off");

            if((onoff.compareTo("on")   == 0 ) ||
               (onoff.compareTo("1")    == 0 ) ||
               (onoff.compareTo("true") == 0 ) ||
               (onoff.compareTo("yes")  == 0 )) {
                status = true;
            }
            else if((onoff.compareTo("off")   == 0 ) ||
                    (onoff.compareTo("0")     == 0 ) ||
                    (onoff.compareTo("false") == 0 ) ||
                    (onoff.compareTo("no")    == 0 )) {
                status = false;
            }
            else {
                usage("'" + onoff + "' is not a valid parameter");
            }

            while(li.hasNext()) {

                UID uid =(UID)li.next();
                commClient().activateHost(uid, status);
            }
        }
        catch(Exception e) {
            if(debug())
		e.printStackTrace();
            connectionRefused();
        }

    }
    /**
     * This executes requested actions.<br>
     * It first tries to connect to the XtremWeb dispatcher.
     */
    private void execute() {

        try {
            mileStone = new MileStone(getClass().getName());
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            if(args.getOption(CommandLineOptions.GUI) == null)
                util.fatal("Can't init comm :  " + e);
        }
        if(args.getOption(CommandLineOptions.GUI) != null) {
            if(config == null) {
                config = new XWConfigurator();
                CommClient.setConfig(config);
            }
            xtremweb.client.gui.MainFrame frame = new xtremweb.client.gui.MainFrame(this);
            frame.pack ();
            frame.setVisible (true);
        }
        else if(args.getOption(CommandLineOptions.MACRO) != null)
            execMacros();
        else
            doItNow(System.in);

        if(args.getOption(CommandLineOptions.GUI) == null) {
            try {
                commClient().disconnect();
            }
            catch(Exception ce) {
                try {
                    commClient().close();
                }
                catch(Exception e2) {
                }
                exit(ce.toString(), XWReturnCode.CONNECTION);
            }
        }

    } // execute()


    /**
     * This is finally where everything takes place.
     * This is called at least once, or once per line found in 
     * "macro" file, if any.
     * @param in is the input stream representing the standard input for the job
     */
    private void doItNow(InputStream in) {

        try {
            switch(args.command()) {
            case GET:
                get();
                break;
            case GETAPPS:
                getApps(true);
                break;
            case SENDAPP:
                sendApp();
                break;
            case REMOVE:
                remove();
                break;
            case GETDATAS:
                getDatas(true);
                break;
            case SENDDATA:
                sendData();
                break;
            case GETGROUPS:
                getGroups(true);
                break;
            case SENDGROUP:
                sendGroup();
                break;
            case GETHOSTS:
                getHosts(true);
                break;
            case SENDHOST:
                sendHost();
                break;
            case GETSESSIONS:
                getSessions(true);
                break;
            case SENDSESSION:
                sendSession();
                break;
            case GETTASKS:
                getTasks(true);
                break;
            case SENDTASK:
                sendTask();
                break;
            case GETTRACES:
                getTraces(true);
                break;
            case SENDTRACE:
                sendTrace();
                break;
            case GETUSERBYLOGIN:
                getUser();
                break;
            case GETUSERS:
                getUsers(true);
                break;
            case SENDUSER:
                sendUser();
                break;
            case GETUSERGROUPS:
                getUserGroups(true);
                break;
            case SENDUSERGROUP:
                sendUserGroup();
                break;
            case GETWORKS:
                getWorks(true);
                break;
            case SENDWORK:
                sendWork();
                break;
            case PING:
                ping();
                break;
            case WORKALIVE:
            case WORKALIVEBYUID:
                workAlive();
                break;
            case CHMOD:
                chmod();
                break;
            }
        }
        catch(ConnectException ce){
            connectionRefused();
        }
        catch(IOException ioe){
            exit(ioe.toString(), XWReturnCode.DISK);
        }
    } // doItNow()


    /**
     * This parses "macro" file and executes each line calling doItNow()<br />
     * <blockquote>
     * Command line parameters : --xwmacro &lt;macro file name&gt;
     * </blockquote>
     * @see #doItNow(InputStream)
     */
    private void execMacros() {

        debug("macro = " + args.getOption(CommandLineOptions.MACRO).toString());
        macroFile = new File((String)args.getOption(CommandLineOptions.MACRO));
        IdRpc lastAction = IdRpc.NULL;

        if(args.xml()) {
	    System.out.println(XMLable.XMLHEADER);
	    System.out.println(XMLable.rootTagOpen(CommonVersion.getCurrent().rev()));
	}

        try { 
            BufferedReader reader = new BufferedReader(new FileReader(macroFile));
            while(true) {
                try {

                    String line = reader.readLine();

                    Vector params = util.split(line);
                    FileInputStream stdin = null;

                    if((params == null) || (params.size() < 1))
                        break;

                    if(params.size() > 1) {
                        if(((String)params.get(params.size() - 2)).compareTo("<") == 0) {
                            stdin = new FileInputStream(new File((String)params.get(params.size() - 1)));
                            params.remove(params.size() - 1);
                            params.remove(params.size() - 2);
                        }
                    }

                    Object[] objarray = params.toArray();
                    String[] paramsarray = new String[objarray.length];
                    for(int i = 0; i < paramsarray.length; i++)
                        paramsarray[i] = (String)objarray[i];
                    args = new CommandLineParser(paramsarray, level);

                    debug("macro command (" + 
                          macroLineNumber + ")= " + args.command());
                    doItNow(stdin);

                    lastAction = args.command();

                    macroLineNumber++;
                }
                catch(EOFException e) {
                    break;
                }


                if((macroLineNumber % 500) == 0)
                    System.gc();

            }

	    System.out.println(XMLable.rootTagClose());

        }
        catch(Exception e) {
            exit(e.toString(), XWReturnCode.PARSING);
        } 

    }

    /**
     * This is the standard main method
     */    
    public static void main(String[] argv) {

        try {
            Client client = new Client(argv);
            client.verbose();
            client.execute();
        }
        catch(Exception e) {
	    e.printStackTrace();
        }

    }// main()

} // end of class Client
