/**
 * JobsTableModel.java
 *
 * Purpose : This is the table model to display XtremWeb tasks informations
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.communications.IdRpc;
import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.util;
import xtremweb.common.XWAccessRights;
import xtremweb.common.CommandLineParser;
import xtremweb.common.CommandLineOptions;
import xtremweb.common.UserInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.JobInterface;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.TaskInterface;
import xtremweb.common.WorkInterface;
import xtremweb.common.XWStatus;
import xtremweb.client.Client;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;

import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.awt.Cursor;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Vector;
import java.util.Hashtable;
import java.net.ConnectException;



/**
 * This displays a job by collecting informations 
 * from works, tasks, users, apps and hosts.<br />
 * This is used to display informations in a more friendly way than
 * xtremweb.common.WorkInterface only.
 * This mainly translates UID to names and labels (i.e. users UID to users name etc.).<br />
 *
 * This gathers informations from apps, works, tasks, users.<br />
 *
 * This derives from xtremweb.common.TableInterface to uniform code so that it
 * can be used where a TableInterface is expected but this does not transit 
 * through the network.<br />
 * This is only used on client side.<br />
 * <br />
 * This can be understood as the following SQL command:<br />
 *    SELECT works.uid,users.name,apps.name,works.label,works.status,
 *           works.resultstatus,works.cmdline,works.arrivaldate,
 *           works.completeddate,works.resultdate,works.returncode,works.error_msg,
 *           hosts.name
 *    FROM   users,apps,tasks,hosts
 *    WHERE      works.uid = tasks.uid AND works.user = users.uid 
 *           AND works.app = apps.uid  AND tasks.host = hosts.uid;<br />
 * <br />
 * Created: 23 avril 2006<br />
 *
 * @author <a href="mailto:lodygens /at\ .in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

class JobsTableModel extends TableModel {

    /**
     * This is used in the application drop down menu
     */
    private static final String SELECT = "Select...";

    /**
     * This is the current directory.
     * This is used to (re)open file choosers at the last directory
     */
    private File currentDir;

    /**
     * These defines submission parameters
     */
    private static final String UID = "UID";
    private static final String USERLABEL = "User";
    private static final String APPLABEL = "Application";
    private static final String JOBLABEL = "Label";
    private static final String ACCESSRIGHTSLABEL = "Access rights";
    private static final String CMDLINELABEL = "Command line";
    private static final String STDINLABEL = "Standard input";
    private static final String DIRINLABEL = "Local directory";
    private static final String EXPECTEDHOSTLABEL = "Expected host";
    private static final String MEMORYLABEL = "Memory";
    private static final String CPUSPEEDLABEL = "CPU Speed";

    private static final String HELPSTRING = 
        new String(APPLABEL + " is a drop down menu to select application\n" +
                   JOBLABEL + " is an optionnal field to set a job label\n" +
                   CMDLINELABEL + " is an optionnal field to set the job command line\n" +
                   EXPECTEDHOSTLABEL + " is an optionnal field to set the wished worker\n" +
                   STDINLABEL + " is optionnal; click to select/deselect an input text file\n" +
                   DIRINLABEL + " is optionnal; click to select/deselect a ZIP file,\n" + 
                   "a set of files or a directory.\n" + 
                   "If a set of files or a directory is choosen, it is automatically ZIPed");
    /**
     * These defines submission parameter labels
     */
    private static final String[] labels = {
        UID,
        USERLABEL,
        APPLABEL,
        JOBLABEL,
        ACCESSRIGHTSLABEL,
        CMDLINELABEL,
        STDINLABEL,
        DIRINLABEL,
        EXPECTEDHOSTLABEL,
        MEMORYLABEL,
        CPUSPEEDLABEL
    };


    /**
     * This combo box contains expected status to download
     */
    private JComboBox refreshComboBox;

    /**
     * This is the combo box selected index
     */
    private XWStatus refreshSelectedIndex;

    /**
     * This is the activate button label, alos used as key in hashtable
     */
    protected final String RESULT_LABEL = "Download results";

    /**
     * This is the default constructor.
     */
    public JobsTableModel (MainFrame p) {
        this (p, true);
    }
    /**
     * This is a constructor.
     * @param detail tells whether to add a last column to get details
     */
    public JobsTableModel (MainFrame p, boolean detail) {
        super (p, new JobInterface(), detail);
        refreshSelectedIndex = XWStatus.NONE;
    }
    /**
     * This creates new JButton
     * @return a Vector of JButton
     */
    public Hashtable getButtons() {

        Hashtable ret = super.getButtons();

        ((JButton)(ret.get(ADD_LABEL))).setEnabled(true);
        ((JButton)(ret.get(ADD_LABEL))).setText("Submit");
        ((JButton)(ret.get(ADD_LABEL))).setMnemonic(KeyEvent.VK_S);


        ret.remove(REFRESH_LABEL);
        refreshComboBox = new JComboBox(XWStatus.getLabels());
        refreshComboBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JComboBox source = (JComboBox)e.getSource();
                    String statusText = (String)source.getSelectedItem();
                    refreshSelectedIndex = XWStatus.fromInt(source.getSelectedIndex());
                    try {
                        refresh();
                    }
                    catch(ConnectException ex) {
                        parent.setTitleNotConnected();
                        if(debug())
                            ex.printStackTrace();
                    }
                }
            });

        ret.put(REFRESH_LABEL, refreshComboBox);


        ((JButton)(ret.get(DEL_LABEL))).setEnabled(true);

        JButton resultButton = new JButton(RESULT_LABEL);
        resultButton.setMnemonic(KeyEvent.VK_D);
        resultButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    result();
                }
            });
        resultButton.setEnabled(true);
        ret.put(RESULT_LABEL, resultButton);

        return ret;
    }
    /**
     * This retreives a Vector of work UID from server
     * @see xtremweb.communications.CommAPI#getTasks()
     */
    public Vector getRows() {
        try {
            return parent.commClient().getWorks();
        }
        catch(Exception e) {
            return new Vector();
        }
    }

    /**
     * This create a job interface
     * @return an JobInterface or null on error
     */
    public TableInterface getRow(UID uid) throws ConnectException {
        try {
            WorkInterface work = (WorkInterface)parent.commClient().get(uid);
            if(work == null)
                return null;

            if((refreshSelectedIndex != XWStatus.ANY) &&
               (refreshSelectedIndex != work.getStatus())) {
                return null;
            }

            HostInterface host = null;
            try {
                TaskInterface task = (TaskInterface)parent.commClient().get(uid);
                host = (HostInterface)parent.commClient().get(task.getHost());
            }
            catch(Exception e) {
            }
            AppInterface  app  = null;
            try {
                app  = (AppInterface)parent.commClient().get(work.getApplication());
            }
            catch(Exception e) {
            }
            UserInterface user = null;
            try {
                user = (UserInterface)parent.commClient().get(work.getUser());
            }
            catch(Exception e) {
                e.printStackTrace();
            }
            JobInterface  row  = new JobInterface(work,app,user,host);

            return row;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            return null;
        }
    }

    /**
     * This views a job
     */
    public void view() {
        super.view("Job viewer");
    }

    /**
     * This retreives job results 
     * @see xtremweb.client.Client#result()
     */
    public void result() {

        int[] selectedRows = jTable.getSelectedRows();
        int selection = selectedRows.length;
        if(selection == 0) {
            JOptionPane.showMessageDialog (parent,
                                           "No row selected!",
                                           WARNING,
                                           JOptionPane.WARNING_MESSAGE);
            return;
        }
				
        int confirm = JOptionPane.showConfirmDialog(parent,
                                                    "Do you want to download " +
                                                    selection + " result(s) ?");
        if(confirm != 0)
            return;

        JFileChooser fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if(currentDir != null)
            fc.setCurrentDirectory(currentDir);

        confirm  = fc.showOpenDialog(parent);

        currentDir = fc.getSelectedFile();

        debug("result currentDir = " + currentDir);
        debug("result filename = " + fc.getName());

        if((confirm == JFileChooser.CANCEL_OPTION) && (currentDir == null))
            return;

        debug("result currentDir = " + currentDir);

        System.out.println("00 coucoucoucoucoucocuocuocuocucoucoucocuocu");

        parent.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

        int downloaded = 0;

        for(int i = 0; i < selection; i ++) {
            int selectedRow = getSelectedRowIndex(selectedRows[i]);
            Vector row = getSelectedRow(selectedRow);

            try {
                UID jobUid = (UID)row.elementAt(JobInterface.Columns.UID.ordinal());
                String jobLabel = (String)row.elementAt(JobInterface.Columns.LABEL.ordinal());
                URI dataUri = (URI)row.elementAt(JobInterface.Columns.RESULTURI.ordinal());
                UID dataUid = dataUri.getUID();
                DataInterface data = (DataInterface)parent.commClient().get(dataUid);
                if(data == null)
                    continue;

                System.out.println("01 coucoucoucoucoucocuocuocuocucoucoucocuocu");

                String fext = "";
                System.out.println("02 coucoucoucoucoucoucocuocuocuocucoucoucoucocuocu data type = " + data.getType());
                if(data.getType() != null) {
                    fext = data.getType().getFileExtension();
                    System.out.println("02 data type = " + data.getType().getFileExtension());
                }
                File fdata = null;
                if(jobLabel != null)
                    fdata = new File(currentDir, jobUid.toString() +
                                     "_" + jobLabel + fext);
                else
                    fdata = new File(currentDir, jobUid.toString() + fext);

                System.out.println("03 coucoucoucoucoucoucocuocuocuocucoucoucoucocuocu result fdata = " + fdata);

                parent.commClient().downloadData(dataUid, fdata);
                downloaded++;    
            }
            catch(Exception e) {
            }
        }

        parent.setCursor(null);

        JOptionPane.showMessageDialog (parent,
                                       "" + downloaded + " retreived result(s)\n" + 
                                       "Results are stored in " + currentDir,
                                       INFO,
                                       JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * This adds a job by calling Client.java::submit(InputStream)
     * @see xtremweb.client.Client#submit(InputStream)
     */
    public void add() {

        UID jobUID = new UID();

        Vector newRow = new Vector();

        newRow.add(jobUID);
        newRow.add(new String());  // user name
        newRow.add(newContainer(Commands.BINARY)); // app
        newRow.add(new String());  // label
        newRow.add(new String(XWAccessRights.DEFAULT.toString())); // access rights
        newRow.add(new String());  // cmd line
        newRow.add(newContainer(Commands.STDIN)); // stdin
        newRow.add(newContainer(Commands.DIRIN)); // dirin
        newRow.add(new String());  // expected host
        newRow.add(new String());        // Min memory
        newRow.add(new String());        // Min CPUSpeed

        viewDialog = new ViewDialog(parent, "Submit new job",
                                    labels, newRow, true);

        //				JTextField component = (JTextField)dlg.fields.get(UID);
        //				component.setEnabled(false);

        JTextField component  = (JTextField)viewDialog.fields.get(USERLABEL);
        component.setEnabled(false);
        component.setText(parent.user().getLogin());

        viewDialog.helpString = HELPSTRING;

        viewDialog.setVisible(true);

        if(viewDialog.cancelled == true)
            return;

        try {
            WorkInterface job = new WorkInterface();
            job.setUID(jobUID);

            job.setLabel((String)((JTextField)viewDialog.
                                  fields.get(JOBLABEL)).getText());

            job.setCmdLine((String)((JTextField)viewDialog.
                                    fields.get(CMDLINELABEL)).getText());

            JPanel innerPanel = (JPanel)viewDialog.fields.get(APPLABEL);
            JTextField jtf = (JTextField)innerPanel.getComponent(0);
            job.setApplication(new UID(jtf.getText()));


            innerPanel = (JPanel)viewDialog.fields.get(STDINLABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            String str = jtf.getText();
            if((str != null) && (str.length() > 0))
                job.setStdin(new URI(str));

            innerPanel = (JPanel)viewDialog.fields.get(DIRINLABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            str = jtf.getText();
            if((str != null) && (str.length() > 0))
                job.setDirin(new URI(str));

            String minMem =
                (String)((JTextField)viewDialog.fields.get(MEMORYLABEL)).getText();
            if((minMem != null) && (minMem.length() > 0))
                job.setMinMemory(new Integer(minMem).intValue());

            String minSpeed = 
                (String)((JTextField)viewDialog.fields.get(CPUSPEEDLABEL)).getText();
            if((minSpeed != null) && (minSpeed.length() > 0))
                job.setMinCpuSpeed(new Integer(minSpeed).intValue());


            parent.commClient().send(job);
        }
        catch(Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog (parent,
                                           "An error occured : " + e,
                                           ERROR,
                                           JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This opens a dialog box to select a row from data table and
     * set binary, stdin, dirin
     */
    public void selectData(Commands id) {

        TableModel tm = null;
        if(id == Commands.BINARY)
            tm = new AppsTableModel (parent);
        else
            tm = new DatasTableModel (parent);

        try {
            tm.refresh();
        }
        catch(ConnectException ex) {
            parent.setTitleNotConnected();
            if(debug())
                ex.printStackTrace();
            return;
        }

        TableInterface row = (TableInterface)selectDialogBox(id.getTitle(),
                                                             tm);
        if(row == null) {
            System.out.println("row is null");
            return;
        }

        JPanel innerPanel = null;

        switch(id) {
        case BINARY :
            innerPanel = (JPanel)viewDialog.fields.get(APPLABEL);
            break;
        case STDIN :
            innerPanel = (JPanel)viewDialog.fields.get(STDINLABEL);
            break;
        case DIRIN :
            innerPanel = (JPanel)viewDialog.fields.get(DIRINLABEL);
            break;
        }

        if(innerPanel != null) {
            JTextField jtf = (JTextField)innerPanel.getComponent(0);
            if(id == Commands.BINARY)
                try {
                    jtf.setText(row.getUID().toString());
                }
                catch(IOException e){
                    e.printStackTrace();
                }
            else
                jtf.setText(((DataInterface)row).getURI().toString());
        }
    }

} // class JobsTableModel
