/**
 * UsersTableModel.java
 *
 * Purpose : This is the table model to display XtremWeb users informations
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.MD5;
import xtremweb.common.TableInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.UserGroupInterface;
import xtremweb.common.UserRights;


import java.io.IOException;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.net.ConnectException;



/**
 * This class defines a swing table model to display XtremWeb informations<br />
 * This displays and manages an src/common/UserInterface object
 */

class UsersTableModel extends TableModel {

    /**
     * These defines submission parameters
     */
    private static final String UID = "UID";
    private static final String GROUP = "Group";
    private static final String LOGIN = "Login";
    private static final String PASSWORD = "Password";
    private static final String PASSWORD2 = "Confirm password";
    private static final String EMAIL = "E-mail";
    private static final String FNAME = "First name";
    private static final String LNAME = "Last name";
    private static final String TEAM = "Team";
    private static final String COUNTRY = "Country";
    private static final String RIGHTS = "Rights";
    /**
     * These defines submission parameter labels
     */
    private static final String[] labels = {
        UID,
        GROUP,
        LOGIN,
        PASSWORD,
        PASSWORD2,
        EMAIL,
        FNAME,
        LNAME,
        TEAM,
        COUNTRY,
        RIGHTS
    };

    /**
     * This is used in the user group drop down menu
     */
    private static final String SELECT = "Select...";


    /**
     * This is the default constructor.
     */
    public UsersTableModel (MainFrame p) throws IOException{
        this (p, true);
    }


    /**
     * This is a constructor.
     * @param detail tells whether to add a last column to get details
     */
    public UsersTableModel (MainFrame p, boolean detail) throws IOException{
        super (p, new UserInterface(), detail);
    }


    /**
     * This adds an user
     */
    public void add() {
        Vector newRow = new Vector();
        UID uid = new UID();
        newRow.add(uid);            // UID


        // keep user groups UID
        Hashtable groupsUID = new Hashtable();

        String[] groupLabels = {"undefined"};

        try {
            Vector groups = parent.commClient().getUserGroups();
            Enumeration enums = groups.elements();

            groupLabels = new String[groups.size() + 1];
            int i = 0;
            groupLabels[i++] = new String(SELECT);

            while(enums.hasMoreElements()) {
                UID groupUID = (UID)enums.nextElement();
                UserGroupInterface group = (UserGroupInterface)parent.commClient().get(groupUID, false);
                groupLabels[i++] = group.getLabel();
                groupsUID.put(group.getLabel(), groupUID);
            }
        }
        catch(Exception e){
            e.printStackTrace();
            return;
        }

        newRow.add(groupLabels);      // group labels

        newRow.add(new String());   // login
        newRow.add(new JPasswordField());   // password
        newRow.add(new JPasswordField());   // verify password
        newRow.add(new String());   // email
        newRow.add(new String());   // first name
        newRow.add(new String());   // last name
        newRow.add(new String());   // team
        newRow.add(new String());   // country
        newRow.add(UserRights.getLabels());   // rights

        ViewDialog dlg = new ViewDialog(parent, "Create new user",
                                        labels, newRow, true);

        JTextField component = (JTextField)dlg.fields.get(UID);
        component.setEnabled(false);

        dlg.helpString = "LOGIN should be unic in the platform; reusing an existing login update user\n" +
            "USERGROUP is a drop down menu to select a user group, if any\n" +
            "A PASSWORD must be provided and typed twice\n" +
            "An EMAIL must be provided\n";
        dlg.setVisible(true);

        if(dlg.cancelled == true) {
            return;
        }

        try {
            UserInterface user = new UserInterface(uid);
            JTextField jtf = (JTextField)dlg.fields.get(LOGIN);
            user.setLogin((String)jtf.getText());

            if(user.getLogin().length() < 1) {
                JOptionPane.showMessageDialog (parent,
                                               "You must specify a login",
                                               WARNING,
                                               JOptionPane.WARNING_MESSAGE);
                return;
            }

            jtf = (JTextField)dlg.fields.get(PASSWORD);
            String password = (String)jtf.getText();
            jtf = (JTextField)dlg.fields.get(PASSWORD2);
            String password2 = (String)jtf.getText();

            if(password2.compareTo(password) != 0) {
                JOptionPane.showMessageDialog (parent,
                                               "Passwords do not match!",
                                               WARNING,
                                               JOptionPane.WARNING_MESSAGE);
                return;
            }

            MD5	md5 = new MD5();
            md5.Init();
            md5.Update(password + parent.getClient().getPassPhrase());
            String coded = md5.asHex();
            user.setPassword(coded);

        System.out.println("UsersTableModel#add()  login = " + user.getLogin() + " passwd = " + password + " coded = " + coded);

            try {
                JComboBox jcb = (JComboBox)dlg.fields.get(GROUP);
                String groupLabel = (String)jcb.getSelectedItem();

                UID groupUID = (UID)groupsUID.get(groupLabel);
                if(groupUID != null) {
                    user.setGroup(groupUID);
                }
            }
            catch(Exception e) {
                // group is optionnal
            }

            //						jtf = (JTextField)dlg.fields.get(TEAM);
            //						user.setTeam((String)jtf.getText());
            jtf = (JTextField)dlg.fields.get(COUNTRY);
            user.setCountry((String)jtf.getText());

            jtf = (JTextField)dlg.fields.get(FNAME);
            user.setFirstName((String)jtf.getText());
            jtf = (JTextField)dlg.fields.get(LNAME);
            user.setLastName((String)jtf.getText());

            jtf = (JTextField)dlg.fields.get(EMAIL);
            user.setEMail((String)jtf.getText());

            JComboBox jcb = (JComboBox)dlg.fields.get(RIGHTS);
            String rights = (String)jcb.getSelectedItem();
            user.setRights(UserRights.valueOf(rights));

            parent.commClient().send(user);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This views an user
     */
    public void view() {
        super.view("User viewer");
    }
    /**
     * This replaces UID by human readable columns
     */
    protected Vector getViewableRow(Vector row) {
        Vector clone = (Vector)row.clone();
        try {
            int index = UserInterface.Columns.USERGROUPUID.ordinal();
            UID uid = (UID)clone.elementAt(index);
            UserGroupInterface usergroup = (UserGroupInterface)parent.commClient().get(uid, false);
            clone.set(index, usergroup.getLabel());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return clone;
    }

    /**
     * This retreives a Vector of user UID from server
     * @see xtremweb.communications.CommAPI#getUsers()
     */
    public Vector getRows() throws ConnectException{
        try {
            parent.setTitleConnected();
            return parent.commClient().getUsers();
        }
        catch(Exception e) {
             parent.setTitleNotConnected();
             if(debug())
                 e.printStackTrace();
             throw new ConnectException(e.toString());            
        }
    }

    /**
     * This creates a new ViewDialog to display row details
     * @param title is the dialog title
     * @param selectedRow is the row to edit/display
     * @param editable enables/disables edition
     * @return a new ViewDialog
     */
    protected ViewDialog getViewDialog(String title, int selectedRow, boolean editable) {
        return (ViewDialog)new UserDialog(parent, title,
                                          itf.columns(),
                                          (Vector)rows.elementAt(selectedRow),
                                          editable);
    }

} // class UsersTableModel
