/**
 * TasksTableModel.java
 *
 * Purpose : This is the table model to display XtremWeb tasks informations
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.TableInterface;
import xtremweb.common.TaskInterface;


import java.util.Vector;
import java.util.Hashtable;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.net.ConnectException;



/**
 * This class defines a swing table model to display XtremWeb informations<br />
 * This displays and manages an src/common/TaskInterface object
 */

class TasksTableModel extends TableModel {

    /**
     * This is the default constructor.
     */
    public TasksTableModel (MainFrame p) {
        this (p, true);
    }


    /**
     * This is a constructor.
     * @param detail tells whether to add a last column to get details
     */
    public TasksTableModel (MainFrame p, boolean detail) {
        super (p, new TaskInterface(), detail);
    }


    /**
     * This creates new JButton
     * @return a Vector of JButton
     */
    public Hashtable getButtons() {

        Hashtable ret = super.getButtons();

        ((JButton)(ret.get(ADD_LABEL))).setEnabled(true);
        ((JButton)(ret.get(DEL_LABEL))).setEnabled(true);

        return ret;
    }

    /**
     * This adds a task
     */
    public void add() {
        JOptionPane.showMessageDialog (parent,
                                       "You can't add task",
                                       WARNING,
                                       JOptionPane.WARNING_MESSAGE);
    }

    /**
     * This views a task
     */
    public void view() {
        super.view("Task viewer");
    }

    /**
     * This deletes a task
     */
    public void del() {
        JOptionPane.showMessageDialog (parent,
                                       "You can't delete tasks",
                                       WARNING,
                                       JOptionPane.WARNING_MESSAGE);
    }

    /**
     * This retreives a Vector of task UID from server
     * @see xtremweb.communications.CommAPI#getTasks()
     */
    public Vector getRows() throws ConnectException{
        try {
            parent.setTitleConnected();
            return parent.commClient().getTasks();
        }
        catch(Exception e) {
             parent.setTitleNotConnected();
             if(debug())
                 e.printStackTrace();
             throw new ConnectException(e.toString());            
        }
    }

} // class TasksTableModel
