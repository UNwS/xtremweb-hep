/**
 * MainFrame.java
 *
 * Purpose : XtremWeb client main frame (prev known as XWMA)
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I, %G
 */


package xtremweb.client.gui;

import xtremweb.common.UID;
import xtremweb.worker.Worker;
import xtremweb.common.Loggerable;
import xtremweb.common.LoggerLevel;
import xtremweb.common.MD5;
import xtremweb.common.MileStone;
import xtremweb.common.util;
import xtremweb.common.UserRights;
import xtremweb.common.JarClassLoader;
import xtremweb.common.XWConfigurator;
import xtremweb.common.XWRole;
import xtremweb.common.XWReturnCode;
import xtremweb.common.XWPropertyDefs;
import xtremweb.common.CommonVersion;
import xtremweb.common.UserInterface;
import xtremweb.communications.CommClient;
import xtremweb.communications.Connection;
import xtremweb.client.Client;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.rmi.RemoteException;
import java.net.URL;
import java.net.URLConnection;
import java.net.ConnectException;
import java.net.UnknownHostException;


import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JEditorPane;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JMenuItem;
import javax.swing.SwingConstants;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.table.AbstractTableModel;
import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;



/**
 * This class describes the needed swing frame; it implements the
 * <CODE>ActionListener</CODE> interface to catch user events.
 * This is the main class as it contains the <CODE>main</CODE> method.
 */
public class MainFrame extends JFrame
    implements ActionListener, Loggerable {

    protected LoggerLevel level;

    public LoggerLevel getLoggerLevel() {
        return level;
    }

    /**
     * This helps to format date : the format is "yyyy-MM-dd HH:mm:ss"
     */
    public  final SimpleDateFormat logDateFormat = new SimpleDateFormat("[dd/MMM/yyyy:HH:mm:ss Z]", Locale.US);
    
    /**
     * This logs out a message
     */
    public void printLog(String msg) {
        System.out.println (logDateFormat.format(new Date()) +
                            " [" +  this.getClass().getName() + "] " + 
                            level + " : " + msg);
    }

    /**
     * This tells whether debug level is set to DEBUG
     * @return true if debug level is set to DEBUG
     */
    public  boolean debug() {
        return (level.ordinal() <= LoggerLevel.DEBUG.ordinal());
    }
    /**
     * This logs out a DEBUG message
     */
    public  void debug(String msg) {
        if (debug())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to INFO
     * @return true if debug level is set to INFO
     */
    public  boolean info() {
        return (level.ordinal() <= LoggerLevel.INFO.ordinal());
    }
    /**
     * This logs out an INFO message
     */
    public  void info(String msg) {
        if (info())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to WARN
     * @return true if debug level is set to WARN
     */
    public  boolean warn() {
        return (level.ordinal() <= LoggerLevel.WARN.ordinal());
    }
    /**
     * This logs out a WARN message
     */
    public  void warn (String msg) {
        if (warn())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to ERROR
     * @return true if debug level is set to ERROR
     */
    public  boolean error() {
        return (level.ordinal() <= LoggerLevel.ERROR.ordinal());
    }
    /**
     * This logs out an ERROR message
     */
    public  void error(String msg) {
        if(error())
            printLog(msg);
    }

    private final Dimension DEFAULTSIZE = new Dimension (800,600);

    /**
     * This sets the logger level.
     * This also sets the logger levels checkboxes menu item.
     */
    public void setLoggerLevel(LoggerLevel l) {
        try{
            level = l;
            client.setLoggerLevel(l);
            myPanel.setLoggerLevel(l);

            itemError.setSelected(false);
            itemWarn.setSelected(false);
            itemInfo.setSelected(false);
            itemDebug.setSelected(false);

            switch(l) {
            case ERROR :
                itemError.setSelected(true);
                break;
            case WARN :
                itemWarn.setSelected(true);
                break;
            case INFO :
                itemInfo.setSelected(true);
                break;
            case DEBUG :
                itemDebug.setSelected(true);
                break;
            }
        }
        catch(Exception e) {
        }
    }

    /**
     * This is the client
     */
    private Client client;
    /**
     * This retreives the client
     */
    public Client getClient() {
        return client;
    }

    /**
     * This retreives the communication layer
     */
    public CommClient commClient()
        throws ClassNotFoundException, 
               RemoteException, 
               UnknownHostException, 
               ConnectException {
            return client.commClient();
    }

    /**
     * This defines the current user
     */
    UserInterface user;

    /**
     * This is the "quit" menu item, in "File" menu
     */
    private JMenuItem itemQuit;
    /**
     * This is the "Login as" menu item, in "File" menu
     */
    private JMenuItem itemLoginAs;

    /**
     * This is the "Start worker" button
     */
    private JButton startWorker;
    /**
     * This is the "Show worker" button
     */
    private JButton showWorker;
    /**
     * This is the "View tasks" menu item, in "View" menu
     */
    private JCheckBoxMenuItem itemTasks;
    /**
     * This is the "View works" menu item, in "View" menu
     */
    private JCheckBoxMenuItem itemWorks;

    /**
     * This is the "Version" menu item, in "Help" menu
     */
    private JMenuItem itemVersion;

    /**
     * This is the "logger error" menu item, in "Help" menu
     */
    private JCheckBoxMenuItem itemError;
    /**
     * This is the "logger warn" menu item, in "Help" menu
     */
    private JCheckBoxMenuItem itemWarn;
    /**
     * This is the "logger info" menu item, in "Help" menu
     */
    private JCheckBoxMenuItem itemInfo;
    /**
     * This is the "logger debug" menu item, in "Help" menu
     */
    private JCheckBoxMenuItem itemDebug;
    /**
     * This is the HTTPCommClient menu item, in "Comm" menu
     */
    private JCheckBoxMenuItem itemHttp;
    /**
     * This is the TCPCommClient menu item, in "Comm" menu
     */
    private JCheckBoxMenuItem itemTcp;
    /**
     * This is the UDPCommClient menu item, in "Comm" menu
     */
    private JCheckBoxMenuItem itemUdp;

    /**
     * This is the main panel
     */
    public MainPanel myPanel;

    /**
     * This shows download progress
     */
    private JProgressBar progressBar;
    /**
     * This sets the progressbar value
     */
    public void setProgressValue(int v) {
        progressBar.setValue(v);
        progressBar.paintImmediately(progressBar.getVisibleRect());
    }
    /**
     * This sets the progressbar value
     */
    public void setProgressStringPainted(boolean b) {
        progressBar.setStringPainted(b);
    }
    /**
     * This increments the progressbar value
     */
    public void incProgressValue() {
        setProgressValue(getProgressValue() + 1);
    }
    /**
     * This returns the progressbar value
     */
    public int getProgressValue() {
        return progressBar.getValue();
    }
    /**
     * This sets the progressbar minimum
     */
    public void setProgressMinimum(int v) {
        progressBar.setMinimum(v);
    }
    /**
     * This sets the progressbar maximum
     */
    public void setProgressMaximum(int v) {
        progressBar.setMaximum(v);
    }
    /**
     * This sets title to "not connected"
     */
    public void setTitleNotConnected() {
        setTitle("XWHEP : not connected");
    }
    /**
     * This sets title to "login@server"
     */
    public void setTitleConnected() {
        setTitleConnected(client.getConfig()._user.getLogin(),
                          client.getConfig().getCurrentDispatcher());
    }
    /**
     * This sets title to "login@server"
     */
    public void setTitleConnected(String login, String server) {
        setTitle("XWHEP : " + login + "@" + server);
    }
    /**
     * This stores the total lines
     */
    private int totalLines;
    /**
     * This stores the number of selected lines
     */
    private int selectedLines;
    /**
     * This shows lines information in the form "selectedLines/totalLines"
     */
    private JTextField linesInfo;
    /**
     * This sets the total lines and refresh linesInfo
     */
    public void setTotalLines(int v) {
        totalLines = v;
        linesInfo.setText("" + selectedLines + "/" + totalLines);
    }
    /**
     * This retreives the total lines and refresh linesInfo
     */
    public int getTotalLines() {
        return totalLines;
    }
    /**
     * This increments the total lines and refresh linesInfo
     */
    public void incTotalLines() {
        setTotalLines(totalLines + 1);
    }
    /**
     * This sets the selected lines and refresh linesInfo
     */
    public void setSelectedLines(int v) {
        selectedLines = v;
        linesInfo.setText("" + selectedLines + "/" + totalLines);
    }


    /******************************************************************/
    /*                    inner class WinListener                     */
    /******************************************************************/

    /**
     * This inner class implements the interface <CODE>WindowAdapter</CODE>
     * to catch window close event.
     */
    class WinListener extends WindowAdapter {
        /**
         * This is the only method of that class,
         * inherited from interface <CODE>WindowAdapter</CODE>.
         *
         * @param ev is the event to process.
         */
        public void windowClosing( WindowEvent ev ) {
            processQuit();
        }

    } //  inner class WinListener


    /**
     * This constructor creates the main window.
     * Including a <CODE>Panel</CODE> panel.
     *
     * @param c is the client
     */
    public MainFrame(Client c) {

        super("XWHEP Client");

        this.client = c;

        addWindowListener( new WinListener() );

        /*
         * Adds menus.
         */
        JMenuBar  menuBar = new JMenuBar ();

        JMenu menuFile = new JMenu ("File");
        menuFile.setMnemonic(KeyEvent.VK_F);

        itemQuit = new JMenuItem("Close", KeyEvent.VK_C);
        itemQuit.addActionListener(this);

        itemLoginAs = new JMenuItem("Login as...", KeyEvent.VK_L);
        itemLoginAs.addActionListener(this);

        menuFile.add(itemLoginAs);
        menuFile.add(itemQuit);
        menuBar.add (menuFile);

        JMenu menuView = new JMenu ("View");
        menuView.setMnemonic(KeyEvent.VK_W);

        itemTasks = new JCheckBoxMenuItem("Show tasks");
        itemTasks.setMnemonic(KeyEvent.VK_T);
        itemTasks.addActionListener(this);
        itemTasks.setSelected(false);

        itemWorks = new JCheckBoxMenuItem("Show works");
        itemWorks.setMnemonic(KeyEvent.VK_W);
        itemWorks.addActionListener(this);
        itemWorks.setSelected(false);

        menuView.add(itemWorks);
        menuView.add(itemTasks);
        menuBar.add (menuView);

        JMenu menuComm = new JMenu ("Comm");
        menuView.setMnemonic(KeyEvent.VK_C);

        itemHttp = new JCheckBoxMenuItem("HTTP");
        itemHttp.setMnemonic(KeyEvent.VK_H);
        itemHttp.addActionListener(this);
        boolean selected = true;
        if(client.getConfig().getProperty(XWPropertyDefs.COMMLAYER.toString()) != null) {
            selected = (client.getConfig().getProperty(XWPropertyDefs.COMMLAYER.toString()).
                        compareToIgnoreCase(Connection.HTTP.layer()) == 0);
        }
        else {
            client.getConfig().setProperty(XWPropertyDefs.COMMLAYER.toString(),
                                           XWPropertyDefs.COMMLAYER.value());
        }

        itemHttp.setSelected(selected);

        itemTcp = new JCheckBoxMenuItem("TCP");
        itemTcp.setMnemonic(KeyEvent.VK_T);
        itemTcp.addActionListener(this);
        selected = false;
        selected = (client.getConfig().getProperty(XWPropertyDefs.COMMLAYER.toString()).
                    compareToIgnoreCase(Connection.TCP.layer()) == 0);
        itemHttp.setSelected(selected);

        itemUdp = new JCheckBoxMenuItem("UDP");
        itemUdp.setMnemonic(KeyEvent.VK_U);
        itemUdp.addActionListener(this);
        selected = false;
        selected = (client.getConfig().getProperty(XWPropertyDefs.COMMLAYER.toString()).
                    compareToIgnoreCase(Connection.UDP.layer()) == 0);

        menuComm.add(itemHttp);
        menuComm.add(itemTcp);
        menuComm.add(itemUdp);
        menuBar.add (menuComm);

        JMenu menuHelp = new JMenu ("?");
        itemVersion = new JMenuItem("Version", KeyEvent.VK_V);
        itemVersion.addActionListener(this);
        menuHelp.add(itemVersion);

        menuHelp.add(new JSeparator());

        JMenu menuLog = new JMenu ("Log level");
        menuLog.setMnemonic(KeyEvent.VK_L);

        itemError = new JCheckBoxMenuItem("Error");
        itemError.setMnemonic(KeyEvent.VK_E);
        itemError.addActionListener(this);
        menuLog.add(itemError);
        itemWarn = new JCheckBoxMenuItem("Warning");
        itemWarn.setMnemonic(KeyEvent.VK_W);
        itemWarn.addActionListener(this);
        itemWarn.setSelected(true);
        menuLog.add(itemWarn);
        itemInfo = new JCheckBoxMenuItem("Info");
        itemInfo.setMnemonic(KeyEvent.VK_I);
        itemInfo.addActionListener(this);
        menuLog.add(itemInfo);
        itemDebug = new JCheckBoxMenuItem("Debug");
        itemDebug.setMnemonic(KeyEvent.VK_D);
        itemDebug.addActionListener(this);
        menuLog.add(itemDebug);

        menuHelp.add(menuLog);

        menuBar.add(menuHelp);
        menuBar.add(Box.createHorizontalGlue());
        startWorker = new JButton ("Start a new worker");
        startWorker.setMnemonic(KeyEvent.VK_W);
        startWorker.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    startWorker();
                }
            });
        menuBar.add(startWorker);
        showWorker = new JButton ("Show worker");
        showWorker.setMnemonic(KeyEvent.VK_W);
        showWorker.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    showWorker();
                }
            });
        showWorker.setEnabled(false);
        menuBar.add(showWorker);

        setJMenuBar(menuBar);

        //
        // Adds panel in center of main frame
        //
        myPanel = new MainPanel(this);
        myPanel.setSize (DEFAULTSIZE);
        myPanel.setPreferredSize (DEFAULTSIZE);
        getContentPane().add(myPanel, BorderLayout.CENTER);

        //
        // adds progressbar at bottom of main frame
        //
        JPanel statusPanel = new JPanel(new GridBagLayout ());
        GridBagLayout gbLayout = (GridBagLayout)statusPanel.getLayout ();
        GridBagConstraints gbConstraints = new GridBagConstraints();

        linesInfo = new JTextField();
        linesInfo.setEnabled(false);
        linesInfo.setMinimumSize(new Dimension(150,10));
        linesInfo.setSize(150,10);
        linesInfo.setHorizontalAlignment(JTextField.CENTER);
        gbConstraints.anchor = GridBagConstraints.EAST;
        gbConstraints.fill = GridBagConstraints.BOTH;
        gbConstraints.gridx = GridBagConstraints.RELATIVE;
        gbConstraints.gridy = GridBagConstraints.RELATIVE;
        gbConstraints.weightx = 0.0;
        gbConstraints.weighty = 0.0;
        gbLayout.setConstraints (linesInfo, gbConstraints);
        statusPanel.add(linesInfo);

        progressBar = new JProgressBar();
        progressBar.setStringPainted(false);
        progressBar.setMinimum(0);

        gbConstraints.anchor = GridBagConstraints.WEST;
        gbConstraints.fill = GridBagConstraints.BOTH;
        gbConstraints.gridx = GridBagConstraints.RELATIVE;
        gbConstraints.gridy = GridBagConstraints.RELATIVE;
        gbConstraints.weightx = 1.0;
        gbConstraints.weighty = 0.0;
        gbLayout.setConstraints (progressBar, gbConstraints);
        statusPanel.add(progressBar);

        //        getContentPane().add(progressBar, BorderLayout.SOUTH);

        getContentPane().add(statusPanel, BorderLayout.SOUTH);

        //
        // initial size
        //
        //        setSize (DEFAULSIZE);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JFrame.setDefaultLookAndFeelDecorated(true);

        getUser();
        myPanel.enableButtons();

    } // MainFrame ()


    /**
     * This checks whether user is administrator
     * @return true if user is administrator
     * @see #xtremweb.common.UserRights
     */
    public boolean privileged() {
        try{
            return (user.getRights().higherOrEquals(UserRights.SUPER_USER));
        }
        catch(NullPointerException e) {
            // this may happen if not connected (missing config file...)
            return false;
        }
    }


    /**
     * This instanciates the ActionListener interface
     * method to catch menu events.
     * @param ev is the event to process.
     */
    public void actionPerformed( ActionEvent ev ) {
        JMenuItem src = (JMenuItem)ev.getSource();

        if(src == itemQuit)
            processQuit();
        else if(src == itemLoginAs)
            processLoginAs();
        else if(src == itemHttp)
            processHttp();
        else if(src == itemTcp)
            processTcp();
        else if(src == itemUdp)
            processUdp();
        else if(src == itemTasks)
            itemTasks.setSelected(myPanel.toggleTasks());
        else if(src == itemWorks)
            itemWorks.setSelected(myPanel.toggleWorks());
        else if(src == itemVersion)
            processVersion();
        else if(src == itemError)
            setLoggerLevel(LoggerLevel.ERROR);
        else if(src == itemWarn)
            setLoggerLevel(LoggerLevel.WARN);
        else if(src == itemInfo)
            setLoggerLevel(LoggerLevel.INFO);
        else if(src == itemDebug)
            setLoggerLevel(LoggerLevel.DEBUG);
    }
    /**
     * This is called by menu item 'HTTP',
     */
    private void processHttp() {
        try {
            client.getConfig().setProperty(XWPropertyDefs.COMMLAYER.toString(),
                                           Connection.HTTP.layer());
            CommClient.addHandler(Connection.XWSCHEME,
                                  Connection.HTTP.layer());
            tryGetUser();
            itemHttp.setState(true);
            itemTcp.setState(false);
            itemUdp.setState(false);
        }
        catch(Exception e) {
            itemHttp.setState(false);
            JOptionPane.
                showMessageDialog (this,
                                   e.toString(),
                                   TableModel.WARNING,
                                   JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * This is called by menu item 'TCP',
     */
    private void processTcp() {
        try {
            client.getConfig().setProperty(XWPropertyDefs.COMMLAYER.toString(),
                                           Connection.TCP.layer()); 
            CommClient.addHandler(Connection.XWSCHEME,
                                  Connection.TCP.layer());
            tryGetUser();
            itemHttp.setState(false);
            itemTcp.setState(true);
            itemUdp.setState(false);
        }
        catch(Exception e) {
            itemTcp.setState(false);
            JOptionPane.
                showMessageDialog (this,
                                   e.toString(),
                                   TableModel.WARNING,
                                   JOptionPane.ERROR_MESSAGE);
        }
   }
    /**
     * This is called by menu item 'UDP',
     */
    private void processUdp() {
        try {
            client.getConfig().setProperty(XWPropertyDefs.COMMLAYER.toString(),
                                           Connection.UDP.layer());
            CommClient.addHandler(Connection.XWSCHEME,
                                  Connection.UDP.layer());
            tryGetUser();
            itemHttp.setState(false);
            itemTcp.setState(false);
            itemUdp.setState(true);
        }
        catch(Exception e) {
            itemUdp.setState(false);
            JOptionPane.
                showMessageDialog (this,
                                   e.toString(),
                                   TableModel.WARNING,
                                   JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * This is called by menu item 'Quit',
     */
    private void processQuit() {
        setVisible (false);
        //				if (standAlone == true)
        System.exit (XWReturnCode.SUCCESS.ordinal());
    }
    /**
     * This is called by menu item 'Login as...',
     */
    private void processLoginAs() {

        LoginDialog dlg = new LoginDialog(this);

        try {
            // we must initialize mile stoning
            new MileStone(new Vector());

            if(client.getConfig() == null)
                client.setConfig(new XWConfigurator());
            client.getConfig().addDispatcher("");
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            util.fatal("Can instanciate new communication layer (this is a huuuuuge bug, folks)");
        }

        dlg.server.setText(client.getConfig().getCurrentDispatcher());
        dlg.setVisible(true);
        if(dlg.cancelled == true)
            return;

        String login = new String(dlg.login.getText());
        String password = new String(dlg.password.getPassword());

        MD5	md5 = new MD5();
        md5.Init();
        md5.Update(password + client.getPassPhrase());
        String coded = md5.asHex();

        try {
            client.getConfig().addDispatcher(dlg.server.getText());
            client.getConfig().setCurrentDispatcher(dlg.server.getText());
        }
        catch(Exception e) {
            JOptionPane.
                showMessageDialog (this,
                                   e.toString(),
                                   TableModel.WARNING,
                                   JOptionPane.ERROR_MESSAGE);
            return;
        }

        client.getConfig().setProperty(XWPropertyDefs.LOGIN.toString(), login);
        client.getConfig().setProperty(XWPropertyDefs.PASSWORD.toString(), coded);

        client.getConfig()._user.setLogin(login);
        client.getConfig()._user.setPassword(coded);

        tryGetUser();
    }

    /**
     * This is called by menu item 'Version',
     */
    private void processVersion() {
        JOptionPane.showMessageDialog (this,
                                       "Version : " + CommonVersion.getCurrent().rev() + "\n" +
                                       "Branch  : " + CommonVersion.getCurrent().branch(),
                                       "XWHEP Version",
                                       JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * This returns this client user
     */
    public UserInterface user() {
        return user;
    }


    private void tryGetUser() {
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

        try {
            if(getUser() == false) {
                JOptionPane.
                    showMessageDialog (this,
                                       "Connection error!!!\n\n" +
                                       "This may be due to :\n" +
                                       "  - server is not reachable;\n" +
                                       "  - communication layer is wrong" +
                                       " (try another one in 'Comm' menu);\n" +
                                       "  - wrong login/password.",
                                       TableModel.WARNING,
                                       JOptionPane.ERROR_MESSAGE); 
                startWorker.setEnabled(false);
            }

            myPanel.reset();
            myPanel.enableButtons();
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            setTitleNotConnected();
            startWorker.setEnabled(false);
            myPanel.setEnabled(false);
            JOptionPane.showMessageDialog (this, "Can not connect to server " + 
                                           client.getConfig().getCurrentDispatcher(),
                                           TableModel.WARNING,
                                           JOptionPane.WARNING_MESSAGE);
        }

        setCursor(null);
    }
    /**
     * This retreive user's properties from server
     */
    private boolean getUser() {
        boolean ret = true;
        try {
            //
            // retreive our user properties
            //
            user = client.getConfig()._user;
            Vector users = null;
            try {
                users = commClient().getUsers();
            }
            catch(Exception e) {
                if(debug())
                    e.printStackTrace();
                return false;
            }

            Enumeration enums = users.elements();
            while(enums.hasMoreElements()) {
                UID uid = (UID)(enums.nextElement());
                UserInterface aUser = (UserInterface)commClient().get(uid);
                if(aUser.getLogin().compareTo(user.getLogin()) == 0) {
                    user = aUser;
                    break;
                }
            }
            if(privileged() == false)
                JOptionPane.showMessageDialog (this,
                                               "You are not administrator : " +
                                               "some options are disabled",
                                               TableModel.WARNING,
                                               JOptionPane.WARNING_MESSAGE);
            setTitleConnected(user.getLogin(),
                              client.getConfig().getCurrentDispatcher());

            myPanel.setEnabled(true);
            startWorker.setEnabled(true);
        }
        catch(Exception e) {
            //            if(getLevel() == Level.DEBUG)
                e.printStackTrace();
            setTitleNotConnected();
            myPanel.setEnabled(false);
            startWorker.setEnabled(false);
            myPanel.setEnabled(false);
            ret = false;
        }

        pack();
        return ret;
    }


    /**
     * This is the HTTP port the worker is listening to 
     */
    private int workerPort;

    URL workerURL = null;

    static final String[] cursors = {
        "|",
        "/",
        "-",
        "\\"
    };

    /**
     * This launches a new worker
     */
    private void startWorker() {

        //
        // verifying URL launcher
        //
        String launchURL = client.getConfig().getProperty(XWPropertyDefs.LAUNCHERURL.toString());
        if((launchURL == null) || (launchURL.length() == 0)) {
            String strurl = JOptionPane.
                showInputDialog (this,
                                 XWPropertyDefs.LAUNCHERURL.toString() + 
                                 " is not set.\n" +
                                 "Do you knwow a valid URL ?",
                                 TableModel.WARNING,
                                 JOptionPane.WARNING_MESSAGE);
            if((strurl == null) || (strurl.length() <= 0))
                return;

            client.getConfig().setProperty(XWPropertyDefs.LAUNCHERURL.toString(), strurl);
            launchURL = client.getConfig().getProperty(XWPropertyDefs.LAUNCHERURL.toString());

        }

        boolean validJarUrl = false;
        while(validJarUrl == false) {

            try { 
                URL url = new URL(launchURL);
                if((url.getPath() == null) || (url.getPath().length() == 0))
                    url = new URL(url.toString() + "/XWHEP/download/xtremweb.jar");
                System.out.println("url launcher = " + launchURL);
                JarClassLoader cl = new JarClassLoader(url);
                cl.getMainClassName();

                validJarUrl = true;
            }
            catch (Exception e) {
                e.printStackTrace ();
                String strurl = JOptionPane.
                    showInputDialog (this,
                                     "Invalid launch URL : " + launchURL + "\n" +
                                     "Do you have a valid URL ?",
                                     TableModel.WARNING,
                                     JOptionPane.WARNING_MESSAGE);
                if((strurl == null) || (strurl.length() <= 0))
                    return;

                client.getConfig().setProperty(XWPropertyDefs.LAUNCHERURL.toString(), strurl);
                launchURL = client.getConfig().getProperty(XWPropertyDefs.LAUNCHERURL.toString());
            }
        }

        showWorker.setEnabled(true);
        startWorker.setEnabled(false);

        //
        // Launching
        //
        new Thread() {
            public void run() {
                try {
                    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

                    // try to find a free port to ensure worker can start 
                    // a new HTTP server in order to be able to stop the worker
                    workerPort = client.getConfig().
                        getPort(Connection.HTTPWORKER,
                                Connection.HTTPWORKER.defaultPortValue());

                    boolean success = false;
                    int seconds = 0;

                    JOptionPane pane = new JOptionPane("Please wait   " + cursors[0],
                                                       JOptionPane.INFORMATION_MESSAGE);
                    pane.setVisible(true);
                    int i = 0;
                    while(success == false) {
                          try { 
                              workerURL = new URL("http://localhost:" + workerPort + "/");
                              URLConnection connection = workerURL.openConnection();
                              connection.connect();
                              workerPort++;

                              pane.setMessage("Please wait   " + cursors[++i % 4]);
                          }
                          catch (Exception e) {
                              e.printStackTrace ();
                              success = true;
                          }
                    }

                    pane.setVisible(true);

                    // create a configuration file
                    XWConfigurator clone = (XWConfigurator)client.getConfig().clone();
                    clone.setProperty(XWPropertyDefs.ROLE.toString(), 
                                      XWRole.WORKER.toString());
                    clone.setProperty(Connection.HTTP.propertyName(),
                                      "" + workerPort);
                    clone.setProperty(XWPropertyDefs.SERVERHTTP.toString(),
                                      "true");

                    File out = 
                        new File(System.
                                 getProperty(XWPropertyDefs.JAVATMPDIR.toString()),
                                 "workerconf.txt");

                    clone.configFile = out;
                    clone.setProperty(XWPropertyDefs.CONFIGFILE.toString(),
                                      out.getCanonicalPath());

                    clone.store("# Launched by client", out);

                    String[] argv = {
                        "--xwconfig",
                        out.getCanonicalPath()
                    };

                    Worker worker = new Worker();
                    worker.initialize(argv);
                    worker.run();
                }
                catch(IOException e) {
                    new JOptionPane("Worker launch error : " + e,
                                    JOptionPane.ERROR_MESSAGE).setVisible(true);
                    startWorker.setEnabled(true);
                    showWorker.setEnabled(false);
                    setCursor(null);
                }
            }
        }.start();

        setCursor(null);
    }
    /**
     * This launches a new worker
     */
    private void showWorker() {

        JOptionPane pane = new JOptionPane("Please wait   " + cursors[0],
                                           JOptionPane.INFORMATION_MESSAGE);
        pane.setVisible(true);

        for(int i = 9; i >= 0; i--){
            try {
                Thread.sleep(1000);
            }
            catch(Exception e) {
            }
            try { 
                URLConnection connection = workerURL.openConnection();
                connection.connect();

                util.launchBrowser(workerURL.toString());
                break;
            }
            catch (Exception e) {
            }
            pane.setMessage(new String("Please wait   " + cursors[i % 4]));
        }

        pane.setVisible(false);
    }
    /**
     * This launches a new worker
     */
    private void stopWorker() {

        startWorker.setEnabled(true);
        showWorker.setEnabled(false);

        try { 
            URL url = new URL("http://localhost:" + workerPort + "/?exit=1");
            url.openStream();
        }
        catch (Exception e) {
            e.printStackTrace ();
        }
    }


} // class MainFrame
