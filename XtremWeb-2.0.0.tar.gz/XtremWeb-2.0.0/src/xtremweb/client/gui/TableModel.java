/**
 * TableModel.java
 *
 * Purpose : This is the table model to display XtremWeb informations
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.common.LoggerLevel;
import xtremweb.common.Loggerable;
import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.TableInterface;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import java.util.Vector;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.TreeSet;
import java.net.ConnectException;
import java.lang.reflect.Array;



/**
 * This class defines a swing table model to display XtremWeb informations<br />
 * This displays and manages an src/common/TableInterface object
 */
public abstract class TableModel extends DefaultTableModel implements Loggerable {


    protected LoggerLevel level;

    public LoggerLevel getLoggerLevel() {
        return level;
    }

    /**
     * This helps to format date : the format is "yyyy-MM-dd HH:mm:ss"
     */
    public  final SimpleDateFormat logDateFormat = new SimpleDateFormat("[dd/MMM/yyyy:HH:mm:ss Z]", Locale.US);
    
    /**
     * This logs out a message
     */
    public void printLog(String msg) {
        System.out.println (logDateFormat.format(new Date()) +
                            " [" +  this.getClass().getName() + "] " + 
                            level + " : " + msg);
    }

    /**
     * This tells whether debug level is set to DEBUG
     * @return true if debug level is set to DEBUG
     */
    public  boolean debug() {
        return (level.ordinal() <= LoggerLevel.DEBUG.ordinal());
    }
    /**
     * This logs out a DEBUG message
     */
    public  void debug(String msg) {
        if (debug())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to INFO
     * @return true if debug level is set to INFO
     */
    public  boolean info() {
        return (level.ordinal() <= LoggerLevel.INFO.ordinal());
    }
    /**
     * This logs out an INFO message
     */
    public  void info(String msg) {
        if (info())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to WARN
     * @return true if debug level is set to WARN
     */
    public  boolean warn() {
        return (level.ordinal() <= LoggerLevel.WARN.ordinal());
    }
    /**
     * This logs out a WARN message
     */
    public  void warn (String msg) {
        if (warn())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to ERROR
     * @return true if debug level is set to ERROR
     */
    public  boolean error() {
        return (level.ordinal() <= LoggerLevel.ERROR.ordinal());
    }
    /**
     * This logs out an ERROR message
     */
    public  void error(String msg) {
        if(error())
            printLog(msg);
    }

    protected final static String WARNING = "XWHEP Warning";
    protected final static String INFO    = "XWHEP Information";
    protected final static String ERROR   = "XWHEP Error";

    /**
     * This sets the logger level.
     * This also sets the logger levels checkboxes menu item.
     */
    public void setLoggerLevel(LoggerLevel l) {
        level = l;
    }

    /**
     * This dumps a String array, if on debug mode
     */
    protected void debug(String title, String[] argv) {

        if((argv == null) || (level != LoggerLevel.DEBUG))
            return;

        for(int i = 0; i < argv.length; i++) {
            debug(title + " : argv[" + i + "] = " + argv[i]);
        }
    }

    /**
     * These commands are used to set some fields in dialog boxes
     * @see #selectData(Commands)
     */
    protected enum Commands {
        LINUXIX86,
        LINUXAMD64,
        LINUXPPC,
        MACOSIX86,
        MACOSPPC,
        WIN32IX86,
        WIN32AMD64,
        BINARY,
        STDIN,
        DIRIN;

        private final String[] titles = {
            "Select linux ix86 binary",
            "Select linux amd64 binary",
            "Select linux ppc binary",
            "Select mac os x ix86 binary",
            "Select mac os x ppc binary",
            "Select win32 ix86 binary",
            "Select win32 amd64 binary",
            "Select binary",
            "Select data",
            "Select data"
        };

        public String getTitle() {
            return titles[this.ordinal()];
        }
    }


    protected final Dimension BUTTONDIMENSION  = new Dimension(40,10);
    protected final Dimension DIALOGDIMENSION  = new Dimension(700,500);

    /**
     * This is the base dialog box
     */
    protected ViewDialog viewDialog = null;

    /**
     * This is the select button label, also used as key in hashtable
     */
    protected final String SELECT_LABEL = "Select all";
    /**
     * This is the select button
     */
    JButton selectButton;
    /**
     * This is the deselect button label, also used as key in hashtable
     */
    protected final String UNSELECT_LABEL = "Clear selection";
    /**
     * This is the unselect button
     */
    JButton unselectButton;
    /**
     * This is the refresh button label, also used as key in hashtable
     */
    protected final String REFRESH_LABEL = "Refresh";
    /**
     * This is the refresh button
     */
    JButton refreshButton;
    /**
     * This is the add button label, also used as key in hashtable
     */
    protected final String ADD_LABEL = "Add";
    /**
     * This is the add button
     */
    JButton addButton;
    /**
     * This is the view button label, also used as key in hashtable
     */
    protected final String VIEW_LABEL = "View";
    /**
     * This is the view button
     */
    JButton viewButton;
    /**
     * This is the del button label, also used as key in hashtable
     */
    protected final String DEL_LABEL = "Del";
    /**
     * This is the del button
     */
    JButton delButton;


    /**
     * This tells whether to add a last column to detailed rows.
     */
    protected boolean detailed = false;

    /**
     * This is the parent main frame
     */
    protected MainFrame parent;
    /**
     * This is the table
     */
    protected JTable jTable;
    /**
     * This is the sorter
     */
    protected TableSorter sorter;

    /**
     * This is the interface to display and manage
     */
    protected TableInterface itf;

    /**
     * This contains datas.<BR>
     * Each rows has also a last item which contains a <CODE>JButton</CODE>
     * to view data.
     */
    Vector rows = new Vector ();

    /**
     * This is a constructor.
     * @param p is the parent main frame
     * @param itf is the interface
     * @param d is a boolean that tells whether to add a last column
     * to details rows.
     */
    protected TableModel (MainFrame p, TableInterface itf, boolean d) {

        detailed = d;
        parent = p;
        this.itf = itf;

        setLoggerLevel(parent.getLoggerLevel());

        selectButton = null;
        unselectButton = null;
        refreshButton = null;
        addButton = null;
        viewButton = null;
        delButton = null;
        jTable = null;
        sorter = null;
    }

    /**
     * This sets the JTable
     */
    public void setTable(JTable j) {
        jTable = j;

        ListSelectionModel selectionListener = jTable.getSelectionModel();

        selectionListener.addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    //Ignore extra messages.
                    if (e.getValueIsAdjusting()) return;

                    ListSelectionModel lsm = (ListSelectionModel)e.getSource();
                    if (!lsm.isSelectionEmpty()) {
                        parent.setSelectedLines(getSelectionLength());
                    }
                }
            });

    }
    /**
     * This gets the JTable
     */
    public JTable getTable() {
        return jTable;
    }

    /**
     * This sets the TableSorter
     */
    public void setSorter(TableSorter s) {
        sorter = s;
    }

    /**
     * This retreives buttons.
     * If button are not created yet (on first call), they are created.<br />
     * Some buttons may be disabled accordingly to user rights
     * @return a Vector of JButton
     */
    public Hashtable getButtons() {

        Hashtable ret = new Hashtable();

        if(selectButton == null) {
            selectButton = new JButton(SELECT_LABEL);
            selectButton.setMnemonic(KeyEvent.VK_A);
            selectButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        selectAll();
                    }
                });
        }

        ret.put(SELECT_LABEL, selectButton);

        if(unselectButton == null) {
            unselectButton = new JButton(UNSELECT_LABEL);
            unselectButton.setMnemonic(KeyEvent.VK_C);
            unselectButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        unselectAll();
                    }
                });
        }

        ret.put(UNSELECT_LABEL, unselectButton);

        if(refreshButton == null) {
            refreshButton = new JButton(REFRESH_LABEL);
            refreshButton.setMnemonic(KeyEvent.VK_R);
            refreshButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            parent.setTitleConnected();
                            refresh();
                        }
                        catch(ConnectException ex) {
                            if(debug())
                                ex.printStackTrace();
                            parent.setTitleNotConnected();
                        }
                    }
                });
        }

        ret.put(REFRESH_LABEL, refreshButton);

        if(addButton == null) {
            addButton = new JButton(ADD_LABEL);
            addButton.setMnemonic(KeyEvent.VK_D);
            addButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        add();
                    }
                });
        }

        addButton.setEnabled(parent.privileged());
        ret.put(ADD_LABEL, addButton);

        if(viewButton == null) {
            viewButton = new JButton(VIEW_LABEL);
            viewButton.setMnemonic(KeyEvent.VK_V);
            viewButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        view();
                    }
                });
        }

        ret.put(VIEW_LABEL, viewButton);

        if(delButton == null) {
            delButton = new JButton(DEL_LABEL);
            delButton.setMnemonic(KeyEvent.VK_E);
            delButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        del();
                    }
                });
        }

        delButton.setEnabled(parent.privileged());
        ret.put(DEL_LABEL, delButton);

        return ret;
    }

    /**
     * This adds an object
     */
    public abstract void add();

    /**
     * This retreives selected row indexes, if any.
     * To retreive a row, each element of the returned array must be used
     * as parameter of getSelectedRow() since the sorter may have
     * modified row order
     * @see #getSelectedRowIndex(int)
     * @see #getSelectedRow(int)
     */
    public int[] getSelection() {
        return jTable.getSelectedRows();
    }
    /**
     * This retreives the amount of selected rows, if any
     */
    public int getSelectionLength() {
        return jTable.getSelectedRows().length;
    }
    /**
     * This retreives a selected row index, accordingly to the sorter indexation
     * @param index is the selected row index retreived with getSelection()
     * @see #getSelection()
     */
    public int getSelectedRowIndex(int index) {
        return sorter.modelIndex(index);
    }
    /**
     * This retreives a selected row, accordingly to the sorter indexation
     * @param index is the selected row index retreived with getSelection()
     * @see #getSelection()
     */
    public Vector getSelectedRow(int index) {
        int selectedRow = getSelectedRowIndex(index);
        return (Vector)rows.elementAt(selectedRow);
    }
    /**
     * This deletes an user
     */
    public void del() {

        int[] selectedRows = getSelection();
        int selection = selectedRows.length;
        if(selection == 0) {
            JOptionPane.showMessageDialog (parent,
                                           "No row selected!",
                                           WARNING,
                                           JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(parent,
                                                    "Do you want to delete " + selection + " row(s) ?");
        if(confirm != 0)
            return;

        int removed = 0;

        TreeSet sortedIndexes = new TreeSet();
        for(int i = 0; i < selection; i ++) {
            int selectedRow = getSelectedRowIndex(selectedRows[i]);
            sortedIndexes.add(new Integer(selectedRow));
        }
        while(sortedIndexes.isEmpty() == false) {
            int selectedRow = ((Integer)sortedIndexes.last()).intValue();
            Vector v = getSelectedRow(selectedRow);

            Enumeration enums = v.elements();

            try {
                UID uid = (UID)enums.nextElement();
                parent.commClient().remove(uid);
                rows.remove(selectedRow);
                removed++;    
            }
            catch(Exception e) {
            }
            sortedIndexes.remove(sortedIndexes.last()); 
       }
//         for(int i = 0; i < selection; i ++) {
//             int selectedRow = getSelectedRowIndex(selectedRows[0]);
//             Vector v = getSelectedRow(selectedRows[0]);

//             Enumeration enums = v.elements();

//             try {
//                 UID uid = (UID)enums.nextElement();
//                 parent.commClient().remove(uid);
//                 removed++;    
//             }
//             catch(Exception e) {
//                 selection = 0;
//                 break;
//             }
//         }

        JOptionPane.showMessageDialog (parent,
                                       "" + removed + " row(s) deleted",
                                       INFO,
                                       JOptionPane.INFORMATION_MESSAGE);
        try {
            parent.setTitleConnected();
            refresh();
        }
        catch(ConnectException ex) {
            if(debug())
                ex.printStackTrace();
            parent.setTitleNotConnected();
        }
    }
    /**
     * This details objects
     */
    public abstract void view();
    /**
     * This saved objects to server
     */
    protected void save(Hashtable columns) {
        System.out.println("TableModel#save() does nothing");
    }
    /**
     * This replaces UID by human readable columns
     */
    protected Vector getViewableRow(Vector row) {
        System.out.println("TableModel#getViewableRow() does nothing");
        return row;
    }

    /**
     * This select all rows
     */
    protected void selectAll() {
        jTable.selectAll();
    }

    /**
     * This unselect all rows
     */
    protected void unselectAll() {
        jTable.clearSelection();
        parent.setSelectedLines(0);
    }

    /**
     * This views an object
     */
    protected void view(String title) {
        this.view(title, "no help available");
    }

    /**
     * This views an object
     */
    protected void view(String title, String help) {
        int[] selectedRows = getSelection();
        if(selectedRows.length == 0) {
            JOptionPane.showMessageDialog (parent,
                                           "No row selected!",
                                           WARNING,
                                           JOptionPane.WARNING_MESSAGE);
            return;
        }
        else if(selectedRows.length > 1) {
            JOptionPane.showMessageDialog (parent,
                                           "You can not view more than one row at a time",
                                           WARNING,
                                           JOptionPane.WARNING_MESSAGE);
            return;
        }

        ViewDialog dlg = getViewDialog(title,
                                       getViewableRow(getSelectedRow(selectedRows[0])),
                                       false);
        dlg.helpString = help;
        dlg.setVisible(true);
        if((dlg.edited == true) && (dlg.cancelled == false))
            save(dlg.fields);
    }

    /**
     * This retreives a Vector of object UID from server
     */
    public abstract Vector getRows() throws ConnectException;

    /**
     * This retreives an object from server
     * @return a TableInterface or null on error
     * @see xtremweb.communications.CommAPI#get(UID)
     */
    public TableInterface getRow(UID uid) throws ConnectException{
        try {
            parent.setTitleConnected();
            return parent.commClient().get(uid);
        }
        catch(Exception e) {
            parent.setTitleNotConnected();
            if(debug())
                e.printStackTrace();
            throw new ConnectException(e.toString());
        }
    }

    /**
     * This creates a new ViewDialog to display row details
     * @param title is the dialog title
     * @param selectedRow is the row to edit/display
     * @param editable enables/disables edition
     * @return a new ViewDialog
     */
    protected ViewDialog getViewDialog(String title, Vector row, boolean editable) {
        return new ViewDialog(parent, title,
                              itf.columns(),
                              row, editable);
    }

    /**
     * This reset table
     */
    public void reset() {

        rows.clear ();
        fireTableChanged(new TableModelEvent(this));
    }

    /**
     * This retreives datas from server
     * @see #getRows()
     * @see #getRow()
     */
    public void refresh() throws ConnectException {

        int lines = 0;

        //        try {
            rows.clear ();
            Vector datas = getRows();

            parent.setProgressStringPainted(true);
            parent.setProgressValue(0);
            parent.setProgressMinimum(0);
            parent.setProgressMaximum(datas.size());

            parent.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

            if(datas != null) {
                Enumeration enums = datas.elements();
								
                while(enums.hasMoreElements()) {

                    UID uid = (UID)(enums.nextElement());

                    parent.incProgressValue();

                    if(uid == null)
                        continue;

                    TableInterface row = getRow(uid);
                    if(row == null)
                        continue;

                    Vector v = row.toVector();
                    if(v == null)
                        continue;

                    rows.addElement(v);
                    lines++;
                }
            }
            fireTableChanged(new TableModelEvent(this));
//         }
//         catch (Exception ex) {
//             ex.printStackTrace();
//         }

        parent.setProgressStringPainted(false);
        parent.setCursor(null);
        parent.setTotalLines(lines);
        parent.setSelectedLines(0);

    } // refresh()
    public void close() {
        //    resultSet.close();
    }

    protected void finalize() throws Throwable {
        close();
        super.finalize();
    }


    public int getColumnCount() {
        try {
            return itf.columns().length;
        }
        catch (Exception e) {
            return 0;
        }
    }

    public int getRowCount() {
        try {
            return rows.size();
        }
        catch (Exception e) {
            return 0;
        }
    }

    public String getColumnName(int col) {
        if(itf.columns()[col] != null)
            return itf.columns()[col];
        else
            return "";
    }

    public Object getValueAt(int arow, int acol) {
        try {
            Vector row = (Vector)rows.elementAt(arow);
            return row.elementAt(acol);
        }
        catch (Exception e) {
            return null;
        }
    }

    /**
     * This changes value in table thanks to its coordinates.
     * @param value is the new value
     * @param arow is the row where data is
     * @param acol is the column where data is
     */
    public void setValueAt (Object value, int arow, int acol) {

        if (isCellEditable (arow, acol) == false)
            return;

        try {
            Vector row = (Vector)rows.elementAt (arow);
            row.setElementAt ((Boolean)value, acol);
        }
        catch (Exception e) {
            System.err.println("TasksTableModel::setValueAt () " + e);
            return;
        }

    } // setValueAt ()


    /**
     * JTable uses this method to determine the default renderer/
     * editor for each cell.  If we didn't implement this method,
     * then the last column would contain text ("true"/"false"),
     * rather than a check box.
     */
    public Class getColumnClass(int column) {
        try{
            /*
              System.out.println(getColumnName(column).toString() + 
                                 " = " + getValueAt(0, column).toString() +
                                 " is a " + getValueAt(0, column).getClass().toString());
            */
            if(getValueAt(0, column) == null)
                return new String().getClass ();
            return getValueAt(0, column).getClass();
        }
        catch (Exception e) {
            e.printStackTrace();
            return new String().getClass ();
        }
    }


    /**
     * This is called to determine whether a cell is editable or not.
     * This returns true for the last column only to enable row details edition.
     * @param row    : cell row
     * @param column : cell column
     * @return true if cell is editable
     */
    public boolean isCellEditable(int row, int column) {
        return false;
    }

    /**
     * This create a new JPanel containing a JTextField with associated button
     * The button calls selectData()
     * @return the new JPanel
     */
    protected JPanel newContainer (final Commands id) {
        JButton button = new JButton("...");
        JTextField uri = new JTextField();
        button.setMaximumSize(BUTTONDIMENSION);
        button.setMinimumSize(BUTTONDIMENSION);
        button.setPreferredSize(BUTTONDIMENSION);
        button.setSize(BUTTONDIMENSION);
        button.addActionListener(new ActionListener() {
                public final void actionPerformed(ActionEvent e) {
                    selectData(id);
                }
            });

        JPanel container = new JPanel(new GridBagLayout());
        GridBagLayout gbLayout = (GridBagLayout)container.getLayout ();
        GridBagConstraints gbConstraints = new GridBagConstraints();
        gbConstraints.anchor = GridBagConstraints.CENTER;
        gbConstraints.fill = GridBagConstraints.BOTH;
        gbConstraints.gridx = GridBagConstraints.RELATIVE;
        gbConstraints.gridy = GridBagConstraints.RELATIVE;
        gbConstraints.weightx = 1.0;
        gbConstraints.weighty = 0.0;
        container.add(uri);
        container.add(button);
        gbLayout.setConstraints (uri, gbConstraints);
        gbLayout.setConstraints (container, gbConstraints);
        gbConstraints.weightx = 0.0;
        gbLayout.setConstraints (button, gbConstraints);

        return container;
    }

    /**
     * This does nothing and must be overriden, if needed
     */
    public void selectData(Commands id) {
    }
    /**
     * This opens a dialog box to display the provided table model.
     * The can select a row from the provided table model
     */
    public TableInterface selectDialogBox(String title, TableModel tableModel) {

        Vector newRow = new Vector();

        JPanel container = new JPanel(new GridBagLayout());
        GridBagLayout gbLayout = (GridBagLayout)container.getLayout();
        GridBagConstraints gbConstraints = new GridBagConstraints();
        gbConstraints.anchor = GridBagConstraints.CENTER;
        gbConstraints.fill = GridBagConstraints.BOTH;
        gbConstraints.gridx = GridBagConstraints.RELATIVE;
        gbConstraints.gridy = GridBagConstraints.RELATIVE;
        gbConstraints.weightx = 1.0;
        gbConstraints.weighty = 1.0;
        gbConstraints.gridwidth = GridBagConstraints.REMAINDER;

        TablePanel panel = new TablePanel(tableModel);
        gbLayout.setConstraints(panel, gbConstraints);
        container.add(panel);
        newRow.add(container);

        ViewDialog dlg = new ViewDialog(parent, title,
                                        null, newRow, false);
        
        dlg.setSize(DIALOGDIMENSION);
        dlg.setVisible(true);

        if((dlg.cancelled == true) ||
           (tableModel.getSelectionLength() != 1))
            return null;

        int selection = tableModel.getSelection()[0];
        Vector row = tableModel.getSelectedRow(selection);
        UID uid = (UID)row.get(0);

        try {
            return parent.commClient().get(uid, false);
        }
        catch(Exception exc) {
        }

        return null;
    }

} // class TableModel
