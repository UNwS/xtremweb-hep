/**
 * ParamsPanel.java
 *
 * Purpose : XtremWeb parameters GUI panel
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.border.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.lang.System;
import java.awt.event.MouseEvent;

import xtremweb.common.*;



/**
 * This class describes the XtremWeb parameter GUI panel
 */

public class ParamsPanel extends JPanel {
		/**
		 * This displays trusted addresses in a list
		 */
		private JList trustedAddressesList;
		/**
		 * This is needed to be able to add/remove trusted addresses
		 * to/from <CODE>trustedAddressesList</CODE>
		 */
		private DefaultListModel trustedAddressesModel;
		/**
		 * This button helps to remove address from trusted ones.
		 */
		private JButton removeTrustedAddress;
		/**
		 * This button helps to add address to trusted ones.
		 */
		private JButton addTrustedAddress;

		/**
		 * These are needed to retreive parameters values from user.
		 */
		JTextField paramsNbWorkers;
		//		JTextField tracesPeriod;
		//		JTextField tracesResultsPeriod;


		private MainFrame parent;


		/**
		 * This constructs a new panel with GUI to manage XtremWeb parameters
		 */
		public ParamsPanel (MainFrame p) {

				parent = p;
				//
				// Creates panes.
				//
				JTabbedPane tabbedPane = new JTabbedPane();
				GridBagLayout gbLayout = new GridBagLayout ();
				GridBagConstraints gbConstraints = new GridBagConstraints();
				WorkerParameters params;



				//////////////////////////////////////////////////////////////////
				//                   Parameters panel
				//////////////////////////////////////////////////////////////////


				try {
						//						params = parent.getWorkersParameters ();
				}
				catch (Exception ex) {
						params = new WorkerParameters ();
				}

				try {
						//String addresses = parent.getTrustedAddresses ();
						//trustedAddressesModel = stringToListModel (addresses, ' ');
				}
				catch (Exception ex2) {
						trustedAddressesModel = new DefaultListModel ();
				}

				JButton aButton = new JButton ("Commit");

				aButton.addActionListener(
																	new ActionListener()
																	{
																			public void actionPerformed(ActionEvent e)
																			{
																					commitParams (e);
																			}
																	}
																	);

				gbConstraints.anchor = GridBagConstraints.CENTER;
				gbConstraints.fill = GridBagConstraints.VERTICAL;
				gbConstraints.gridx = GridBagConstraints.RELATIVE;
				gbConstraints.gridy = GridBagConstraints.RELATIVE;
				gbConstraints.weightx = 1.0;
				gbConstraints.weighty = 0.0;
				gbConstraints.gridwidth = GridBagConstraints.REMAINDER;
				gbLayout.setConstraints (aButton, gbConstraints);
				add (aButton);

				JLabel label = new JLabel ("Expected workers");
				gbConstraints.fill = GridBagConstraints.BOTH;
				gbConstraints.gridwidth = 1;
				gbLayout.setConstraints (label, gbConstraints);
				add (label);

				paramsNbWorkers = new JTextField ("0", 5);
				gbConstraints.gridwidth = GridBagConstraints.REMAINDER;
				gbLayout.setConstraints (paramsNbWorkers, gbConstraints);
				add (paramsNbWorkers);

				/*

				label = new JLabel ("Trace frequency (sec)");
				gbConstraints.gridwidth = 1;
				gbLayout.setConstraints (label, gbConstraints);
				add (label);

				tracesPeriod = new JTextField (String.valueOf (params.resultDelay / 1000),
																			 5);
				gbConstraints.gridwidth = GridBagConstraints.REMAINDER;
				gbLayout.setConstraints (tracesPeriod, gbConstraints);
				add (tracesPeriod);


				label = new JLabel ("Nb traces in traces file");
				gbConstraints.gridwidth = 1;
				gbLayout.setConstraints (label, gbConstraints);
				add (label);

				tracesResultsPeriod = new JTextField (String.valueOf(params.sendResultDelay),
																							5);
				gbConstraints.gridwidth = GridBagConstraints.REMAINDER;
				gbLayout.setConstraints (tracesResultsPeriod, gbConstraints);
				add (tracesResultsPeriod);
				*/

				trustedAddressesList = new JList (trustedAddressesModel);
				trustedAddressesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				JScrollPane addrScrollPane = new JScrollPane(trustedAddressesList);
				gbConstraints.weighty = 1.0;
				gbConstraints.ipadx = -5;
				gbConstraints.gridwidth = GridBagConstraints.REMAINDER;
				gbLayout.setConstraints (addrScrollPane, gbConstraints);
				add (addrScrollPane);


				addTrustedAddress = new JButton ("Add");
				addTrustedAddress.addActionListener(
																						new ActionListener()
																						{
																								public void actionPerformed(ActionEvent e)
																								{
																										addAddress (e);
																								}
																						}
																						);
				gbConstraints.weighty = 0.0;
				gbConstraints.gridwidth = 1;
				gbLayout.setConstraints (addTrustedAddress, gbConstraints);
				add (addTrustedAddress);

				removeTrustedAddress = new JButton ("Remove");
				removeTrustedAddress.addActionListener(
																							 new ActionListener()
																							 {
																									 public void actionPerformed(ActionEvent e)
																									 {
																											 removeAddress (e);
																									 }
																							 }
																							 );
				gbConstraints.gridwidth = GridBagConstraints.REMAINDER;
				gbLayout.setConstraints (removeTrustedAddress, gbConstraints);
				add (removeTrustedAddress);


		} // ParamsPanel()


		/**
		 * This is called when user clicks 'commit' on page 'params'
		 */
		void commitParams (ActionEvent e) {

				int nbWorkers;
				int sendResultDelay = 0;
				int resultDelay = 0;

				try {
						nbWorkers = Integer.parseInt (paramsNbWorkers.getText());
						//						sendResultDelay = Integer.parseInt (tracesResultsPeriod.getText());
						//						resultDelay = Integer.parseInt (tracesPeriod.getText()) * 1000;
				}
				catch (Exception ex) {
						JOptionPane.showMessageDialog (this, "Integer format error!!!");
						return;
				}

				try {
						/*
						parent.setWorkersParameters (nbWorkers,
																				 resultDelay,
																				 sendResultDelay);
						*/
				}
				catch (Exception ex) {
						System.err.println("something wrong while forwarding parameters");
				}
		}


		/**
		 * This is called when user clicks 'add' on page 'params' to add a
		 * trusted adresse.
		 */
		void addAddress (ActionEvent e) {
				JOptionPane jop = new JOptionPane ();
				String newAddr;

				try {
						/*
						newAddr = jop.showInputDialog (this, "Enter new address");
						parent.addTrustedAddress (newAddr);
						trustedAddressesModel.addElement (newAddr);
						*/
				}
				catch (Exception ex) {
						JOptionPane.showMessageDialog (this, "Server error!!!");
				}
		}


		/**
		 * This is called when user clicks 'remove' on page 'params' to remove
		 * selected trusted adresse.
		 */
		void removeAddress (ActionEvent e) {
				try {
						/*
						int index = trustedAddressesList.getSelectedIndex();
						String addr = (String)trustedAddressesModel.elementAt (index);

						parent.removeTrustedAddress (addr);

						trustedAddressesModel.remove(index);

						int size = trustedAddressesModel.getSize();

						if (size != 0) {
								//removed item in last position
								if (index == trustedAddressesModel.getSize())
										index--;
								//otherwise select same index
								trustedAddressesList.setSelectedIndex(index); 
						}
						*/
				}
				catch (Exception ex) {
						JOptionPane.showMessageDialog (this, "Server error!!!");
				}
		}


		/**
		 * This converts a string to a list model accordingly to a separator
		 */
		private DefaultListModel stringToListModel (String input, char separator) {
				DefaultListModel ret = new DefaultListModel ();
				int index = 0;
				int lastIndex = -1;

				if (input == null)
						return ret;

				for (index = input.indexOf (separator);
						 index != -1;
						 index = input.indexOf (separator, index + 1)) {

						String newStr = input.substring (lastIndex + 1, index);
						ret.addElement (newStr);
						lastIndex = index;
				}

				return ret;
		}


} // class ParamsPanel
