/**
 * TablePanel.java
 *
 * Purpose : XtremWeb main GUI panel
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.common.XWStatus;
import xtremweb.common.UID;


import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.DefaultCellEditor;
import javax.swing.table.TableCellRenderer;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.net.ConnectException;


/**
 * This class describes the XtremWeb client swing panel.
 */

public class TablePanel extends JPanel {

    JTable jTable;
    final TableModel model;
    public TableModel getTableModel() {
        return model;
    }

    final TableSorter sorter;

    /**
     * This constructor inserts needed tables.
     */
    public TablePanel (TableModel m) {

        super(new GridBagLayout ());
        model = m;

        sorter = new TableSorter(model);

        GridBagLayout gbLayout = (GridBagLayout)getLayout ();
        GridBagConstraints gbConstraints = new GridBagConstraints();
        //				JPanel jPanel = new JPanel(gbLayout);

        //				model.refresh();

        //				jTable = new JTable(model);
        jTable = new JTable(sorter);
        sorter.setTableHeader(jTable.getTableHeader());

        model.setTable(jTable);
        model.setSorter(sorter);

        Hashtable buttons = model.getButtons();

        gbConstraints.anchor = GridBagConstraints.CENTER;
        gbConstraints.fill = GridBagConstraints.BOTH;
        gbConstraints.gridx = GridBagConstraints.RELATIVE;
        gbConstraints.gridy = GridBagConstraints.RELATIVE;
        gbConstraints.weightx = 1.0;
        gbConstraints.weighty = 0.0;

        Enumeration enums = buttons.elements();
        int i = 0;
        int size = buttons.size();
        while(enums.hasMoreElements()) {

            //						JButton button = (JButton)(enums.nextElement());
            JComponent button = (JComponent)(enums.nextElement());

            if(i == size - 1)
                gbConstraints.gridwidth = GridBagConstraints.REMAINDER;
            gbLayout.setConstraints (button, gbConstraints);
            add(button);

            i++;
        }

        setUpButtonRenderer(jTable);
        setUpButtonEditor(jTable);
        jTable.setPreferredScrollableViewportSize(new Dimension(500, 70));

        //
        // Create the scroll pane and add the table to it. 
        //
        JScrollPane jScrollPane = new JScrollPane(jTable);
        gbConstraints.weighty = 1.0;
        gbConstraints.ipadx = -5;
        gbConstraints.gridwidth = GridBagConstraints.REMAINDER;
        gbLayout.setConstraints (jScrollPane, gbConstraints);
        add(jScrollPane);
    }

    /**
     * This retreives datas from server; this also enable/disable buttons
     */
    public void refresh() throws ConnectException {
        // retreive datas from server
        model.refresh();
        // enable/disable buttons
        model.getButtons();
    }

    public int getRowCount() {
        return model.getRowCount();
    }
    public JTable getTable() {
        return model.getTable();
    }

    /**
     * This calls JTable::setDefaultRenderer().
     * Its sets a renderer for JButton; we don't have to worry about
     * rendering JCheckBox since it is included in standard Java API.
     * @see the java programming API.
     * @param  table containing button cells.
     */
    private void setUpButtonRenderer(JTable table) {
        table.setDefaultRenderer(JButton.class,
                                 new PushButtonRenderer());
        table.setDefaultRenderer(String.class,
                                 new StringRenderer());
        table.setDefaultRenderer(UID.class,
                                 new StringRenderer());
        table.setDefaultRenderer(Date.class,
                                 new DateRenderer());
    }


    /**
     * This defines action on button click in dedicated table button cells.
     * Its sets an editor for JButton; we don't have to worry about
     * editing JCheckBox since it is included in standard Java API.
     * @see the java programming API.
     * @param  table containing button cells.
     */
    private void setUpButtonEditor(JTable table) {
        //
        // First, set up button that bring up the dialog.
        //
        final JButton pushButton = new JButton ("Detail");

        //
        // Now create editors to encapsulate buttons, and
        // set them up as editors.
        //
        final PushButtonEditor pushButtonEditor = new PushButtonEditor(pushButton);
        table.setDefaultEditor(JButton.class,   pushButtonEditor);
    }


    /************************************************
     * This inner class defines the Button renderer *
     ************************************************/

    class ArrayRenderer extends JComboBox
        implements TableCellRenderer {
        public ArrayRenderer() {
        }

        public Component getTableCellRendererComponent(JTable table,
                                                       Object value, 
                                                       boolean isSelected,
                                                       boolean hasFocus,
                                                       int row, int column) {
            return this;
        }
    }


    /************************************************
     * This inner class defines the Button renderer *
     ************************************************/

    class PushButtonRenderer extends JButton
        implements TableCellRenderer {
        public PushButtonRenderer() {
            super("Detail");
        }

        public Component getTableCellRendererComponent(JTable table,
                                                       Object value, 
                                                       boolean isSelected,
                                                       boolean hasFocus,
                                                       int row, int column) {
            return this;
        }
    }


    /************************************************
     * This inner class defines the String renderer *
     ************************************************/

    class StringRenderer extends JLabel
        implements TableCellRenderer {
        public StringRenderer() {
            super("");
            setOpaque(true);
            this.setBackground(Color.WHITE);
        }

        public Component getTableCellRendererComponent(JTable table,
                                                       Object value, 
                                                       boolean isSelected,
                                                       boolean hasFocus,
                                                       int row, int column) {
            if(value != null) {

                Color color = Color.BLACK;

                setText(value.toString());
                try {
                    switch(XWStatus.valueOf(value.toString())) {
                    case COMPLETED:
                        color = Color.GREEN.darker();
                        break;
                    case RUNNING:
                        color = Color.ORANGE.darker();
                        break;
                    case ERROR:
                        color = Color.RED.darker();
                        break;
                    }
                }
                catch(Exception e) {
                    // not a status
                }

                this.setForeground(color);

                if(isSelected)
                    this.setBackground(Color.LIGHT_GRAY);
                else
                    this.setBackground(Color.WHITE);
            }
            return this;
        }
    }

    /************************************************
     * This inner class defines the Date renderer   *
     ************************************************/

    class DateRenderer extends JLabel
        implements TableCellRenderer {
        public DateRenderer() {
            super("");
            setOpaque(true);
            this.setBackground(Color.WHITE);
        }

        public Component getTableCellRendererComponent(JTable table,
                                                       Object value, 
                                                       boolean isSelected,
                                                       boolean hasFocus,
                                                       int row, int column) {
            if(value != null) {
                setText(value.toString());
                if(isSelected)
                    this.setBackground(Color.LIGHT_GRAY);
                else
                    this.setBackground(Color.WHITE);
            }
            return this;
        }
    }


    /**************************************************
     * This inner class defines the PushButton editor *
     **************************************************/

    class PushButtonEditor extends DefaultCellEditor {

        public PushButtonEditor(JButton b) {
            // This is an artefact only, since our button is a simple JButton.
            // Unfortunately, the constructor expects JCheckBox, JComboBox,
            // or JText.
            super(new JCheckBox());
	                        

            editorComponent = b;
            setClickCountToStart(1); //This is usually 1 or 2.

            //Must do this so that editing stops when appropriate.
            b.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        fireEditingStopped();
                    }
                });
        }

        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }

        public Object getCellEditorValue() {
            return new Boolean (false);
        }

        public Component getTableCellEditorComponent(JTable table, 
                                                     Object value,
                                                     boolean isSelected,
                                                     int row,
                                                     int column) {

            JTable dataTable;
            String dlgTitle;
            String dlgLabel;

            ((JButton)editorComponent).setSelected (false);

            return editorComponent;

        } // getTableCellEditorComponent()

    } // class PushButtonEditor

}
