/**
 * This defines a modal Dialog to enter server, login and password
 * Created : 18 Avril 2006
 * @author Oleg Lodygensky
 */

package xtremweb.client.gui;

import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class LoginDialog extends JDialog
    implements ActionListener {
    private static String OK = "Ok";
    private static String CANCEL = "Cancel";
    private static String HELP = "Help";

    private JFrame parent;
    public JTextField server;
    public JTextField login;
    public JPasswordField password;
    public boolean cancelled;

    /**
     * This constructor does everything
     */
    public LoginDialog(JFrame f) {

        super(f, "XWHEP login", true);

        cancelled = true;

        //Use the default FlowLayout.
        parent = f;

        // server field
        server = new JTextField(50);
        server.addActionListener(this);
        JLabel sLabel = new JLabel("Server : ");
        sLabel.setLabelFor(server);

        // login field
        login = new JTextField(50);
        login.addActionListener(this);
        JLabel lLabel = new JLabel("Login : ");
        lLabel.setLabelFor(login);

        // password field
        password = new JPasswordField(10);
        password.setEchoChar('#');
        password.setActionCommand(OK);
        password.addActionListener(this);

        JLabel pLabel = new JLabel("Password : ");
        pLabel.setLabelFor(password);

        JButton okButton = new JButton(OK);
        JButton cancelButton = new JButton(CANCEL);
        JButton helpButton = new JButton(HELP);

        okButton.setActionCommand(OK);
        okButton.setMnemonic(KeyEvent.VK_O);
        cancelButton.setActionCommand(CANCEL);
        cancelButton.setMnemonic(KeyEvent.VK_C);
        helpButton.setActionCommand(HELP);
        helpButton.setMnemonic(KeyEvent.VK_H);
        okButton.addActionListener(this);
        cancelButton.addActionListener(this);
        helpButton.addActionListener(this);


        JPanel textPane = new JPanel(new GridLayout(5,2));
        textPane.add(sLabel);
        textPane.add(server);
        textPane.add(lLabel);
        textPane.add(login);
        textPane.add(pLabel);
        textPane.add(password);

        textPane.add(okButton);
        textPane.add(cancelButton);
        textPane.add(helpButton);

        getContentPane().add(textPane);
        //				getContentPane().add(buttonPane);
        resetFocus();
        pack();
        setSize(400,150);
    }

    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        if (OK.equals(cmd)) {
            cancelled = false;
            setVisible(false);
        }
        else if (CANCEL.equals(cmd)) {
            cancelled = true;
            setVisible(false);
        } 
        else {
            JOptionPane.showMessageDialog(parent,
                                          "Server is either a resolved server name, or an IP address\n"
                                          + "Login/Password are those provided by the server administrator",
                                          TableModel.INFO,
                                          JOptionPane.INFORMATION_MESSAGE);
        }
    }

    //Must be called from the event-dispatching thread.
    protected void resetFocus() {
        login.requestFocusInWindow();
    }

}
