/**
 * This defines a modal Dialog to enter server, login and password
 */

package xtremweb.client.gui;

import xtremweb.common.UID;

import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JComponent;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ViewDialog extends JDialog
    implements ActionListener {

    protected static String OK = "Ok";
    protected static String EDIT = "Edit";
    protected static String CANCEL = "Cancel";
    protected static String HELP = "Help";
    protected JFrame parent;
    protected JPanel textPane = null;

    /**
     * This contains the editable fields
     */
    public String[] columns;
    /**
     * This contains the editable fields
     */
    public Hashtable fields;
    /**
     * This is true if user cancelled
     */
    public boolean cancelled;
    /**
     * This is true if user is editing
     */
    public boolean editing;
    /**
     * This is true if user has edited
     */
    public boolean edited;
    /**
     * This contains the help string, if any
     */
    public String helpString;

    /**
     * This constructor does everything
     * @param f is the aprent JFrame
     * @param title is the dialog title
     * @param c is a String array containing columns name, if c is null, row contains a single TableModel
     * @param row is a Vector containing the selected row or a single JComponent if c is null
     * @param editable enables/disables edition
     */
    public ViewDialog(JFrame f, String title, 
                      String[] c, Vector row, boolean editable) {

        super(f, title, true);

        helpString = "No help available";
        cancelled = true;
        editing = false;
        edited = false;

        parent = f;
        fields = new Hashtable();
        columns = c;

        if(columns != null) {

            textPane = new JPanel(new GridLayout(columns.length + 2, 2));

            for(int i = 0; i < columns.length; i++) {

                Object value = row.get(i);

                JComponent field = null;

                if(value != null) {
                    if(value.getClass() == java.lang.Boolean.class) {
                        field = (JComponent)(new JCheckBox());
                        ((JCheckBox)field).setSelected(((Boolean)value).booleanValue());
                    }
                    else if(value.getClass().isArray()) {
                        String[] v = (String[])value;
                        JComboBox jcb = new JComboBox(v);
                        field = (JComponent)jcb;
                    }
                    //                 else if(value.getClass() == javax.swing.JButton.class) {
                    //                     field = (JComponent)value;
                    //                 }
                    else if(value instanceof javax.swing.JComponent) {
                        field = (JComponent)value;
                    }
                    else {
                        field = (JComponent)(new JTextField(value.toString()));
                    }
                }
                else {
                    field = (JComponent)(new JTextField(""));
                }

                if(columns[i].compareToIgnoreCase("UID") == 0)
                    field.setEnabled(false);
                else
                    if(field.isEnabled() == true)
                        field.setEnabled(editable);

                JLabel label = new JLabel(columns[i]);
                label.setLabelFor(field);
                textPane.add(label);
                textPane.add(field);
                fields.put(columns[i], field);
            }
        }
        else {
            textPane = new JPanel(new GridBagLayout());
            GridBagLayout gbLayout = (GridBagLayout)textPane.getLayout();
            GridBagConstraints gbConstraints = new GridBagConstraints();
            gbConstraints.anchor = GridBagConstraints.CENTER;
            gbConstraints.fill = GridBagConstraints.BOTH;
            gbConstraints.gridx = GridBagConstraints.RELATIVE;
            gbConstraints.gridy = GridBagConstraints.RELATIVE;
            gbConstraints.weightx = 1.0;
            gbConstraints.weighty = 1.0;
            gbConstraints.gridwidth = GridBagConstraints.REMAINDER;
            JComponent component = (JComponent)row.get(0);
            gbLayout.setConstraints (component, gbConstraints);
            textPane.add(component);
        }

        JButton button = new JButton(OK);
        button.setActionCommand(OK);
        button.setMnemonic(KeyEvent.VK_O);
        button.addActionListener(this);

        textPane.add(button);

        // 26 novemvre 2007 : editing is not implemented yet
//         if(columns != null) {
//             if(editable == false) {
//                 button = new JButton(EDIT);
//                 button.setActionCommand(EDIT);
//                 button.setMnemonic(KeyEvent.VK_E);
//                 button.addActionListener(this);

//                 textPane.add(button);
//             }
//         }

        button = new JButton(CANCEL);
        button.setMnemonic(KeyEvent.VK_C);
        button.setActionCommand(CANCEL);
        button.addActionListener(this);

        textPane.add(button);

        button = new JButton(HELP);
        button.setMnemonic(KeyEvent.VK_H);
        button.setActionCommand(HELP);
        button.addActionListener(this);

        textPane.add(button);

        getContentPane().add(textPane);
        //				getContentPane().add(buttonPane);
        pack();
        //				setSize(600, (columns.length) * 30);
    }
    /**
     * This toggles edit on/off
     */
    private void toggleEdit() {

        edited = true;
        editing = !editing;

        for(int i = 0; i < columns.length; i++) {

            JComponent field = (JComponent)fields.get(columns[i]);
            if(columns[i].compareToIgnoreCase("UID") == 0)
                field.setEnabled(false);
            else
                field.setEnabled(editing);
        }
    }
    /**
     * This is called when user clicks on any button
     */
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        if (OK.equals(cmd)) {
            cancelled = false;
            setVisible(false);
        } 
        else if (EDIT.equals(cmd)) {
            toggleEdit();
        } 
        else if (CANCEL.equals(cmd)) {
            cancelled = true;
            setVisible(false);
        } 
        else if (HELP.equals(cmd)) {
            JOptionPane.showMessageDialog(parent, helpString,
                                          "XWHEP help",
                                          JOptionPane.INFORMATION_MESSAGE);
        }
    }

}
