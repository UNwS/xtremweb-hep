/**
 * AppsTableModel.java
 *
 * Purpose : This is the table model to display XtremWeb applications informations
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.common.util;
import xtremweb.common.XWAccessRights;
import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.TableInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.AppInterface;
import xtremweb.common.DataInterface;
import xtremweb.common.XWCPUs;
import xtremweb.common.XWOSes;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JButton;

import java.io.File;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.net.ConnectException;



/**
 * This class defines a swing table model to display XtremWeb informations<br />
 * This displays and manages an src/common/AppInterface object
 */

class AppsTableModel extends TableModel {

    /**
     * These defines submission parameters
     */
    private static final String UIDLABEL = "UID";
    private static final String NAMELABEL = "NAME";
    private static final String ACCESSRIGHTSLABEL = "Access rights";
    //    private static final String OSLABEL = "OS";
    //    private static final String CPULABEL = "CPU";
    private static final String LINUXIX86LABEL  = "Linux ix86";
    private static final String LINUXAMD64LABEL = "Linux AMD 64";
    private static final String LINUXPPCLABEL   = "Linux PPC";
    private static final String MACOSIX86LABEL  = "Mac OS X ix86";
    private static final String MACOSPPCLABEL   = "Mac OS X PPC";
    private static final String WIN32IX86LABEL  = "Win32 ix86";
    private static final String WIN32AMD64LABEL = "Win32 AMD 64";
    private static final String STDINLABEL = "Standard input";
    private static final String DIRINLABEL = "Environment";
    private static final String MEMORYLABEL = "Memory";
    private static final String CPUSPEEDLABEL = "CPU Speed";
    /**
     * These defines submission parameter labels
     */
    private static final String[] labels = {
        UIDLABEL,
        NAMELABEL,
        ACCESSRIGHTSLABEL,
//        OSLABEL,
//        CPULABEL,
        LINUXIX86LABEL,
        LINUXAMD64LABEL,
        LINUXPPCLABEL,
        MACOSIX86LABEL,
        MACOSPPCLABEL,
        WIN32IX86LABEL,
        WIN32AMD64LABEL,
        STDINLABEL,
        DIRINLABEL,
        MEMORYLABEL,
        CPUSPEEDLABEL
    };

    private static final String HELPSTRING = 
        new String("Name should be unic in the platform; reusing an existing name update application\n" +
                   "Select your operating system from OS menu\n" +
                   "Select your CPU type from CPU menu\n" +
                   "Select a binary or enter a valid URI\n" + 
                   "Select an stdin or enter a valid URI\n" + 
                   "Select a dirin or enter a valid URI\n" + 
                   "Enter the minimal RAM requirements\n" + 
                   "Enter the minimal CPU speed requirements\n");
    /**
     * This is the default constructor.
     */
    public AppsTableModel (MainFrame p) {
        this (p, true);
    }


    /**
     * This is a constructor.
     * @param detail tells whether to add a last column to get details
     */
    public AppsTableModel (MainFrame p, boolean detail) {
        super (p, new AppInterface(), detail);
    }
    /**
     * This creates new JButton
     * @return a Vector of JButton
     */
    public Hashtable getButtons() {

        Hashtable ret = super.getButtons();

        ((JButton)(ret.get(ADD_LABEL))).setEnabled(true);
        ((JButton)(ret.get(DEL_LABEL))).setEnabled(true);

        return ret;
    }
    /**
     * This adds an application
     */
    public void add() {
        Vector newRow = new Vector();
        UID newUID = new UID();
        newRow.add(newUID);              // UID
        newRow.add(new String());        // name
        newRow.add(new String(XWAccessRights.DEFAULT.toString())); // access rights
//         newRow.add(XWOSes.getLabels());  // OS
//         newRow.add(XWCPUs.getLabels());  // CPU
        newRow.add(newContainer(Commands.LINUXIX86));// binary
        newRow.add(newContainer(Commands.LINUXAMD64));// binary
        newRow.add(newContainer(Commands.LINUXPPC));// binary
        newRow.add(newContainer(Commands.MACOSIX86));// binary
        newRow.add(newContainer(Commands.MACOSPPC));// binary
        newRow.add(newContainer(Commands.WIN32IX86));// binary
        newRow.add(newContainer(Commands.WIN32AMD64));// binary
        newRow.add(newContainer(Commands.STDIN)); // stdin
        newRow.add(newContainer(Commands.DIRIN)); // dirin
        newRow.add(new String());        // Min memory
        newRow.add(new String());        // Min CPUSpeed

        viewDialog = new ViewDialog(parent, "Add application",
                                    labels, newRow, true);

        JTextField component = (JTextField)viewDialog.fields.get(UIDLABEL);
        component.setEnabled(false);

        viewDialog.helpString = HELPSTRING;
        viewDialog.setVisible(true);

        if(viewDialog.cancelled == true)
            return;

        String appName = (String)((JTextField)viewDialog.fields.get(NAMELABEL)).getText();
        if((appName == null) || (appName.length() == 0)) {
            JOptionPane.showMessageDialog (parent,
                                           "You must specify an application name",
                                           WARNING,
                                           JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            AppInterface app = new AppInterface(newUID);
            app.setName(appName);

//            String os = (String)((JComboBox)viewDialog.fields.get(OSLABEL)).getSelectedItem();
//            String cpu = (String)((JComboBox)viewDialog.fields.get(CPULABEL)).getSelectedItem();
//            JPanel innerPanel = (JPanel)viewDialog.fields.get(BINARYLABEL);
//             JTextField jtf = (JTextField)innerPanel.getComponent(0);
//             app.setBinary(XWCPUs.getCpu(cpu.toUpperCase()), 
//                           XWOSes.valueOf(os.toUpperCase()),
//                           new URI(jtf.getText()));

            JPanel innerPanel = (JPanel)viewDialog.fields.get(LINUXIX86LABEL);
            JTextField jtf = (JTextField)innerPanel.getComponent(0);
            if(jtf.getText().length() > 0) 
                app.setBinary(XWCPUs.IX86,
                              XWOSes.LINUX,
                              new URI(jtf.getText()));

            innerPanel = (JPanel)viewDialog.fields.get(LINUXAMD64LABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            if(jtf.getText().length() > 0) 
                app.setBinary(XWCPUs.AMD64,
                              XWOSes.LINUX,
                              new URI(jtf.getText()));

            innerPanel = (JPanel)viewDialog.fields.get(LINUXPPCLABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            if(jtf.getText().length() > 0) 
                app.setBinary(XWCPUs.PPC,
                              XWOSes.LINUX,
                              new URI(jtf.getText()));

            innerPanel = (JPanel)viewDialog.fields.get(WIN32IX86LABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            if(jtf.getText().length() > 0) 
                app.setBinary(XWCPUs.IX86,
                              XWOSes.WIN32,
                              new URI(jtf.getText()));

            innerPanel = (JPanel)viewDialog.fields.get(WIN32AMD64LABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            if(jtf.getText().length() > 0) 
                app.setBinary(XWCPUs.AMD64,
                              XWOSes.WIN32,
                              new URI(jtf.getText()));

            innerPanel = (JPanel)viewDialog.fields.get(MACOSIX86LABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            if(jtf.getText().length() > 0) 
                app.setBinary(XWCPUs.IX86,
                              XWOSes.MACOSX,
                              new URI(jtf.getText()));

            innerPanel = (JPanel)viewDialog.fields.get(MACOSPPCLABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            if(jtf.getText().length() > 0) 
                app.setBinary(XWCPUs.PPC,
                              XWOSes.MACOSX,
                              new URI(jtf.getText()));

            innerPanel = (JPanel)viewDialog.fields.get(STDINLABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            String str = jtf.getText();
            if((str != null) && (str.length() > 0))
                app.setDefaultStdin(new URI(str));

            innerPanel = (JPanel)viewDialog.fields.get(DIRINLABEL);
            jtf = (JTextField)innerPanel.getComponent(0);
            str = jtf.getText();
            if((str != null) && (str.length() > 0))
                app.setDefaultDirin(new URI(str));

            String minMem = (String)((JTextField)viewDialog.fields.get(MEMORYLABEL)).getText();
            if((minMem != null) && (minMem.length() > 0))
                app.setMinMemory(new Integer(minMem).intValue());

            String minSpeed = (String)((JTextField)viewDialog.fields.get(CPUSPEEDLABEL)).getText();
            if((minSpeed != null) && (minSpeed.length() > 0))
                app.setMinCpuSpeed(new Integer(minSpeed).intValue());

            parent.commClient().send(app);
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            JOptionPane.showMessageDialog (parent,
                                           "An error occured : " + e,
                                           ERROR,
                                           JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * This opens a dialog box to select a row from data table and
     * set binary, stdin, dirin
     */
    public void selectData(Commands id) {

        TableModel tm = new DatasTableModel(parent);
        try {
            parent.setTitleConnected();
            tm.refresh();
        }
        catch(ConnectException e) {
            parent.setTitleNotConnected();
            if(debug())
                e.printStackTrace();
            return;
        }

        DataInterface data = (DataInterface)selectDialogBox(id.getTitle(), tm);

         if(data == null)
             return;

        JPanel innerPanel = null;

        switch(id) {
        case LINUXIX86 :
            innerPanel = (JPanel)viewDialog.fields.get(LINUXIX86LABEL);
            break;
        case LINUXAMD64 :
            innerPanel = (JPanel)viewDialog.fields.get(LINUXAMD64LABEL);
            break;
        case LINUXPPC :
            innerPanel = (JPanel)viewDialog.fields.get(LINUXPPCLABEL);
            break;
        case MACOSIX86 :
            innerPanel = (JPanel)viewDialog.fields.get(MACOSIX86LABEL);
            break;
        case MACOSPPC :
            innerPanel = (JPanel)viewDialog.fields.get(MACOSPPCLABEL);
            break;
        case WIN32IX86 :
            innerPanel = (JPanel)viewDialog.fields.get(WIN32IX86LABEL);
            break;
        case WIN32AMD64 :
            innerPanel = (JPanel)viewDialog.fields.get(WIN32AMD64LABEL);
            break;
        case STDIN :
            innerPanel = (JPanel)viewDialog.fields.get(STDINLABEL);
            break;
        case DIRIN :
            innerPanel = (JPanel)viewDialog.fields.get(DIRINLABEL);
            break;
        }

        if(innerPanel != null) {
            JTextField jtf = (JTextField)innerPanel.getComponent(0);
            jtf.setText(data.getURI().toString());
        }
    }
    /**
     * This views an application
     */
    public void view() {
        super.view("Application viewer");
    }
    /**
     * This replaces UID by human readable columns
     */
    protected Vector getViewableRow(Vector row) {
        Vector clone = (Vector)row.clone();
        try {
            int index = AppInterface.Columns.OWNERUID.ordinal();
            UID uid = (UID)clone.elementAt(index);
            UserInterface user = (UserInterface)parent.commClient().get(uid, false);
            clone.set(index, user.getLogin());
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
        }
        return clone;
    }

    /**
     * This retreives a Vector of application UID from server
     * @return an empty vector on error
     * @see xtremweb.communications.CommAPI#getApps()
     */
    public Vector getRows() throws ConnectException {
        try {
            parent.setTitleConnected();
            return parent.commClient().getApps();
        }
        catch(Exception e) {
            parent.setTitleNotConnected();
            if(debug())
                e.printStackTrace();
            throw new ConnectException(e.toString());
        }
    }

    /**
     * This retreives an application from server
     * @return an AppInterface or null on error
     * @see xtremweb.communications.CommAPI#getApp(UID)
     */
    public TableInterface getRow(UID uid) throws ConnectException{
        try {
            AppInterface app = (AppInterface)super.getRow(uid);
            if(app == null)
                return null;
            //
            // Next forces ISSERVICE attribute to its default value, if not set
            // Otherwise AppInterface#values[ISSERVICE] is null 
            // and JTable generates an exception
            //
            app.isService();

            TableInterface row = (TableInterface)app;

            return row;
        }
        catch(Exception e) {
            if(debug())
                e.printStackTrace();
            return null;
        }
    }


} // class AppsTableModel
