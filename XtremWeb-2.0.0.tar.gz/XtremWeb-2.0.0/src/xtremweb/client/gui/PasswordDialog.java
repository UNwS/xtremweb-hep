/**
 * This defines a modal Dialog to enter server, login and password
 * Created : 18 Avril 2006
 * @author Oleg Lodygensky
 */

package xtremweb.client.gui;

import xtremweb.common.UserInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class PasswordDialog extends JDialog
		implements ActionListener {
    private static String OK = "Ok";
    private static String CANCEL = "Cancel";
    private static String HELP = "Help";

    private JFrame parent;
    public JPasswordField password;
    public JPasswordField password2;
		public boolean cancelled;

		/**
		 * This constructor does everything
		 */
    public PasswordDialog(JFrame f, String login) {

				super(f, "XWHEP login", true);

				cancelled = true;

        //Use the default FlowLayout.
        parent = f;

				// login field
        JLabel jlogin = new JLabel(login);
				jlogin.setForeground(Color.red);
        JLabel lLabel = new JLabel("Login : ");
				lLabel.setForeground(Color.red);

				// password field
        password = new JPasswordField(10);
        password.setEchoChar('#');
        password.setActionCommand(OK);
        password.addActionListener(this);

        JLabel pLabel = new JLabel("New password : ");
        pLabel.setLabelFor(password);

				// password2 field
        password2 = new JPasswordField(10);
        password2.setEchoChar('#');
        password2.setActionCommand(OK);
        password2.addActionListener(this);

        JLabel pLabel2 = new JLabel("Retype new password : ");
        pLabel2.setLabelFor(password2);

        JButton okButton = new JButton(OK);
        JButton cancelButton = new JButton(CANCEL);
        JButton helpButton = new JButton(HELP);

        okButton.setActionCommand(OK);
        cancelButton.setActionCommand(CANCEL);
        helpButton.setActionCommand(HELP);
        okButton.addActionListener(this);
        cancelButton.addActionListener(this);
        helpButton.addActionListener(this);


				JPanel textPane = new JPanel(new GridLayout(5,2));
        textPane.add(lLabel);
        textPane.add(jlogin);
        textPane.add(pLabel);
        textPane.add(password);
        textPane.add(pLabel2);
        textPane.add(password2);

        textPane.add(okButton);
        textPane.add(cancelButton);
        textPane.add(helpButton);

        getContentPane().add(textPane);
				//				getContentPane().add(buttonPane);
        pack();
				setSize(400,150);
    }

    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        if (OK.equals(cmd)) {
						cancelled = false;
            setVisible(false);
        }
        else if (CANCEL.equals(cmd)) {
						cancelled = true;
            setVisible(false);
        } 
				else {
            JOptionPane.showMessageDialog(parent,
																					"You must enter password twice to avoid errors");
        }
    }

}
