/**
 * HostsTableModel.java
 *
 * Purpose : This is the table model to display XtremWeb workers informations
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.TableInterface;
import xtremweb.common.HostInterface;
import xtremweb.common.UserInterface;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.util.Hashtable;
import java.util.Vector;
import java.net.ConnectException;



/**
 * This class defines a swing table model to display XtremWeb informations<br />
 * This displays and manages an src/common/HostInterface object
 */

class HostsTableModel extends TableModel {

    /**
     * This is the activate button label, alos used as key in hashtable
     */
    protected final String ACTIVATE_LABEL = "Activate";
    /**
     * This is the activate button
     */
    JButton activateButton;
    /**
     * This is the default constructor.
     */
    public HostsTableModel (MainFrame p) {
        this (p, true);
    }


    /**
     * This is a constructor.
     * @param detail tells whether to add a last column to get details
     */
    public HostsTableModel (MainFrame p, boolean detail) {
        super (p, new HostInterface(), detail);
        activateButton = null;
    }


    /**
     * This creates new JButton
     * @return a Vector of JButton
     */
    public Hashtable getButtons() {

        Hashtable ret = super.getButtons();

        if(activateButton == null) {
            activateButton = new JButton(ACTIVATE_LABEL);
            activateButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        activate();
                    }
                });
            activateButton.setEnabled(parent.privileged());
        }

        ret.put(ACTIVATE_LABEL, activateButton);

        ret.remove(ADD_LABEL);

        return ret;
    }

    /**
     * This adds a host
     */
    public void add() {
        System.out.println("host add is not implemented");
    }

    /**
     * This views a host
     */
    public void view() {
        super.view("Host viewer",
                   "ACTIVE flag is set on server side: only ACTIVE workers may receive jobs\n" +
                   "AVAILABLE flas is set by the worker itself, accordingly to its local policy (mouse/keyboard...)");
    }
    /**
     * This replaces UID by human readable columns
     */
    protected Vector getViewableRow(Vector row) {
        Vector clone = (Vector)row.clone();
        try {
            int index = HostInterface.Columns.OWNERUID.ordinal();
            UID uid = (UID)clone.elementAt(index);
            UserInterface user = (UserInterface)parent.commClient().get(uid, false);
            clone.set(index, user.getLogin());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return clone;
    }

    /**
     * This de/activates a host
     */
    public void activate() {
        System.out.println("host activate is not implemented");
    }

    /**
     * This retreives a Vector of worker UID from server
     * @return an empty vector on error
     * @see xtremweb.communications.CommAPI#getHosts()
     */
    public Vector getRows() throws ConnectException {
        try{
            parent.setTitleConnected();
            return parent.commClient().getHosts();
        }
        catch(Exception e) {
             parent.setTitleNotConnected();
             if(debug())
                 e.printStackTrace();
             throw new ConnectException(e.toString());            
        }
    }

    /**
     * This retreives an host from server
     * @return an HostInterface or null on error
     * @see xtremweb.communications.CommAPI#getWorker(UID)
     */
    public TableInterface getRow(UID uid) throws ConnectException{
        try {
            parent.setTitleConnected();
            HostInterface host = (HostInterface)parent.commClient().get(uid);
            if(host == null)
                return null;
            //
            // Next forces boolean attributes to their default value, if not set
            // Otherwise HostInterface#values[] are null 
            // and JTable generates an exception
            //
            host.isTracing();
            host.isActive();
            host.isAvailable();

            return (TableInterface)host;
        }
        catch(Exception e) {
             parent.setTitleNotConnected();
             if(debug())
                 e.printStackTrace();
             throw new ConnectException(e.toString());            
        }
    }

    /**
     * This called when Commit button is clicked; it sends all hosts informations
     * to XW server.
     */
    public void onCommitClicked () {

        HostInterface.Columns column = HostInterface.Columns.TRACES;
        Hashtable tracerHosts    = new Hashtable ();
        Hashtable activatedHosts = new Hashtable ();

        for (int row = 0; row < getRowCount(); row++) {

            String hostName =  (String)getValueAt(row, 
                                                  HostInterface.Columns.NAME.ordinal());
            Boolean trace   = (Boolean)getValueAt(row,
                                                  HostInterface.Columns.TRACES.ordinal());
            Boolean active  = (Boolean)getValueAt (row,
                                                   HostInterface.Columns.ACTIVE.ordinal());

            activatedHosts.put (hostName, active);
            tracerHosts.put (hostName, trace);

        } // for (all rows)

        try {
            //						if (parent.traceWorkers (tracerHosts) == false)
            System.err.println("traceWorkers() error");
        }
        catch (Exception e) {
            System.err.println("traceWorkers() " + e);
        }

        try {
            //if (parent.activateWorkers (activatedHosts) == false)
            System.err.println("activateWorkers() error");
        }
        catch (Exception e) {
            System.err.println("activateWorkers() " + e);
        }

    } // onCommitClicked ()


} // class HostsTableModel
