/**
 * MainPanel.java
 *
 * Purpose : XtremWeb main GUI panel
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.common.util;
import xtremweb.common.Loggerable;
import xtremweb.common.LoggerLevel;

import java.util.Locale;
import java.util.Date;
import java.text.SimpleDateFormat;

import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.GridLayout;
import java.awt.Dimension;
import java.net.ConnectException;
import java.lang.System;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;



/**
 * This class describes the XtremWeb client swing panel.
 */

public class MainPanel extends JPanel implements Loggerable {

    protected LoggerLevel level;

    public LoggerLevel getLoggerLevel() {
        return level;
    }

    /**
     * This helps to format date : the format is "yyyy-MM-dd HH:mm:ss"
     */
    public  final SimpleDateFormat logDateFormat = new SimpleDateFormat("[dd/MMM/yyyy:HH:mm:ss Z]", Locale.US);
    
    /**
     * This logs out a message
     */
    public void printLog(String msg) {
        System.out.println (logDateFormat.format(new Date()) +
                            " [" +  this.getClass().getName() + "] " + 
                            level + " : " + msg);
    }

    /**
     * This tells whether debug level is set to DEBUG
     * @return true if debug level is set to DEBUG
     */
    public  boolean debug() {
        return (level.ordinal() <= LoggerLevel.DEBUG.ordinal());
    }
    /**
     * This logs out a DEBUG message
     */
    public  void debug(String msg) {
        if (debug())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to INFO
     * @return true if debug level is set to INFO
     */
    public  boolean info() {
        return (level.ordinal() <= LoggerLevel.INFO.ordinal());
    }
    /**
     * This logs out an INFO message
     */
    public  void info(String msg) {
        if (info())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to WARN
     * @return true if debug level is set to WARN
     */
    public  boolean warn() {
        return (level.ordinal() <= LoggerLevel.WARN.ordinal());
    }
    /**
     * This logs out a WARN message
     */
    public  void warn (String msg) {
        if (warn())
            printLog(msg);
    }
    /**
     * This tells whether debug level is set to ERROR
     * @return true if debug level is set to ERROR
     */
    public  boolean error() {
        return (level.ordinal() <= LoggerLevel.ERROR.ordinal());
    }
    /**
     * This logs out an ERROR message
     */
    public  void error(String msg) {
        if(error())
            printLog(msg);
    }

    /**
     * This defines tabs order
     * Tab must be inserted in this order
     */
    public enum Tabs {
        JOBS,
        DATAS,
        APPS,
        USERS,
        USERGROUPS,
        HOSTS,
        WORKS,
        TASKS
    }

    /**
     * This sets the logger level.
     * This also sets the logger levels checkboxes menu item.
     */
    public void setLoggerLevel(LoggerLevel l) {
        jobsTableModel.setLoggerLevel(l);
        appsTableModel.setLoggerLevel(l);
        datasTableModel.setLoggerLevel(l);
        usersTableModel.setLoggerLevel(l);
        usergroupsTableModel.setLoggerLevel(l);
        hostsTableModel.setLoggerLevel(l);
        tasksTableModel.setLoggerLevel(l);
        worksTableModel.setLoggerLevel(l);
    }
    /**
     * This is the parent frame
     */
    private MainFrame parent;

    /**
     * This is the tabbed pane containing all panes
     */
    public JTabbedPane tabbedPane;

    /**
     * This is the jobs table model
     */
    private JobsTableModel jobsTableModel;
    /**
     * This is the apps table model
     */
    public AppsTableModel appsTableModel;
    /**
     * This is the datas table model
     */
    public DatasTableModel datasTableModel;
    /**
     * This is the users table model
     */
    private UsersTableModel usersTableModel;
    /**
     * This is the user groups table model
     */
    private UsergroupsTableModel usergroupsTableModel;
    /**
     * This is the hosts table model
     */
    private HostsTableModel hostsTableModel;
    /**
     * This is the works table model
     */
    private WorksTableModel worksTableModel;
    /**
     * This is the tasks table model
     */
    private TasksTableModel tasksTableModel;

    /**
     * This is the tasks pane
     */
    private TablePanel tasksPanel;
    /**
     * This tells whether task pane is shown
     */
    private boolean viewTasks;
    /**
     * This is the works pane
     */
    private TablePanel worksPanel;
    /**
     * This tells whether works pane is shown
     */
    private boolean viewWorks;

    /**
     * This constructor inserts needed panels in a new tabbed pane
     */
    public MainPanel (MainFrame p) {

        parent = p;

        tabbedPane = new JTabbedPane();

        try {
            //				tabbedPane.addTab("Params", new ParamsPanel());
            jobsTableModel = new JobsTableModel(parent);
            datasTableModel = new DatasTableModel (parent);
            appsTableModel = new AppsTableModel (parent);
            usersTableModel = new UsersTableModel(parent);
            usergroupsTableModel = new UsergroupsTableModel(parent);
            hostsTableModel = new HostsTableModel(parent);
            tasksTableModel = new TasksTableModel(parent);
            worksTableModel = new WorksTableModel(parent);

            tabbedPane.addTab("Jobs",  new TablePanel(jobsTableModel));
            tabbedPane.setMnemonicAt(Tabs.JOBS.ordinal(), KeyEvent.VK_J);
            tabbedPane.addTab("Datas", new TablePanel(datasTableModel));
            tabbedPane.setMnemonicAt(Tabs.DATAS.ordinal(), KeyEvent.VK_T);
            tabbedPane.addTab("Apps",  new TablePanel(appsTableModel));
            tabbedPane.setMnemonicAt(Tabs.APPS.ordinal(), KeyEvent.VK_P);
            tabbedPane.addTab("Users", new TablePanel(usersTableModel));
            tabbedPane.setMnemonicAt(Tabs.USERS.ordinal(), KeyEvent.VK_U);
            tabbedPane.addTab("Usergroups", new TablePanel(usergroupsTableModel));
            tabbedPane.setMnemonicAt(Tabs.USERGROUPS.ordinal(), KeyEvent.VK_G);
            tabbedPane.addTab("Hosts", new TablePanel(hostsTableModel));
            tabbedPane.setMnemonicAt(Tabs.HOSTS.ordinal(), KeyEvent.VK_H);

            tasksPanel = new TablePanel(tasksTableModel);
            viewTasks = false;
            worksPanel = new TablePanel(worksTableModel);
            viewWorks = false;

            tabbedPane.addChangeListener(new ChangeListener() {
                    // This method is called whenever the selected tab changes
                    public void stateChanged(ChangeEvent evt) {
                        JTabbedPane pane = (JTabbedPane)evt.getSource();
                        TablePanel tab = (TablePanel)pane.getSelectedComponent();
                        parent.setTotalLines(tab.getRowCount());
                        parent.setSelectedLines(tab.getTable().getSelectedRows().length);
                    }
                });
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }


        ///////////////////////////////////////////////////////////////////////
        // Done :)
        ///////////////////////////////////////////////////////////////////////
        tabbedPane.setSelectedIndex(0);

        //
        // Add the tabbed pane to this panel.
        //
        setLayout (new GridLayout (1, 1));
        add(tabbedPane);

        setMinimumSize (new Dimension (500, 450));

        setLoggerLevel(parent.getLoggerLevel());

    } // MainPanel()

    /**
     * This refreshes display; this is especially used on reconnection
     */
//     public void refresh() throws ConnectException{

//         for(int tabs = 0; tabs < tabbedPane.getTabCount(); tabs++) {
//             TablePanel tb = (TablePanel)tabbedPane.getComponentAt(tabs);
//             // retreive datas from server
//             tb.refresh();
//         }
//     }

    /**
     * This reset lists; this is used on reconnection
     */
    public void reset() {
        jobsTableModel.reset();
        appsTableModel.reset();
        datasTableModel.reset();
        usersTableModel.reset();
        usergroupsTableModel.reset();
        hostsTableModel.reset();
        tasksTableModel.reset();
        worksTableModel.reset();
    }
    /**
     * This reset job list; this is used on reconnection
     */
    public void resetJobList() {
        jobsTableModel.reset();				
    }
    /**
     * This enables/disables button accordingly to user rights.
     * This is used on reconnection
     */
    public void enableButtons() {
        jobsTableModel.getButtons();
        datasTableModel.getButtons();
        appsTableModel.getButtons();
        usersTableModel.getButtons();
        usergroupsTableModel.getButtons();
        hostsTableModel.getButtons();
        tasksTableModel.getButtons();
        worksTableModel.getButtons();
    }

    /**
     * This shows/hides tasks pane
     */
    public boolean toggleTasks() {
        if(viewTasks == false) {
            tabbedPane.addTab("Tasks", tasksPanel);
            viewTasks = true;
        }
        else {
            tabbedPane.remove(tasksPanel);
            viewTasks = false;
        }
        return viewTasks;
    }
    /**
     * This shows/hides works pane
     */
    public boolean toggleWorks() {
        if(viewWorks == false) {
            tabbedPane.addTab("Works", worksPanel);
            viewWorks = true;
        }
        else {
            tabbedPane.remove(worksPanel);
            viewWorks = false;
        }
        return viewWorks;
    }


} // class MainPanel
