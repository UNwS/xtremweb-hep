/**
 * UsergroupsTableModel.java
 *
 * Purpose : This is the table model to display XtremWeb users informations
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.common.UID;
import xtremweb.common.util;
import xtremweb.common.TableInterface;
import xtremweb.common.UserGroupInterface;


import java.io.IOException;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import javax.swing.event.TableModelEvent;
import java.net.ConnectException;




/**
 * This class defines a swing table model to display XtremWeb informations<br />
 * This displays and manages an src/common/UserInterface object
 */

class UsergroupsTableModel extends TableModel {

    /**
     * These defines submission parameters
     */
    private static final String UID = "UID";
    private static final String LABEL = "Label";
    /**
     * These defines submission parameter labels
     */
    private static final String[] labels = {
        UID,
        LABEL
    };

    /**
     * This is the default constructor.
     */
    public UsergroupsTableModel (MainFrame p) throws IOException{
        this (p, true);
    }


    /**
     * This is a constructor.
     * @param detail tells whether to add a last column to get details
     */
    public UsergroupsTableModel (MainFrame p, boolean detail) throws IOException{
        super (p, new UserGroupInterface(), detail);
    }


    /**
     * This adds an user group
     */
    public void add() {
        Vector newRow = new Vector();
        UID uid = new UID();
        newRow.add(uid);            // UID
        newRow.add(new String());   // label

        ViewDialog dlg = new ViewDialog(parent, "Create new user group",
                                        labels, newRow, true);

        JTextField component = (JTextField)dlg.fields.get(UID);
        component.setEnabled(false);

        dlg.helpString = "LABEL is free";
        dlg.setVisible(true);

        if(dlg.cancelled == true) {
            return;
        }

        try {
            UserGroupInterface group = new UserGroupInterface(uid);
            JTextField jtf = (JTextField)dlg.fields.get(LABEL);
            group.setLabel((String)jtf.getText());

            if(group.getLabel().length() < 1) {
                JOptionPane.showMessageDialog (parent,
                                               "You must specify a label",
                                               WARNING,
                                               JOptionPane.WARNING_MESSAGE);
                return;
            }

            parent.commClient().send(group);
//             rows.addElement(group.toVector());
//             parent.incTotalLines();
        }
        catch(Exception e) {
            e.printStackTrace();
        }

//        refresh();
    }

    /**
     * This views an user
     */
    public void view() {
        super.view("User group viewer");
    }

    /**
     * This retreives a Vector of user group UID from server
     * @see xtremweb.communications.CommAPI#getUsers()
     */
    public Vector getRows() throws ConnectException{
        try {
            parent.setTitleConnected();
            return parent.commClient().getUserGroups();
        }
        catch(Exception e) {
             parent.setTitleNotConnected();
             if(debug())
                 e.printStackTrace();
             throw new ConnectException(e.toString());            
        }
    }
    /**
     * This creates a new ViewDialog to display row details
     * @param title is the dialog title
     * @param selectedRow is the row to edit/display
     * @param editable enables/disables edition
     * @return a new ViewDialog
     */
    protected ViewDialog getViewDialog(String title, int selectedRow, boolean editable) {
        return (ViewDialog)new UserDialog(parent, title,
                                          itf.columns(),
                                          (Vector)rows.elementAt(selectedRow),
                                          editable);
    }
} // class UsergroupsTableModel
