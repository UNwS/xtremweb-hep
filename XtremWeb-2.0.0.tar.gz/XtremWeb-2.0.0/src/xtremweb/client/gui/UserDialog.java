/**
 * This defines a modal Dialog to enter server, login and password
 */

package xtremweb.client.gui;

import xtremweb.common.*;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class UserDialog extends ViewDialog
		implements ActionListener {

    private static String PASSWORD = "Change password";

		/**
		 * This constructor does everything
		 * @param f is the aprent JFrame
		 * @param title is the dialog title
		 * @param columns is a String array containing columns name
		 * @param row is a Vector containing the selected row
		 * @param editable enables/disables edition
		 */
    public UserDialog(JFrame f, String title, 
											String[] columns, Vector row, boolean editable) {

				super(f, title, columns, row, editable);

        JButton passwordButton = new JButton(PASSWORD);

        passwordButton.setActionCommand(PASSWORD);
        passwordButton.addActionListener(this);

        textPane.add(passwordButton);

        pack();
				//				setSize(600, (columns.length) * 30);
    }

    public void actionPerformed(ActionEvent e) {

				super.actionPerformed(e);
				if(isVisible() == false)
						return;

        String cmd = e.getActionCommand();

        if (PASSWORD.equals(cmd)) {
						JTextField jlogin = (JTextField)fields.get("LOGIN");
						PasswordDialog dlgPassword = new PasswordDialog(parent, 
																														jlogin.getText());
						dlgPassword.setVisible(true);
        } 
    }

}
