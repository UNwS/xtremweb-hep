/**
 * DatasTableModel.java
 *
 * Purpose : This is the table model to display XtremWeb datas informations
 * Created : 18 Avril 2006
 *
 * @author <a href="mailto:lodygens /at\ lal.in2p3.fr>Oleg Lodygensky</a>
 * @version %I%, %G%
 */

package xtremweb.client.gui;

import xtremweb.common.util;
import xtremweb.common.XWStatus;
import xtremweb.common.MD5;
import xtremweb.common.XWAccessRights;
import xtremweb.common.UID;
import xtremweb.common.URI;
import xtremweb.common.DataInterface;
import xtremweb.common.UserInterface;
import xtremweb.common.TableInterface;
import xtremweb.common.XWOSes;
import xtremweb.common.XWCPUs;
import xtremweb.common.DataType;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.Cursor;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JFileChooser;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.net.ConnectException;

import java.io.File;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;



/**
 * This class defines a swing table model to display XtremWeb informations<br />
 * This displays and manages an src/common/DataInterface object
 */

class DatasTableModel extends TableModel {

    /**
     * These defines submission parameters
     */
    private static final String UIDLABEL = "UID";
    private static final String SIZELABEL = "Length";
    private static final String MD5LABEL = "MD5";
    private static final String NAMELABEL = "Name";
    private static final String ACCESSRIGHTSLABEL = "Access rights";
    private static final String TYPELABEL = "Type";
    private static final String OSLABEL = "OS";
    private static final String CPULABEL = "CPU";
    private static final String BINARYLABEL = "BINARY";
    /**
     * These defines submission parameter labels
     */
    private static final String[] labels = {
        UIDLABEL,
        NAMELABEL,
        ACCESSRIGHTSLABEL,
        TYPELABEL,
        OSLABEL,
        CPULABEL,
        SIZELABEL,
        MD5LABEL,
        BINARYLABEL
    };

    /**
     * This is the activate button label, alos used as key in hashtable
     */
    protected final String DOWNLOAD_LABEL = "Download";

    /**
     * This is the dialog used to add data
     */
    ViewDialog dlg;
    /**
     * This stores new UID when adding data
     */
    UID newUID;
    /**
     * This is the button to select the data binary file
     */
    private JTextField binURI;
    /**
     * This is the data binary file
     */
    private File binFile;
    /**
     * This is the current directory.
     * This is used to (re)open file choosers at the last directory
     */
    private File currentDir;

    /**
     * This is the default constructor.
     */
    public DatasTableModel (MainFrame p) {
        this (p, true);
    }
    /**
     * This is a constructor.
     * @param detail tells whether to add a last column to get details
     */
    public DatasTableModel (MainFrame p, boolean detail) {
        super (p, new DataInterface(), detail);
        dlg = null;
    }
    /**
     * This creates new JButton
     * @return a Vector of JButton
     */
    public Hashtable getButtons() {

        Hashtable ret = super.getButtons();

        ((JButton)(ret.get(ADD_LABEL))).setEnabled(true);
        ((JButton)(ret.get(DEL_LABEL))).setEnabled(true);

        JButton downloadButton = new JButton(DOWNLOAD_LABEL);
        downloadButton.setMnemonic(KeyEvent.VK_D);
        downloadButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    download();
                }
            });

        downloadButton.setEnabled(true);
        ret.put(DOWNLOAD_LABEL, downloadButton);

        return ret;
    }
    /**
     * This adds an data
     */
    public void add() {
        Vector newRow = new Vector();
        newUID = new UID();
        newRow.add(newUID);
        newRow.add(new String());       // name
        newRow.add(new String(XWAccessRights.DEFAULT.toString()));       // access rights
        newRow.add(DataType.getLabels()); // type
        newRow.add(XWOSes.getLabels()); // OS
        newRow.add(XWCPUs.getLabels()); // CPU

        JTextField field = new JTextField();  // SIZE
        field.setEnabled(false);
        newRow.add(field);

        field = new JTextField();             // MD5
        field.setEnabled(false);
        newRow.add(field);

        JButton binButton = new JButton("...");
        binButton.setMaximumSize(new Dimension(40,10));
        binButton.setPreferredSize(new Dimension(40,10));
        binButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    selectBin();
                }
            });

        binURI = new JTextField();

        JPanel container = new JPanel(new GridBagLayout());
        GridBagLayout gbLayout = (GridBagLayout)container.getLayout ();
        GridBagConstraints gbConstraints = new GridBagConstraints();
        gbConstraints.anchor = GridBagConstraints.CENTER;
        gbConstraints.fill = GridBagConstraints.BOTH;
        gbConstraints.gridx = GridBagConstraints.RELATIVE;
        gbConstraints.gridy = GridBagConstraints.RELATIVE;
        gbConstraints.weightx = 1.0;
        gbConstraints.weighty = 0.0;
        container.add(binURI);
        container.add(binButton);
        gbLayout.setConstraints (binURI, gbConstraints);
        gbLayout.setConstraints (container, gbConstraints);
        gbConstraints.weightx = 0.0;
        gbLayout.setConstraints (binButton, gbConstraints);
        newRow.add(container);

        dlg = new ViewDialog(parent, "Add data",
                             labels, newRow, true);

        JTextField component = (JTextField)dlg.fields.get(UIDLABEL);
        component.setEnabled(false);

        dlg.helpString = "NAME should be unic in the platform; reusing an existing name updates data\n" +
            "Select data type from Type menu\n" +
            "Select data operating system from OS menu\n" +
            "Select data CPU type from CPU menu\n" +
            "Select a binary from local file system, or enter any valid URI\n";
        dlg.setVisible(true);

        if(dlg.cancelled == true) {
            binFile = null;
            return;
        }

        String dataName = (String)((JTextField)dlg.fields.get(NAMELABEL)).getText();
        if((dataName == null) || (dataName.length() == 0)) {
            JOptionPane.showMessageDialog (parent,
                                           "You must specify an data name",
                                           WARNING,
                                           JOptionPane.WARNING_MESSAGE);
            binFile = null;
            return;
        }
        String accessRights = (String)((JTextField)dlg.fields.get(ACCESSRIGHTSLABEL)).getText();
        String md5Value = (String)((JTextField)dlg.fields.get(MD5LABEL)).getText();
        String sizeValue = (String)((JTextField)dlg.fields.get(SIZELABEL)).getText();
        String type = (String)((JComboBox)dlg.fields.get(TYPELABEL)).getSelectedItem();
        String os = (String)((JComboBox)dlg.fields.get(OSLABEL)).getSelectedItem();
        String cpu = (String)((JComboBox)dlg.fields.get(CPULABEL)).getSelectedItem();
        JPanel filePanel = (JPanel)dlg.fields.get(BINARYLABEL);
        JTextField jtf = (JTextField)filePanel.getComponent(0);
        String fileName = jtf.getText();

        try {
            DataInterface data = new DataInterface(newUID);
            data.setName(dataName);
            data.setMD5(md5Value);
            if((sizeValue != null) && (sizeValue.length() > 0))
                data.setSize(new Long(sizeValue).longValue());
            data.setAccessRights(new XWAccessRights(accessRights));
            data.setType(DataType.valueOf(type.toUpperCase()));
            data.setCpu(XWCPUs.valueOf(cpu.toUpperCase()));
            data.setOs(XWOSes.valueOf(os.toUpperCase()));

            try {
                if(binFile == null)
                    data.setStatus(XWStatus.AVAILABLE);
                else {
                    if(binFile.exists() == true) {
                        data.setStatus(XWStatus.UNAVAILABLE);
                    }
                    else {
                        JOptionPane.showMessageDialog (parent,
                                                       "File not found",
                                                       WARNING,
                                                       JOptionPane.WARNING_MESSAGE);
                        binFile = null;
                        return;
                    }
                }

                parent.commClient().send(data);
                boolean success = false;
                while(!success) {
                    try {
                        parent.commClient().get(data.getUID());
                        success = true;
                    }
                    catch(Exception e) {
                        try{
                            Thread.sleep(50);
                        }
                        catch(Exception s) {
                        }
                        // data not ready yet
                    }
                }
                if(binFile != null) {
                    parent.commClient().uploadData(data.getUID(), binFile);
                }
            }
            catch(Exception e) {
                if(debug())
                    e.printStackTrace();
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        binFile = null;
    }

    /**
     * This opens a file chooser dialog to select stdin
     */
    public void selectBin() {
        JFileChooser fc = new JFileChooser();

        if(currentDir != null)
            fc.setCurrentDirectory(currentDir);

        fc.showOpenDialog(parent);

        if(fc.getCurrentDirectory() != null)
            currentDir = fc.getCurrentDirectory();

        binFile = fc.getSelectedFile();

        if(binFile != null) {
            binURI.setText(binFile.getName());
            try {
                ((JTextField)dlg.fields.get(MD5LABEL)).setText(MD5.asHex(MD5.getHash(binFile)));
                ((JTextField)dlg.fields.get(SIZELABEL)).setText("" + binFile.length());
            }
            catch(Exception e) {
            }
        }
        else {
            ((JTextField)dlg.fields.get(MD5LABEL)).setText("");
            ((JTextField)dlg.fields.get(SIZELABEL)).setText("");
            binURI.setText("");
        }
    }
    /**
     * This views an data
     */
    public void view() {
        super.view("Data viewer");
    }
    /**
     * This replaces UID by human readable columns
     */
    protected Vector getViewableRow(Vector row) {
        Vector clone = (Vector)row.clone();
        try {
            int index = DataInterface.Columns.OWNERUID.ordinal();
            UID uid = (UID)clone.elementAt(index);
            UserInterface user = (UserInterface)parent.commClient().get(uid, false);
            clone.set(index, user.getLogin());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return clone;
    }

    /**
     * This retreives a Vector of data UID from server
     * @return an empty vector on error
     * @see xtremweb.communications.CommAPI#getDatas()
     */
    public Vector getRows() throws ConnectException {
        try {
            parent.setTitleConnected();
            return parent.commClient().getDatas();
        }
        catch(Exception e) {
            parent.setTitleNotConnected();
            if(debug())
                e.printStackTrace();
            throw new ConnectException(e.toString());            
        }
    }

    /**
     * This downloads data content
     * @see xtremweb.client.Client#result()
     */
    public void download() {

        int[] selectedRows = jTable.getSelectedRows();
        int selection = selectedRows.length;
        if(selection == 0) {
            JOptionPane.showMessageDialog (parent,
                                           "No row selected!",
                                           WARNING,
                                           JOptionPane.WARNING_MESSAGE);
            return;
        }
				
        int confirm = JOptionPane.showConfirmDialog(parent,
                                                    "Do you want to download " +
                                                    selection + " data(s) ?");
        if(confirm != 0)
            return;

        JFileChooser fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if(currentDir != null)
            fc.setCurrentDirectory(currentDir);

        confirm  = fc.showOpenDialog(parent);

        currentDir = fc.getSelectedFile();

        debug("download currentDir = " + currentDir);
        debug("download filename   = " + fc.getName());

        if((confirm == JFileChooser.CANCEL_OPTION) && (currentDir == null))
            return;

        debug("download currentDir = " + currentDir);

        parent.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

        int downloaded = 0;

        for(int i = 0; i < selection; i ++) {
            int selectedRow = getSelectedRowIndex(selectedRows[i]);
            Vector row = getSelectedRow(selectedRow);

            try {
                UID dataUid = (UID)row.elementAt(DataInterface.Columns.UID.ordinal());
                String dataName = (String)row.elementAt(DataInterface.Columns.NAME.ordinal());
                DataInterface data = (DataInterface)parent.commClient().get(dataUid);
                if(data == null)
                    continue;

                String fext = "";
                if(data.getType() != null)
                    fext = data.getType().getFileExtension();

                File fdata = null;
                if(dataName != null)
                    fdata = new File(currentDir, dataUid.toString() +
                                     "_" + dataName + fext);
                else
                    fdata = new File(currentDir, dataUid.toString() + fext);
                parent.commClient().downloadData(dataUid, fdata);
                downloaded++;    
            }
            catch(Exception e) {
            }
        }

        parent.setCursor(null);

        JOptionPane.showMessageDialog (parent,
                                       "" + downloaded + " downloaded data(s)\n" + 
                                       "Datas are stored in " + currentDir,
                                       INFO,
                                       JOptionPane.INFORMATION_MESSAGE);
    }

} // class DatasTableModel
