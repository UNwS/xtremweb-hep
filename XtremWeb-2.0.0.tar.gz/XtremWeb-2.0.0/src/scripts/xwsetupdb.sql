--
-- Version : XWHEP 1.0.25
--
-- File    : xwsetupdb.sql
-- Purpose : this file contains the needed SQL commands to 
--           create the XWHEP database
-- Usage   : this is used by xtremweb.database
--

--
-- you must uncomment the two next commands and set the appropriate
-- database name

   CREATE DATABASE IF NOT EXISTS xtremweb;

--   connect xtremweb;

--
-- CREATE DATABASE IF NOT EXISTS ;
-- CONNECT ;
--

--
-- please don't forget to look at the end of this file
-- to set your xtremweb database user privileges
--

        CREATE TABLE IF NOT EXISTS xtremweb.apps (
-- primay key
        uid char(50) NOT NULL,
-- optionnal; user UID
        ownerUID char(50),
-- secondary key
        name char(100),
-- optionnal; true is app is a service
        isService char(5) DEFAULT 'false',
-- see common/XWAccessRights.java
        accessRights int(4) DEFAULT 0x755,
-- average execution time; updated on work completion
        avgExecTime int(15),
-- optionnal ; minimum memory need
        minMemory int(10),
-- optionnal ; minimum CPU speed need
        minCPUSpeed int(10),
-- jobs counter; updated on work completion
        nbJobs int(15),
-- optionnal ; this is the default STDIN, if any; this is an URI
-- If set, this is automatically provided to any job, except if job defines its own STDIN
-- works.stdin may be set to NULLUID to force no STDIN even if this apps.stdin is defined
        defaultStdinURI char(200),
-- optionnal ; this is the base environments, if any; this is an URI
-- If set, this is automatically provided to any job
        baseDirinURI char(200),
-- optionnal ; this is the default environment, if any; this is an URI
-- If set, this is automatically provided to any job, except if job defines its own DIRIN
-- works.dirin may be set to NULLUID to force no DIRIN even if this apps.dirin is defined
        defaultDirinURI char(200),
-- optionnal ; this is the linux    ix86  binary, if any; this is an URI
        linux_ix86URI char(200),
-- optionnal ; this is the linux    amd64 binary, if any; this is an URI
        linux_amd64URI char(200),
-- optionnal ; this is the linux    ppc   binary, if any; this is an URI
        linux_ppcURI char(200),
-- optionnal ; this is the mac os x ix86  binary, if any; this is an URI
        macos_ix86URI char(200),
-- optionnal ; this is the mac os x ppc   binary, if any; this is an URI
        macos_ppcURI char(200),
-- optionnal ; this is the win32    ix86  binary, if any; this is an URI
        win32_ix86URI char(200),
-- optionnal ; this is the win32    amd64 binary, if any; this is an URI
        win32_amd64URI char(200),
-- optionnal ; this is the java           binary, if any; this is an URI
        javaURI char(200),
-- optionnal ; this is the osf1     alpha binary, if any; this is an URI
        osf1_alphaURI char(200),
-- optionnal ; this is the osf1     sparc binary, if any; this is an URI
        osf1_sparcURI char(200),
-- optionnal ; this is the solaris  alpha binary, if any; this is an URI
        solaris_alphaURI char(200),
-- optionnal ; this is the solaris  sparc binary, if any; this is an URI
        solaris_sparcURI char(200),
-- optionnal ; this is the linux    ix86  library, if any; this is an URI
        ldlinux_ix86URI char(200),
-- optionnal ; this is the linux    amd64 library, if any; this is an URI
        ldlinux_amd64URI char(200),
-- optionnal ; this is the linux    ppc   library, if any; this is an URI
        ldlinux_ppcURI char(200),
-- optionnal ; this is the mac os x ix86  library, if any; this is an URI
        ldmacos_ix86URI char(200),
-- optionnal ; this is the mac os x ppc   library, if any; this is an URI
        ldmacos_ppcURI char(200),
-- optionnal ; this is the win32    ix86  library, if any; this is an URI
        ldwin32_ix86URI char(200),
-- optionnal ; this is the win32    amd64 library, if any; this is an URI
        ldwin32_amd64URI char(200),
-- optionnal ; this is the osf1     alpha library, if any; this is an URI
        ldosf1_alphaURI char(200),
-- optionnal ; this is the osf1     sparc library, if any; this is an URI
        ldosf1_sparcURI char(200),
-- optionnal ; this is the solaris  alpha library, if any; this is an URI
        ldsolaris_alphaURI char(200),
-- optionnal ; this is the solaris  sparc library, if any; this is an URI
        ldsolaris_sparcURI char(200),

-- true is this row has been deleted
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid),
        CONSTRAINT UNIQUE INDEX apps_uniq_name(name)
        ) ; 


        CREATE TABLE IF NOT EXISTS xtremweb.hosts (
-- primay key
        uid char(50) NOT NULL,
-- jobs counter; updated on work completion
        nbJobs int(15),
-- how many time to wait before this host is considered as lost
-- default is provided by server, but this may also be defined from host config
        timeOut int(15),
-- average execution time; updated on work completion
        avgExecTime int(15),
-- last communication time (helps to determine whether this host is lost)
        lastAlive datetime,
-- this host name
        name char(100),
-- how many time this host has been connected
        nbconnections int(10),
-- This is the IP address as provided by worker itself.
-- This is certainly a NATed IP
        natedipaddr char(20),
-- This is the IP address obtained at connexion time.
-- This is set by server at connexion time.
-- This may be different from NATed IP.
        ipaddr char(20),
-- MAC address
        hwaddr char(20),
-- time zone
        timezone char(50),
-- OS name
        os char(20),
-- CPU name
        cputype char(20),
-- CPU counter
        cpunb int(2),
-- CPU model
        cpumodel char(50),
-- CPU speed
        cpuspeed int(10),
-- total RAM
        totalmem int(10),
-- total SWAP
        totalswap int(10),
-- time diff from host to server
        timeShift int(15),
-- average ping to server
        avgping int(20),
-- ping amount to server
        nbping int(10),
-- upload bandwidth usage (in Mb/s)
        uploadbandwidth float,
-- download bandwidth usage (in Mb/s)
        downloadbandwidth float,
-- user UID
        ownerUID char(50),
-- project this worker wants to participate
-- in practice, this is a usergroup name
        project char(50),
-- this flag tells whether this host may be used 
-- if a host has ever generated any error, this flag is automatically set to false
-- so that we don't use faulty worker
        active char(5) DEFAULT 'true',
-- this flag tells whether this host may run jobs accordingly to its local activation policy
-- this flag is provided by worker with alive signal
        available char(5) DEFAULT 'false',
-- this flag tells whether this host accept application binary 
-- if false, this host accept to execute services written in java only
        acceptbin char(5) DEFAULT 'true',
-- this is this host XWHEP software version
        version char(50) NOT NULL,
-- this flag tells whether this host is collecting traces (CPU, memory, disk usage)
        traces char(5) DEFAULT 'false',
-- true is this row has been deleted
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid)
        ) ; 

        CREATE TABLE IF NOT EXISTS xtremweb.usergroups (
-- primay key
        uid char(50) NOT NULL,
-- user group label
        label char(50),
-- true is this can be a "project"
-- this is always true, except for worker and administrator user groups
        project char(5) DEFAULT 'true',
-- true is this row has been deleted
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid),
        CONSTRAINT UNIQUE INDEX usergroups_uniq_label(label)
        ) ; 

        CREATE TABLE IF NOT EXISTS xtremweb.users (
-- primay key
        uid char(50) NOT NULL,
-- optionnal; user group UID
        usergroupUID char(50),
-- jobs counter; updated on work completion
        nbJobs int(15),
-- user login
        login char(25) NOT NULL,
-- user passworkd
        password char(50) DEFAULT '' NOT NULL,
-- user email
        email char(50) DEFAULT '' NOT NULL,
-- optionnal, user first name
        fname char(25),
-- optionnal, user last name
        lname char(25),
-- user country
        country char(25),
-- user rights; see common/UserRights.java
        rights char(20) DEFAULT 'NONE',
-- true is this row has been deleted
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid),
        CONSTRAINT UNIQUE INDEX users_uniq_login(login)
        ) ;

        CREATE TABLE IF NOT EXISTS xtremweb.tasks (
-- primay key
        uid char(50) NOT NULL,
-- host UID
        hostUID char(50),
-- instanciation counter
        trial int(11),
-- status; see common/XWStatus.java
        status char(20),
-- when the server put this task into queue
        InsertionDate datetime,
-- first instanciation date
        StartDate datetime,
-- last instanciation date
        LastStartDate datetime,
-- is it necessary ?
        AliveCount int(11),
-- is it necessary ?
        LastAlive datetime,
-- when this task has been removed
        removalDate datetime,
-- last instanciation duration
        duration int(11),
-- true is row has been deleted 
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid)
        ) ;


        CREATE TABLE IF NOT EXISTS xtremweb.works (
-- primay key
        uid char(50) NOT NULL,
-- optionnal; expected host UID
        expectedhostUID char(50),
-- see common/XWAccessRights.java
        accessRights int(4) DEFAULT 0x755,
-- optionnal; session UID
        sessionUID char(50),
-- optionnal; group UID (we call it 'groupUID' since 'group' is a MySql reserved word)
        groupUID char(50),
-- optionnal; user label
        label char(50),
-- application UID
        appUID char(50),
-- user UID
        userUID char(50),
-- status; see common/XWStatus.java
        status char(20),
-- how many instanciation ; above mark this work as error
        maxRetry int(3),
-- optionnal ; minimum memory need
        minMemory int(10),
-- optionnal ; minimum CPU speed need
        minCPUSpeed int(10),
-- application return code
        returnCode int(3),
-- for replication
        server char(200),
-- this work command line to provide to application
        cmdLine char(255),
-- data URI; this is the STDIN. If not set, apps.stdin is used by default
-- NULLUID may be used to force no STDIN even if apps.stdin is defined
-- see common/UID.java#NULLUID
        stdinURI char(200),
-- data URI; this is the DIRIN. If not set, apps.dirin is used by default
-- NULLURI may be used to force no DIRIN even if apps.dirin is defined
-- see common/UID.java#NULLUID
        dirinURI char(200),
-- data URI
        resultURI char(200),
-- when the server received this work
        arrivalDate datetime,
-- when this work has been completed
        completedDate datetime,
-- when this work result has been available
        resultDate datetime,
-- error message
        error_msg char(255),
-- used for replication
        sendToClient char(5) DEFAULT 'false',
-- used for replication
        local char(5) DEFAULT 'true',
-- used for replication
        active char(5) DEFAULT 'true',
-- optionnal; used for replication
        replicated char(5) DEFAULT 'false',
-- is it a service (see apps.isService)
        isService char(5) DEFAULT 'false',
-- true is row has been deleted 
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid),
        INDEX works_status_active (status, active)
        ) ;

        CREATE TABLE IF NOT EXISTS xtremweb.datas (
-- primary key
        uid char(50) NOT NULL,
-- may be {user, app, work} UID
        ownerUID char(50),
-- this is the URI of the content
        uri char(200),
-- see common/XWAccessRights.java
        accessRights int(4) DEFAULT 0x755,
-- symbolic file name (i.e. alias name)
        name char(100),
-- how many times it is used; can be deleted if 0
        links int(4),
-- last access date
        accessDate datetime,
-- creation date
        insertionDate datetime,
-- status; see common/XWStatus.java
        status char(20),
-- see common/DataType.java
        type char(20),
-- optionnal; mainly necessary if data is an app binary
        os char(20),
-- optionnal; mainly necessary if data is an app binary
        cpu char(20),
-- data md5
        md5 char(50),
-- effective file size
        size int(10),
-- optionnal; used by replication
        sendToClient char(5) DEFAULT 'false',
-- optionnal; used by replication
        replicated char(5) DEFAULT 'false',
-- true is row has been deleted 
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid)
        ) ; 

        CREATE TABLE IF NOT EXISTS xtremweb.sessions (
-- primary key
        uid char(50) NOT NULL,
-- session name
        name char(50) NOT NULL,
-- owner (user) UID
        clientUID char(50) NOT NULL,
-- true is this row has been deleted
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid)
        ) ;


        CREATE TABLE IF NOT EXISTS xtremweb.groups (
-- primary key
        uid char(50) NOT NULL,
-- group name
        name char(50) NOT NULL,
-- session UID
        sessionUID char(50) NOT NULL,
-- owner (user) UID
        clientUID char(50) NOT NULL,
-- true is this row has been deleted
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid)
        ) ;

        CREATE TABLE IF NOT EXISTS xtremweb.traces (
-- primary key
        uid char(50) NOT NULL,
-- host UID
        hostUID char(50) DEFAULT '' NOT NULL,
--
        login char(25) DEFAULT '' NOT NULL,
        arrivalDate datetime NOT NULL,
        startDate datetime NOt NULL,
        endDate datetime NOT NULL,
-- data URI
        data char(200) DEFAULT '' NOT NULL,
-- true is this row has been deleted
        isdeleted char(5) DEFAULT 'false',

        PRIMARY KEY (uid)
        ) ;


--
-- Allow access to your database
--
-- GRANT ALL PRIVILEGES ON * TO ${aDBUser}@localhost IDENTIFIED BY '${aPassword}' WITH GRANT OPTION;
--
-- e.g. :GRANT ALL PRIVILEGES ON xtremweb.* TO xtremweb@localhost IDENTIFIED BY 'xwpassword' WITH GRANT OPTION;
--GRANT ALL PRIVILEGES ON xtremweb.* TO xtremweb@localhost IDENTIFIED BY 'xwpassword' WITH GRANT OPTION;
--

--
-- Finally insert a priviliged user to be able to manage your platform
--
-- insert into users (uid,login,password,fname,lname,email,rights) values ("0:0:0",${xw.passwordPass})),&quot;${xtremweb.admin.login}&quot;,md5(concat(&quot;${xtremweb.admin.password}&quot;,${xw.passwordPass})), &quot;${xtremweb.admin.fname}&quot;, &quot;${xtremweb.admin.lname}&quot;, &quot;${xtremweb.admin.email}&quot;,100);
--
-- e.g. :insert into xtremweb.users (uid,login,password,email,rights) values (md5(concat('xwpassword','apassphrase')),'xtremweb',md5('xwpassword','apassphrase')),'toto@titi',100);
--insert into xtremweb.users (uid,login,password,email,rights) values ("0:0:0",'@DEFAULTUSER@',md5(concat('@DEFAULTPASSWORD@','@PASSWORDPASS@')),'toto@titi',100);
--insert into xtremweb.users (uid,login,password,email,rights) values ("0:0:1",'@WORKERUSER@',md5(concat('@WORKERPASSWORD@','@PASSWORDPASS@')),'toto@titi',3);
--

--
-- if your dispatcher complains about handshake, try this
--set password for xtremweb@localhost = old_password('xwpassword');









GRANT ALL PRIVILEGES ON xtremweb.* TO administrator@localhost IDENTIFIED BY 'xwpassword' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON xtremweb.* TO administrator@localhost.localdomain IDENTIFIED BY 'xwpassword' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON xtremweb.* TO administrator@'@XWHOST@' IDENTIFIED BY 'xwpassword' WITH GRANT OPTION;
set password for administrator@localhost = old_password('xwpassword');

insert into xtremweb.usergroups (uid,label,project) values("f12d56d3-8d9b-4961-bad7-9e9877456b96","admin", "false");
insert into xtremweb.usergroups (uid,label,project) values("92c6069a-ca4e-49d2-83c0-953182854944","publicworkers", "false");
insert into xtremweb.users (uid,usergroupUID,login,password,fname,lname,email,rights) values ("88740354-2e5a-4e84-9005-8e9c9ce77093","f12d56d3-8d9b-4961-bad7-9e9877456b96","administrator",md5(concat("xwpassword","some chars to generate keys")), "", "", "","SUPER_USER");
insert into xtremweb.users (uid,usergroupUID,login,password,fname,lname,email,rights) values ("2e958450-54e7-457f-9e76-fe1446cf64c7","92c6069a-ca4e-49d2-83c0-953182854944","worker",md5(concat("${xtremweb.worker.password.coded}","some chars to generate keys")), "", "", "","WORKER_USER");

---
--- End Of File
---
