#!/usr/bin/perl

#
# File    : gmond.pl
# Author  : Oleg Lodygens (lodygens at lal.in2p3.fr)
# Date    : Octobre 20th, 2005
# Purpose : this retreives the XWHEP DesktopGrid cluster informations
#
# chkconfig: 345 99 99
#

use strict;
use English;
use IO::Handle;
use IO::Socket;
use File::Basename;
use File::stat;
use DirHandle;
use integer;
use DBI;

#
# trap CTRL+C
#
use sigtrap 'handler' => \&ctrlcHandler, 'INT';

#
# this controls program execution
#
my $continuer = 1;

# Synchronize the Perl IOs
autoflush STDIN 1;
autoflush STDERR 1;
autoflush STDOUT 1;

#
# default values
#
my $user = "root";
my $password = "";
my $database = "xtremweb";
my $clusterName = "XWHEP";
my $tcpPort = 8694;
my $startTime = time;
my $currentTime = time;
my $scriptName = `basename $0`;
my $scriptDir = `dirname $0`;


chomp ($scriptName);
chomp ($scriptDir);
$scriptDir = `pwd` if ($scriptDir = ".");
chomp ($scriptDir);

#
# debug levels
#
my $DEBUG = 0;
my $INFO  = 1;
my $WARN  = 2;
my $ERROR = 3;
my $debug = $INFO;



#
# this is called whenever user hits CTRL+C
#
sub ctrlcHandler {
    print "Caught SIGINT\n";
    exit 1;
}


#
# This prints out usage
#
sub usage {
    print "Usage : $scriptName -u user -p password [-db database] [-r dir] [-h] [-d level] \n";
    print "\t -h            to get this help\n";
    print "\t -d    level     to set debug level\n";
    print "\t -u    user      where user     is the DB user name\n";
    print "\t -pass password  where password is the DB user password\n";
    print "\t -db   database  where database is the DB name\n";
    print "\t -p    port      where port is the port to listen to (default = $tcpPort)\n";
    exit;
}


#
# This prints out debugs
#
sub debug {
    print "DEBUG : @_\n" if ($debug <= $DEBUG);
}


#
# This prints out infos
#
sub info {
    print "INFO : @_\n" if ($debug <= $INFO);
}


#
# This prints warnings
#
sub warn {
    print "WARN : @_\n" if ($debug <= $WARN);
}


#
# This prints out errors
#
sub error {
    print "ERROR : @_\n" if ($debug <= $ERROR);
}



# ============================================== #
# *                    Main                      #
# ============================================== #


#
# parse command line args
#
my $arg;

while ($arg = shift) {
    if (($arg eq '-h') || ($arg eq '--help')) {
        usage;
    }
    if ($arg eq '-c') {
        $clusterName = shift;
    }
    if ($arg eq '-d') {
        $debug = shift;
    }
    if ($arg eq '-pass') {
        $password = shift;
    }
    if ($arg eq '-p') {
        $tcpPort = shift;
    }
    if ($arg eq '-u') {
        $user = shift;
    }
    if ($arg eq '-db') {
        $database = shift;
    }
}

#
# create socket to listen to
#
my $inputSocket = new IO::Socket::INET (LocalHost => 'localhost',
                                        LocalPort => $tcpPort,
                                        Proto => 'tcp',
                                        Listen => 1,
                                        Reuse => 1);
die "Could not create socket: $!\n" unless $inputSocket;


#
# connect to mysql
#
my $dbh = DBI->connect("DBI:mysql:$database", $user, $password)
    or die "Couldn't connect to database: " . DBI->errstr;
#
# SELECT statement
# This retreives max(lastalive) group by name, ipaddr
#
my $reqMaxLastAlive = $dbh->prepare("select name,ipaddr,max(lastalive) as lastalive,sum(nbjobs) as nbjobs from hosts group by hosts.name, hosts.ipaddr")
    or die "Couldn't prepare statement: " . $dbh->errstr;

#
# This retreives worker accordingly to name, ipaddr and lastalive
#
my $reqWorker = $dbh->prepare("select uid as uid, os as osrelease, cpunb as cpunb, cpuspeed as cpuspeed, cputype as machinetype, totalswap as swaptotal, totalmem as memtotal,name as name, ipaddr as ipaddr, unix_timestamp(now())-unix_timestamp(lastalive) as delai,active as active,available as available from hosts where lastalive=? and name=? and ipaddr=?")
    or die "Couldn't prepare statement: " . $dbh->errstr;

my $runningText="select count(*) as runningJobs from hosts,tasks where tasks.status='RUNNING' and tasks.hostUID=hosts.uid and hosts.name=? and hosts.ipaddr=?";
my $reqRunning = $dbh->prepare($runningText)
    or die "Couldn't prepare statement: " . $dbh->errstr;

my $errorText="select count(*) as errorJobs from hosts,tasks where tasks.status='ERROR' and tasks.hostUID=hosts.uid and hosts.name=? and hosts.ipaddr=?";
my $reqError = $dbh->prepare($errorText)
    or die "Couldn't prepare statement: " . $dbh->errstr;

#
# Loop for ever
#
while(1) {
    #
    # wait incoming connections
    #
    while (my $inSock = $inputSocket->accept()) {

        $currentTime = time;

        #
        # Print Ganglia header
        #
        print $inSock "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"yes\"?>\n";
        print $inSock "<!DOCTYPE GANGLIA_XML [\n";
        print $inSock "<!ELEMENT GANGLIA_XML (GRID)*>\n";
        print $inSock "<!ATTLIST GANGLIA_XML VERSION CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST GANGLIA_XML SOURCE CDATA #REQUIRED>\n";
        print $inSock "<!ELEMENT GRID (CLUSTER | GRID | HOSTS | METRICS)*>\n";
        print $inSock "<!ATTLIST GRID NAME CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST GRID AUTHORITY CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST GRID LOCALTIME CDATA #IMPLIED>\n";
        print $inSock "<!ELEMENT CLUSTER (HOST | HOSTS | METRICS)*>\n";
        print $inSock "<!ATTLIST CLUSTER NAME CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST CLUSTER OWNER CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST CLUSTER LATLONG CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST CLUSTER URL CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST CLUSTER LOCALTIME CDATA #REQUIRED>\n";
        print $inSock "<!ELEMENT HOST (METRIC)*>\n";
        print $inSock "<!ATTLIST HOST NAME CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST HOST IP CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST HOST LOCATION CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST HOST REPORTED CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST HOST TN CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST HOST TMAX CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST HOST DMAX CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST HOST GMOND_STARTED CDATA #IMPLIED>\n";
        print $inSock "<!ELEMENT METRIC EMPTY>\n";
        print $inSock "<!ATTLIST METRIC NAME CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST METRIC VAL CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST METRIC TYPE (string | int8 | uint8 | int16 | uint16 | int32 | uint32 | float | double | timestamp) #REQUIRED>\n";
        print $inSock "<!ATTLIST METRIC UNITS CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST METRIC TN CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST METRIC TMAX CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST METRIC DMAX CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST METRIC SLOPE (zero | positive | negative | both | unspecified) #IMPLIED>\n";
        print $inSock "<!ATTLIST METRIC SOURCE (gmond | gmetric) #REQUIRED>\n";
        print $inSock "<!ELEMENT HOSTS EMPTY>\n";
        print $inSock "<!ATTLIST HOSTS UP CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST HOSTS DOWN CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST HOSTS SOURCE (gmond | gmetric | gmetad) #REQUIRED>\n";
        print $inSock "<!ELEMENT METRICS EMPTY>\n";
        print $inSock "<!ATTLIST METRICS NAME CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST METRICS SUM CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST METRICS NUM CDATA #REQUIRED>\n";
        print $inSock "<!ATTLIST METRICS TYPE (string | int8 | uint8 | int16 | uint16 | int32 | uint32 | float | double | timestamp) #REQUIRED>\n";
        print $inSock "<!ATTLIST METRICS UNITS CDATA #IMPLIED>\n";
        print $inSock "<!ATTLIST METRICS SLOPE (zero | positive | negative | both | unspecified) #IMPLIED>\n";
        print $inSock "<!ATTLIST METRICS SOURCE (gmond | gmetric) #REQUIRED>\n";
        print $inSock "]>\n";
        print $inSock "<GANGLIA_XML VERSION=\"2.5.6\" SOURCE=\"gmond\">\n";
        print $inSock "<CLUSTER NAME=\"".$clusterName."\" LOCALTIME=\"".$currentTime."\" OWNER=\"unspecified\" LATLONG=\"unspecified\" URL=\"unspecified\">\n";
				
				
        #
        # retreive workers group by name, ipaddr
        #
        $reqMaxLastAlive->execute()
            or die "Couldn't execute statement: " . $reqMaxLastAlive->errstr;

        while (my $alive = $reqMaxLastAlive->fetchrow_hashref) {
            
            #
            # retreive worker
            #
            $reqWorker->execute($alive->{lastalive}, $alive->{name}, $alive->{ipaddr})
                or die "Couldn't execute statement: " . $reqWorker->errstr;

            #
            # parse rows
            #
            while (my $worker = $reqWorker->fetchrow_hashref) {
                my $tn = 0;
                
                if($worker->{delai} > 1000) {
                    next;
                }
                
                print $inSock "<HOST NAME=\"".$worker->{name}."_".$worker->{ipaddr}."\"";
                print $inSock " IP=\"".$worker->{ipaddr}."\"";
                print $inSock " REPORTED=\"".$currentTime."\"";
                print $inSock " TN=\"".$tn."\"";
                print $inSock " TMAX=\"900\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " LOCATION=\"unspecified\"";
                print $inSock " GMOND_STARTED=\"" .$startTime."\">\n";
                
                print $inSock "<METRIC NAME=\"cpu_num\" VAL=\"".$worker->{cpunb}."\"";
                print $inSock " TYPE=\"uint16\"";
                print $inSock " UNITS=\"CPUs\"";
                print $inSock " TN=\"0\"";
                print $inSock " TMAX=\"1200\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"zero\"";
                print $inSock " SOURCE=\"gmond\" />\n";
                
                print $inSock "<METRIC NAME=\"cpu_speed\" VAL=\"".$worker->{cpuspeed}."\"";
                print $inSock " TYPE=\"uint16\"";
                print $inSock " UNITS=\"CPUs\"";
                print $inSock " TN=\"0\"";
                print $inSock " TMAX=\"1200\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"zero\"";
                print $inSock " SOURCE=\"gmond\" />\n";
                
                print $inSock "<METRIC NAME=\"os_release\" VAL=\"".$worker->{osrelease}."\"";
                print $inSock " TYPE=\"string\"";
                print $inSock " UNITS=\"\"";
                print $inSock " TN=\"0\"";
                print $inSock " TMAX=\"1200\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"zero\"";
                print $inSock " SOURCE=\"gmond\" />\n";
                
                print $inSock "<METRIC NAME=\"machine_type\" VAL=\"".$worker->{machinetype}."\"";
                print $inSock " TYPE=\"string\"";
                print $inSock " UNITS=\"\"";
                print $inSock " TN=\"0\"";
                print $inSock " TMAX=\"1200\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"zero\"";
                print $inSock " SOURCE=\"gmond\" />\n";

                print $inSock "<METRIC NAME=\"mem_total\" VAL=\"".$worker->{memtotal}."\"";
                print $inSock " TYPE=\"uint32\"";
                print $inSock " UNITS=\"BYTES\"";
                print $inSock " TN=\"0\"";
                print $inSock " TMAX=\"1200\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"zero\"";
                print $inSock " SOURCE=\"gmond\" />\n";
                
                print $inSock "<METRIC NAME=\"swap_total\" VAL=\"".$worker->{swaptotal}."\"";
                print $inSock " TYPE=\"uint32\"";
                print $inSock " UNITS=\"BYTES\"";
                print $inSock " TN=\"0\"";
                print $inSock " TMAX=\"1200\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"zero\"";
                print $inSock " SOURCE=\"gmond\" />\n";
                
                print $inSock "<METRIC NAME=\"ALIVEDELAI\" VAL=\"".$worker->{delai}."\"";
                print $inSock " TYPE=\"uint32\"";
                print $inSock " UNITS=\"seconds\"";
                print $inSock " TN=\"".$tn."\"";
                print $inSock " TMAX=\"900\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"both\"";
                print $inSock " SOURCE=\"gmetric\" />\n";
                
                my $aliveBoolean = 1;
                $aliveBoolean = 0 if $worker->{delai} > 900;
                print $inSock "<METRIC NAME=\"ALIVE\" VAL=\"".$aliveBoolean."\"";
                print $inSock " TYPE=\"uint8\"";
                print $inSock " UNITS=\"boolean\"";
                print $inSock " TN=\"".$tn."\"";
                print $inSock " TMAX=\"900\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"both\"";
                print $inSock " SOURCE=\"gmetric\" />\n";
                
                my $myBoolean = 0;
                $myBoolean = 1 if ($worker->{active} eq "true");
                $myBoolean = 0 if ($aliveBoolean == 0);
                print $inSock "<METRIC NAME=\"ACTIVE\" VAL=\"".$myBoolean."\"";
                print $inSock " TYPE=\"uint8\"";
                print $inSock " UNITS=\"boolean\"";
                print $inSock " TN=\"".$tn."\"";
                print $inSock " TMAX=\"900\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"both\"";
                print $inSock " SOURCE=\"gmetric\" />\n";
                
                $myBoolean = 0;
                $myBoolean = 1 if ($worker->{available} eq "true");
                $myBoolean = 0 if ($aliveBoolean == 0);
                print $inSock "<METRIC NAME=\"AVAILABLE\" VAL=\"".$myBoolean."\"";
                print $inSock " TYPE=\"uint8\"";
                print $inSock " UNITS=\"boolean\"";
                print $inSock " TN=\"".$tn."\"";
                print $inSock " TMAX=\"900\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"both\"";
                print $inSock " SOURCE=\"gmetric\" />\n";
                
                print $inSock "<METRIC NAME=\"COMPLETEDS\" VAL=\"".$alive->{nbjobs}."\"";
                print $inSock " TYPE=\"uint32\"";
                print $inSock " UNITS=\"Jobs\"";
                print $inSock " TN=\"".$tn."\"";
                print $inSock " TMAX=\"900\"";
                print $inSock " DMAX=\"0\"";
                print $inSock " SLOPE=\"both\"";
                print $inSock " SOURCE=\"gmetric\" />\n";
                
                #
                # retreive running tasks
                #
                $reqRunning->execute($worker->{name}, $worker->{ipaddr})
                    or die "Couldn't execute statement: " . $reqRunning->errstr;
                
                if(my $runnings = $reqRunning->fetchrow_hashref) {
                    
                # print "\"".$reqTaskText."\"(".$row->{name}.", ".$row->{ipaddr}.") = ".$runnings->{runningJobs}."\n";
                    
                    print $inSock "<METRIC NAME=\"RUNNINGS\" VAL=\"".$runnings->{runningJobs}."\"";
                    print $inSock " TYPE=\"uint32\"";
                    print $inSock " UNITS=\"Jobs\"";
                    print $inSock " TN=\"".$tn."\"";
                    print $inSock " TMAX=\"900\"";
                    print $inSock " DMAX=\"0\"";
                    print $inSock " SLOPE=\"both\"";
                    print $inSock " SOURCE=\"gmetric\" />\n";
                }
                
                #
                # retreive errors tasks
                #
                $reqError->execute($worker->{name}, $worker->{ipaddr})
                    or die "Couldn't execute statement: " . $reqError->errstr;
                
                if(my $errors = $reqError->fetchrow_hashref) {
                    
                    print $inSock "<METRIC NAME=\"ERRORS\" VAL=\"".$errors->{errorJobs}."\"";
                    print $inSock " TYPE=\"uint32\"";
                    print $inSock " UNITS=\"Jobs\"";
                    print $inSock " TN=\"".$tn."\"";
                    print $inSock " TMAX=\"900\"";
                    print $inSock " DMAX=\"0\"";
                    print $inSock " SLOPE=\"both\"";
                    print $inSock " SOURCE=\"gmetric\" />\n";
                }
                
                print $inSock "</HOST>\n";
            }
        }
        
        #
        # Print Ganglia trailer
        #
        print $inSock "</CLUSTER>\n</GANGLIA_XML>\n";
        
        close($$inSock);
    }
}

#
# End of file
#
