#!/bin/sh

ROOT=`dirname $0`
[ -f $ROOT/mysqlconf.sh ] && . $ROOT/mysqlconf.sh
. $ROOT/parseargs.sh

#echo "USER=$USER"
#echo "PASSWORD=$PASSWORD"
#echo "DATABASE=$DATABASE"
#echo "SQLFILE=$SQLFILE"

PSWD=""
[ "$PASSWORD" != "" ] && PSWD="--password=$PASSWORD"

mysql -u $USER $PSWD $DATABASE < $SQLFILE

