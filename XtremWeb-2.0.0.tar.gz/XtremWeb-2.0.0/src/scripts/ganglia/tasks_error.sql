select count(*) from tasks where status="ERROR"
