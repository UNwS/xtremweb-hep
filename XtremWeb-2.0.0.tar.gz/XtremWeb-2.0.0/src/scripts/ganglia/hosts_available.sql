select  available,now()-lastAlive as delai from hosts where available="true" having delai<=4500
