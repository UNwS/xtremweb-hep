#!/bin/sh
ROOT=`dirname $0`
FILE=`basename $0 | cut -d '.' -f 1`

NB=`$ROOT/mysql.sh -f "$ROOT/$FILE.sql" $* | tail -1`
[ "$NB" = "" ] && NB=0
echo $NB
