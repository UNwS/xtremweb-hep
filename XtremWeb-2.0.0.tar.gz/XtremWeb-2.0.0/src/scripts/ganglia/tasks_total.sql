select count(*) from tasks
