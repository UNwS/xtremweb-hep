#!/bin/sh
#


# Author: Oleg Lodygensky
# E-mail: lodygens@lal.in2p3.fr
#
# File   : parseargs.sh
#


# ------------------- Local Function

Help()
{ 
	echo
	echo $0 [-h] [-u user] [-p passwd] [-d database] [-f sqlfile]
	echo "	-h : get this help msg"
	echo "	-u : db user"
	echo "	-p : user password"
	echo "	-f : sql command file"
	echo "	-d : db name"
	echo
 }

# ------------------- Main Function

#USER=""
#PASSWORD=""
#DATABASE="xtremweb"
SQLFILE=""

while [ $# -ne 0 ]; do

  case $1 in
    "-h" | "--help" ) 
      Help
      exit
    ;; 
    "-u" )
    shift
    USER=$1
    ;;
    "-p" )
    shift
    PASSWORD=$1
    ;;
    "-d" )
    shift
    DATABASE=$1
    ;;
    "-f" )
    shift
    SQLFILE=$1
    ;;
  * )
    echo "Unknown args : $1"
    ;; 
  esac

  shift

done


