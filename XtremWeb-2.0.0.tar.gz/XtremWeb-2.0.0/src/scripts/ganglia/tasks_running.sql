select count(*),now()-lastAlive as delai  from tasks where status="RUNNING" group by uid having delai<=4500
