#!/bin/sh

USER="root"
#PASSWORD=""
DATABASE="xtremweb"

