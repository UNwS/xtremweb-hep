select count(*) from hosts;
