select count(*) from tasks where status="WAITING"
