select now()-lastAlive as delai from hosts having delai<=4500
