select count(*) from tasks where status="COMPLETED"
