select  active,now()-lastAlive as delai from hosts where active="true" having delai<=4500
