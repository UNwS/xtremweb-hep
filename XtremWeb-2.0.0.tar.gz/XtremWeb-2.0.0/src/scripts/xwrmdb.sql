--
-- Version : XWHEP 1.0.25
--
-- File    : xwrmdb.sql
-- Purpose : this file contains the needed SQL commands to 
--           remove the XWHEP database tables
--           This does **not** remove the database itself
--           If needed you must do it manually
--
-- Usage   : this is used by xtremweb.database
--

--
-- you must uncomment next command and set the appropriate
-- database name
-- e.g. : connect xtremweb;
--
-- connect ;

drop table if exists apps;
drop table if exists datas;
drop table if exists hosts;
drop table if exists users;
drop table if exists usergroups;
drop table if exists traces;
drop table if exists tasks;
drop table if exists works;
drop table if exists sessions;
drop table if exists groups;
