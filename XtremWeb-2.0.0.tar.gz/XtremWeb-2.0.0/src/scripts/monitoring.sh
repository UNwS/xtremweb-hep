#!/bin/sh

FREE=/usr/bin/free
LSOF=/usr/bin/lsof
#LSOF=/usr/sbin/lsof
SLEEP=1
HOST=`uname -n`

USER=xtremweb

[ -x /usr/bin/free  ] && FREE=/usr/bin/free
[ -x /usr/sbin/free ] && FREE=/usr/sbin/free

[ -x /usr/bin/lsof  ] && LSOF=/usr/bin/lsof
[ -x /usr/sbin/lsof ] && LSOF=/usr/sbin/lsof

OUTFILE=$HOST".txt"
#OUTFILE=""

if [ "$OUTFILE" != "" ] ; then
		[ -f $OUTFILE ] && mv $OUTFILE $OUTFILE.bak
		touch $OUTFILE
fi

totalMem=`$FREE | grep Mem | sed "s/[[:space:]][[:space:]]*/ /g" | cut -d ' ' -f 2`
totalSwap=`$FREE | grep Swap | sed "s/[[:space:]][[:space:]]*/ /g" | cut -d ' ' -f 2`
if [ "$OUTFILE" != "" ] ; then
		echo "Total Mem : $totalMem" >> $OUTFILE
		echo "Total Swap : $totalSwap" >> $OUTFILE
		echo "date;sqlOf;pipeOf;totalOf;TOTALPROC;XWPROC;XWCHILD;XWCPU;XWMEM;CHILDCPU;CHILDMEM;FREEMEM;FREESWAP" >> $OUTFILE
else
		echo "Total Mem : $totalMem"
		echo "Total Swap : $totalSwap"
		echo "date;sqlOf;pipeOf;totalOf"
		echo "date;sqlOf;pipeOf;totalOf;TOTALPROC;XWPROC;XWCHILD;XWCPU;XWMEM;CHILDCPU;CHILDMEM;FREEMEM;FREESWAP"
fi

for (( i=0;i>=0;i++ )) ; do
		freeMem=`$FREE | grep Mem | sed "s/[[:space:]][[:space:]]*/ /g" | cut -d ' ' -f 4`
		freeSwap=`$FREE | grep Swap | sed "s/[[:space:]][[:space:]]*/ /g" | cut -d ' ' -f 4`
		totalof=`$LSOF | grep xtremweb | grep java  | wc -l`
		mysqlof=`$LSOF | grep xtremweb | grep mysql | wc -l`
		pipeof=`$LSOF | grep xtremweb | grep pipe  | wc -l`

		TOTALPROC=`ps u -u $USER | wc -l`
		XWPROC=`ps u -u $USER | grep java | wc -l`
		XWCPUS=`ps u -u $USER | grep java | sed "s/[[:space:]][[:space:]]*/ /g" | cut -d ' ' -f 3`
		XWMEMS=`ps u -u $USER | grep java | sed "s/[[:space:]][[:space:]]*/ /g" | cut -d ' ' -f 4`

		XWTOTALCPU=0
		for cpu in $XWCPUS ; do
				XWTOTALCPU=`echo "$XWTOTALCPU + $cpu" | bc`
		done
		XWTOTALMEM=0
		for mem in $XWMEMS ; do
				XWTOTALMEM=`echo "$XWTOTALMEM + $mem" | bc`
		done

#	echo "XWTOTALCPU = $XWTOTALCPU"
#	echo "XWTOTALMEM = $XWTOTALMEM"

		NBCHILD=`ps u -u $USER | grep -v java | wc -l`
		CHILDCPUS=`ps u -u $USER | grep -v java | grep -v "%CPU" | sed "s/[[:space:]][[:space:]]*/ /g" | cut -d ' ' -f 3`
		CHILDMEMS=`ps u -u $USER | grep -v java | grep -v "%MEM" | sed "s/[[:space:]][[:space:]]*/ /g" | cut -d ' ' -f 4`

		CHILDTOTALCPU=0
		for cpu in $CHILDCPUS ; do
#			echo "$CHILDTOTALCPU + $cpu"
				CHILDTOTALCPU=`echo "$CHILDTOTALCPU + $cpu" | bc`
#			echo "CHILDTOTALCPU = $CHILDTOTALCPU"
		done
		CHILDTOTALMEM=0
		CHILDMAXMEM=0
		PIDCHILDMAXMEM=0
		for mem in $CHILDMEMS ; do
				CHILDTOTALMEM=`echo "$CHILDTOTALMEM + $mem" | bc`
				test=`echo "$mem > $CHILDMAXMEM" | bc`
				if [ "$test" = "1"  ] ; then
						CHILDMAXMEM=$mem
						PIDCHILDMAXMEM=$mem
				fi
		done

		pourcentSwapFree=`echo $freeSwap"00/"$totalSwap | bc`
		[] && echo "TotalSwap = $totalSwap  FreeSwap = $freeSwap  %SwapFree=$pourcentSwapFree"
#	echo "NBCHILD       = $NBCHILD"
#	echo "CHILDTOTALCPU = $CHILDTOTALCPU"
#	echo "CHILDTOTALMEM = $CHILDTOTALMEM"

		if [ "$OUTFILE" != "" ] ; then
				echo `date +%s`";$mysqlof;$pipeof;$totalof;$TOTALPROC;$XWPROC;$NBCHILD;$XWTOTALCPU;$XWTOTALMEM;$CHILDTOTALCPU;$CHILDTOTALMEM;$freeMem;$freeSwap" >> $OUTFILE
		else
				echo `date +%s`";$mysqlof;$pipeof;$totalof;$TOTALPROC;$XWPROC;$NBCHILD;$XWTOTALCPU;$XWTOTALMEM;$CHILDTOTALCPU;$CHILDTOTALMEM;$freeMem;$freeSwap"
		fi
		sleep $SLEEP
done
