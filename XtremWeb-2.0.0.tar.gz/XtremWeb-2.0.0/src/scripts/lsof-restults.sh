#!/bin/sh

if [ "$1" = "" ] ; then
	echo "not enough arg"
	exit 1
fi

filename=`echo $1 | cut -d '.' -f 1`
datfile=$filename".dat"
gpfile=$filename".gp"
pngfile=$filename".png"

cat $1 | gawk 'BEGIN{FS=";"}{ printf ("%i\t%i\t%i\n", $2,$3,$4)}' > $datfile

echo $gpfile

rm -f $gpfile


cat > $gpfile << EOF
set key outside
set title "lsof | grep java | wc -l\nOneworker, one client and one dispatcher on a single host"
set xlabel "Time (step = ~1 sec)"
set ylabel "opened files"

set terminal png
set output '$pngfile'

plot "$datfile" using 1 title "mysql", "$datfile" using 2 title "pipe", "$datfile" using 3 title "total"

EOF

gnuplot $gpfile


kuickshow $pngfile