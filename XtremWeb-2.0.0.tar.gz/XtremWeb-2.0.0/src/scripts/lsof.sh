#!/bin/sh

for (( i=0 ; i>=0; i++ )) ; do echo -n "`date` ; "; /usr/sbin/lsof | grep java | wc -l ; sleep 1 ; done > lsof.txt &
