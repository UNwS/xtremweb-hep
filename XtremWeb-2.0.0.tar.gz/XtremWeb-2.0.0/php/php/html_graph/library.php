<?php

/*
 * File   : html_graph/library.php
 * Date   : Sep 26th, 2003
 * Author : Oleg Lodygensky
 * Email  : lodygens@lal.in2p3.fr
 */




/* ------------------------------------------ */
function graphTask ($user = "", $delay="week") {
/*
 * @user is the user name
 * @param delay of tasks
 *        "week" for the last wekk tasks
 *        "month" for the last month tasks
 *        "year" for the last year tasks
 * @return: 0 on success
 *          1 if no task found
 */
/* ------------------------------------------ */

  if ($user == "") { 
    if ($delay == "week")
      $request = "SELECT COUNT(status) AS nbTasks, TO_DAYS(StartDate) AS period,DATE_FORMAT(StartDate,'%a') AS same_day, status FROM tasks WHERE ((TO_DAYS(NOW()) - TO_DAYS(StartDate) < 7)) GROUP BY period, status ORDER BY period";
    else if ($delay == "month")
      $request = "SELECT COUNT(status) AS nbTasks, TO_DAYS(StartDate) AS day,DATE_FORMAT(StartDate,'%b %d') AS period, status FROM tasks WHERE ((TO_DAYS(NOW()) - TO_DAYS(StartDate) < 31)) GROUP BY period, status ORDER BY period";
    else if ($delay == "year")
      $request = "SELECT COUNT(status) AS nbTasks, TO_DAYS(StartDate) AS day,DATE_FORMAT(StartDate,'%b') AS period, status FROM tasks WHERE ((TO_DAYS(NOW()) - TO_DAYS(StartDate) < 365)) GROUP BY period, status ORDER BY period";

    $labelTail = "";
  }
  else {

    if ($delay == "week")
      $request = "SELECT COUNT(tasks.status) AS nbTasks, TO_DAYS(tasks.StartDate) AS period,DATE_FORMAT(tasks.StartDate,'%a') AS same_day, tasks.status, works.userName FROM tasks,works WHERE ((TO_DAYS(NOW()) - TO_DAYS(StartDate) < 7))";
    else if ($delay == "month")
      $request = "SELECT COUNT(tasks.status) AS nbTasks, TO_DAYS(tasks.StartDate) AS day,DATE_FORMAT(tasks.StartDate,'%b %d') AS period, tasks.status, works.userName FROM tasks,works WHERE ((TO_DAYS(NOW()) - TO_DAYS(StartDate) < 31))";
    else if ($delay == "year")
      $request = "SELECT COUNT(tasks.status) AS nbTasks, TO_DAYS(tasks.StartDate) AS day,DATE_FORMAT(tasks.StartDate,'%b') AS period, tasks.status, works.userName FROM tasks,works WHERE ((TO_DAYS(NOW()) - TO_DAYS(StartDate) < 365))";

    $request = $request." AND (tasks.wid=works.wid) AND (works.userName ='".$user."')";

    $request = $request." GROUP BY period, status ORDER BY period";

    $labelTail = "for ".$user;
  }

  $connection = dbConnect ();
  $resultat = dbQuery($connection, $request);

  if ($resultat)
    $nb_enr   = mysql_num_rows( $resultat );


  if ($nb_enr == 0)
		return 1;

	$i = $index = $largest = 0;

	$previousDate = -1;
	$i=-1;

	while ($activity = mysql_fetch_array ($resultat)) {
		
		$status  = $activity[3];
		$date    = $activity[2];
		$nbTasks = $activity[0];

		if ($previousDate == -1) {
			$previousDate = $date;
			$i++;
		}
		else if ($previousDate != $date) {
			$previousDate = $date;
			$i++;
			$previousDate=$date;
		}

		if (!$lostTasks[$i])
			$lostTasks[$i]=0;
		if (!$completedTasks[$i])
			$completedTasks[$i]=0;

//      echo " i: $i  status: $status  date: $jours_semaine[$date] ::: $nbTasks<br>\n";
		if ($status == "COMPLETED") {
			$completedTasks[$i] = $nbTasks;
		}
		else if ($status == "ERROR") {
			$lostTasks[$i]  = $nbTasks;
		}

		$names[$i]    = "<b>" . $date ."</b>";
		$completedTasksBars[$i] = "pics/rainbow_blue.png";
		$lostTasksBars[$i]     = "pics/rainbow_red.gif";
		
		if( $largest < $nbTasks ) {
			$largest = $nbTasks;
		}
    //finish the loop
		
	}


	if ($i < 0)
		return 1;

	$graph_vals = array(
											"vlabel"       => "T<BR>a<BR>s<BR>k<BR>s",
											"hlabel"       => "This ".$delay." tasks stats ".$labelTail,
											"type"         => 3,
											"cellspacing"  => "1",
											"vfcolor"      => "#FDFC65",
											"hfcolor"      => "#FDFC65",
											"vbgcolor"     => "050064",
											"hbgcolor"     => "050064",
											"width"        => 350,
											"vfstyle"      => "Helvetica, Arial",
											"hfstyle"      => "Helvetica, Arial",
											"valuebgcolor" => "B8C8FE",
											"scale"        => 150/$largest,
											"namefcolor"   => "#1C2D67",
											"namebgcolor"  => "#FDFC65",
											"namefstyle"   => "Helvetica, Arial");
		
	echo "<!--- here is the graph -->\n";
	
	html_graph( $names, $lostTasks, $lostTasksBars, $graph_vals, $completedTasks, $completedTasksBars );

  return 0;
}


/* ------------------------------------------ */
function graphTaskLastWeek ($user = "") {
/*
 * @see graphTask()
 */
/* ------------------------------------------ */

  return graphTask ($user, "week");
}


/* ------------------------------------------ */
function graphTaskLastMonth ($user = "") {
/*
 * @see graphTask()
 */
/* ------------------------------------------ */

  return graphTask ($user, "month");
}


/* ------------------------------------------ */
function graphTaskLastYear ($user = "") {
/*
 * @see graphTask()
 */
/* ------------------------------------------ */

  return graphTask ($user, "year");
}




?>

