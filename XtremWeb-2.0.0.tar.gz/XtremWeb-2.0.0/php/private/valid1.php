<html>
<body>

<?php
echo "Nom = ".$V_Nom."<BR>";
echo "Prenom = ".$V_Prenom."<BR>";
echo "ID = ".$V_ID."<BR>";
?>

<a href="./essaiform.htm">Retour</a>
</body>
</html>

