You have to modify php/config/library.php accordingly to your parameters


