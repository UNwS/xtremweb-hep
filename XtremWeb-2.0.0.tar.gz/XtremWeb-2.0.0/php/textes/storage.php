<center>
<table bgcolor="#f47a07">
<tr>
<td>
<br>
Any submitted jobs must be removed by its owner (typically, at -successfull <b>and</b> erroneus- completion time).
<br>
Otherwise the server may be unecessary fillfulled.
<br><br>
This server is <b>not</b> a storage server&nbsp;:
<ul>
<li> user can not expect any backup for any server local datas&nbsp;;
<li> the server administrator keeps the right to remove any old datas (typically more than 8 days old).
</ul>
<br>
</td>
</tr>
</table>
</center>

